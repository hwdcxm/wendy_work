#if !defined(AFX_WNDBGN_H__EA9B2517_AD0C_11D3_AF16_00A0CC23E698__INCLUDED_)
#define AFX_WNDBGN_H__EA9B2517_AD0C_11D3_AF16_00A0CC23E698__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// wndBgn.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CwndBgn window

#define	MACRO_MsgUpdateCtrls		2000

#define	MACRO_BtnItemCodeID		600
#define	MACRO_BtnOptMonthID		601
#define	MACRO_EdtCashID			602
#define	MACRO_EdtFuturesID		603
#define	MACRO_HeaderID			604
#define	MACRO_List1ID			605

#define	MACRO_EdtVHSIID			620

#define	MACRO_BtnHighPriceID		606
#define	MACRO_BtnColumnWidthID		607
#define	MACRO_Btn_IV_ID				608
#define	MACRO_Btn_ExportCSV_ID		609
#define MACRO_Btn_Simple_ID			610
#define MACRO_Btn_Stra_ID			611



class CTTOptions ;
class CwndBgn : public CWnd
{
// Construction
public:
	CwndBgn();

// Attributes
public:
	CTTOptions* m_pOwner ;
	static CString m_strMyClass;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CwndBgn)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CwndBgn();

	// Generated message map functions
protected:
	//{{AFX_MSG(CwndBgn)
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	afx_msg LRESULT OnUpdateCtrls(WPARAM, LPARAM);
	afx_msg void OnSelectItemCode() ;
	afx_msg void OnSelectMonth() ;
	afx_msg void OnSelectHighPrice() ;
	afx_msg void OnSelectColumnWidth() ;
	afx_msg void OnSelectIVMode() ;
	afx_msg void OnSelectSimple() ;
	afx_msg void OnSelectExportCSV() ;
	afx_msg void OnSelectStrategy() ;
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WNDBGN_H__EA9B2517_AD0C_11D3_AF16_00A0CC23E698__INCLUDED_)
