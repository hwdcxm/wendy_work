#if !defined(AFX_BTNWITHTIP_H__F7F51706_BCD6_11D3_AF2A_00A0CC23E698__INCLUDED_)
#define AFX_BTNWITHTIP_H__F7F51706_BCD6_11D3_AF2A_00A0CC23E698__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// btnWithTip.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CbtnWithTip window
class CTTOptions ;
class CbtnWithTip : public CButton
{
// Construction
public:
	CbtnWithTip();

// Attributes
public:
	CToolTipCtrl*	m_pToolTipCtrl1 ;
	CTTOptions* m_TTOptions;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CbtnWithTip)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CbtnWithTip();

	// Generated message map functions
protected:
	//{{AFX_MSG(CbtnWithTip)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnDestroy();
	afx_msg void OnMenuStgy();
	afx_msg void OnMenuPain();
	afx_msg void OnMenuNormal();
	afx_msg void OnMenuIV();
	afx_msg void OnMenuPB();
	afx_msg void OnMenuGK();
	afx_msg void OnMenuOI();
	afx_msg void OnMenuMG();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BTNWITHTIP_H__F7F51706_BCD6_11D3_AF2A_00A0CC23E698__INCLUDED_)
