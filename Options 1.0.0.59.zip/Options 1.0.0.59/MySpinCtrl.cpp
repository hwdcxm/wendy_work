// MySpinCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "MySpinCtrl.h"
#include "Strategy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMySpinCtrl

CMySpinCtrl::CMySpinCtrl()
{
	m_pStgy = NULL;
}

CMySpinCtrl::~CMySpinCtrl()
{
}


BEGIN_MESSAGE_MAP(CMySpinCtrl, CSpinButtonCtrl)
	//{{AFX_MSG_MAP(CMySpinCtrl)
	ON_NOTIFY_REFLECT(UDN_DELTAPOS, OnDeltapos)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMySpinCtrl message handlers

void CMySpinCtrl::OnDeltapos(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	
	if( m_pStgy->m_nIndex==STGY_CUSTOM && this!=m_pStgy->m_pSpin_C )
	{
		for( int i=0;i<3;i++ )
		{
			m_pStgy->m_bResetBF[i] = TRUE;	
		}
	}

	if( this==m_pStgy->m_pSpin_C )
	{
		if(pNMUpDown->iDelta<0)  
		{
			if( m_pStgy->m_fStock_C>=1.998 )  //2.0
				return;
			else
				m_pStgy->m_fStock_C += 0.1;

			m_pStgy->SufPaint();
		}
		else if(pNMUpDown->iDelta>0)
		{
			if( m_pStgy->m_fStock_C<=1.001 ) //1.0
				return;
			else
				m_pStgy->m_fStock_C -= 0.1;

			m_pStgy->SufPaint();
		}

		*pResult = 0;
		return;
	}

	CString str;
	int itemp,iValue;
	if( this==m_pStgy->m_pSpin && m_pStgy->m_nIndex!=STGY_CUSTOM )
	{
		int nRow = m_pStgy->m_nRow;
		int iInt1=0,iInt2=0,iInt3=0,iInt4=0;
		switch( nRow )
		{
		case 1:
			str = m_pStgy->m_list.GetItemText(2,2);
			iInt1 = atoi(str)/m_pStgy->m_nOrderCount;
			break;
		case 2:
			str = m_pStgy->m_list.GetItemText(2,2);
			iInt1 = atoi(str)/m_pStgy->m_nOrderCount;
			str = m_pStgy->m_list.GetItemText(3,2);
			iInt2 = atoi(str)/m_pStgy->m_nOrderCount;
			break;
		case 3:
			str = m_pStgy->m_list.GetItemText(2,2);
			iInt1 = atoi(str)/m_pStgy->m_nOrderCount;
			str = m_pStgy->m_list.GetItemText(3,2);
			iInt2 = atoi(str)/m_pStgy->m_nOrderCount;
			str = m_pStgy->m_list.GetItemText(4,2);
			iInt3 = atoi(str)/m_pStgy->m_nOrderCount;
			break;
		case 4:
			str = m_pStgy->m_list.GetItemText(2,2);
			iInt1 = atoi(str)/m_pStgy->m_nOrderCount;
			str = m_pStgy->m_list.GetItemText(3,2);
			iInt2 = atoi(str)/m_pStgy->m_nOrderCount;
			str = m_pStgy->m_list.GetItemText(4,2);
			iInt3 = atoi(str)/m_pStgy->m_nOrderCount;
			str = m_pStgy->m_list.GetItemText(5,2);
			iInt4 = atoi(str)/m_pStgy->m_nOrderCount;
			break;
		}
		
		if(pNMUpDown->iDelta<0)                    
		{
			m_pStgy->m_nOrderCount++;
			m_pStgy->m_nRetn = m_pStgy->PrePaint();
			if( m_pStgy->m_nRetn==1 )
			{
				m_pStgy->DrawIncomeLine();
			}
		}
		else if(pNMUpDown->iDelta>0)
		{
			if( m_pStgy->m_nOrderCount==1 )
			{
				*pResult = 0;
				return;
			}
			m_pStgy->m_nOrderCount--;
			m_pStgy->m_nRetn = m_pStgy->PrePaint();
			if( m_pStgy->m_nRetn==1 )
			{
				m_pStgy->DrawIncomeLine();
			}
		}
		
		switch( nRow )
		{
		case 1:
			str.Format("%d", iInt1*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(2,2,str);
			break;
		case 2:
			str.Format("%d", iInt1*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(2,2,str);
			str.Format("%d", iInt2*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(3,2,str);
			break;
		case 3:
			str.Format("%d", iInt1*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(2,2,str);
			str.Format("%d", iInt2*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(3,2,str);
			str.Format("%d", iInt3*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(4,2,str);
			break;
		case 4:
			str.Format("%d", iInt1*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(2,2,str);
			str.Format("%d", iInt2*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(3,2,str);
			str.Format("%d", iInt3*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(4,2,str);
			str.Format("%d", iInt4*m_pStgy->m_nOrderCount);
			m_pStgy->m_list.SetItemText(5,2,str);
			break;
		}
	}
	else if( this==m_pStgy->m_pSpin && m_pStgy->m_nIndex==STGY_CUSTOM )
	{
		if( m_pStgy->m_nCustomIx[0]==6 )
		{
			*pResult = 0;
			return;
		}

		if(pNMUpDown->iDelta<0)                    
		{
			iValue = m_pStgy->m_nCustomCount[0];
			if( m_pStgy->m_nCustomIx[0]==0 || m_pStgy->m_nCustomIx[0]==2 || m_pStgy->m_nCustomIx[0]==4 )
				itemp = -1;
			else
				itemp = 1;
			iValue = abs(iValue)+1;
			m_pStgy->m_nCustomCount[0] = itemp*iValue;
			m_pStgy->m_nRetn = m_pStgy->PrePaint();
			if( m_pStgy->m_nRetn==1 )
			{
				m_pStgy->DrawIncomeLine();
			}
		}
		else if(pNMUpDown->iDelta>0)
		{
			iValue = m_pStgy->m_nCustomCount[0];
			if( abs(iValue)==1 )
			{
				*pResult = 0;
				return;
			}
			if( m_pStgy->m_nCustomIx[0]==0 || m_pStgy->m_nCustomIx[0]==2 || m_pStgy->m_nCustomIx[0]==4 )
				itemp = -1;
			else
				itemp = 1;
			iValue = abs(iValue)-1;
			m_pStgy->m_nCustomCount[0] = itemp*iValue;
			m_pStgy->m_nRetn = m_pStgy->PrePaint();
			if( m_pStgy->m_nRetn==1 )
			{
				m_pStgy->DrawIncomeLine();
			}
		}

		str.Format("%d", m_pStgy->m_nCustomCount[0]);
		m_pStgy->m_list.SetItemText(2,2,str);
	}
	else
	{
		for( int i=1;i<6;i++ )
		{
			if( this==m_pStgy->m_pSpinEx[i-1] )
			{
				if( m_pStgy->m_nCustomIx[i]==6 )
				{
					*pResult = 0;
					return;
				}

				if(pNMUpDown->iDelta<0)                    
				{
					iValue = m_pStgy->m_nCustomCount[i];
					if( m_pStgy->m_nCustomIx[i]==0 || m_pStgy->m_nCustomIx[i]==2 || m_pStgy->m_nCustomIx[i]==4 )
						itemp = -1;
					else
						itemp = 1;
					iValue = abs(iValue)+1;
					m_pStgy->m_nCustomCount[i] = itemp*iValue;
					m_pStgy->m_nRetn = m_pStgy->PrePaint();
					if( m_pStgy->m_nRetn==1 )
					{
						m_pStgy->DrawIncomeLine();
					}
				}
				else if(pNMUpDown->iDelta>0)
				{
					iValue = m_pStgy->m_nCustomCount[i];
					if( abs(iValue)==1 )
					{
						*pResult = 0;
						return;
					}
					if( m_pStgy->m_nCustomIx[i]==0 || m_pStgy->m_nCustomIx[i]==2 || m_pStgy->m_nCustomIx[i]==4 )
						itemp = -1;
					else
						itemp = 1;
					iValue = abs(iValue)-1;
					m_pStgy->m_nCustomCount[i] = itemp*iValue;
					m_pStgy->m_nRetn = m_pStgy->PrePaint();
					if( m_pStgy->m_nRetn==1 )
					{
						m_pStgy->DrawIncomeLine();
					}
				}
				
				str.Format("%d", m_pStgy->m_nCustomCount[i]);
				m_pStgy->m_list.SetItemText(i+2,2,str);
			}
		}
	}

	*pResult = 0;
}
