// listctrl785.cpp : implementation file
//

#include "stdafx.h"
#include "listctrlOptions.h"
#include "TTOptions.h"
#include "btnWithTip.h"
#include "Strategy.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


UINT ColorThread(LPVOID  lParam);



ItemOptionsText::ItemOptionsText()
{
	ReInit() ;
	
}

void ItemOptionsText::ReInit()
{
	memset( this, 0, sizeof(*this) ) ;
	
}

ItemOptionsTextColor::ItemOptionsTextColor()
{
	ReInit() ;
	
}

void ItemOptionsTextColor::ReInit()
{
	memset( this, 0, sizeof(*this) ) ;
	
}

/////////////////////////////////////////////////////////////////////////////
// ClistctrlOptions
ClistctrlOptions::ClistctrlOptions()
{
	memset(m_buf,0,sizeof(ItemOptionsText)*MACRO_MaxItems);
	memset(m_buf_simple,0,sizeof(ItemOptionsText)*MACRO_SmpItems);

	m_Max_Min_Flag = 0;
	m_Head.m_plist = this;
	
	m_nTotal = 0 ;
	m_nTotal_simple = 0;
	m_pOwner = NULL ;
	m_nStart = -1;
	m_nEnd = -1;
	m_iNum = -1;
	m_iNumST = -1;
	
	m_bShowHighPrice = 1;
	m_nColorMode = _COLORMODE_BK_WHITE;
	
	m_bStopColorThread = FALSE;
	m_bStoppedColorThread = FALSE;
	
	m_iColumnMode = 2;//�п�����ʾ����ͷ������
	m_bIVMode = 0;  
	m_bSimpleMode = 0;
	
	DWORD dwThreadID;
	m_hColorThread = CreateThread( NULL,
		0,
		(LPTHREAD_START_ROUTINE)ColorThread,
		(LPVOID)this,
		0,
		&dwThreadID);
}

ClistctrlOptions::~ClistctrlOptions()
{
	m_bStopColorThread = TRUE;
}

void ClistctrlOptions::SetItemsTotal( int nTotal, BYTE* pDirtyBuf ) 
{
	if( m_nTotal != nTotal )
	{
		m_nTotal = nTotal ;
		if( m_hWnd!=NULL )
			PostMessage( MACRO_MsgSetItemsTotal, m_nTotal, 0);
	}
	
	for( int i=0;i<nTotal;i++ )
	{
		if( pDirtyBuf[i]==1 )
		{
			if( m_hWnd!=NULL )
				PostMessage( MACRO_MsgRedrawItem, i, 0xffffffff ) ;
		}
		
	}//end for.
	
}

BEGIN_MESSAGE_MAP(ClistctrlOptions, CListCtrl)
//{{AFX_MSG_MAP(ClistctrlOptions)
ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnCustomDraw)
ON_NOTIFY_REFLECT(LVN_GETDISPINFO, OnGetdispinfo)
ON_WM_ERASEBKGND()
ON_WM_HSCROLL()
ON_NOTIFY(HDN_BEGINTRACK, 0, OnTrack )	// begin track.  
ON_WM_DESTROY()
ON_WM_KEYDOWN()
ON_WM_CREATE()
ON_NOTIFY(HDN_ENDTRACK, 0, OnTrack )	// ENDTRACK.	 
ON_NOTIFY(HDN_TRACK, 0, OnTrack )		// TRACK.		 
ON_NOTIFY(NM_RELEASEDCAPTURE , 0, OnTrack )		// TRACK.		 
ON_NOTIFY(HDN_BEGINTRACKW, 0, OnTrack )	// begin track.  0xBA
ON_NOTIFY(HDN_ENDTRACKW, 0, OnTrack )	// ENDTRACK.	 0xB9.	
ON_NOTIFY(HDN_TRACKW, 0, OnTrack )	// TRACK.			 0xB8
ON_WM_DRAWITEM()
ON_WM_MEASUREITEM()
ON_WM_SYSCOMMAND()
//}}AFX_MSG_MAP
ON_MESSAGE( MACRO_MsgRedrawItem, OnMyRedrawItem ) 
ON_MESSAGE( MACRO_MsgSetItemsTotal, OnMySetItemsTotal ) 
ON_WM_MEASUREITEM_REFLECT()
ON_MESSAGE(WM_SETFONT,   OnSetFont)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ClistctrlOptions message handlers

void ClistctrlOptions::OnHScroll( UINT nSBCode, UINT nPos, CScrollBar* pScrollBar )
{
	CListCtrl::OnHScroll( nSBCode, nPos, pScrollBar ) ;
	if( m_pOwner!=NULL )
		m_pOwner->OnLstHScr() ;
}

LRESULT ClistctrlOptions::OnMyRedrawItem( WPARAM item, LPARAM subitem )  //������� �����ػ�item �ź�
{
	CString asd;
	asd.Format("%d,%d",item,subitem);
//	OutputDebugString(asd);
	if( item == 0xFFFFFFFE) // if item = -2, redraw whole list control �ػ�����list control
	{
		Invalidate(FALSE);
	}
	if( item==0xffffffff )  // item<0, mean redraw items[0,subitem]    �ػ�items[0,subitem] 
	{
		RedrawItems( 0, subitem );
	}
	else
		if( subitem==0xffffffff )  // subItem<0, mean Update item's all subitem.  �ػ�items[subitem,subitem] 
		{
			RedrawItems( item, item );		
		}
		else
		{
			if( subitem>=0 && subitem<MACRO_MaxSubItems )
			{
				int refrectsubitem = subitem ;
				if( refrectsubitem>=0 )
				{
					CRect rect ;
					if( GetSubItemRect( item, refrectsubitem, LVIR_LABEL, rect )==TRUE )
					{	
						rect.left++ ;          
						rect.right-- ;
						rect.top++ ;
						rect.bottom-- ;   
						InvalidateRect( rect, FALSE );  // only update subitem, no need clear bgn.
					}
				}
				
			}
			
		}
		return 0;
}

LRESULT ClistctrlOptions::OnMySetItemsTotal( WPARAM itemstotal, LPARAM )  
{
	//	ATLTRACE("OnMySetItemsTotal \r\n");
	SetItemCountEx( itemstotal ) ;
	if( itemstotal == 0 )
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_ERASE) ;
	
	return 0;
}


void ClistctrlOptions::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)   //�����ػ�ʱListCtrl�������� 
{
	LPNMLVCUSTOMDRAW lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;
	
	COLORREF color;
	int item = lplvcd->nmcd.dwItemSpec;
	int subitem = lplvcd->iSubItem;
	int iTempItem;
	iTempItem = m_TTOptions->m_nDivision;
	if( m_bSimpleMode==1 )
		iTempItem = iTempItem-m_nStart+1;
	if( m_TTOptions->m_bCash )
	{
		if( m_bSimpleMode==0 )
			iTempItem = m_TTOptions->m_nDataTotal;
		else
			iTempItem = MACRO_SmpItems;
	}

    switch(lplvcd->nmcd.dwDrawStage)
	{
	case CDDS_PREPAINT:
		// Request prepaint notifications for each item.
		*pResult = CDRF_NOTIFYITEMDRAW;
		break;
		
	case CDDS_ITEMPREPAINT: // Requested notification
		/*if (_COLORMODE_BK_WHITE==m_nColorMode) 
		{
			switch(lplvcd->nmcd.dwItemSpec % 5)
			{
			case 0:
			case 2:
				//lplvcd->clrText = RGB(255, 0, 0);
				//lplvcd->clrText = GetTextColor(lplvcd->nmcd.dwItemSpec,lplvcd->iSubItem);
				lplvcd->clrTextBk = RGB( 0xff,0xff,0xff);								
				break;
			case 1:
			case 3:
				//lplvcd->clrText = RGB(255, 255, 255);
				//lplvcd->clrText = GetTextColor(lplvcd->nmcd.dwItemSpec,lplvcd->iSubItem);
				lplvcd->clrTextBk = RGB( 0xf0,0xf0,0xf0);				
				break;
			case 4:
				lplvcd->clrTextBk = RGB( 0xa0,0xe0,0xe0);
				break;
			}
			*pResult = CDRF_DODEFAULT;
		}
		else*/
			*pResult = CDRF_NOTIFYSUBITEMDRAW;
		break;
	case CDDS_ITEMPREPAINT | CDDS_SUBITEM:
		{
			if (_COLORMODE_BK_WHITE==m_nColorMode) 
			{
				if( m_bIVMode == 0 || m_bIVMode == 1 )
				{
					if( subitem >= 0 && subitem <= 9  )
					{
						if( item<iTempItem )
							color = RGB( 190,190,190);
						else
							color = RGB(0xff,0xff,0xff);
					}
					else if( subitem==10 )
					{
						color = RGB(0xa0,0xe0,0xe0);
					}
					else if( subitem >= 11 && subitem <=20 )
					{
						if( item<iTempItem )
							color = RGB(0xff,0xff,0xff);
						else
							color = RGB( 190,190,190);
					}
				}
				else if( m_bIVMode == 2 )
				{
					if( subitem >= 0 && subitem <= 6 )
					{
						if( item<iTempItem )
							color = RGB( 190,190,190);
						else
							color = RGB(0xff,0xff,0xff);
					}
					else if( subitem==7 )
					{
						color = RGB(0xa0,0xe0,0xe0);
					}
					else if( subitem >= 8 && subitem <=14 )
					{
						if( item<iTempItem )
							color = RGB(0xff,0xff,0xff);
						else
							color = RGB( 190,190,190);
					}
					else if( subitem>=15 )
					{
						color = RGB(255,255,255);
					}
				}	
				lplvcd->clrTextBk = color;
			}
			else if( m_nColorMode==1 )
			{
				if( m_bIVMode == 0 || m_bIVMode == 1 )
				{
					if( subitem >= 0 && subitem <= 9  )
					{
						if( item<iTempItem )
							color = RGB( 0, 0, 0 );
						else
							color = RGB( 45,45,45);
					}
					else if( subitem==10 )
					{
						color = RGB(0xa0,0xe0,0xe0);
					}
					else if( subitem >= 11 && subitem <=20 )
					{
						if( item<iTempItem )
							color = RGB( 45,45,45);
						else
							color = RGB( 0, 0, 0 );
					}
				}
				else if( m_bIVMode == 2 )
				{
					if( subitem >= 0 && subitem <= 6 )
					{
						if( item<iTempItem )
							color = RGB( 0, 0, 0 );
						else
							color = RGB( 45,45,45);
					}
					else if( subitem==7 )
					{
						color = RGB(0xa0,0xe0,0xe0);
					}
					else if( subitem >= 8 && subitem <=14 )
					{
						if( item<iTempItem )
							color = RGB( 45,45,45);
						else
							color = RGB( 0, 0, 0 );
					}
					else if( subitem>=15 )
					{
						color = RGB(0,0,0);
					}
				}
				lplvcd->clrTextBk = color;
			}
			else if( m_nColorMode==2 )
			{
				if( m_bIVMode == 0 || m_bIVMode == 1 )
				{
					
					if( subitem >= 0 && subitem <= 9 )
					{
						if( item<iTempItem )
							color = RGB(222,184,87);
						else
							color = RGB(255,236,139);
					}
					else if( subitem==10 )
					{
						color = RGB(191,239,255);
					}
					else if( subitem >= 11 && subitem <=20 )
					{
						if( item<iTempItem )
							color = RGB(255,236,139); 
						else
							color = RGB(222,184,87);
					}
				}
				else if( m_bIVMode == 2 )
				{
					if( subitem >= 0 && subitem <= 6 )
					{
						if( item<iTempItem )
							color = RGB(222,184,87); 
						else
							color = RGB(255,236,139);
					}
					else if( subitem==7 )
					{
						color = RGB(191,239,255);;
					}
					else if( subitem >= 8 && subitem <=14 )
					{
						if( item<iTempItem )
							color = RGB(255,236,139); 
						else
							color = RGB(222,184,87);
					}
					else if( subitem>=15 )
					{
						color = RGB(255,255,255);
					}
				}
				lplvcd->clrTextBk = color;
			}
			
			*pResult = CDRF_DODEFAULT;
		}
		break;
	}


}

#define TT_BT_FZOOMIN		1 //��С����
#define TT_BT_FZOOMOUT		2 //��������


void ClistctrlOptions::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)  //�ػ溯��
{
	////////////��ֹ����Optionʱ�����ִ�������еĴ��󣨵�һ��ǰ�ֶ�һ�пհ��У�  2014.12.19  Keeping////////////////////
	if( m_Max_Min_Flag == 0 )
	{
		m_Max_Min_Flag++;//ȷ������Ĵ���ֻ����һ��
		m_pOwner->Zoom(TT_BT_FZOOMOUT);
		m_pOwner->Zoom(TT_BT_FZOOMIN);
	}
	////////////////////////////////////////

	LPDRAWITEMSTRUCT lpDIS = lpDrawItemStruct;
	int nItem=lpDIS->itemID; //��Ҫ�ػ����ֵ
	if(nItem == -1)		
		return ;

	CRect rcCol = lpDIS->rcItem;
	int iTempItem;
	int iCallUp[2],iPutUp[2],iCallDw[2],iPutDw[2],iCallMax[2],iPutMax[2];
	for(int i=0;i<2;i++)
	{
		iCallUp[i] = m_TTOptions->m_iCallOIUpRow[i];
		iPutUp[i] = m_TTOptions->m_iPutOIUpRow[i];
		iCallDw[i] = m_TTOptions->m_iCallOIDwRow[i];
		iPutDw[i] = m_TTOptions->m_iPutOIDwRow[i];
		iCallMax[i] = m_TTOptions->m_iCallMaxRow[i];
		iPutMax[i] = m_TTOptions->m_iPutMaxRow[i];
	}
	iTempItem = m_TTOptions->m_nDivision;
	if( m_bSimpleMode==1 )
	{
		iTempItem = iTempItem-m_nStart+1;
		for(i=0;i<2;i++)
		{
			iCallUp[i] = iCallUp[i]-m_nStart+1;
			iPutUp[i] = iPutUp[i]-m_nStart+1;
			iCallDw[i] = iCallDw[i]-m_nStart+1;
			iPutDw[i] = iPutDw[i]-m_nStart+1;
			iCallMax[i] = iCallMax[i]-m_nStart+1;
			iPutMax[i] = iPutMax[i]-m_nStart+1;
		}
	}
	if( m_TTOptions->m_bCash )
	{
		if( m_bSimpleMode==0 )
			iTempItem = m_TTOptions->m_nDataTotal;
		else
			iTempItem = MACRO_SmpItems;
	}

	CString sText;	
	CDC* pDC=CDC::FromHandle(lpDIS->hDC);	
	int nOldDCMode=pDC->SaveDC();	
	LVITEM item;
	item.iItem = nItem;
	item.iSubItem = 0;	
	item.mask = LVIF_IMAGE|LVIF_STATE;	
	item.stateMask = 0XFFFF;	//-1
	GetItem(&item);	
	BOOL bSelected = item.state&LVIS_SELECTED;	
	COLORREF color=::GetSysColor(COLOR_WINDOW);
	
	//static BOOL m_Flag = FALSE;  //�����־����   FALSE:��ʾ�ڵ�ʱ
	
	
	int nColorWode = m_nColorMode;  //0:��ɫ   1:��ɫ    2:��ɫ
	
	
	if( nColorWode == 0 )  //��ɫ
	{
		
		//ListView_SetExtendedListViewStyle(this->m_hWnd, this->GetStyle() | LVS_EX_GRIDLINES); //��ʾ������
		ListView_SetExtendedListViewStyle(this->m_hWnd, this->GetStyle() & ~LVS_EX_GRIDLINES);//����ʾ������
		
		
		//������ɫ
		/*switch(nItem % 5)
		{
		case 0:
		case 2:
			color = RGB( 0xff,0xff,0xff); 
			break;
		case 1:
		case 3:
			color = RGB( 0xf0,0xf0,0xf0);
			break;
		case 4:
			color = RGB( 0xa0,0xe0,0xe0);
			break;
		}*/	
		
		
		LV_COLUMN lvc;
		lvc.mask=LVCF_FMT|LVCF_WIDTH;
		rcCol.right = rcCol.left ; 
		for(int nCol=0; GetColumn(nCol,&lvc); nCol++)
		{	
			rcCol.left = rcCol.right; 
			rcCol.right = rcCol.left + GetColumnWidth(nCol);
			
			//������ɫ
			COLORREF crText = GetTextColor(nItem,nCol);
			pDC->SetTextColor(crText);
			
			if( m_bIVMode!=2 )
			{
				if( nCol >= 0 && nCol <= 9  )
				{
					if( nItem<iTempItem )
						color = RGB( 190,190,190);
					else
						color = RGB(0xff,0xff,0xff);
				}
				else if( nCol==10 )
				{
					color = RGB(0xa0,0xe0,0xe0);
				}
				else if( nCol >= 11 && nCol <=20 )
				{
					if( nItem<iTempItem )
						color = RGB(0xff,0xff,0xff);
					else
						color = RGB( 190,190,190);
				}

				if( nCol==0 )
				{
					if(nItem==iCallUp[0]&&iCallUp[0]>0)
						color = RGB(255,0,0);
					else if(nItem==iCallUp[1]&&iCallUp[1]>0)
						color = RGB(255,0,0);
					
					if(nItem==iCallDw[0]&&iCallDw[0]>0)
						color = RGB(0,192,0);
					else if(nItem==iCallDw[1]&&iCallDw[1]>0)
						color = RGB(0,192,0);

					if(nItem==iCallMax[0]&&iCallMax[0]>0)
					{
						color = RGB(255,0,255);
						if(iCallMax[0]==iCallUp[0]||iCallMax[0]==iCallUp[1]||iCallMax[0]==iCallDw[0]||iCallMax[0]==iCallDw[1])
							color = RGB(0,255,255);
					}
					else if(nItem==iCallMax[1]&&iCallMax[1]>0)
					{
						color = RGB(255,0,255);
						if(iCallMax[1]==iCallUp[0]||iCallMax[1]==iCallUp[1]||iCallMax[1]==iCallDw[0]||iCallMax[1]==iCallDw[1])
							color = RGB(0,255,255);
					}
				}
				if( nCol==20 )
				{
					if(nItem==iPutUp[0]&&iPutUp[0]>0)
						color = RGB(255,0,0);
					else if(nItem==iPutUp[1]&&iPutUp[1]>0)
						color = RGB(255,0,0);
					
					if(nItem==iPutDw[0]&&iPutDw[0]>0)
						color = RGB(0,192,0);
					else if(nItem==iPutDw[1]&&iPutDw[1]>0)
						color = RGB(0,192,0);

					if(nItem==iPutMax[0]&&iPutMax[0]>0)
					{
						color = RGB(255,0,255);
						if(iPutMax[0]==iPutUp[0]||iPutMax[0]==iPutUp[1]||iPutMax[0]==iPutDw[0]||iPutMax[0]==iPutDw[1])
							color = RGB(0,255,255);
					}
					else if(nItem==iPutMax[1]&&iPutMax[1]>0)
					{
						color = RGB(255,0,255);
						if(iPutMax[1]==iPutUp[0]||iPutMax[1]==iPutUp[1]||iPutMax[1]==iPutDw[0]||iPutMax[1]==iPutDw[1])
							color = RGB(0,255,255);
					}
				}
			}
			else if( m_bIVMode == 2 )
			{
				if( nCol >= 0 && nCol <= 6 )
				{
					if( nItem<iTempItem )
						color = RGB( 190,190,190);
					else
						color = RGB(0xff,0xff,0xff);
				}
				else if( nCol==7 )
				{
					color = RGB(0xa0,0xe0,0xe0);
				}
				else if( nCol >= 8 && nCol <=14 )
				{
					if( nItem<iTempItem )
						color = RGB(0xff,0xff,0xff);
					else
						color = RGB( 190,190,190);
				}
				else if( nCol>=15 )
				{
					color = RGB(255,255,255);
				}
			}

			if(bSelected )
			{	
				pDC->SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
				pDC->SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));	
				color=::GetSysColor(COLOR_HIGHLIGHT);	
			}	
			else
			{		
				pDC->SetBkColor(color);	
			}
			
			HPEN hOldPen = (HPEN)::SelectObject(lpDIS->hDC, ::CreatePen(PS_SOLID, 1,RGB(0xe5,0xe5,0xe5)));//RGB(0xc0,0xc0,0xc0)));	
			HBRUSH hOldBrush = (HBRUSH)::SelectObject(lpDIS->hDC, ::CreateSolidBrush(color));	
				
			::Rectangle(lpDIS->hDC, rcCol.left-1, rcCol.top-1, rcCol.right, rcCol.bottom);
			::DeleteObject(SelectObject(lpDIS->hDC, hOldBrush));		
			::DeleteObject(SelectObject(lpDIS->hDC, hOldPen));		
			//		sText=MakeShortString(pDC,GetItemText(nItem,nCol),rcCol.Width());	
			//		sText = GetItemText(nItem,nCol);
			
			if(m_bIVMode==0 || m_bIVMode==4 || m_bIVMode==5)
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemText( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemText( m_buf_simple+nItem, nCol ) ;
			}
			else if( m_bIVMode==1 ||m_bIVMode==3 )
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemTextIV( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemTextIV( m_buf_simple+nItem, nCol ) ;
			}
			else if( m_bIVMode==2 )
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemTextPB( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemTextPB( m_buf_simple+nItem, nCol ) ;
			}
			
			if(m_bShowHighPrice == 0 && m_bIVMode == 0)
			{
				if(nCol==1 || nCol==2 || nCol==18 || nCol==19) //high,low
					sText = "  ";
			}
			pDC->DrawText(sText, -1, CRect::CRect(rcCol.left+3,rcCol.top,rcCol.right,rcCol.bottom-2), DT_RIGHT);	
		}	
	}
	else if( nColorWode == 1 ) //��ɫ
	{
		//������ɫ
		//color = RGB( 0, 0, 0 );
		//if( nItem%5 == 4 )
		//	color = RGB( 0x2e,0x2e,0x2e);	
		
		LV_COLUMN lvc;
		lvc.mask=LVCF_FMT|LVCF_WIDTH;
		rcCol.right = rcCol.left ; 
		for(int nCol=0; GetColumn(nCol,&lvc); nCol++)
		{	
			rcCol.left = rcCol.right ; 
			rcCol.right = rcCol.left + GetColumnWidth(nCol);		
			
			//������ɫ
			COLORREF crText = GetTextColor(nItem,nCol);
			pDC->SetTextColor(crText);	
			
			if( m_bIVMode!=2 )
			{
				if( nCol >= 0 && nCol <= 9  )
				{
					if( nItem<iTempItem )
						color = RGB( 45,45,45);
					else
						color = RGB( 0,0,0);
				}
				else if( nCol==10 )
				{
					color = RGB(0xa0,0xe0,0xe0);
				}
				else if( nCol >= 11 && nCol <=20 )
				{
					if( nItem<iTempItem )
						color = RGB( 0,0,0);
					else
						color = RGB( 45,45,45);
				}

				if( nCol==0 )
				{//��ɫģʽ��������µ�����ɫҪ����
					if(nItem==iCallUp[0]&&iCallUp[0]>0)
					{
						color = RGB(255,0,0);
						pDC->SetTextColor(RGB(0,0,0));
					}
					else if(nItem==iCallUp[1]&&iCallUp[1]>0)
					{
						color = RGB(255,0,0);
						pDC->SetTextColor(RGB(0,0,0));
					}
					
					if(nItem==iCallDw[0]&&iCallDw[0]>0)
					{
						color = RGB(0,192,0);
						pDC->SetTextColor(RGB(0,0,0));
					}
					else if(nItem==iCallDw[1]&&iCallDw[1]>0)
					{
						color = RGB(0,192,0);
						pDC->SetTextColor(RGB(0,0,0));
					}

					if(nItem==iCallMax[0]&&iCallMax[0]>0)
					{
						color = RGB(255,0,255);
						if(iCallMax[0]==iCallUp[0]||iCallMax[0]==iCallUp[1]||iCallMax[0]==iCallDw[0]||iCallMax[0]==iCallDw[1])
							color = RGB(0,255,255);
						pDC->SetTextColor(RGB(0,0,0));
					}
					else if(nItem==iCallMax[1]&&iCallMax[1]>0)
					{
						color = RGB(255,0,255);
						if(iCallMax[1]==iCallUp[0]||iCallMax[1]==iCallUp[1]||iCallMax[1]==iCallDw[0]||iCallMax[1]==iCallDw[1])
							color = RGB(0,255,255);
						pDC->SetTextColor(RGB(0,0,0));
					}
				}
				if( nCol==20 )
				{
					if(nItem==iPutUp[0]&&iPutUp[0]>0)
					{
						color = RGB(255,0,0);
						pDC->SetTextColor(RGB(0,0,0));
					}
					else if(nItem==iPutUp[1]&&iPutUp[1]>0)
					{
						color = RGB(255,0,0);
						pDC->SetTextColor(RGB(0,0,0));
					}
					
					if(nItem==iPutDw[0]&&iPutDw[0]>0)
					{
						color = RGB(0,192,0);
						pDC->SetTextColor(RGB(0,0,0));
					}
					else if(nItem==iPutDw[1]&&iPutDw[1]>0)
					{
						color = RGB(0,192,0);
						pDC->SetTextColor(RGB(0,0,0));
					}

					if(nItem==iPutMax[0]&&iPutMax[0]>0)
					{
						color = RGB(255,0,255);
						if(iPutMax[0]==iPutUp[0]||iPutMax[0]==iPutUp[1]||iPutMax[0]==iPutDw[0]||iPutMax[0]==iPutDw[1])
							color = RGB(0,255,255);
						pDC->SetTextColor(RGB(0,0,0));
					}
					else if(nItem==iPutMax[1]&&iPutMax[1]>0)
					{
						color = RGB(255,0,255);
						if(iPutMax[1]==iPutUp[0]||iPutMax[1]==iPutUp[1]||iPutMax[1]==iPutDw[0]||iPutMax[1]==iPutDw[1])
							color = RGB(0,255,255);
						pDC->SetTextColor(RGB(0,0,0));
					}
				}
			}
			else if( m_bIVMode == 2 )
			{
				if( nCol >= 0 && nCol <= 6 )
				{
					if( nItem<iTempItem )
						color = RGB( 45,45,45);
					else
						color = RGB( 0,0,0);
				}
				else if( nCol==7 )
				{
					color = RGB(0xa0,0xe0,0xe0);
				}
				else if( nCol >= 8 && nCol <=14 )
				{
					if( nItem<iTempItem )
						color = RGB( 0,0,0);
					else
						color = RGB( 45,45,45);
				}
				else if( nCol>=15 )
				{
					color = RGB(0,0,0);
				}	
			}
			
			if(bSelected )
			{	
				pDC->SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
				pDC->SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
				//pDC->SetTextColor(RGB(255,255,255));
				color=::GetSysColor(COLOR_HIGHLIGHT);	
			}	
			else
			{		
				pDC->SetBkColor(color);	
			}
			
			HPEN hOldPen = (HPEN)::SelectObject(lpDIS->hDC, ::CreatePen(PS_SOLID, 1, RGB(0x44,0x44,0x44)));	//RGB(0x77,0x77,0x77));			
			HBRUSH hOldBrush = (HBRUSH)::SelectObject(lpDIS->hDC, ::CreateSolidBrush(color));	
			::Rectangle(lpDIS->hDC, rcCol.left-1, rcCol.top-1, rcCol.right, rcCol.bottom);	
			::DeleteObject(SelectObject(lpDIS->hDC, hOldBrush));		
			::DeleteObject(SelectObject(lpDIS->hDC, hOldPen));		
			//		sText=MakeShortString(pDC,GetItemText(nItem,nCol),rcCol.Width());	
			//		sText = GetItemText(nItem,nCol);
			
			if(m_bIVMode==0||m_bIVMode==4||m_bIVMode==5)
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemText( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemText( m_buf_simple+nItem, nCol ) ;
			}
			else if( m_bIVMode==1||m_bIVMode==3 )
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemTextIV( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemTextIV( m_buf_simple+nItem, nCol ) ;
			}
			else if( m_bIVMode==2 )
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemTextPB( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemTextPB( m_buf_simple+nItem, nCol ) ;
			}
			
			if(m_bShowHighPrice == 0 && m_bIVMode == 0)
			{
				if(nCol==1 || nCol==2 || nCol==18 || nCol==19) //high,low
					sText = "  ";
			}
			pDC->DrawText(sText, -1, CRect::CRect(rcCol.left+3,rcCol.top,rcCol.right,rcCol.bottom-2), DT_RIGHT);
			
			ListView_SetExtendedListViewStyle(this->m_hWnd, this->GetStyle() & ~LVS_EX_GRIDLINES);//����ʾ������
			//	ListView_SetExtendedListViewStyle(this->m_hWnd, this->GetStyle() | LVS_EX_GRIDLINES); //��ʾ������
		}	
	}
	else if( nColorWode == 2 ) //��ɫ
	{
		
	//	ListView_SetExtendedListViewStyle(this->m_hWnd, this->GetStyle() | LVS_EX_GRIDLINES); //��ʾ������
		ListView_SetExtendedListViewStyle(this->m_hWnd, this->GetStyle() & ~LVS_EX_GRIDLINES);//����ʾ������
		
		
		LV_COLUMN lvc;
		lvc.mask=LVCF_FMT|LVCF_WIDTH;
		rcCol.right = rcCol.left; 
		for(int nCol=0; GetColumn(nCol,&lvc); nCol++)
		{	
			rcCol.left = rcCol.right; 
			rcCol.right = rcCol.left + GetColumnWidth(nCol);		
			
			//������ɫ
			COLORREF crText = GetTextColor(nItem,nCol);
			pDC->SetTextColor(crText);	
			
			if( m_bIVMode!=2 )
			{
				if( nCol >= 0 && nCol <= 9 )
				{
					if( nItem<iTempItem )
						color = RGB(222,184,87);
					else
						color = RGB(255,236,139);
				}
				else if( nCol==10 )
				{
					color = RGB(191,239,255);
				}
				else if( nCol >= 11 && nCol <=20 )
				{
					if( nItem<iTempItem )
						color = RGB(255,236,139); 
					else
						color = RGB(222,184,87);
				}

				if( nCol==0 )
				{
					if(nItem==iCallUp[0]&&iCallUp[0]>0)
						color = RGB(255,0,0);
					else if(nItem==iCallUp[1]&&iCallUp[1]>0)
						color = RGB(255,0,0);
					
					if(nItem==iCallDw[0]&&iCallDw[0]>0)
						color = RGB(0,192,0);
					else if(nItem==iCallDw[1]&&iCallDw[1]>0)
						color = RGB(0,192,0);

					if(nItem==iCallMax[0]&&iCallMax[0]>0)
					{
						color = RGB(255,0,255);
						if(iCallMax[0]==iCallUp[0]||iCallMax[0]==iCallUp[1]||iCallMax[0]==iCallDw[0]||iCallMax[0]==iCallDw[1])
							color = RGB(0,255,255);
					}
					else if(nItem==iCallMax[1]&&iCallMax[1]>0)
					{
						color = RGB(255,0,255);
						if(iCallMax[1]==iCallUp[0]||iCallMax[1]==iCallUp[1]||iCallMax[1]==iCallDw[0]||iCallMax[1]==iCallDw[1])
							color = RGB(0,255,255);
					}
				}
				if( nCol==20 )
				{
					if(nItem==iPutUp[0]&&iPutUp[0]>0)
						color = RGB(255,0,0);
					else if(nItem==iPutUp[1]&&iPutUp[1]>0)
						color = RGB(255,0,0);
					
					if(nItem==iPutDw[0]&&iPutDw[0]>0)
						color = RGB(0,192,0);
					else if(nItem==iPutDw[1]&&iPutDw[1]>0)
						color = RGB(0,192,0);

					if(nItem==iPutMax[0]&&iPutMax[0]>0)
					{
						color = RGB(255,0,255);
						if(iPutMax[0]==iPutUp[0]||iPutMax[0]==iPutUp[1]||iPutMax[0]==iPutDw[0]||iPutMax[0]==iPutDw[1])
							color = RGB(0,255,255);
					}
					else if(nItem==iPutMax[1]&&iPutMax[1]>0)
					{
						color = RGB(255,0,255);
						if(iPutMax[1]==iPutUp[0]||iPutMax[1]==iPutUp[1]||iPutMax[1]==iPutDw[0]||iPutMax[1]==iPutDw[1])
							color = RGB(0,255,255);
					}
				}
			}
			else if( m_bIVMode == 2 )
			{
				if( nCol >= 0 && nCol <= 6 )
				{
					if( nItem<iTempItem )
						color = RGB(222,184,87); 
					else
						color = RGB(255,236,139);
				}
				else if( nCol==7 )
				{
					color = RGB(191,239,255);;
				}
				else if( nCol >= 8 && nCol <=14 )
				{
					if( nItem<iTempItem )
						color = RGB(255,236,139); 
					else
						color = RGB(222,184,87);
				}
				else if( nCol>=15 )
				{
					color = RGB(255,255,255);
				}
			}
			
			//if( nItem%5 == 4 )
			//	color = RGB( 0xa0,0xe0,0xe0);
			if(bSelected ) //���ѡ�е���
			{	
				pDC->SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
				pDC->SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));	
				color=::GetSysColor(COLOR_HIGHLIGHT);	
			}
			else //���ûѡ�е���
			{		
				pDC->SetBkColor(color); //���ֵı���ɫ
				//pDC->SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));		
			}
			
			HPEN hOldPen = (HPEN)::SelectObject(lpDIS->hDC, ::CreatePen(PS_SOLID, 1,RGB(0xd8,0xd0,0xd0)));			
			HBRUSH hOldBrush = (HBRUSH)::SelectObject(lpDIS->hDC, ::CreateSolidBrush(color));	
			::Rectangle(lpDIS->hDC, rcCol.left-1, rcCol.top-1 , rcCol.right , rcCol.bottom );
		
			::DeleteObject(SelectObject(lpDIS->hDC, hOldBrush));		
			::DeleteObject(SelectObject(lpDIS->hDC, hOldPen));		
			//		sText=MakeShortString(pDC,GetItemText(nItem,nCol),rcCol.Width());	
			//		sText = GetItemText(nItem,nCol);
			if(m_bIVMode==0||m_bIVMode==4||m_bIVMode==5)
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemText( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemText( m_buf_simple+nItem, nCol ) ;
			}
			else if( m_bIVMode==1||m_bIVMode==3 )
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemTextIV( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemTextIV( m_buf_simple+nItem, nCol ) ;
			}
			else if( m_bIVMode==2 )
			{
				if( m_bSimpleMode==0 )
					sText = GetReflectItemTextPB( m_buf+nItem, nCol ) ;
				else
					sText = GetReflectItemTextPB( m_buf_simple+nItem, nCol ) ;
			}
			
			if(m_bShowHighPrice == 0 && m_bIVMode == 0)
			{
				if(nCol==1 || nCol==2 || nCol==18 || nCol==19) //high,low
					sText = "  ";
			}
			pDC->DrawText(sText, -1, CRect::CRect(rcCol.left+3,rcCol.top,rcCol.right,rcCol.bottom-2), DT_RIGHT);	
		}
	}
	
	pDC->RestoreDC(nOldDCMode);	
	
}

char* ClistctrlOptions::GetReflectItemTextPB( ItemOptionsText* pObj, int nSubItem ) //��ȡPBģʽ��ͷ�ı�
{
	switch(nSubItem)	
	{
	case 0:
		return GetReflectItemText(pObj,21);
		break;
	case 1:
		return GetReflectItemText(pObj,22);
		break;
	case 2:
		return GetReflectItemText(pObj,101);
		break;
	case 3:
		return GetReflectItemText(pObj,102);
		break;
	case 4:
		return GetReflectItemText(pObj,103);
		break;
	case 5:
		return GetReflectItemText(pObj,104);
		break;
	case 6:
		return GetReflectItemText(pObj,105);
		break;
	case 7:
		return GetReflectItemText(pObj,10);
		break;
	case 8:
		return GetReflectItemText(pObj,115);
		break;
	case 9:
		return GetReflectItemText(pObj,116);
		break;
	case 10:
		return GetReflectItemText(pObj,117);
		break;
	case 11:
		return GetReflectItemText(pObj,118);
		break;
	case 12:
		return GetReflectItemText(pObj,119);
		break;
	case 13:
		return GetReflectItemText(pObj,23);
		break;
	case 14:
		return GetReflectItemText(pObj,24);
		break;
	}
	
}


char* ClistctrlOptions::GetReflectItemTextIV( ItemOptionsText* pObj, int nSubItem ) //��ȡIVģʽ��ͷ�ı�
{
	switch(nSubItem)	
	{
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 7:
	case 8:
	case 12:
	case 13:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
		return GetReflectItemText(pObj,nSubItem+100);
		break;
	case 0:  //Call��δƽ
		return GetReflectItemText(pObj,0);
		break;
	/*case 5:  //Call�ĳɽ���
		return GetReflectItemText(pObj,5);         //ben 2017.07.18  �ɼ۸ĳɳɼ�IV   5��15ȥ��
		break;*/
	case 6:  //Call������
		return GetReflectItemText(pObj,6);
		break;
	case 9:  //Call������
		return GetReflectItemText(pObj,9);
		break;
	case 10:  //��ʹ��
		return GetReflectItemText(pObj,10);
		break;
	case 11:  //puts������
		return GetReflectItemText(pObj,11);
		break;
	case 14:  //puts������
		return GetReflectItemText(pObj,14);
		break;
	/*case 15:  //puts�ĳɼ�
		return GetReflectItemText(pObj,15);
		break;*/
	case 20:  //puts��δƽ
		return GetReflectItemText(pObj,20);
		break;
		//	default:
		//		return GetReflectItemText(pObj,nSubItem);
	}
	
}

char* ClistctrlOptions::GetReflectItemText( ItemOptionsText* pObj, int nSubItem )   //��ȡ����ģʽ ��ͷ�ı�
{
	//	ASSERT( pObj!=NULL && nSubItem>=0 && nSubItem<MACRO_MaxSubItems ) ;
	int nReflectItem = nSubItem ; 
	char* pRet = NULL ;
	
	switch(nReflectItem)
	{
	case 0: //fill in main text	
		pRet = pObj->m_szCalls_OI ;  //δƽ
		break;
	case 1: //fill in sub item 1 text
		if( m_bIVMode==5 )
			pRet = pObj->m_szCalls_Margin;
		else
			pRet = pObj->m_szCalls_High ;  //���        
		break;
	case 2: 
		pRet = pObj->m_szCalls_Low ;   //���
		break;
	case 3: 
		pRet = pObj->m_szCalls_Vol ;  //����
		break;
	case 4: 
		pRet = pObj->m_szCalls_NominalQty ;  //����          
		break;
	case 5:
		pRet = pObj->m_szCalls_Nominal ;  //�ɼ�         
		break;
	case 6: 
		pRet = pObj->m_szCalls_BidQty ;   //����
		break;
	case 7: 
		pRet = pObj->m_szCalls_Bid ;   //����      
		break;
	case 8: 
		pRet = pObj->m_szCalls_Ask ;   //����  
		break;
	case 9: 
		pRet = pObj->m_szCalls_AskQty ;  //����
		break;
	case 10: 
		pRet = pObj->m_szStrike ;
		break;
	case 11: 
		pRet = pObj->m_szPuts_BidQty ;  //����        
		break;
	case 12: 
		pRet = pObj->m_szPuts_Bid ;    //����    
		break;
	case 13: 
		pRet = pObj->m_szPuts_Ask ;   //����      
		break;
	case 14: 
		pRet = pObj->m_szPuts_AskQty ;  //����        
		break;
	case 15: //lawrence modify 
		pRet = pObj->m_szPuts_Nominal ;   //�ɼ�
		break;
	case 16: //lawrence modify 
		pRet = pObj->m_szPuts_NominalQty ;   //���� 
		break;
	case 17:
		pRet = pObj->m_szPuts_Vol ;   //����           
		break;
	case 18:
		pRet = pObj->m_szPuts_High ;  //���
		break;
	case 19:
		if( m_bIVMode==5 )
			pRet = pObj->m_szPuts_Margin;
		else
			pRet = pObj->m_szPuts_Low ;   //���
		break;
	case 20:
		pRet = pObj->m_szPuts_OI ;   //δƽ
		break;
	case 21:
		pRet = pObj->m_szCalls_Margin;
		break;
	case 22:
		pRet = pObj->m_szCalls_ITM;
		break;
	case 23:
		pRet = pObj->m_szPuts_ITM;
		break;
	case 24:
		pRet = pObj->m_szPuts_Margin;
		break;
		//˵��: �������ֻ������ȡ��ʾ���ݵ��ڴ��ַ,�ڸ�ֵ	
	case 1 + 100: //Vega
		pRet = pObj->m_szCalls_Vega ;
		break;
	case 2 + 100: //Theta
		pRet = pObj->m_szCalls_Theta ;
		break;
	case 3 + 100: //Gamma
		pRet = pObj->m_szCalls_Gamma;
		break;
	case 4 + 100: //Delta
		pRet = pObj->m_szCalls_Delta ;
		break;
	case 5 + 100: //�ɼ�IV
		pRet = pObj->m_szCalls_Nominal_IV ;
		break;
	case 7 + 100: 
		pRet = pObj->m_szCalls_Bid_IV;  //Bid + (IV)   
		break;
	case 8 + 100: 
		pRet = pObj->m_szCalls_Ask_IV ; //Ask + (IV)
		break;	
	case 12 + 100: 
		pRet = pObj->m_szPuts_Bid_IV ;
		break;
	case 13 + 100: 
		pRet = pObj->m_szPuts_Ask_IV ;
		break;
	case 15 + 100: //�ɼ�IV
		pRet = pObj->m_szPuts_Nominal_IV ;
		break;
	case 16 + 100: //Delta
		pRet =  pObj->m_szPuts_Delta ; 
		break;
	case 17 + 100: //Gamma
		pRet =  pObj->m_szPuts_Gamma ; 
		break;
	case 18 + 100: //Theta
		pRet =  pObj->m_szPuts_Theta;
		break;
	case 19 + 100: //Vaga
		pRet =  pObj->m_szPuts_Vega;
		break;
	default:
		break;			
	}//end switch.
	
	
	 /*
	 
	   if(m_bIVMode == 0 )
	   {		
	   switch(nReflectItem)
	   {
	   case 0: //fill in main text
	   pRet = pObj->m_szCalls_OI ;
	   break;
	   case 1: //fill in sub item 1 text
	   pRet = pObj->m_szCalls_Vol ;
	   break;
	   case 2: 
	   pRet = pObj->m_szCalls_High ;
	   break;
	   case 3: 
	   pRet = pObj->m_szCalls_Low ;
	   break;
	   case 4: 
	   pRet = pObj->m_szCalls_Nominal ;
	   break;
	   case 5:
	   pRet = pObj->m_szCalls_NominalQty ;
	   break;
	   case 6: 
	   pRet = pObj->m_szCalls_BidQty ;
	   break;
	   case 7: 
	   pRet = pObj->m_szCalls_Bid ;
	   break;
	   case 8: 
	   pRet = pObj->m_szCalls_Ask ;
	   break;
	   case 9: 
	   pRet = pObj->m_szCalls_AskQty ;
	   break;
	   case 10: 
	   pRet = pObj->m_szStrike ;
	   break;
	   case 11: 
	   pRet = pObj->m_szPuts_BidQty ;
	   break;
	   case 12: 
	   pRet = pObj->m_szPuts_Bid ;
	   break;
	   case 13: 
	   pRet = pObj->m_szPuts_Ask ;
	   break;
	   case 14: 
	   pRet = pObj->m_szPuts_AskQty ;
	   break;
	   case 15: //lawrence modify 
	   pRet = pObj->m_szPuts_Nominal ;
	   break;
	   case 16: //lawrence modify 
	   pRet = pObj->m_szPuts_NominalQty ;
	   break;
	   case 17:
	   pRet = pObj->m_szPuts_High ;
	   break;
	   case 18:
	   pRet = pObj->m_szPuts_Low ;
	   break;
	   case 19:
	   pRet = pObj->m_szPuts_Vol ;
	   break;
	   case 20:
	   pRet = pObj->m_szPuts_OI ;
	   break;
	   default:
	   break;
	   
		 }//end switch.
		 }
		 else  //IV ģʽ
		 {
		 char szTemp[50];
		 switch(nReflectItem)
		 {
		 case 0: //OI
		 pRet = pObj->m_szCalls_OI ;
		 break;
		 case 1: //Vega
		 pRet = pObj->m_szCalls_Vega ;
		 break;
		 case 2: //Theta
		 pRet = pObj->m_szCalls_Theta ;
		 break;
		 case 3: //Gamma
		 pRet = pObj->m_szCalls_Gamma;
		 break;
		 case 4: //Delta
		 pRet = pObj->m_szCalls_Delta ;
		 break;
		 case 5: //
		 pRet = pObj->m_szCalls_Nominal ;
		 break;
		 case 6: 
		 pRet = pObj->m_szCalls_BidQty ;
		 break;
		 case 7: 
		 pRet = pObj->m_szCalls_Bid_IV;  //Bid + (IV)   
		 break;
		 case 8: 
		 pRet = pObj->m_szCalls_Ask_IV ; //Ask + (IV)
		 break;
		 case 9: 
		 pRet = pObj->m_szCalls_AskQty ;
		 break;
		 case 10: 
		 pRet = pObj->m_szStrike ;
		 break;
		 case 11: 
		 pRet = pObj->m_szPuts_BidQty ;
		 break;
		 case 12: 
		 pRet = pObj->m_szPuts_Bid_IV ;
		 break;
		 case 13: 
		 pRet = pObj->m_szPuts_Ask_IV ;
		 break;
		 case 14: 
		 pRet = pObj->m_szPuts_AskQty ;
		 break;
		 case 15: 
		 pRet = pObj->m_szPuts_Nominal ;
		 break;
		 case 16: //Delta
		 pRet =  pObj->m_szPuts_Delta ; 
		 break;
		 case 17: //Gamma
		 pRet =  pObj->m_szPuts_Gamma ; 
		 break;
		 case 18: //Theta
		 pRet =  pObj->m_szPuts_Theta;
		 break;
		 case 19: //Vaga
		 pRet =  pObj->m_szPuts_Vega;
		 break;
		 case 20:
		 pRet = pObj->m_szPuts_OI ;
		 break;
		 default:
		 break;			
		 }//end switch.
		 
		   }
*/	return pRet ;
}

BYTE  ClistctrlOptions::CheckColumnWidth( int nItem, int nSubItem,char* pNew,char* pOld)  //����еĿ��ȣ�������
{
	if(strlen(pNew) > strlen(pOld)) //���������ݳ��ȱ�ԭ�ȵ����ݳ�
	{
		int iLen = GetStringWidth( pNew ) + 5;
		int iLenOld = GetColumnWidth(nSubItem); //ȡ�еĿ���
		if(iLen > iLenOld) //�����ݿ��ȴ����еĿ���
		{
			SetColumnWidth(nItem,iLen); //�������ݳ�������Ϊ�п�
		}
	}	
	
	return 0;
}

BYTE ClistctrlOptions::AdjustColumnWidth()  //����ģʽ�µ����п�
{   //����2���Զ��л�ģʽ
	if(m_iColumnMode == 0)
	{
		m_iColumnMode = 2;
	}
	else
	{	
		m_iColumnMode = 0;
	}
	m_iColumnMode = 0;
	SetColsMinWidth();
	RecalcColumnWidth(m_iColumnMode);  //�����п�
	
	return 0;
}

BYTE ClistctrlOptions::AdjustColumnWidthIVMode()  //Ivģ�µ����п�
{   
	if(m_iColumnMode == 0)
	{
		m_iColumnMode = 2;//����������ʾ��header����
	}
	else
	{	
		m_iColumnMode = 0;//�����������п�
	}
	m_iColumnMode = 0;
	SetColsMinWidthIVMode();
	RecalcColumnWidthIVMode(m_iColumnMode);//�����п�
	
	return 0;
}

BYTE ClistctrlOptions::AdjustColumnWidthPBMode()  //���ʷ�������п�
{   
	if(m_iColumnMode == 0)
	{
		m_iColumnMode = 2;//����������ʾ��header����
	}
	else
	{	
		m_iColumnMode = 0;//�����������п�
	}
	m_iColumnMode = 0;
	SetColsMinWidthPBMode();
	RecalcColumnWidthPBMode(m_iColumnMode);//�����п�
	
	return 0;
}


BYTE ClistctrlOptions::RecalcColumnWidth(int iMode)
{//���¼������е��п�
	//iMode 0: ȫ�����������ʵ��п� 1:ֻ����ʾ���µ��мӿ� 2:���������Կ���header������
	if(iMode == 2)
	{
		SetRedraw( FALSE );
		for( short i=0;i<MACRO_MaxSubItems;i++ )
		{
			SetColumnWidth( i, m_nColDefWidth[i]) ;
			
			//��ΪHigh Low��ȫ����
			if((m_bShowHighPrice == 0) &&
				(i==1 || i==2 || i==18 || i==19)) //high,low			
			{				
				SetColumnWidth(i,0);  	//���ø��п���Ϊ0		
			}
		}
		
		if( m_pOwner!=NULL )
		{
			m_pOwner->ResizeHeaderCtrl() ;
		}
		
		
		
		Invalidate(FALSE);	 //ȫ���ػ�,�������һ��(��������)���ֿհ�.
		SetRedraw( TRUE );
		return 0;
	}
	
	SetRedraw( FALSE );
	
	int iLen;
	int iLenOld; 
	char* p;
	char* plong;
	for(int nSubItem=0;nSubItem<MACRO_MaxSubItems;nSubItem++)
	{
		iLen = m_nColDefWidth[nSubItem];
		
	/*	if((m_bShowHighPrice == 0) &&
			(nSubItem==1 || nSubItem==2 || nSubItem==18 || nSubItem==19)) //high,low			
		{				
			iLen = GetStringWidth("  ") + 5;	
			iLenOld = GetColumnWidth(nSubItem);
			if(iLen > iLenOld)
			{
				SetColumnWidth(nSubItem,iLen);  
			}		
		}
		else*/	int nTotal = m_nTotal;
		if( m_bSimpleMode==1 )
			nTotal = m_nTotal_simple;
			for(int nItem=0;nItem<nTotal;nItem++)
			{
				if( m_bSimpleMode==0 )
					p=GetReflectItemText( m_buf+nItem,nSubItem) ;
				else
					p=GetReflectItemText( m_buf_simple+nItem,nSubItem) ;
				
				if(GetStringWidth(p)>iLen)
				{
					iLen = GetStringWidth(p);//��¼���ͷ�ĳ���
					plong = p;  //��¼���ͷ
				}
			}
		
		if( iLen!=0 )
			iLen = iLen + 10; //���ͷ�Ŀ���
		if(iMode == 0) //���������ʿ���
		{
			SetColumnWidth(nSubItem,iLen);  
		}
		
		if(iMode == 1) //��ʾ���µ�������
		{	
			
			iLenOld = GetColumnWidth(nSubItem);
			
			if(iLen > iLenOld)
			{
				SetColumnWidth(nSubItem,iLen);  
			}
			
		}
		
		//��ΪHigh Low��ȫ����
		if((m_bShowHighPrice==0&&m_bIVMode==0) &&
			(nSubItem==1 || nSubItem==2 || nSubItem==18 || nSubItem==19)) //high,low			
		{				
			SetColumnWidth(nSubItem,0);  			
		}

		if((m_bIVMode==4 ) &&
			(nSubItem==1 || nSubItem==2 || nSubItem==18 || nSubItem==19)) //high,low			
		{				
			SetColumnWidth(nSubItem,0);  			
		}

		if((m_bIVMode==5 ) &&
			(nSubItem==2 || nSubItem==18)) //high,low			
		{				
			SetColumnWidth(nSubItem,0);  			
		}
	}
	
	if( m_pOwner!=NULL )
	{
		m_pOwner->ResizeHeaderCtrl();//���¼����ⲿ��ͷ�Ŀ���
	}
	
	
	Invalidate(FALSE);	 //ȫ���ػ�,�������һ��(��������)���ֿհ�.
	SetRedraw(TRUE);
	return 0;
}

BYTE ClistctrlOptions::RecalcColumnWidthIVMode(int iMode)
{//���¼������е��п�
	//iMode 0: ȫ�����������ʵ��п� 1:ֻ����ʾ���µ��мӿ� 2:���������Կ���header������

	if(iMode == 2)
	{
		SetRedraw( FALSE );  //����ػ���־
		for( short i=0;i<MACRO_MaxSubItems;i++ )
		{
			SetColumnWidth( i, m_nColDefWidth[i]) ;
		}
		
		if( m_pOwner!=NULL )
		{
			m_pOwner->ResizeHeaderCtrl() ;
		}
		
		
		SetRedraw( TRUE );  //�����ػ���־�����»���
		Invalidate(FALSE);	 //ȫ���ػ�,�������һ��(��������)���ֿհ�.
		return 0;
	}
	
	SetRedraw( FALSE );
	
	int iLen;
	int iLenOld; 
	char* p;
	char* plong;
	char cc[50];
	int nTempSubItem = 0;
	for(int nSubItem=0;nSubItem<MACRO_MaxSubItems;nSubItem++)
	{
		iLen = m_nColDefWidth[nSubItem];
		//Andy 2012.03.08����ԭ���е�����,m_nTotal=0��ʱ��,plong��û��ֵ��,GetStringWidth(plong)���������
     //   if(m_nTotal == 0)
	//		break;
		
		int nTotal = m_nTotal;
		if( m_bSimpleMode==1 )
			nTotal = m_nTotal_simple;			
			for(int nItem=0;nItem<nTotal;nItem++)
			{
				if(nSubItem>0&&nSubItem<6)
					nTempSubItem = nSubItem+100;
				else if(nSubItem==7||nSubItem==8)
					nTempSubItem = nSubItem+100;
				else if(nSubItem==12||nSubItem==13)
					nTempSubItem = nSubItem+100;
				else if(nSubItem>14&&nSubItem<20)
					nTempSubItem = nSubItem+100;
				else
					nTempSubItem = nSubItem;
				if( m_bSimpleMode==0 )
					p=GetReflectItemText( m_buf+nItem,nTempSubItem) ;
				else
					p=GetReflectItemText( m_buf_simple+nItem,nTempSubItem) ;
				
				if(GetStringWidth(p)>iLen)
				{
					iLen = GetStringWidth(p);//��¼���ͷ�ĳ���
					plong = p;  //��¼���ͷ
				}
			}
		
		//	if(m_nTotal == 0)	iLen =  5;
		//	break;
		if( iLen!=0 )
			iLen = iLen + 10;
		if(iMode == 0)
		{
			SetColumnWidth(nSubItem,iLen);
		}
		
		if(iMode == 1)
		{		
			
			iLenOld = GetColumnWidth(nSubItem);
			
			if(iLen > iLenOld)
			{
				SetColumnWidth(nSubItem,iLen);  
			}
		}

		if((m_bIVMode==3 ) &&
			(nSubItem==0 || nSubItem==20)) 			
		{				
			SetColumnWidth(nSubItem,0);  			
		}
		
	}
	
	if( m_pOwner!=NULL )
	{
		m_pOwner->ResizeHeaderCtrl() ;
	}
	
	
	
	SetRedraw(TRUE);
	Invalidate(FALSE);	 //ȫ���ػ�,�������һ��(��������)���ֿհ�.
	return 0;
}

BYTE ClistctrlOptions::RecalcColumnWidthPBMode(int iMode)
{//���¼������е��п�
	//iMode 0: ȫ�����������ʵ��п� 1:ֻ����ʾ���µ��мӿ� 2:���������Կ���header������

	if(iMode == 2)
	{
		SetRedraw( FALSE );  //����ػ���־
		for( short i=0;i<MACRO_PBMaxSubItems;i++ )
		{
			SetColumnWidth( i, m_nColDefWidth[i]) ;
		}
		
		if( m_pOwner!=NULL )
		{
			m_pOwner->ResizeHeaderCtrl() ;
		}
		
		
		SetRedraw( TRUE );  //�����ػ���־�����»���
		Invalidate(FALSE);	 //ȫ���ػ�,�������һ��(��������)���ֿհ�.
		return 0;
	}
	
	SetRedraw( FALSE );
	
	int iLen;
	int iLenOld; 
	char* p;
	char* plong;
	int nTemp = 0;
	for(int nSubItem=0;nSubItem<MACRO_MaxSubItems;nSubItem++)
	{
		iLen = m_nColDefWidth[nSubItem];
		if( nSubItem>MACRO_PBMaxSubItems-1 )
		{
			SetColumnWidth(nSubItem,0);
			continue;
		}
		
		int nTotal = m_nTotal;
		if( m_bSimpleMode==1 )
			nTotal = m_nTotal_simple;		
				for(int nItem=0;nItem<nTotal;nItem++)
				{
					switch(nSubItem)
					{
					case 0:
						nTemp = 21;
						break;
					case 1:
						nTemp = 22;
						break;
					case 13:
						nTemp = 23;
						break;
					case 14:
						nTemp = 24;
						break;
					case 7:
						nTemp = 10;
						break;
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
						nTemp = nSubItem-1 +100;
						break;
					case 8:
					case 9:
					case 10:
					case 11:
					case 12:
						nTemp = nSubItem+7 +100;
						break;
					}
					if( m_bSimpleMode==0 )
						p=GetReflectItemText( m_buf+nItem,nTemp) ;
					else
						p=GetReflectItemText( m_buf_simple+nItem,nTemp) ;
					
					if(GetStringWidth(p)>iLen)
					{
						iLen = GetStringWidth(p);//��¼���ͷ�ĳ���
						plong = p;  //��¼���ͷ
					}
				}
			
		
		
		iLen = iLen + 10; //���ͷ�Ŀ���
		if(iMode == 0) //���������ʿ���
		{
			SetColumnWidth(nSubItem,iLen);  
		}
		
		if(iMode == 1) //��ʾ���µ�������
		{	
			
			iLenOld = GetColumnWidth(nSubItem);
			
			if(iLen > iLenOld)
			{
				SetColumnWidth(nSubItem,iLen);  
			}
			
		}
		
		
	}
	
	if( m_pOwner!=NULL )
	{
		m_pOwner->ResizeHeaderCtrl();//���¼����ⲿ��ͷ�Ŀ���
	}
	
	
	Invalidate(FALSE);	 //ȫ���ػ�,�������һ��(��������)���ֿհ�.
	SetRedraw(TRUE);
	return 0;
	
}

void ClistctrlOptions::SetColsOriginWidthValue(int i,int iWidth)  //�����еĳ�ʼ���ȣ�������ٸ�ԭ����ʼ״̬
{
	m_nColDefWidth[i] = iWidth;	
}

void ClistctrlOptions::SetColsMinWidth()  //����ÿ����С����
{
	CString szDefaults1[MACRO_MaxSubItems] = {
		"δƽ(����)",	
			"���",	//Vol
			"���",	//High
			"����",	
			"����",	
			"�ɼ�",	
			"����",	
			"����",	
			"����",	
			"����",	
			
			"��ʹ��",	
			
			"����",	
			"����",	
			"����",	
			"����",	
			"�ɼ�",	
			"����",	
			"����",	
			"���",	
			"���",	
			"δƽ(����)"
			
	};

	CString szDefaults2[MACRO_MaxSubItems] = {
		"δƽ(����)",	
			"",	//Vol
			"",	//High
			"����",	
			"����",	
			"�ɼ�",	
			"����",	
			"����",	
			"����",	
			"����",	
			
			"��ʹ��",	
			
			"����",	
			"����",	
			"����",	
			"����",	
			"�ɼ�",	
			"����",	
			"����",	
			"",	
			"",	
			"δƽ(����)"
			
	};

	CString szDefaults3[MACRO_MaxSubItems] = {
		"δƽ(����)",	
			"����()",	
			"",	
			"����",	
			"����",	
			"�ɼ�",	
			"����",	
			"����",	
			"����",	
			"����",	
			
			"��ʹ��",	
			
			"����",	
			"����",	
			"����",	
			"����",	
			"�ɼ�",	
			"����",	
			"����",	
			"",	
			"����()",	
			"δƽ(����)"
			
	};

	
	//	int iLen;
	memset(m_nColDefWidth,0,MACRO_MaxSubItems);
	for(int i =0; i< MACRO_MaxSubItems ; i++)
	{
	//	if(i==1 || i==2 || i==18 || i==19) //high,low
	//		m_nColDefWidth[i] = GetStringWidth( szDefaults[i] ) + 6 ;
	//	else
		if( m_bIVMode==0 )
			m_nColDefWidth[i] = GetStringWidth( szDefaults1[i] );
		else if( m_bIVMode==4 )
			m_nColDefWidth[i] = GetStringWidth( szDefaults2[i] );
		else if( m_bIVMode==5 )
			m_nColDefWidth[i] = GetStringWidth( szDefaults3[i] );
	}
	
/*	SetRedraw( FALSE );
	for(i =0; i< MACRO_MaxSubItems ; i++)
	{
		int iLen;
		LV_COLUMN column ;
		column.mask = LVCF_WIDTH ;  
		BOOL ret = GetColumn( i, &column ) ;//��ȡ���е�����
		if( ret==FALSE )
			break;
		int width = column.cx ;
		if( width<m_nColDefWidth[i] )
		{
			//SetColumnWidth( i, m_nColDefWidth[i] ) ;
			iLen = m_nColDefWidth[i]  ;
		}
		else
			if( width>=m_nColDefWidth[i]  )  //+15 )
			{
				//SetColumnWidth( i, m_nColDefWidth[i]+15 ) ;
				iLen = m_nColDefWidth[i]+15 ;
			}
		
			iLen = m_nColDefWidth[i];
			
			SetColumnWidth( i, iLen) ;
			
	}
	SetRedraw( TRUE );*/
	
}

void ClistctrlOptions::SetColsMinWidthIVMode()  //����IVģʽ����С�п�
{
	CString szDefaults1[MACRO_MaxSubItems] = {
		"δƽ(����)",
			"Vega ",	
			"Theta ",	
			"Gamma ",	
			"Delta ",	
			"�ɼ�(����) ",	
			"����",	
			"����(����) ",	
			"����(����) ",	
			"����",	
			
			"��ʹ��",	
			
			"����",	
			"����(����) ",	
			"����(����) ",	
			"����",	
			"�ɼ�(����) ",	
			"Delta ",	
			"Gamma ",	
			"Theta ",	
			"Vega ",	
			"δƽ(����)"	
			
	};

	CString szDefaults2[MACRO_MaxSubItems] = {
		"",
			"Vega ",	
			"Theta ",	
			"Gamma ",	
			"Delta ",	
			"�ɼ�(����) ",	
			"����",	
			"����(����) ",	
			"����(����) ",	
			"����",	
			
			"��ʹ��",	
			
			"����",	
			"����(����) ",	
			"����(����) ",	
			"����",	
			"�ɼ�(����) ",	
			"Delta ",	
			"Gamma ",	
			"Theta ",	
			"Vega ",	
			""	
			
	};
	
	//	int iLen;
	memset(m_nColDefWidth,0,MACRO_MaxSubItems);
	for(int i =0; i< MACRO_MaxSubItems ; i++)
	{
		if( m_bIVMode==1 )
			m_nColDefWidth[i] = GetStringWidth( szDefaults1[i] );
		else if( m_bIVMode==3 )
			m_nColDefWidth[i] = GetStringWidth( szDefaults2[i] );
	}
	
/*	SetRedraw( FALSE );
	for(i =0; i< MACRO_MaxSubItems ; i++)
	{
		int iLen;
		LV_COLUMN column ;
		column.mask = LVCF_WIDTH ;  
		BOOL ret = GetColumn( i, &column ) ;//��ȡ���е�����
		if( ret==FALSE )
			break;
		int width = column.cx ;
		if( width<m_nColDefWidth[i] )
		{
			//SetColumnWidth( i, m_nColDefWidth[i] ) ;
			iLen = m_nColDefWidth[i]  ;
		}
		else
			if( width>=m_nColDefWidth[i] )   //+15 )
			{
				//SetColumnWidth( i, m_nColDefWidth[i]+15 ) ;
				iLen = m_nColDefWidth[i]+15 ;
			}		
			
			iLen = m_nColDefWidth[i];
			SetColumnWidth( i, iLen) ;
			
	}
	SetRedraw( TRUE );*/
	
}

void ClistctrlOptions::SetColsMinWidthPBMode()  //����PBģʽ����С�п�
{
	//P.touch��ȥ�� ֮�󻻰���
	CString szDefaults[MACRO_PBMaxSubItems] = {
			"����()",
			"Prob.ITM",	//Prob.ITM
			"Vega ",	//Vega
			"Theta ",	//Theta
			"Gamma ",	//Gamma
			"Delta ",	//Delta
			"�ɼ�(����) ",	//Last(IV)
			
			
			"��ʹ��",	//Strike
			
			
			"�ɼ�(����) ",	//Last(IV) 
			"Delta ",	//Delta
			"Gamma ",	//Gamma
			"Theta ",	//TheTa
			"Vega " ,	//Vega
			"Prob.ITM",	//Prob.ITM
			"����()"
	};
	
	//	int iLen;
	memset(m_nColDefWidth,0,MACRO_MaxSubItems);
	for(int i =0; i< MACRO_PBMaxSubItems ; i++)
	{
		
		m_nColDefWidth[i] = GetStringWidth( szDefaults[i] );	
		
	}
	
/*	SetRedraw( FALSE );
	for(i =0; i< MACRO_PBMaxSubItems ; i++)
	{
		int iLen;
		LV_COLUMN column ;
		column.mask = LVCF_WIDTH ;  
		BOOL ret = GetColumn( i, &column ) ;//��ȡ���е�����
		if( ret==FALSE )
			break;
		int width = column.cx ;
		if( width<m_nColDefWidth[i] )
		{
			//SetColumnWidth( i, m_nColDefWidth[i] ) ;
			iLen = m_nColDefWidth[i]  ;
		}
		else
			if( width>=m_nColDefWidth[i] )   //+15 )
			{
				//SetColumnWidth( i, m_nColDefWidth[i]+15 ) ;
				iLen = m_nColDefWidth[i]+15 ;
			}		
			
			iLen = m_nColDefWidth[i];
			SetColumnWidth( i, iLen) ;
			
	}
	SetRedraw( TRUE );*/
	
}

void  ClistctrlOptions::SetReflectItemTextColor( int nItem, int nSubItem,char* pNew,char* pOld)//��̬�ı�������ɫ
{
	//< 0 string1 less than string2 
	//0 string1 identical to string2 
	//> 0 string1 greater than string2 
	
	int iRet = strcmp(pNew,pOld);
	if(iRet < 0)  //��С
	{
		m_Color[nItem].m_iColor[nSubItem] = 2;  //��������Ϊ��ɫ
		m_Color[nItem].m_iTime[nSubItem] = COLOR_CHANGE_TIME;  //���ö�ʱ����3S
	}
	else if(iRet > 0)  //���
	{
		m_Color[nItem].m_iColor[nSubItem] = 1;  //��������Ϊ��ɫ
		m_Color[nItem].m_iTime[nSubItem] = COLOR_CHANGE_TIME;
	}
	
	CheckColumnWidth(nItem,nSubItem,pNew,pOld); //����еĿ��ȣ�������
}

void ClistctrlOptions::OnGetdispinfo(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	LV_ITEM* pObj= &(pDispInfo)->item;
	if (pObj->mask & LVIF_TEXT) //valid text buffer?
	{
		//Item*	pItem = m_pBufParams[pObj->iItem];
		char *pRet = NULL ;
		if( pObj->iItem>=0 && pObj->iItem<MACRO_MaxItems )
		{
			if(m_bIVMode == 0)
				pRet = GetReflectItemText( m_buf+pObj->iItem, pObj->iSubItem ) ;
			else
				pRet = GetReflectItemTextIV( m_buf+pObj->iItem, pObj->iSubItem ) ;
			
			if( pRet!=NULL )
				lstrcpy(pObj->pszText, pRet );						
			
		}//end if( 
		
	}//end if.
	*pResult = 0;
	
}

BOOL ClistctrlOptions::OnEraseBkgnd(CDC* pDC) //����ListCtrl ����
{
	// TODO: Add your message handler code here and/or call default
	//if( m_nTotal<=0 )
	//	return ClistctrlOptions::OnEraseBkgnd(pDC);
	//else
	{
		CRect rect ;
		CRect clientrect ;
		
		GetItemRect( 0, rect, LVIR_BOUNDS ) ; //ȡ��һ���λ��
		GetClientRect( clientrect ) ;//��ȡ�ͻ�����λ��
		HBRUSH hBrushBk;
		
		int nColorMode = m_nColorMode;   //0:��ɫ   1:��ɫ    2:��ɫ
		if (nColorMode==0 || nColorMode == 2 ) //��ɫΪ��ɫ ���� ��ɫʱ��list control ���ð�ˢ
		{
			hBrushBk = (HBRUSH)GetStockObject(WHITE_BRUSH);
		}
		else                                       //��ɫΪ��ɫ ��list control ���ú�ˢ
			hBrushBk = (HBRUSH)GetStockObject(BLACK_BRUSH);
		
		if( rect.left>=clientrect.left ) //�����Ŀ�����������
		{
			CRect temprect(clientrect) ;
			temprect.right = rect.left ;
			::FillRect( pDC->m_hDC, temprect,  hBrushBk) ;
		}
		CRect rectHeader;
		GetHeaderCtrl()->GetClientRect(&rectHeader);//��ñ�ͷ��λ��
		if( rect.top>clientrect.top )//�����Ŀ�����ͷ֮�������
		{
			CRect temprect(clientrect) ;
			temprect.top = rectHeader.bottom;
			temprect.bottom = rect.top ;
			::FillRect( pDC->m_hDC, temprect, hBrushBk) ;		
		}   
		
		GetItemRect( m_nTotal-1, rect, LVIR_BOUNDS ) ; //������һ���λ��
		if( rect.right<clientrect.right )//�����Ŀ�����������
		{
			CRect temprect(clientrect) ;
			temprect.left = rect.right ;
			::FillRect( pDC->m_hDC, temprect, hBrushBk) ;
		}
		if( rect.bottom<=clientrect.bottom )//�����Ŀ���±ߵ�����
		{
			clientrect.top = rect.bottom ;
			::FillRect( pDC->m_hDC, clientrect, hBrushBk) ;
			return TRUE ;
		}
		
		return TRUE ;
	}
	
	
	/*if( m_nTotal<=0 )
	return CListCtrl::OnEraseBkgnd(pDC);
	else
	{
	CRect rect ;
	CRect clientrect ;
	
	  GetItemRect( 0, rect, LVIR_BOUNDS ) ; 
	  GetClientRect( clientrect ) ;
	  //if( rect.left>=clientrect.left )
	  {
	  CRect temprect(clientrect) ;
	  temprect.right = rect.left+3 ;
	  ::FillRect( pDC->m_hDC, temprect, (HBRUSH)GetStockObject(WHITE_BRUSH) ) ;
	  }
	  if( rect.top>clientrect.top )
	  {
	  CRect temprect(clientrect) ;
	  temprect.bottom = rect.top ;
	  ::FillRect( pDC->m_hDC, temprect, (HBRUSH)GetStockObject(WHITE_BRUSH) ) ;
	  }
	  
		GetItemRect( m_nTotal-1, rect, LVIR_BOUNDS ) ; 
		if( rect.right<clientrect.right )
		{
		CRect temprect(clientrect) ;
		temprect.left = rect.right+1 ;
		::FillRect( pDC->m_hDC, temprect, (HBRUSH)GetStockObject(WHITE_BRUSH) ) ;
		}
		if( rect.bottom<=clientrect.bottom )
		{
		clientrect.top = rect.bottom ;
		::FillRect( pDC->m_hDC, clientrect, (HBRUSH)GetStockObject(WHITE_BRUSH) ) ;
		return TRUE ;
		}
		return TRUE ;
}*/
	
}

void ClistctrlOptions::OnTrack(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	// TODO: Add your control notification handler code here
	if( m_pOwner!=NULL )
	{
		m_pOwner->ResizeHeaderCtrl() ;
	}
	
	*pResult = 0;
}



void ClistctrlOptions::SaveLastPage()
{
	CFile f("OPTION.DAT",CFile::modeCreate|CFile::modeWrite|CFile::typeBinary);
	int i=GetItemCount();
	f.Write(&i,sizeof(i));
	f.Write(m_buf,sizeof(m_buf));
	f.Close();
}

void ClistctrlOptions::LoadLastPage()
{
	int i;
	
	TRY
	{
		CFile f("OPTION.DAT",CFile::modeRead|CFile::typeBinary);
		f.Read(&i,sizeof(i));
		if(i>0)
		{
			f.Read(m_buf,sizeof(m_buf));
			SetItemCountEx(i);
		}
		f.Close();
		UpdateWindow();
	}
	CATCH(CFileException, pEx)
	{
	}
	END_CATCH
}

void  ClistctrlOptions::CheckColor()  //���������ɫ
{
	if( m_nTotal<=0 )
		return;
	
	SetRedraw( FALSE );  //��ֹ�ػ�
	BOOL bChange;
	for(int i=0 ;i<m_nTotal;i++)
	{
		bChange = FALSE;	
		for(int j=0; j<21; j++)
		{			
			if(m_bStopColorThread == TRUE)
			{
				//				SetRedraw( TRUE );
				return;
			}
			if(m_Color[i].m_iTime[j] > 0)
			{
				m_Color[i].m_iTime[j] --;
				if(m_Color[i].m_iTime[j] == 0) //�ָ���ɫ
				{
					bChange = TRUE;
					m_Color[i].m_iColor[j] = 0;		
					//RedrawItems(i,i);
					int item = i;
					int subitem = j;
					if( subitem>=0 && subitem<MACRO_MaxSubItems )
					{
						int refrectsubitem = subitem ;
						if( refrectsubitem>=0 )
						{
							CRect rect ;
							if( GetSubItemRect( item, refrectsubitem, LVIR_LABEL, rect )==TRUE )
							{	
								rect.left++ ;
								rect.right-- ;
								rect.top++ ;
								rect.bottom-- ;
								InvalidateRect( rect, FALSE );  // only update subitem, no need clear bgn.
							}
						}						
					}
				}
			}
			
			//			if(bChange == TRUE)  //DrawItem��ˢ��һ������Ҳ��ˢ������,�����ж���һ��֮��һ��ˢ��
			//			{
			//				RedrawItems(i,i);
			//			}
		}
	}
	SetRedraw( TRUE );  //�����ػ�
	
}

COLORREF ClistctrlOptions::GetTextColor( int nItem, int nSubItem)  //��ȡ item ������ɫ
{
	COLORREF cr;
	
	//0 - ��ɫ 1 - ��,��ɫ 2 - ��,��ɫ
	
	switch(m_Color[nItem].m_iColor[nSubItem]) 
	{
	case 1:
		cr = RGB(255, 0, 0);
		break;
	case 2:
		cr = RGB(0, 192, 0);
		break;
	default:
		{
			if( m_nColorMode == 0 || m_nColorMode == 2 )  //�����ɫ��ɫ  �� ��ɫ
				cr = RGB(0, 0, 0);
			else
			{
				if( m_bIVMode == 0 || m_bIVMode==4 || m_bIVMode==5 )//����ģʽ��
				{
					switch( nSubItem )
					{
					case 0:
					case 1:
					case 2:
					case 18:
					case 19:
					case 20:
						cr = RGB(168,168,168); //��ɫ
						break;
					case 3:
					case 4:
					case 16:
					case 17:
						cr = RGB( 239,85,231);//��ɫ
						break;
					case 5:
					case 6:
					case 7:
					case 13:
					case 14:
					case 15:
						cr = RGB(232,234,137);//��ɫ
						break;
					case 10:
						//cr = RGB(168,168,168); //��ɫ       //    RGB(4,185,0);//��ɫ
						cr = RGB(0,0,0);
						break;
					case 8:
					case 9:
					case 11:
					case 12:
						cr = RGB(232,234,137);//��ɫ           //RGB(255,58,107);//��ɫ
						break;
					}
				}
				else if( m_bIVMode==1 || m_bIVMode==3 )   //IVģʽ��
				{
					switch( nSubItem )
					{
					case 0:
					case 20:
						cr = RGB(168,168,168); //��ɫ
						break;
					case 1:
					case 3:
					case 17:
					case 19:
						cr = RGB(232,234,137);//��ɫ
						break;
					case 2:
					case 4:
					case 16:
					case 18:
						cr = RGB( 239,85,231);//��ɫ
						break;
					case 5:
					case 15:
						cr = RGB(168,168,168); //��ɫ      //RGB(255,58,107);//��ɫ
						break;
					case 6:
					case 7:
					case 11:
					case 12:
						cr = RGB( 239,85,231);//��ɫ
						break;
					case 8:
					case 9:
					case 13:
					case 14:
						cr = RGB(232,234,137);//��ɫ
						break;
					case 10:
						//cr = RGB(168,168,168); //��ɫ      //RGB(4,185,0);//��ɫ
						cr = RGB(0,0,0);
						break;
					}
				}
				else if( m_bIVMode==2 )   //PBģʽ��
				{
					switch( nSubItem )
					{
					case 0:
					case 1:
					case 13:
					case 14:
						cr = RGB(168,168,168); //��ɫ
						break;
					case 7:
						cr = RGB(0,0,0);
						break;
					case 2:
					case 3:
					case 4:
					case 5:
					case 9:
					case 10:
					case 11:
					case 12:
						cr = RGB(232,234,137);//��ɫ
						break;
					case 6:
					case 8:
						cr = RGB( 239,85,231);//��ɫ
						break;
					}
				}
			}
		}
		
	}
	
	//	ATLTRACE("GetTextColor: [%d][%d]=%d \r\n",nItem,nSubItem,m_Color[nItem].m_iColor[nSubItem]);
	
	return cr;
}

UINT ColorThread(LPVOID  lParam)  //���������ɫ���̺߳���
{
	//CoInitializeEx(NULL,COINIT_MULTITHREADED);
	ClistctrlOptions * pclass;
	pclass=(ClistctrlOptions *)lParam;
	int iCount = 0;
	int iCount2 = 0;
	while (pclass->m_bStopColorThread == FALSE)
	{
		Sleep(50);
		iCount++;
		iCount2++;
		if(iCount >= 20) //1���ж�һ��
		{
			pclass->CheckColor();
			iCount = 0;
		}	
		if( iCount2>=20 )
		{
			if( pclass->m_TTOptions->m_pwndCls!=NULL && pclass->m_TTOptions->m_pwndCls->IsWindowVisible() )
			{
				if( pclass->m_TTOptions->m_pwndCls->m_nRetn==0 )
				{
					pclass->m_TTOptions->OnSelectStrategy();
				}
			}
				
			iCount2 = 0;
		}
		
	}
	
	pclass->m_bStoppedColorThread = TRUE;
	
	return 0;
}


void ClistctrlOptions::OnDestroy() //���ٺ���
{
	CListCtrl::OnDestroy();
	
	// TODO: Add your message handler code here
	m_bStopColorThread = TRUE;
	int i=0;
	while(m_bStoppedColorThread != TRUE)
	{
		Sleep(10);
		if(i++>300)
			break;
	}
	if( m_TTOptions->m_pwndCls!=NULL )
	{
		delete m_TTOptions->m_pwndCls;
		m_TTOptions->m_pwndCls = NULL;
	}
}



void ClistctrlOptions::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct) //����item��С�ߴ�
{
	CDC *pDC = GetDC();
	if(pDC==NULL)
		return;
	CFont *pFont = GetFont();
	CFont *pOldFont = pDC->SelectObject(pFont);
	CSize sz = pDC->GetTextExtent("A0");
	pDC->SelectObject(pOldFont);
	lpMeasureItemStruct->itemHeight	= sz.cy ;
	ReleaseDC(pDC);
	
	CListCtrl::OnMeasureItem(lpMeasureItemStruct->CtlID, lpMeasureItemStruct);
}



LRESULT   ClistctrlOptions::OnSetFont(WPARAM   wParam,   LPARAM)   //
{   
	LRESULT res = Default();   
	
	CRect   rc;   
	GetWindowRect(   &rc   );   
	
	WINDOWPOS   wp;   
	wp.hwnd = m_hWnd;   
	wp.cx   =   rc.Width();   
	wp.cy   =   rc.Height();   
	wp.flags   =   SWP_NOACTIVATE   |   SWP_NOMOVE   |   SWP_NOOWNERZORDER   |   SWP_NOZORDER;   
	SendMessage(   WM_WINDOWPOSCHANGED,   0,   (LPARAM)&wp   );   
	
	return   res;   
} 

void ClistctrlOptions::ShowHighPrice(int bShow)  //��ʾ �ߵ�
{
	m_bShowHighPrice = bShow;  
	//	Invalidate(FALSE);	
    
	if(m_bIVMode == 0)
	{
		m_pOwner->OnSelectColumnWidth();
		//RecalcColumnWidth(m_iColumnMode);
	}
}

void ClistctrlOptions::SelectIVMode(int bMode) //ѡ��ģʽ
{
	//	m_bShowHighPrice = bShow;  
	//	Invalidate(FALSE);	
	
	//	RecalcColumnWidth(m_iColumnMode);
	
	m_bIVMode = bMode;
	
	if(m_bIVMode==0 || m_bIVMode==4 || m_bIVMode==5 ) //����ģʽ  δƽ��  ����
	{
		AdjustColumnWidth();
	}
	else if(m_bIVMode==1 || m_bIVMode==3)     //IVģʽ Greeks
	{ 
		AdjustColumnWidthIVMode();
	}
	else if(m_bIVMode==2)     //���ʷ���
	{ 
		AdjustColumnWidthPBMode();
	}
	
	
	//	SwitchMode();
}

void ClistctrlOptions::SelectSimpleMode(int bMode, int iNum) //ѡ�񾫼�ģʽ
{
	m_iNum = iNum;

	m_bSimpleMode = bMode;
	BYTE FlagBuf[MACRO_MaxItems];
	memset( FlagBuf, 1, sizeof(FlagBuf) ) ;

	if(bMode==0) //�˳�����ģʽ
	{
		SetItemsTotal(m_TTOptions->m_nDataTotal,FlagBuf);
		PostMessage(MACRO_MsgRedrawItem, (WPARAM)0xFFFFFFFE, 0);
	}
	else      //����ģʽ
	{ 
		if( iNum==-1 )
			iNum = 5;  //20180622  ֮ǰ��-1�ͷ��أ���������ڿ���ǰ�޼۸��¾���ģʽ������

		m_nStart = iNum-5;
		m_nEnd = iNum+5;
		if( m_nStart<0 )
			m_nStart = 0;
		if( m_nEnd>m_TTOptions->m_nDataTotal )
			m_nEnd = m_TTOptions->m_nDataTotal;

		m_nTotal_simple = m_nEnd-m_nStart+1;
		m_nTotal_simple++;
		if( m_nStart==0 && m_nEnd==0 )
			m_nTotal_simple = MACRO_SmpItems;
	//	char cc[50];
	//	sprintf(cc,"%d",m_nTotal_simple);
	//	m_TTOptions->WriteLogFile(cc);
		if( m_nTotal_simple!=0 )
		{
			memset(m_buf_simple,0,sizeof(ItemOptionsText)*MACRO_SmpItems);
			SetItemsTotal(m_nTotal_simple,FlagBuf);
			for( int i=0;i<m_nTotal_simple;i++ )
			{
				if( m_nStart==0 )
				{
					memcpy(&m_buf_simple[i], &m_buf[i], sizeof(ItemOptionsText));
				}
				else
				{
					if( i==0 )
						memcpy(&m_buf_simple[i], &m_buf[i], sizeof(ItemOptionsText));
					else
						memcpy(&m_buf_simple[i], &m_buf[i+m_nStart-1], sizeof(ItemOptionsText));
				}
			}
			
			PostMessage(MACRO_MsgRedrawItem, (WPARAM)0xFFFFFFFE, 0);
		}
	}
}

void ClistctrlOptions::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if (nChar == VK_ADD && GetKeyState(VK_CONTROL) )
	{
		ATLTRACE("Ctrl+ Pressed !");
		if (m_bIVMode == 0)
		{
			AdjustColumnWidth();  //��������DrawItem��ԭ��,ϵͳ�Լ���Ctrl+̫��,�����Լ��ĺ���!
		}
		else
		{
			AdjustColumnWidthIVMode();
		}
		return;
	}
	
	CListCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
}



int ClistctrlOptions::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	return 0;
}

void ClistctrlOptions::SetHead()  //������ͷ��ʵ�ֱ�ͷ���ػ�
{
	if (!m_Head.GetSafeHwnd())
	{
		//m_Head.SubclassWindow(GetHeaderCtrl()->GetSafeHwnd());
		ModifyStyle(0, LVS_REPORT);
		if (!m_Head.SubclassWindow(GetHeaderCtrl()->GetSafeHwnd()))
			return;
	}
}

void ClistctrlOptions::SetColorMode(int nColMode) //���ñ�����ɫ
{
	m_nColorMode = nColMode;
	m_Head.RedrawWindow();
	this->RedrawWindow();
}


// void ClistctrlOptions::PreSubclassWindow()
// {
// 	// TODO: �ڴ�����ר�ô����/����û���
// 	ModifyStyle(0,LVS_OWNERDRAWFIXED);
// //	ModifyStyle(0,LVS_REPORT);
// 
// 
// 	CListCtrl::PreSubclassWindow();
//  	CHeaderCtrl *pHeader = GetHeaderCtrl();
// 	
// 	m_Head.SubclassWindow(pHeader->GetSafeHwnd());
// 
// }


















//************* CHeaderCtrlCl ****************************

IMPLEMENT_DYNAMIC(CHeaderCtrlCl, CHeaderCtrl)

CHeaderCtrlCl::CHeaderCtrlCl()
: m_R(255)
, m_G(255)
, m_B(255)
, m_Gradient(0)
{
	m_nColorMode = 0;	
}

CHeaderCtrlCl::~CHeaderCtrlCl()
{
}



BEGIN_MESSAGE_MAP(CHeaderCtrlCl, CHeaderCtrl)
ON_WM_PAINT()
END_MESSAGE_MAP()

void CHeaderCtrlCl::SetColorMode( int colMode )
{
	m_nColorMode = colMode;
	this->RedrawWindow();
}

// CHeaderCtrlCl ��Ϣ��������




void CHeaderCtrlCl::OnPaint()
{
	int nColorMode = m_plist->m_nColorMode;  //0:��ɫ   1:��ɫ   2:��ɫ
	
	if( nColorMode == 0 )  //��ɫģʽ
	{
		CPaintDC dc(this); // device context for painting
		// TODO: �ڴ˴�������Ϣ�����������
		// ��Ϊ��ͼ��Ϣ���� CHeaderCtrl::OnPaint()
		int nItem; 
		nItem = GetItemCount();//�õ��м�����Ԫ 
		for(int i = 0; i<nItem;i ++) 
		{ 
			
			CRect tRect;
			GetItemRect(i,&tRect);//�õ�Item�ĳߴ�
			
			CRect nRect(tRect);//�����ߴ絽�µ������� 
			nRect.left++;//�����ָ��ߵĵط� 
			//�������屳�� 
			for(int j = tRect.top;j<=tRect.bottom;j++) 
			{ 
				nRect.bottom = nRect.top+1; 
				CBrush _brush; 
				//AfxMessageBox("asdasdsada");
				_brush.CreateSolidBrush(RGB(225,225,225));//������ˢ 
				dc.FillRect(&nRect,&_brush); //��䱳�� 
				_brush.DeleteObject(); //�ͷŻ�ˢ 
				nRect.top = nRect.bottom; 
			} 
			
			dc.SetBkMode(TRANSPARENT); //DrawText�����������ʽΪ͸����
			CFont nFont ,* nOldFont; 
			
			dc.SetTextColor(RGB(0,0,0));
			nFont.CreateFont(15,0,0,0,0,FALSE,FALSE,0,0,0,0,0,0,_TEXT("����"));//�������� 
			nOldFont = dc.SelectObject(&nFont);
			
			UINT nFormat = 1;
			
			TEXTMETRIC metric;
			dc.GetTextMetrics(&metric);
			int ofst = 0;
			ofst = tRect.Height() - metric.tmHeight;
			tRect.OffsetRect(0,ofst/2);
			dc.DrawText(this->m_HChar[i],&tRect,nFormat);
			dc.SelectObject(nOldFont); 
			nFont.DeleteObject(); //�ͷ����� 
		} 
	}
	if( nColorMode == 1)   //��ɫģʽ
	{
		CPaintDC dc(this); // device context for painting
		// TODO: �ڴ˴�������Ϣ�����������
		// ��Ϊ��ͼ��Ϣ���� CHeaderCtrl::OnPaint()
		
		CRect clienrect;	
		GetClientRect(clienrect);//��ȡ�ͻ������λ��
	
		CBrush brush;
		brush.CreateSolidBrush(RGB(0,0,0));
	
		dc.FillRect(&clienrect,&brush);

		HDITEM hdi;
		TCHAR  lpBuffer[256];
		
		hdi.mask = HDI_TEXT;
		hdi.pszText = lpBuffer;
		hdi.cchTextMax = 256;

		CBrush brushRect;
		brushRect.CreateSolidBrush(RGB(0x44,0x44,0x44));

		CFont pFont;
		pFont.CreateFont(15,0,0,0,0,FALSE,FALSE,0,0,0,0,0,0,_TEXT("����"));//�������� 
		CFont *pOldFont = dc.SelectObject(&pFont);

		int nItem; 
		nItem = GetItemCount();//�õ��м�����Ԫ 
		for(int i = 0; i<nItem;i ++) 
		{ 			
			dc.SetBkMode(TRANSPARENT); //DrawText�����������ʽΪ͸����	
		
			COLORREF crText;  //������ɫ
			
			if( m_plist->m_bIVMode == 0 || m_plist->m_bIVMode == 4 || m_plist->m_bIVMode == 5 )//����ģʽ��
			{
				switch( i )
				{
				case 0:
				case 1:
				case 2:
				case 18:
				case 19:
				case 20:
					crText = RGB(168,168,168); //��ɫ
					break;
				case 3:
				case 4:
				case 16:
				case 17:
					crText = RGB( 239,85,231);//��ɫ
					break;
				case 5:
				case 6:
				case 7:
				case 13:
				case 14:
				case 15:
					crText = RGB(232,234,137);//��ɫ
					break;
				case 10:
					crText = RGB(168,168,168); //��ɫ                
					break;
				case 8:
				case 9:
				case 11:
				case 12:
					crText = RGB(232,234,137);//��ɫ                   //RGB(255,58,107);//��ɫ
					break;
				}
			}
			else if( m_plist->m_bIVMode == 1 || m_plist->m_bIVMode == 3 )   //IVģʽ��
			{
				switch( i )
				{
				case 0:
				case 20:
					crText = RGB(168,168,168); //��ɫ
					break;
				case 1:
				case 3:
				case 17:
				case 19:
					crText = RGB(232,234,137);//��ɫ
					break;
				case 2:
				case 4:
				case 16:
				case 18:
					crText = RGB( 239,85,231);//��ɫ
					break;
				case 5:
				case 15:
					crText = RGB(168,168,168); //��ɫ      //RGB(255,58,107);//��ɫ
					break;
				case 6:
				case 7:
				case 11:
				case 12:
					crText = RGB( 239,85,231);//��ɫ
					break;
				case 8:
				case 9:
				case 13:
				case 14:
					crText = RGB(232,234,137);//��ɫ
					break;
				case 10:
					crText = RGB(168,168,168); //��ɫ             //RGB(4,185,0);//��ɫ
					break;
				}
			}  
			else if( m_plist->m_bIVMode == 2 )   //PBģʽ��
			{
				switch( i )
				{
				case 0:
				case 1:
				case 7:
				case 13:
				case 14:
					crText = RGB(168,168,168); //��ɫ
					break;
				case 2:
				case 3:
				case 4:
				case 5:
				case 9:
				case 10:
				case 11:
				case 12:
					crText = RGB(232,234,137);//��ɫ
					break;
				case 6:
				case 8:
					crText = RGB( 239,85,231);//��ɫ
					break;
				}
			} 
			dc.SetTextColor(crText);
			CRect rectItem;
			GetItemRect(i,&rectItem);
			GetItem(i,&hdi);
			UINT nFormat = DT_CENTER;

			dc.FrameRect(rectItem,&brushRect);
			dc.DrawText(hdi.pszText,rectItem,nFormat|DT_VCENTER|DT_SINGLELINE);
					
		} 
		dc.SelectObject(pOldFont);
		pFont.DeleteObject(); //�ͷ����� 
	}
	if( nColorMode == 2 )   //��ɫģʽ
	{
		CPaintDC dc(this); // device context for painting
		// TODO: �ڴ˴�������Ϣ�����������
		// ��Ϊ��ͼ��Ϣ���� CHeaderCtrl::OnPaint()
		int nItem; 
		nItem = GetItemCount();//�õ��м�����Ԫ 
		for(int i = 0; i<nItem;i ++) 
		{ 
			
			CRect tRect;
			GetItemRect(i,&tRect);//�õ�Item�ĳߴ�
			int R = m_R,G = m_G,B = m_B;
			
			if( m_plist->m_bIVMode == 0 || m_plist->m_bIVMode == 4 || m_plist->m_bIVMode == 5 )
			{
				if( i >=0 && i <= 9 )
				{
					R=222;G=184;B=87;//DE B8 87  
				}
				else if( i==10 )
				{
					R=191;G=239;B=255;//BF EF FF
				}
				else if( i >=11 && i <= 20 )
				{
					R=255;G=236;B=139;//FF EC 8B
				}
			}
			else if( m_plist->m_bIVMode == 1 || m_plist->m_bIVMode == 3 )
			{
				if( i >=0 && i <= 9 )
				{
					R=222;G=184;B=87;//DE B8 87  
				}
				else if( i==10 )
				{
					R=191;G=239;B=255;//BF EF FF
				}
				else if( i >= 11 && i <= 20 )
				{
					R=255;G=236;B=139;//FF EC 8B
				}
			}
			else if( m_plist->m_bIVMode == 2 )
			{
				if( i >=0 && i <= 6 )
				{
					R=222;G=184;B=87;//DE B8 87  
				}
				else if( i==7 )
				{
					R=191;G=239;B=255;//BF EF FF
				}
				else if( i >= 8 && i <= 14 )
				{
					R=255;G=236;B=139;//FF EC 8B
				}
				else if( i>=15 )
				{
					R=255;G=255;B=255;
				}
			}
			
			
			CRect nRect(tRect);//�����ߴ絽�µ������� 
			nRect.left++;//�����ָ��ߵĵط� 
			//�������屳�� 
			for(int j = tRect.top;j<=tRect.bottom;j++) 
			{ 
				nRect.bottom = nRect.top+1; 
				CBrush _brush; 
				//AfxMessageBox("asdasdsada");
				_brush.CreateSolidBrush(RGB(R,G,B));//������ˢ 
				dc.FillRect(&nRect,&_brush); //��䱳�� 
				_brush.DeleteObject(); //�ͷŻ�ˢ 
				R-=m_Gradient;G-=m_Gradient;B-=m_Gradient;
				if (R<0)R = 0;
				if (G<0)G = 0;
				if (B<0)B= 0;
				nRect.top = nRect.bottom; 
			} 
			
			dc.SetBkMode(TRANSPARENT); //DrawText�����������ʽΪ͸����
			CFont nFont ,* nOldFont; 
			
			dc.SetTextColor(RGB(0,0,0));
			nFont.CreateFont(15,0,0,0,0,FALSE,FALSE,0,0,0,0,0,0,_TEXT("����"));//�������� 
			nOldFont = dc.SelectObject(&nFont);
			
			UINT nFormat = 1;
			
			TEXTMETRIC metric;
			dc.GetTextMetrics(&metric);
			int ofst = 0;
			ofst = tRect.Height() - metric.tmHeight;
			tRect.OffsetRect(0,ofst/2);
			dc.DrawText(this->m_HChar[i],&tRect,nFormat);
			dc.SelectObject(nOldFont); 
			nFont.DeleteObject(); //�ͷ����� 
		} 
	}
}


//************* CHeaderCtrlCl  END  ****************************










//************* CHeaderCtrlOptions ****************************

IMPLEMENT_DYNAMIC(CHeaderCtrlOptions, CHeaderCtrl)

CHeaderCtrlOptions::CHeaderCtrlOptions()
: m_R(255)
, m_G(255)
, m_B(255)
, m_Gradient(0)
{
	m_nColorMode = 0;
}

CHeaderCtrlOptions::~CHeaderCtrlOptions()
{
}



BEGIN_MESSAGE_MAP(CHeaderCtrlOptions, CHeaderCtrl)
ON_WM_PAINT()
END_MESSAGE_MAP()

void CHeaderCtrlOptions::SetColorMode(int colMode)
{
	m_nColorMode = colMode;
}

// CHeaderCtrlOptions ��Ϣ��������

void CHeaderCtrlOptions::OnPaint()
{
	

	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CHeaderCtrl::OnPaint()
	int nColorMode =  m_TTOptions->m_nColorMode;       //  //��ȡ������ɫ

	int width = 0; 

	if( nColorMode == 0 )  //��ɫ
	{
		for(int i = 0; i<3;i++) 
		{ 
			//����ListCtrl��λ�����趨�ⲿ��ͷ��λ�ã���ֹ����   Keeping 2014-11-11
			CRect tRect;
			GetItemRect(i,&tRect);//�õ�Item�ĳߴ�

			int R = 230,G = 230,B = 230;
		
			CRect nRect(tRect);//�����ߴ絽�µ������� 
			nRect.left++;//�����ָ��ߵĵط� 
			//���Ʊ��� 
			
			for(int j = tRect.top;j<=tRect.bottom;j++) 
			{ 
				nRect.bottom = nRect.top+1;
				
				CBrush _brush; 
				_brush.CreateSolidBrush(RGB(R,G,B));//������ˢ 
				dc.FillRect(&nRect,&_brush); //��䱳�� 
				_brush.DeleteObject(); //�ͷŻ�ˢ 
				
				R-=m_Gradient;G-=m_Gradient;B-=m_Gradient;
				if (R<0)R = 0;
				if (G<0)G = 0;
				if (B<0)B= 0;
				nRect.top = nRect.bottom; 
			} 
			
			dc.SetBkMode(TRANSPARENT); //DrawText�����������ʽΪ͸����
			CFont nFont ,* nOldFont; 
			
			dc.SetTextColor(RGB(0,0,0));
			nFont.CreateFont(15,0,0,0,0,FALSE,FALSE,0,0,0,0,0,0,_TEXT("����"));//�������� 
			nOldFont = dc.SelectObject(&nFont);
			
			UINT nFormat = 1;
			
			TEXTMETRIC metric;
			dc.GetTextMetrics(&metric);
			int ofst = 0;
			ofst = tRect.Height() - metric.tmHeight;
			tRect.OffsetRect(0,ofst/2);
			dc.DrawText(this->m_HChar[i],&tRect,nFormat);
			dc.SelectObject(nOldFont); 
			nFont.DeleteObject(); //�ͷ����� 
		} 
	}
	else if( nColorMode == 1 ) //��ɫ
	{
		CRect clienrect;	
		GetClientRect(clienrect);//��ȡ�ͻ������λ��
		
		CBrush brush;
		brush.CreateSolidBrush(RGB(0,0,0));
		
		dc.FillRect(&clienrect,&brush);
		
		HDITEM hdi;
		TCHAR  lpBuffer[256];
		
		hdi.mask = HDI_TEXT;
		hdi.pszText = lpBuffer;
		hdi.cchTextMax = 256;
		
		CBrush brushRect;
		brushRect.CreateSolidBrush(RGB(0x44,0x44,0x44));
		
		CFont pFont;
		pFont.CreateFont(15,0,0,0,0,FALSE,FALSE,0,0,0,0,0,0,_TEXT("����"));//�������� 
		CFont *pOldFont = dc.SelectObject(&pFont);

		for(int i = 0; i<3;i++) 
		{ 
			
			CRect tRect;
			GetItemRect(i,&tRect);//�õ�Item�ĳߴ�

			
			dc.SetBkMode(TRANSPARENT); 

			
			if(i==0)
				dc.SetTextColor(RGB(255,0,0));
			if(i==2)
				dc.SetTextColor(RGB(0,255,0));
			CRect rectItem;
			GetItemRect(i,&rectItem);
			GetItem(i,&hdi);
			UINT nFormat = DT_CENTER;
			
			dc.FrameRect(rectItem,&brushRect);
			dc.DrawText(hdi.pszText,rectItem,nFormat|DT_VCENTER|DT_SINGLELINE);
			
		} 
		dc.SelectObject(pOldFont);
		pFont.DeleteObject(); //�ͷ����� 
	} 
	else if( nColorMode == 2 )  //��ɫ
	{
		for(int i = 0; i<3;i++) 
		{ 
			
			CRect tRect;
			GetItemRect(i,&tRect);//�õ�Item�ĳߴ�
			int R = m_R,G = m_G,B = m_B;
			
			if( i ==0  )
			{
				R=222;G=184;B=87;//DE B8 87
			}
			else if( i == 1 )
			{
				R=191;G=239;B=255;
			}
			else if( i == 2 )
			{
				R=255;G=236;B=139;
			}
			
			CRect nRect(tRect);//�����ߴ絽�µ������� 
			nRect.left++;//�����ָ��ߵĵط� 
			for(int j = tRect.top;j<=tRect.bottom;j++) 
			{ 
				nRect.bottom = nRect.top+1;
				
				CBrush _brush; 
				_brush.CreateSolidBrush(RGB(R,G,B));//������ˢ 
				dc.FillRect(&nRect,&_brush); //��䱳�� 
				_brush.DeleteObject(); //�ͷŻ�ˢ 
				
				R-=m_Gradient;G-=m_Gradient;B-=m_Gradient;
				if (R<0)R = 0;
				if (G<0)G = 0;
				if (B<0)B= 0;
				nRect.top = nRect.bottom; 
			} 
			
			
			dc.SetBkMode(TRANSPARENT); //DrawText�����������ʽΪ͸����
			CFont nFont ,* nOldFont; 
			
			dc.SetTextColor(RGB(0,0,0));
			nFont.CreateFont(15,0,0,0,0,FALSE,FALSE,0,0,0,0,0,0,_TEXT("����"));//�������� 
			nOldFont = dc.SelectObject(&nFont);
			
			UINT nFormat = 1;
			
			TEXTMETRIC metric;
			dc.GetTextMetrics(&metric);
			int ofst = 0;
			ofst = tRect.Height() - metric.tmHeight;
			tRect.OffsetRect(0,ofst/2);
			dc.DrawText(this->m_HChar[i],&tRect,nFormat);
			dc.SelectObject(nOldFont); 
			nFont.DeleteObject(); //�ͷ����� 
		} 
	}
}






//BOOL CHeaderCtrlOptions::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
//{
//	return CHeaderCtrl::Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
//}

//************* CHeaderCtrlOptions  END  ****************************




