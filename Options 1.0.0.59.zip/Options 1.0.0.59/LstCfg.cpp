

/////////////////////////////////////////////////////////////////////////////////////////
//
//	System:			
//	Modul:		��װListCtrl�ؼ���������Ϣ.
//	Descripe:		
//
//	List:
//
//	File:			LstCfg.cpp
//	Coding Man:		lzy.
//	Last Version:	1998-08-18.
//
//////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "LstCfg.h"

#include <afxcmn.h>



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif









LstHead::LstHead()
{
	m_nWidth = 0 ;
}

LstHead::LstHead( const LstHead& obj )
{
	*this = obj ;
}

BOOL LstHead::operator = ( const LstHead& obj )
{
	m_szText[0] = obj.m_szText[0] ;
	m_szText[1] = obj.m_szText[1] ;
	m_szText[2] = obj.m_szText[2] ;
	m_nWidth = obj.m_nWidth ;
	m_nFtm = obj.m_nFtm ;
	m_szSampleData = obj.m_szSampleData ;
	return TRUE;
}


LstHead::~LstHead()
{
	
}


BOOL LstHead::Config( LPCSTR szText1, LPCSTR szText2, LPCSTR szText3, int nWidth, int fmt, LPCSTR szSampleData )
{
	m_szText[0] = szText1 ;
	m_szText[1] = szText2 ;
	m_szText[2] = szText3 ;
	m_nWidth = nWidth ;
	m_nFtm = fmt ;
	if( szSampleData!=NULL )
		m_szSampleData = szSampleData ;
	else
		m_szSampleData = m_szText[0] ;
	return TRUE;
	
}


////////////////////////////////////////////////////////////////////

LstHeadsInfo::LstHeadsInfo( int BufSize )
{
	m_pBuf = NULL ;
	m_nBufTotal = 0 ;
	m_nCurLang = 0 ;
	
	m_nShowTotal = 0 ;
	m_Orders.SetSize( BufSize, 20 );
	for( int i=0;i<BufSize;i++ )
		m_Orders[i] = i ;
	m_nShowTotal = BufSize ;
	
	if( BufSize>0 )
	{
		m_pBuf = new LstHead[BufSize] ;
		ASSERT( m_pBuf!=NULL );
		m_nBufTotal = BufSize ;
	}
	
}

LstHeadsInfo::LstHeadsInfo( const LstHeadsInfo& obj )
{
	m_pBuf = NULL ;
	m_nBufTotal = 0 ;
	*this = obj ;
	
}

BOOL LstHeadsInfo::operator = ( const LstHeadsInfo& obj )
{
	ReInit();
	if( obj.m_pBuf!=NULL &&  obj.m_nBufTotal>0 )
	{
		m_pBuf = new LstHead[ obj.m_nBufTotal ] ;
		ASSERT( m_pBuf!=NULL );
		m_nBufTotal = obj.m_nBufTotal ;
		for( int i=0;i<m_nBufTotal;i++ )
			m_pBuf[i] = obj.m_pBuf[i] ;
		
	}
	m_nShowTotal = obj.m_nShowTotal ;
	m_Orders.Append( obj.m_Orders ) ;
	return TRUE;
	
}

LstHeadsInfo::~LstHeadsInfo()
{
	ReInit();
}

void LstHeadsInfo::ReInit()
{
	if( m_pBuf!=NULL )
	{
		delete [] m_pBuf ;
		m_pBuf = NULL ;
	}
	m_nBufTotal = 0 ;
	m_nShowTotal = 0 ;
	m_Orders.RemoveAll();
	
}

BOOL LstHeadsInfo::CreateBuf( int BufSize )
{
	ReInit(); //�����ǰ������
	
	m_Orders.SetSize( BufSize, 20 );
	for( int i=0;i<BufSize;i++ )
		m_Orders[i] = i ;
	m_nShowTotal = BufSize ;
	
	if( BufSize>0 )
	{
		m_pBuf = new LstHead[BufSize] ;
		ASSERT( m_pBuf!=NULL );
		m_nBufTotal = BufSize ;
	}
	return TRUE;
	
}

void LstHeadsInfo::CreateLstHead( ClistctrlOptions& lst )   
{
	CListCtrl *lst1 = &lst;
	lst1->DeleteAllItems();
	while( lst1->DeleteColumn(0) );
	
	if( m_pBuf==NULL || m_nBufTotal<=0 )
		return;
	
	int lang = m_nCurLang ; //ѡ������
	if( lang<0 || lang>2 ) 
		lang = 0 ;
	
	// ��ʼ��ListView.
	LV_COLUMN	lvcolumn; //�е�����
	//CHeaderCtrl* pWnd = (CHeaderCtrl*)lst.GetDlgItem(0) ; 
	//HDITEM		hditem ;
	for( int i=0;i<m_nShowTotal;i++ )
	{
		char text[300];
		strcpy( text, (LPCSTR)m_pBuf[i].m_szText[lang] );
		
//		ClistctrlOptions *p_list = &lst;
		lst.m_Head.m_HChar.Add( m_pBuf[i].m_szText[lang] ); //���õ�ǰͷ�����֣�����ͷ���ػ�ʱ��������

		lvcolumn.mask = LVCF_FMT | LVCF_TEXT | LVCF_WIDTH ;
		lvcolumn.fmt = m_pBuf[i].m_nFtm ;	
		lvcolumn.cx = m_pBuf[i].m_nWidth;
		lvcolumn.pszText = text;
		lst1->InsertColumn( i, &lvcolumn);  
		
		if(i == 0)
		{
			BOOL aa = lst1->SetColumn(i,&lvcolumn);
		}
		
		
		/*
		hditem.mask = HDI_FORMAT ;	//
		hditem.fmt  = HDF_CENTER | HDF_STRING ;	// always make headerctrl's item in center, have a good look! 
		pWnd->SetItem( i, &hditem ) ;
		*/
		
	}// end for( add Lst's title. )		
	for( i=0;i<m_nShowTotal;i++ )
	{
		lvcolumn.mask = LVCF_ORDER ;
		lvcolumn.iOrder = m_Orders[i] ;
		lst1->SetColumn( i, &lvcolumn);  
	}// end for( add Lst's title. )		
	
}

void LstHeadsInfo::SaveLstOpt( CListCtrl& list )  //��������
{
	if( m_pBuf==NULL || m_nBufTotal<=0 || list.m_hWnd==NULL )
		return ;
	
	LV_COLUMN	col;
	col.mask = LVCF_WIDTH | LVCF_ORDER ;
	for( int i=0;i<m_nBufTotal;i++ )
	{
		if( list.GetColumn( i, &col )==FALSE )
			break ;
		m_pBuf[i].m_nWidth = col.cx ;
		m_Orders.SetAtGrow( i, col.iOrder ) ;
	}		
	
}

void LstHeadsInfo::ResetLang( int nCurLang, ClistctrlOptions& list ) //��������
{
	CListCtrl * lst = &list;
	if( m_nCurLang!=nCurLang ) 
		m_nCurLang = nCurLang ;
	if( lst->m_hWnd==NULL )
		return ;
	
	int lang = m_nCurLang ;
	if( lang<0 || lang>2 ) 
		lang = 0 ;

	list.m_Head.m_HChar.RemoveAll(); //������е�ǰͷ������

	for( int i=0;i<m_nShowTotal;i++ )
	{
		int addr = i ;
		ASSERT( addr>=0 && addr <m_nBufTotal ) ;
		
		LV_COLUMN	lvcolumn;
		char text[300];
		strcpy( text, (LPCSTR)m_pBuf[addr].m_szText[lang] );
		
		lvcolumn.mask = LVCF_TEXT ;
		lvcolumn.pszText = text;
		lst->SetColumn( i, &lvcolumn);
		
		list.m_Head.m_HChar.Add( m_pBuf[i].m_szText[lang] ); //�������õ�ǰͷ�����֣�����ͷ���ػ�ʱ��������
	}
	
	
}

int	 LstHeadsInfo::FindColumn( const char* pszColName ) const //����ҪѰ���е��±�ֵ
{
	if( m_pBuf==NULL || m_nBufTotal<=0 || pszColName==NULL )
		return -1;
	
	int lang = m_nCurLang ;
	if( lang<0 || lang>2 ) 
		lang = 0 ;
	
	for( int i=0;i<m_nBufTotal;i++ )
	{
		CString temp = pszColName ;
		if( m_pBuf[i].m_szText[lang]==temp )
			return i;
	}
	return -1;
	
}

int GetColumnsTotal( CListCtrl& list )  //����CListCtrl �е�����
{
	int nTotal = 0 ;
	if( list.m_hWnd==NULL )
		return nTotal ;
	
	LVCOLUMN col ;
	col.mask = LVCF_WIDTH ;
	while( list.GetColumn( nTotal, &col )==TRUE )
		nTotal++ ;
	return nTotal ;
	
}


void LstHeadsInfo::SetColumnOrder(CListCtrl& lst)
{
	int *orderArr = new int[m_nShowTotal];
	for(int i=0;i<m_nShowTotal;i++ )
	{
		orderArr[i] = m_Orders[i];
	}
	lst.SetColumnOrderArray(m_nShowTotal, orderArr);
	delete orderArr;
//��ListCtrl��SetColumn(LV_COLUMN.iOrder)������ʱ�ᵼ��˳�����
/*
	LV_COLUMN	lvcolumn;
	for(int i=0;i<m_nShowTotal;i++ )
	{
		lvcolumn.mask = LVCF_ORDER ;
		lvcolumn.iOrder = m_Orders[i] ;
		lst.SetColumn( i, &lvcolumn);  
	}// end for( add Lst's title. )		
*/

}

void LstHeadsInfo::GetColumnOrder(CListCtrl &lst)
{
	int *lpOrders = new int[m_nShowTotal];

	lst.GetColumnOrderArray(lpOrders,m_nShowTotal);
	for(int i=0;i<m_nShowTotal;i++ )
	{
		m_Orders[i] = lpOrders[i];
		
	}// end for( add Lst's title. )		
	delete []lpOrders;
/*
	LV_COLUMN	lvcolumn;
	for(int i=0;i<m_nShowTotal;i++ )
	{
		lvcolumn.mask = LVCF_ORDER ;
		lst.GetColumn(i,&lvcolumn);
		m_Orders[i] = lvcolumn.iOrder;
		
	}// end for( add Lst's title. )		
*/

}