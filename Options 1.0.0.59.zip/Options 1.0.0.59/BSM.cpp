
/*
	Black-Scholes Model

*/


#include "stdafx.h"
#include "BSM.h"
#include "PolyNormalTable.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/*
	��BSMģ�� ���� modelled option price.
	
		double S --> ��ǰ���ɵļ۸�
		double r --> �޷���Ͷ�ʵĻ�����( ͨ��ָ������ծ ) 
		double K --> Option striking price( ��ʹ�� )
		double t --> ����ֹ������/365
		double s --> Imply Volitility.

*/

/*
BOOL CBSMWrapper::CalMOP_ByBSM( double S, double r, double K, double t, double s, BSMCALINFO& echoInfo ) 
{
	memset( &echoInfo, 0, sizeof(echoInfo) ) ;

	double d1, d2 ;
	d1 = ( log( S/K ) + ( r + s*s/2 )*t ) / ( s*sqrt(t) ) ;
	d2 = d1 - s*sqrt(t) ;

	double C = S*N(d1) - K*pow( MathE, -1.0*r*t )*N(d2) ;

	echoInfo.C = C ;
	return TRUE ;

}
*/

BOOL CBSMWrapper::CalMOP_ByBSM( WARRANTOPT& warOpt,				
						  BSMCALINFO& echoInfo ) 
{
	return CalMOP_ByBSM( warOpt.bCallOption, 
						 warOpt.warrantPrice,
						 warOpt.conversionRatio,
						 warOpt.currentAssetPrice, 
						 warOpt.R,
						 warOpt.exercisePrice,
						 warOpt.T_t,
						 warOpt.riskFreeInterestRate,
						 warOpt.sd,
						 echoInfo ) ;
						
}

/*
BOOL CBSMWrapper::CalMOP_ByBSM( BOOL   bCallOption,				// ��call option��? 
							    double warrantPrice,			// ��֤�۸�
								double currentAssetPrice,		// ���ɼ۸�
								double exercisePrice,			// ��ʹ��
								double T_t,						// �����ձ���
								double riskFreeInterestRate,	// �޷���Ͷ�ʻ�����
								double sd,						// ���Ƶ�Imply Volitility.
								BSMCALINFO& echoInfo ) 			// ������Ϣ.
{
	memset( &echoInfo, 0, sizeof(echoInfo) ) ;

	// ����jacky��excel����������.
	double C3 = warrantPrice ;
	double C4 = currentAssetPrice ;
	double C5 = exercisePrice ;
	double C6 = T_t ;
	double C10 = riskFreeInterestRate ;
	double C11 = sd ;

	double C13 = log( C4/C5 ) ;
	double C14 = ( C10+C11*C11/2.0 )*C6 ;
	double C15 = C4*( (C13+C14)/( C11*sqrt(C6) ) ) ;

	double C19 = C5*( pow( MathE, -(C10*C6) ) ) ;
	double C20 = ( log(C4/C5)+(C10-C11*C11/2.0)*C6)/(C11*sqrt(C6)) ;

	double C16 = C19*C20 ;
	double C21 = ( log(C4/C5)+(C10+C11*C11/2.0)*C6)/(C11*sqrt(C6)) ;
	double C22 = C21-(C11*(sqrt(C6))) ;
	
	double C24 = N( C21 ) ;
	double C25 = N( C22 ) ;

	double C26 = C4*C24-C19*C25 ;
	double C27 = C4*(sqrt(C6)) ;
	double C28 = 1.0/(sqrt(2.0*MathPI)) ;
	double C29 = pow( MathE, -(C21*C21/2.0) ) ;
	double C30 = C27*C28*C29 ;
	double C33 = (1.0/sqrt(2.0*MathPI))*pow( MathE, -(C21*C21/2.0) ) ;
	double C34 = C33/(C4*C11*sqrt(C6)) ;
	double C36 = C5*C6*pow( MathE, -(C10*C6) )*C25 ;
	double C37 = -C5*C6*pow( MathE, -(C10*C6) )*(1.0-C25) ;
	double C38 = -(C4*C33*C11)/(2.0*sqrt(C6)) ;
	double C39 = C38-C10*C5*pow( MathE, -(C10*C6) )*(C25) ;
	double C40 = (C4*C24)/C26 ;

	double D31 = C11-(C26-C3)/C30 ;

	//double gamma = pow( MathE, -(C21*C21/2.0) ) / (C4*C11*sqrt(2.0*MathPI*C6)) ;
	double gamma = C28*C29 / (C4*C11*sqrt(C6)) ;
	//double theta = -( C4*C29*C28*C11/( 2.0*sqrt(C6) ) ) - C10*C5*pow( MathE, 
//
	TRACE( "C03:%.8f\r\n", C3  ) ;
	TRACE( "C04:%.8f\r\n", C4  ) ;
	TRACE( "C05:%.8f\r\n", C5  ) ;
	TRACE( "C06:%.8f\r\n", C6  ) ;
	TRACE( "C10:%.8f\r\n", C10  ) ;
	TRACE( "C11:%.8f\r\n", C11  ) ;
	TRACE( "C13:%.8f\r\n", C13  ) ;
	TRACE( "C14:%.8f\r\n", C14  ) ;
	TRACE( "C15:%.8f\r\n", C15  ) ;
	TRACE( "C16:%.8f\r\n", C16  ) ;
	TRACE( "C19:%.8f\r\n", C19  ) ;
	TRACE( "C20:%.8f\r\n", C20  ) ;
	TRACE( "C21:%.8f\r\n", C21  ) ;
	TRACE( "C22:%.8f\r\n", C22  ) ;
	TRACE( "C24:%.8f\r\n", C24  ) ;
	TRACE( "C25:%.8f\r\n", C25  ) ;
	TRACE( "C26(Modelled option price):%.8f\r\n", C26  ) ;
	TRACE( "C27:%.8f\r\n", C27  ) ;
	TRACE( "C28:%.8f\r\n", C28  ) ;
	TRACE( "C29:%.8f\r\n", C29  ) ;
	TRACE( "Vega C30:%.8f\r\n", C30  ) ;
	TRACE( "C33:%.8f\r\n", C33  ) ;
	TRACE( "C34:%.8f\r\n", C34  ) ;
	TRACE( "C36:%.8f\r\n", C36  ) ;
	TRACE( "C37:%.8f\r\n", C37  ) ;
	TRACE( "C38:%.8f\r\n", C38  ) ;
	TRACE( "C39:%.8f\r\n", C39  ) ;
	TRACE( "C40:%.8f\r\n", C40  ) ;
	TRACE( "D31:%.8f\r\n", D31  ) ;
	TRACE( "gamma:%.8f\r\n", gamma ) ;
//

	echoInfo.modelledOptionPrice = C26  ;		
	echoInfo.vega = C30 ;						
	if( bCallOption==FALSE )
	{
		echoInfo.rho  = C37 ;						
	}
	else
	{
		echoInfo.rho  = C36 ;						
	}
	echoInfo.theta = C38 ;						
	echoInfo.gamma = gamma ;

	echoInfo.impliedVolitility = D31 ;			
	return TRUE ;

}
*/

BOOL CBSMWrapper::CalMOP_ByBSM( BOOL   bCallOption,				// ��call option��? 
							    double warrantPrice,			// ��֤�۸�
							    double conversionRatio,			// ���ɱ���
								double currentAssetPrice,		// ���ɼ۸�
								double R,						// ��Ϣ	 
								double exercisePrice,			// ��ʹ��
								double T_t,						// �����ձ���
								double riskFreeInterestRate,	// �޷���Ͷ�ʻ�����
								double sd,						// ���Ƶ�Imply Volitility.
								BSMCALINFO& echoInfo ) 			// ������Ϣ.
{
	memset( &echoInfo, 0, sizeof(echoInfo) ) ;
	if( conversionRatio<=0.0 )
		return FALSE ;

	// ����: http://www.anthony-vba.kefra.com/vba/vba13.htm

	//double S = currentAssetPrice ;	// ���ɼ۸�
	double S = (R==0.0) ? currentAssetPrice : currentAssetPrice*pow( MathE, -1.0*R*T_t ) ;		// ���ɼ۸�( ������Ϣ���� )

	double X = exercisePrice ;					// ��ʹ��
	double r = riskFreeInterestRate ;			// �޷���Ͷ�ʻ�����
	double time_sqrt = sqrt(T_t) ;

	double d1 = ( log( S/X ) + r*T_t ) / ( sd*time_sqrt ) + 0.5*sd*time_sqrt ;
	double d2 = d1 - sd*time_sqrt ;

	double N_d1  =  ( d1>0.0) ? N(d1) : 1.0-N(fabs(d1)) ;			// 
	double N_d2  =  ( d2>0.0) ? N(d2) : 1.0-N(fabs(d2)) ;			// 
	double Np_d1 =	pow( MathE, -0.5*d1*d1 ) / ( sqrt( 2.0*MathPI ) ) ;	// N'(d1)
	
	// ���� ��֤�۸�.
	double MOP ; 
	if( bCallOption==TRUE )
	{
		double c  = S*N_d1 - X*pow( MathE, -1.0*r*T_t )*N_d2 ;			//  call 
		MOP = c/conversionRatio ;
	}
	else
	{
		double p  = X*pow( MathE, -1.0*r*T_t )*(1.0-N_d2) - S*(1.0-N_d1) ;	//  put	
		MOP = p/conversionRatio ;
	}
	
	double delta = ( bCallOption==TRUE ) ? N_d1 : N_d1-1.0 ;	// ÿ�� �Գ�ֵ
	double gamma = Np_d1 / ( S*sd*time_sqrt ) ;
	double vega  = S*time_sqrt*Np_d1*0.01/conversionRatio ;		// paul, 2008-4-30, *0.01/conversionRatio
	double theta = ( bCallOption==TRUE ) ? 
						-1.0*( S*Np_d1*sd / (2.0*time_sqrt) ) - r*X*pow( MathE, -1.0*r*T_t )*N_d2 : 
						-1.0*( S*Np_d1*sd / (2.0*time_sqrt) ) + r*X*pow( MathE, -1.0*r*T_t )*( 1-N_d2 ) ; 	
	theta = theta/(365.0*conversionRatio) ;	// paul, 2008-4-30
											// ben 2017.6.29   252��Ϊ365

	double rho  =  ( bCallOption==TRUE ) ? 
						X*T_t*pow( MathE, -1.0*r*T_t )*N_d2/conversionRatio :
						-1.0*X*T_t*pow( MathE, -1.0*r*T_t )*( 1.0 - N_d2 )/conversionRatio ;

	// �����ʽ��վ��û��, jacky��excel����.
	double temp1 = S*time_sqrt ;
	double temp2 = 1.0/(sqrt(2.0*MathPI)) ;
	double temp3 = pow( MathE, -(d1*d1/2.0) ) ;
	double temp4 = temp1*temp2*temp3 ;
	double IV  = sd-(MOP-warrantPrice)/temp4 ;
	double IV_Sensitivity	= (warrantPrice!=0.0) ? ( warrantPrice+vega )/warrantPrice*100.0-100.0 : 0.0 ;
	double TimeDecaysPerDay = (warrantPrice!=0.0) ? ( warrantPrice-theta )/warrantPrice*100.0-100.0 : 0.0 ;
	double omega = (warrantPrice!=0.0) ? currentAssetPrice*N_d1/(warrantPrice*conversionRatio) : 0.0 ;

	echoInfo.gamma = gamma ;
	echoInfo.impliedVolitility = IV ;
	echoInfo.modelledOptionPrice = MOP ;
	echoInfo.rho	= rho ;
	echoInfo.theta  = theta ;
	echoInfo.vega   = vega ;
	echoInfo.delta  = delta ;
	echoInfo.IV_Sensitivity = IV_Sensitivity ;
	echoInfo.TimeDecaysPerDay = TimeDecaysPerDay ;
	echoInfo.omega = omega ;

	return TRUE ;

}

double CBSMWrapper::N( double sd ) 
{
	// ����ľ���ֻ��ȡ��С��λ4λ.
	//return CPolyNormalWrapper::CalPr_Below( sd ) ;
	
	// ��̬���ٶ���������? 
	if( sd>=0.0 )
	{
		return CPolyNormalWrapper::CalPolyNormal( sd )+0.5 ;
	}
	else
	{
		return 0.5 - CPolyNormalWrapper::CalPolyNormal( fabs(sd) ) ;
	}

}

BOOL CBSMWrapper::CalIV_ByCalculous( WARRANTOPT& warOpt, BSMCALINFO& echoInfo )
{
	// ��Ȼһֱ������ȥҲ���ܴﵽ��С���, ��֪��ʲôԭ��.
	memset( &echoInfo, 0, sizeof(echoInfo) ) ;
	int i = 0 ;
	do
	{
		if( CalMOP_ByBSM( warOpt, echoInfo )==FALSE )
		{
			memset( &echoInfo, 0, sizeof(echoInfo) ) ;
			return FALSE ;
		}

		if( fabs( warOpt.warrantPrice-echoInfo.modelledOptionPrice )<=0.0001 )
			break ;
		warOpt.sd = echoInfo.impliedVolitility ;

		i++ ;
	}while( i<7 ) ;

	/*
		���һ��, Ҫ���� ������ֵ.
	*/
	WARRANTOPT TempOpt ;
	memcpy( &TempOpt, &warOpt, sizeof(WARRANTOPT) ) ;
	TempOpt.T_t = TempOpt.T_t-1.0/365.0 ;   //ben 2017.6.29   5.0��Ϊ1.0  ����������
	echoInfo.TimeDecay = 0.0 ;
	if( TempOpt.T_t>0.0 )
	{
		BSMCALINFO TempInfo ;
		if( CalMOP_ByBSM( TempOpt, TempInfo )==TRUE && echoInfo.theta!=0.0 )
		{
			echoInfo.TimeDecay = (TempInfo.theta/echoInfo.theta)*100.0 - 100.0 ;
		}

	}

	return TRUE ;

}

BOOL CBSMWrapper::CalIV_BySection( WARRANTOPT& warOpt, BSMCALINFO& echoInfo ) 
{
	int count = 1 ;

	double dtMin = 0.0 ;
	double dtMax = 2.0 ;
	//double dtMin = 0.83 ;
	//double dtMax = 0.83 ;

	double dtAvg = 0.0 ;

	int i = 0 ;
	do
	{
		dtAvg = (dtMin+dtMax)/2 ;
		warOpt.sd = dtAvg ;
		if( CalMOP_ByBSM( warOpt, echoInfo )==FALSE )
		{
			memset( &echoInfo, 0, sizeof(echoInfo) ) ;
			return FALSE ;
		}

		// ��� iv<=0.0 || iv>=2.0, ������, û������. 
		if( echoInfo.impliedVolitility<=0.0f || echoInfo.impliedVolitility>=2.0f )
		{
			memset( &echoInfo, 0, sizeof(echoInfo) ) ;
			return FALSE ;
		}

		TRACE( "count:%d, min:%.8f, max:%.8f, MOP:%.8f\r\n", count, dtMin, dtMax, echoInfo.modelledOptionPrice ) ;
		count++ ;
		if( echoInfo.modelledOptionPrice<warOpt.warrantPrice )
		{
			dtMin = dtAvg ;
		}
		else
		{
			dtMax = dtAvg ;
		}

		if( fabs(echoInfo.modelledOptionPrice-warOpt.warrantPrice)<=0.00005 )
			break ;
		if( (dtMax-dtMin)<=0.00001 )
			break ;

		i++ ;

		TRACE( "count(%d) IV:%.3f, sd: %.3f\r\n", i, echoInfo.impliedVolitility, dtAvg ) ;


	}while( i<50 ) ;

	/*
		���һ��, Ҫ���� ������ֵ.
	*/
	WARRANTOPT TempOpt ;
	memcpy( &TempOpt, &warOpt, sizeof(WARRANTOPT) ) ;
	TempOpt.T_t = TempOpt.T_t-1.0/365.0 ;   //ben 2017.6.29   5.0��Ϊ1.0  ����������
	echoInfo.TimeDecay = 0.0 ;
	if( TempOpt.T_t>0.0 )
	{
		TempOpt.sd = dtAvg ;
		BSMCALINFO TempInfo ;
		if( CalMOP_ByBSM( TempOpt, TempInfo )==TRUE && echoInfo.theta!=0.0 )
		{
			echoInfo.TimeDecay = (TempInfo.theta/echoInfo.theta)*100.0 - 100.0 ;
		}

	}

	TRACE( "last IV:%.3f, sd: %.3f\r\n", echoInfo.impliedVolitility, dtAvg ) ;
	echoInfo.impliedVolitility = dtAvg ;
	return TRUE ;

}