#if !defined(AFX_CALENDAR_H__4C784250_DF23_46A1_A090_F83C6517B7CF__INCLUDED_)
#define AFX_CALENDAR_H__4C784250_DF23_46A1_A090_F83C6517B7CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Calendar.h : header file
//
#include "Strategy.h"
/////////////////////////////////////////////////////////////////////////////
// CCalendar dialog

class CCalendar : public CDialog
{
// Construction
public:
	CCalendar(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCalendar)
	enum { IDD = IDD_CALENDARDLG };
	CStatic	m_near;
	CStatic	m_far;
	CComboBox	m_CmbStk;
	CComboBox	m_CmbMth2;
	CComboBox	m_CmbMth1;
	CComboBox	m_CmbDebit;
	CComboBox	m_CmbCall;
	//}}AFX_DATA
	CStrategy *m_pStgy;
	Calend  cald;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalendar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCalendar)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeCmbcall();
	afx_msg void OnSelchangeCmbdebit();
	afx_msg void OnSelchangeCmbmonth1();
	afx_msg void OnSelchangeCmbmonth2();
	afx_msg void OnSelchangeCmbstrike();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALENDAR_H__4C784250_DF23_46A1_A090_F83C6517B7CF__INCLUDED_)
