// ConfDlg.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "ConfDlg.h"
#include <math.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfDlg dialog

char* szTitle[3] = {"Order Confirmation Dialog","�µ�ȷ��","�U��T�{"};
char* szDescpt[3] = {"Order Description","�µ�˵��","���f��"};
char* szBkEven[3] = {"Breakeven","��ͼ�","��̓r"};
char* szGain[3] = {"Max Gain","���ӯ��","���ӯ��"};
char* szLoss[3] = {"Max Loss","������","���̝�p"};
char* szCost[3] = {"Cost of Trade excluding commissions","���׳ɱ�(������Ӷ��)","���׳ɱ�(������Ӷ��)"};
char* szDebit[3] = {"Debit","����","����"};
char* szCredit[3] = {"Credit","�տ�","�տ�"};
char* szInfy[3] = {"Infinity","����","�o��"};

CConfDlg::CConfDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConfDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConfDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CConfDlg::~CConfDlg()
{
	m_brush.DeleteObject();
	m_font.DeleteObject();
}

void CConfDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConfDlg, CDialog)
	//{{AFX_MSG_MAP(CConfDlg)
	ON_WM_CTLCOLOR()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConfDlg message handlers

HBRUSH CConfDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if(nCtlColor ==CTLCOLOR_DLG) 
		return m_brush;
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

BOOL CConfDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(szTitle[m_pStgy->m_TTOptions->m_iLangType]);
	m_brush.CreateSolidBrush(RGB(255,255,255));
	LOGFONT nflog; 
	ZeroMemory(&nflog,sizeof(nflog)); 
	nflog.lfHeight=16; 
	nflog.lfCharSet=GB2312_CHARSET; 
	m_font.CreateFontIndirect(&nflog); 

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CConfDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
	}
	else
	{
		CPaintDC dc(this);
		//dc.SetBkMode(TRANSPARENT);
		int i,row,st;
		CRect rect;
		GetClientRect(&rect);
		CPen *oldpen = NULL;
		CFont *oldfont = NULL;
		CPen pen(PS_SOLID,1,RGB(211,211,211));  //��ɫ
		oldpen = dc.SelectObject(&pen);
		CSize size = dc.GetTextExtent("Order");
		oldfont = dc.SelectObject(&m_font);
		dc.SetTextColor(RGB(0,0,0));

		//dc.SetBkColor(RGB(255,192,203));
		CString str,str1,str2,strtmp;
		row = m_pStgy->m_nRow;
		st = -1;
		for( i=2;i<row+2;i++ )
		{
			strtmp = m_pStgy->m_list.GetItemText(i,1);
			if( strtmp=="-- --" )
				continue;
			if( strtmp.Find("Buy Call",0)!=-1 )
			{
				str1 = " B.C ";
			}
			else if( strtmp.Find("Buy Put",0)!=-1 )
			{
				str1 = " B.P ";
			}
			else if( strtmp.Find("Sell Call",0)!=-1 )
			{
				str1 = " S.C ";
			}
			else if( strtmp.Find("Sell Put",0)!=-1 )
			{
				str1 = " S.P ";
			}

			int itmp = st/2;
			st++;
			if( itmp==st/2 && str!="" )
				str += ", ";
			else if( itmp!=st/2 )
			{
				if( itmp==0 )
				{
					dc.FillSolidRect(rect.left+4,rect.top+2,rect.Width()-8,size.cy+8,RGB(255,192,203));
					dc.TextOut(rect.left+rect.Width()/2,rect.top+6,str);
				}
				else
				{
					dc.FillSolidRect(rect.left+4,rect.top+itmp*(size.cy+12)+2,rect.Width()-8,size.cy+8,RGB(255,192,203));
					dc.TextOut(rect.left+rect.Width()/2,rect.top+itmp*(size.cy+12)+6,str);
				}

				str = "";
			}

			strtmp = m_pStgy->m_list.GetItemText(i,2);
			str += strtmp;
			str += str1;
			strtmp = m_pStgy->m_list.GetItemText(i,3);
			str += strtmp;
			str += " @";
			strtmp = m_pStgy->m_list.GetItemText(i,5);
			str += strtmp;	
		}
		st = st/2;
		dc.FillSolidRect(rect.left+4,rect.top+st*(size.cy+12)+2,rect.Width()-8,size.cy+8,RGB(255,192,203));
		if( st==0 )
			dc.TextOut(rect.left+rect.Width()/2,rect.top+6,str);
		else
			dc.TextOut(rect.left+rect.Width()/2,rect.top+st*(size.cy+12)+6,str);

		for( i=1;i<=(st+5);i++ )
		{
			dc.MoveTo(rect.left,rect.top+i*(size.cy+12));
			dc.LineTo(rect.right,rect.top+i*(size.cy+12));
		}
		dc.SetBkMode(TRANSPARENT);
		dc.SelectObject(oldpen);
		dc.TextOut(rect.left+10,rect.top+6,szDescpt[m_pStgy->m_TTOptions->m_iLangType]);
		dc.TextOut(rect.left+10,rect.top+(st+1)*(size.cy+12)+6,szBkEven[m_pStgy->m_TTOptions->m_iLangType]);
		dc.TextOut(rect.left+10,rect.top+(st+2)*(size.cy+12)+6,szGain[m_pStgy->m_TTOptions->m_iLangType]);
		dc.TextOut(rect.left+10,rect.top+(st+3)*(size.cy+12)+6,szLoss[m_pStgy->m_TTOptions->m_iLangType]);
		dc.TextOut(rect.left+10,rect.top+(st+4)*(size.cy+12)+6,szCost[m_pStgy->m_TTOptions->m_iLangType]);
		
		CString strForm;
		if( m_pStgy->m_arrBrkValue.GetSize()==1 )
			m_pStgy->GetPriceTxt(m_pStgy->m_arrBrkValue[0],strForm);
		else if( m_pStgy->m_arrBrkValue.GetSize()==2 )
		{
			CString str;
			m_pStgy->GetPriceTxt(m_pStgy->m_arrBrkValue[0],str);
			strForm = str;
			strForm += "/";
			m_pStgy->GetPriceTxt(m_pStgy->m_arrBrkValue[1],str);
			strForm += str;
		}
		else if( m_pStgy->m_arrBrkValue.GetSize()==0 )
			strForm = "--/--";
		dc.TextOut(rect.left+rect.Width()/2,rect.top+(st+1)*(size.cy+12)+6,strForm);

		str.Format("$  %.0f",m_pStgy->Gain);
		if( m_pStgy->Gain==1.0 )
			str = szInfy[m_pStgy->m_TTOptions->m_iLangType];
		dc.TextOut(rect.left+rect.Width()/2,rect.top+(st+2)*(size.cy+12)+6,str);
		str.Format("$ %.0f",m_pStgy->Loss);
		if( m_pStgy->Loss==1.0 )
			str = szInfy[m_pStgy->m_TTOptions->m_iLangType];
		dc.TextOut(rect.left+rect.Width()/2,rect.top+(st+3)*(size.cy+12)+6,str);
		if( m_pStgy->principal>0 )
			str.Format("%s $ %.0f",szCredit[m_pStgy->m_TTOptions->m_iLangType],fabs(m_pStgy->principal*m_pStgy->m_lShares));
		else if( m_pStgy->principal<0 )
			str.Format("%s $ %.0f",szDebit[m_pStgy->m_TTOptions->m_iLangType],fabs(m_pStgy->principal*m_pStgy->m_lShares));
		else
			str = "$ 0";
		dc.TextOut(rect.left+rect.Width()/2,rect.top+(st+4)*(size.cy+12)+6,str);
		dc.SelectObject(oldfont);

		CDialog::OnPaint();
	}
}
