// MyStatic.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "MyStatic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyStatic


CMyStatic::CMyStatic()
{
	m_colBack = GetSysColor(COLOR_WINDOWTEXT);
	m_colTxt = GetSysColor(COLOR_3DFACE);
}

CMyStatic::~CMyStatic()
{
}


BEGIN_MESSAGE_MAP(CMyStatic, CStatic)
	//{{AFX_MSG_MAP(CMyStatic)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyStatic message handlers

void CMyStatic::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	//CString strTxt;
	//GetWindowText(strTxt);
	RECT rect;
	GetClientRect(&rect);
	dc.FillSolidRect(&rect,m_colBack);
	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor(m_colTxt);
	dc.TextOut(0,1,m_strText);
}

//DEL BOOL CMyStatic::OnEraseBkgnd(CDC* pDC) 
//DEL {
//DEL 	// TODO: Add your message handler code here and/or call default
//DEL /*
//DEL 	RECT rect;
//DEL 	GetClientRect(&rect);
//DEL 	pDC->FillSolidRect(&rect,RGB(0,0,0));
//DEL */
//DEL 	return CStatic::OnEraseBkgnd(pDC);
//DEL }

void CMyStatic::SetWindowText(LPCTSTR lpszString)
{
//	this->LockWindowUpdate();
//	CStatic::SetWindowText(lpszString);
//	this->UnlockWindowUpdate();
//	this->Invalidate();
	m_strText = lpszString;
	this->RedrawWindow();
}

void CMyStatic::SetBkColor(COLORREF colBk)
{
	m_colBack = colBk;
}

void CMyStatic::SetTxtColor(COLORREF colTxt)
{
	m_colTxt = colTxt;
}

void CMyStatic::SetColorMode(int colMode)
{
	if (colMode == 0  || colMode == 2 ) //��ɫ���߲�ɫ 
	{
		m_colTxt = GetSysColor(COLOR_WINDOWTEXT);
		 m_colBack= GetSysColor(COLOR_3DFACE);
	}
	else  //��ɫ
	{
		m_colBack = RGB(0,0,0);
		m_colTxt =  RGB( 4,185,0);

	}
	this->Invalidate();
}

BOOL CMyStatic::Create( LPCTSTR lpszText, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID  )
{
	// TODO: Add your specialized code here and/or call the base class
	m_strText = lpszText;
	return CStatic::Create( lpszText, dwStyle, rect, pParentWnd, nID  );
}