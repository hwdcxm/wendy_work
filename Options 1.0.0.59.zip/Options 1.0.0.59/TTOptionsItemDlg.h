// TTOptionsItemDlg1.h: interface for the CTTOptionsItemDlg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TTOPTIONSITEMDLG1_H__1F5F75E7_8C0A_11D3_BE5B_00A0CC23E61B__INCLUDED_)
#define AFX_TTOPTIONSITEMDLG1_H__1F5F75E7_8C0A_11D3_BE5B_00A0CC23E61B__INCLUDED_

#include "resource.h"       // main symbols
#include <atlhost.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_OPTIONS_COUNT 500

class CTTOptionsItemDlg   :
	public CAxDialogImpl<CTTOptionsItemDlg>
{
public:
	void AddFutText(int nIndex,LPCTSTR pszFutText);
	void AddName(int nIndex,LPCTSTR pszName);
	void AddCashCode(int nIndex,LPCTSTR pszCashCode);
	void AddOptCode(int nIndex,LPCTSTR pszCashCode);

	CTTOptionsItemDlg(int iLangType = 0);
	~CTTOptionsItemDlg();
	int  AddItemString(LPCTSTR pszText);
	enum {IDD = IDD_OPITEMDLG};
//	TCHAR m_szText[20][10];
//	TCHAR m_szFutText[20][10];
//	TCHAR m_szName[20][30];
	TCHAR m_szText[MAX_OPTIONS_COUNT][10];
	TCHAR m_szFutText[MAX_OPTIONS_COUNT][10];
	TCHAR m_szName[MAX_OPTIONS_COUNT][30];
	TCHAR m_szCashCode[MAX_OPTIONS_COUNT][10];
	TCHAR m_szOptCode[MAX_OPTIONS_COUNT][5];
	//TCHAR m_szVHSICode[MAX_OPTIONS_COUNT][10];
	int   m_nText;
	int   m_nSel;
	BOOL  m_bOver;
	HWND  m_hwndParent;
	int	  m_iLangType;

BEGIN_MSG_MAP(CTTOptionsItemDlg)
	MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)
	MESSAGE_HANDLER(WM_INITDIALOG,OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)	
	COMMAND_HANDLER(IDC_EDIT1, EN_CHANGE, OnChangeEdit1)
	//COMMAND_HANDLER(IDC_LV_OPTIONSITEM, LVN_SELCHANGE, OnSelchangeLb_optionsitem)
	
	MESSAGE_HANDLER(WM_LBUTTONUP, OnLButtonUP)
	MESSAGE_HANDLER(WM_CLOSE, OnClose)
	NOTIFY_HANDLER(IDC_LV_OPTIONSITEM, LVN_ITEMCHANGED, OnItemchangedLv_optionsitem)
	NOTIFY_HANDLER(IDC_LV_OPTIONSITEM, NM_DBLCLK, OnDblclkLv_optionsitem)
END_MSG_MAP()
	BOOL EndDialog(int nRetCode)
	{
		//ReleaseCapture();
		return CAxDialogImpl<CTTOptionsItemDlg>::EndDialog(nRetCode);
	}
	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		//CreateListBox();
		//CreateEdit();
		::EnableWindow(GetDlgItem(IDOK),FALSE);
		if(m_hwndParent != NULL)
		{
			RECT rc;
			::GetWindowRect(m_hwndParent,&rc);
			//ben 2017.07.18Ϊ���ڲ���ͼ��Ҳ�ܵ��� �޸ĵ�������
			::SetWindowPos(m_hWnd,NULL,rc.left,/*rc.bottom*/rc.top+25,0,0,SWP_NOSIZE|SWP_NOZORDER);
		}
		ListView_SetExtendedListViewStyle(GetDlgItem(IDC_LV_OPTIONSITEM),
			LVS_EX_FULLROWSELECT);
		LVCOLUMN lvColumn;
		lvColumn.mask = LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM; 
		lvColumn.fmt = LVCFMT_LEFT;
		lvColumn.cx = 65;
		lvColumn.iSubItem = 0;
		if(m_iLangType == 2)
		{
			lvColumn.pszText = _T("�N�X");
		}
		else if(m_iLangType == 1)
		{
			lvColumn.pszText = _T("����");
		}
		else
			lvColumn.pszText = _T("Code");
		ListView_InsertColumn(GetDlgItem(IDC_LV_OPTIONSITEM),0,&lvColumn);
		lvColumn.cx = 170;
		lvColumn.iSubItem = 1;
		if(m_iLangType == 2)
		{
			lvColumn.pszText = _T("�W��");
		}
		else if(m_iLangType == 1)
		{
			lvColumn.pszText = _T("����");
		}
		else
			lvColumn.pszText = _T("Name");
		ListView_InsertColumn(GetDlgItem(IDC_LV_OPTIONSITEM),1,&lvColumn);
		

		if(m_iLangType == 2)
		{
			SetDlgItemText(IDOK,"�T�w");
			SetDlgItemText(IDCANCEL,"����");
			SetWindowText("���v");
		}
		else if(m_iLangType == 1)
		{
			SetDlgItemText(IDOK,"ȷ��");
			SetDlgItemText(IDCANCEL,"ȡ��");
			SetWindowText("��Ȩ");
		}

		LVITEM lvItem;
		lvItem.mask = LVIF_TEXT;
		lvItem.iSubItem = 0;
		for(int j= 0; j< m_nText; j++)
		{
			lvItem.iItem = j;
			lvItem.pszText=(LPTSTR)m_szText[j];
			ListView_InsertItem(GetDlgItem(IDC_LV_OPTIONSITEM),&lvItem);
			ListView_SetItemText(GetDlgItem(IDC_LV_OPTIONSITEM),j,1,m_szName[j]);
		}
		//HWND hWnd = ::SetCapture(m_hWnd);
		return 0;  // Let the system set the focus
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		m_nSel = ListView_GetNextItem(GetDlgItem(IDC_LV_OPTIONSITEM),-1,LVNI_SELECTED);
		EndDialog(0);
		return 0;
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}	
	LRESULT OnLButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		
		return 0;
	}
	LRESULT OnLButtonUP(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		// TODO : Add Code for message handler. Call DefWindowProc if necessary.
		//ReleaseCapture();
		return 0;
	}
	LRESULT OnClose(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		//ReleaseCapture();
		return 0;
	}
	LRESULT OnItemchangedLv_optionsitem(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
	{
		::EnableWindow(GetDlgItem(IDOK),TRUE);
		m_nSel = ListView_GetNextItem(GetDlgItem(IDC_LV_OPTIONSITEM),-1,LVNI_SELECTED);
		return 0;
	}
	LRESULT OnDblclkLv_optionsitem(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
	{
		m_nSel = ListView_GetNextItem(GetDlgItem(IDC_LV_OPTIONSITEM),-1,LVNI_SELECTED);
		EndDialog(0);
		return 0;
	}
	
	LRESULT OnChangeEdit1(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		
//		GetDlgItem(IDC_EDIT1);
		CComBSTR   text;   
	    GetDlgItemText(IDC_EDIT1,   text.m_str);                 
	
		CString str = text.m_str;	
		CString strText;
		int bestindex = -1;
		int bestfrom  = m_nText;
		for ( int x = 0; x < m_nText; x++ )
		{
			strText = m_szText[x];
			strText.TrimRight();
			if(strText == str)  //��ȫ��ͬ�������
			{
				bestindex=0;
				m_nSel = x;
				::EnableWindow(GetDlgItem(IDOK),TRUE);
				ListView_SetItemState(GetDlgItem(IDC_LV_OPTIONSITEM),m_nSel,LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED);
				ListView_EnsureVisible(GetDlgItem(IDC_LV_OPTIONSITEM),m_nSel,TRUE);
				return 1;
			}
			else
			{
				::EnableWindow(GetDlgItem(IDOK),FALSE);
			}

			int from = strText.Find(str);		
			ATLTRACE("OnChangeEdit1 %d %s from=%d\r\n",x,m_szText[x],from);		
			
			if ( from != -1 && from < bestfrom )
			{
				bestindex = x;
				bestfrom  = from;

				ATLTRACE("OnChangeEdit1 bestindex=%d bestfrom=%d\r\n",bestindex,bestfrom);		
			}
		}
		

		ATLTRACE("****OnChangeEdit1 bestindex=%d bestfrom=%d m_nSel=%d\r\n",bestindex,bestfrom,m_nSel);		
		if ( bestindex != -1 && m_nSel != bestindex )
		{
			//m_nSel = bestindex;
			ListView_EnsureVisible(GetDlgItem(IDC_LV_OPTIONSITEM),bestindex,TRUE);  //ֻ��ʾ,��ѡ��
		}


		return 0;
	}
};

#endif // !defined(AFX_TTOPTIONSITEMDLG1_H__1F5F75E7_8C0A_11D3_BE5B_00A0CC23E61B__INCLUDED_)




