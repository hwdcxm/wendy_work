#if !defined(AFX_TARGET_H__D9DE1533_685C_4BF9_9C27_D5FFEC42966C__INCLUDED_)
#define AFX_TARGET_H__D9DE1533_685C_4BF9_9C27_D5FFEC42966C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Target.h : header file
//
#include "resource.h"
/////////////////////////////////////////////////////////////////////////////
// CTarget dialog
class CTarget : public CDialog
{
// Construction
public:
	CTarget(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTarget)
	enum { IDD = IDD_TARGETDLG };
	float	m_fLo;
	float	m_fUp;
	//}}AFX_DATA
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTarget)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTarget)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TARGET_H__D9DE1533_685C_4BF9_9C27_D5FFEC42966C__INCLUDED_)
