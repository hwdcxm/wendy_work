// TTOptions.cpp : Implementation of CTTOptions

#include "stdafx.h"
#include "Options.h"
#include "TTOptions.h"
#include "listctrlOptions.h"
#include "LstCfg.h"
#include "wndBgn.h"
#include "..\common\common.h"
#include "..\DataProxy\DataProxy_i.c"
#include "..\common\GroupsMng_i.c"
#include "WTTCommon_i.c"
#include "dlgMonth.h"
#include "btnWithTip.h"
#include "Strategy.h"
#include <afxext.h>
#include "..\\common\\TTCfgObject.h"
#include <math.h>
#include "PolyNormalTable.h"


#define CFGID_OPTIONS			5600
#define CFGID_OPTIONS_COLOR		17

#define CONST_STEP  30

//andy add 2012.02.07 for calc IV Data.
//#include "BM1976.h"
//#include "BSM.h"
//ben 2017.7.28 �Ƶ�ͷ�ļ�����


//  #define _IV_LOG   ������ʱ����дLOG�ļ�

ItemOptions::ItemOptions()
{
	ReInit() ;
}

void ItemOptions::ReInit()
{
	memset( this, 0, sizeof(*this) ) ;
	
}

/////////////////////////////////////////////////////////////////////////////
// CTTOptions

UINT AdviseThread(LPVOID lParam)
{
	UINT bRet;
	CTTOptions* pv = (CTTOptions*)lParam;

	try
	{
	if(pv->m_bAdvise)
	{
		pv->m_dwAdvise = 0;
		bRet =  (S_OK == AtlAdvise(pv->m_pDataProxy,pv->GetUnknown(),IID__ITTDataProxyEvents,&pv->m_dwAdvise));
		pv->SendMonthRequestFrame();
		pv->SendRequestFrame();
		pv->SendDFRequestFrame();
	}
	else
	{
		if(!pv->m_bAdvise)
		{
			bRet = (S_OK == AtlUnadvise(pv->m_pDataProxy,IID__ITTDataProxyEvents,pv->m_dwAdvise));
		}
	}
	}
	catch(...)
	{
	}

	return bRet;
}


IUnknown * CTTOptions::m_pICfgCenter = NULL;

CTTOptions::CTTOptions() 
{

	m_nColorMode = 0;  //��ɫ  0��ɫ   1��ɫ   2��ɫ

	m_lShares = 1;  //Ben 2017.06.05
	m_fBF = 0.0;

	m_bStgyMode = -1;
	m_bChanged = FALSE;

	m_pICfgCenter = NULL;

	m_bWindowOnly = TRUE;
	m_hAdviseThread = NULL;

	m_bUseNtMth = FALSE;

	m_pwndCls = NULL;
	m_bSelectWin = 0;
	m_nDivision = -1;

	m_pList1 = new ClistctrlOptions();
	m_pList1->m_TTOptions = this;
	ASSERT(m_pList1!=NULL);

	// rise list head.
	m_pLstHeadsInfo = new LstHeadsInfo( MACRO_MaxSubItems ) ;
	ASSERT(m_pLstHeadsInfo != NULL) ;
	int i=0 ;

	GetRootPath();

	m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT ) ;  // LVCFMT_RIGHT no effect ???
		m_pLstHeadsInfo->m_pBuf[i++].Config( "High", "���", "�̰�", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Low", "���", "�̧C", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vol","����", "�`��", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "L.Q.","����", "���i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last", "�ɼ�", "����", 64/*80*/, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q.", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid", "����", "�R�J", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask",  "����", "��X", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q.", "����", "��i", 30, LVCFMT_RIGHT ) ;
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Strike",  "��ʹ��", "��ϻ�", 30, LVCFMT_RIGHT ) ;

		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid",  "����", "�R�J", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask","����", "��X", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q", "����", "��i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last","�ɼ�", "����", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "L.Q.","����", "���i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vol","����", "�`��", 64, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "High", "���", "�̰�", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Low", "���", "�̧C", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT  ) ;

	m_pwndBgn = new CwndBgn() ;
	ASSERT( m_pwndBgn!=NULL ) ;

	//m_pHeader = new CHeaderCtrl() ;
	m_pHeader = new CHeaderCtrlOptions() ; //�Ϲ���Ȩ ��ͷ
	m_pHeader->m_TTOptions = this;
	ASSERT( m_pHeader!=NULL ) ;

	m_pbtnItemCode = new CbtnWithTip() ;  //
	ASSERT( m_pbtnItemCode!=NULL ) ;
	m_pstaItemName = new CStatic() ;
	ASSERT( m_pstaItemName!=NULL ) ;
	m_pbtnOptMonth = new CbtnWithTip() ;
	ASSERT( m_pbtnOptMonth!=NULL ) ;
	m_pstaCash = new CStatic() ;
	ASSERT( m_pstaCash!=NULL ) ;
	m_pstaFutures = new CStatic() ;
	ASSERT( m_pstaFutures!=NULL ) ;
	m_pstaVHSI = new CStatic() ;
	ASSERT( m_pstaVHSI!=NULL ) ;
	m_pstaEAS = new CStatic() ;
	ASSERT( m_pstaEAS!=NULL ) ;
//	m_pbtnMini= new CbtnWithTip() ;
	m_pstaExpiryDate = new CStatic() ;
	ASSERT( m_pstaExpiryDate!=NULL ) ;
			
	m_pbtnHighPrice = new CbtnWithTip() ;
	ASSERT( m_pbtnHighPrice!=NULL ) ;
	m_pbtnColumnWidth = new CbtnWithTip() ;
	ASSERT( m_pbtnColumnWidth!=NULL ) ;
	m_pbtnIVMode = new CbtnWithTip() ;
	ASSERT( m_pbtnIVMode!=NULL ) ;
	m_pbtnIVMode->m_TTOptions = this;
	m_pbtnExportCSV = new CbtnWithTip() ;
	ASSERT( m_pbtnExportCSV!=NULL ) ;
	m_pbtnSimple = new CbtnWithTip() ;
	ASSERT( m_pbtnSimple!=NULL ) ;
	m_pbtnStra = new CbtnWithTip();
	ASSERT( m_pbtnStra!=NULL ) ;
	m_pbtnStra->m_TTOptions = this;

	m_pedtCash = new CStatic() ;
	ASSERT( m_pedtCash!=NULL ) ;
	m_pedtFutures = new CStatic() ;
	ASSERT( m_pedtFutures!=NULL ) ;
	m_pedtVHSI = new CStatic() ;
	ASSERT( m_pedtVHSI!=NULL ) ;
	m_pedtEAS = new CStatic() ;
	ASSERT( m_pedtEAS!=NULL ) ;
	

	m_pDataBuf = new ItemOptions[MACRO_MaxItems] ;
	ASSERT( m_pDataBuf!=NULL ) ;
	m_nDataTotal = 0 ;
	for(i=0;i<MACRO_MaxItems;i++)
	{
		m_fCallOIDiff[i] = 0.0;
		m_fPutOIDiff[i] = 0.0;
	}

//	CButton *p_MyBut;
//	p_MyBut = NewMyButton(ID_Mini, CRect(55,20,95,35), 0 );

	m_nControlID = 0;
	//_tcscpy(m_strFontName, _T("Lucida Console"));
	_tcscpy(m_strFontName, _T("Courier New"));  //�����ʼ����
	m_nFontSize = 120;  //�����ʼ��С �ϰ棺110

	m_cbGroupCode = 'A';		
	memset( m_szItemCode, 0, sizeof(m_szItemCode) ) ;
	memcpy( m_szItemCode  ,"HSI     ", G_GENCODELEN);

	memset( m_szItemCashCode, 0, sizeof(m_szItemCashCode) ) ;
	memcpy( m_szItemCashCode  ,"HSI     ", G_GENCODELEN);

	memset( m_szVHSICode, 0, sizeof(m_szVHSICode) ) ;
	memcpy( m_szVHSICode  ,"VHSI    ", G_GENCODELEN);

	memset( m_szOptCode, 0, sizeof(m_szOptCode) ) ;
	memcpy( m_szOptCode  ,"HSI  ", 5);

	memset( m_szFuturesCode, 0, sizeof(m_szFuturesCode) ) ;
	lstrcpy(m_szFuturesTitle,_T("HI"));
	m_lTransdate = CTime::GetCurrentTime().GetYear()*100 + CTime::GetCurrentTime().GetMonth();
	MakeFutCode(m_szFuturesCode,m_szFuturesTitle,m_lTransdate%100,(m_lTransdate/100)%100);
	sprintf(m_szText, "%2d/%4d",m_lTransdate%100,m_lTransdate/100);

	memset( m_szCash, 0, sizeof(m_szCash) ) ;
	memset( m_szFutures, 0, sizeof(m_szFutures) ) ;

	sprintf(m_szPCR,"PCR=0.00");

	m_bClick_SelMonth = FALSE ;

	m_bShowHighPrice = 1;
	m_bIVMode = 0;
	m_bSimple = 0;
	m_bCash = FALSE;
	for(i=0;i<2;i++)
	{
		m_iCallOIUpRow[i] = 0;
		m_iPutOIUpRow[i] = 0;
		m_iCallOIDwRow[i] = 0;
		m_iPutOIDwRow[i] = 0;
		m_iCallMaxRow[i] = 0;
		m_iPutMaxRow[i] = 0;
	}
	
	ReadExpiryDateListFile();
	GetExpiryTime();
	ReadHKStockOccFile();
	ReadMarginFile();
	ReadRclFile();

	InitializeCriticalSection(&m_cs);
//	m_bClickMonth = FALSE;

}

CTTOptions::~CTTOptions()
{
	if(m_pList1 != NULL)
	{
		delete m_pList1 ;
		m_pList1 = NULL ;
	}
	if( m_pLstHeadsInfo != NULL )
	{
		delete m_pLstHeadsInfo ;
		m_pLstHeadsInfo = NULL ;
	}

	if( m_pwndBgn != NULL )
	{
		delete m_pwndBgn ;
		m_pwndBgn = NULL ;
	}
	if( m_pHeader != NULL )
	{
		delete m_pHeader ;
		m_pHeader = NULL ;
	}
	if( m_pbtnItemCode != NULL )
	{
		delete m_pbtnItemCode ;
		m_pbtnItemCode = NULL ;
	}
	if( m_pstaItemName != NULL )
	{
		delete m_pstaItemName ;
		m_pstaItemName = NULL ;
	}

	if( m_pstaExpiryDate != NULL )
	{
		delete m_pstaExpiryDate ;
		m_pstaExpiryDate = NULL ;
	}


	if( m_pbtnOptMonth != NULL )
	{
		delete m_pbtnOptMonth ;
		m_pbtnOptMonth = NULL ;
	}

	if( m_pbtnHighPrice!=NULL )
	{
		delete m_pbtnHighPrice ;
		m_pbtnHighPrice = NULL ;
	}

	if( m_pbtnColumnWidth!=NULL )
	{
		delete m_pbtnColumnWidth ;
		m_pbtnColumnWidth = NULL ;
	}

	if( m_pbtnIVMode!=NULL )
	{
		delete m_pbtnIVMode ;
		m_pbtnIVMode = NULL ;
	}

	if( m_pbtnExportCSV!=NULL )
	{
		delete m_pbtnExportCSV ;
		m_pbtnExportCSV = NULL ;
	}
	if( m_pbtnStra!=NULL )
	{
		delete m_pbtnStra ;
		m_pbtnStra = NULL ;
	}
	if( m_pbtnSimple!=NULL )
	{
		delete m_pbtnSimple ;
		m_pbtnSimple = NULL ;
	}

	if( m_pwndCls!=NULL )
	{
		delete m_pwndCls;
		m_pwndCls = NULL;
	}


	if( m_pstaCash != NULL )
	{
		delete m_pstaCash ;
		m_pstaCash = NULL ;
	}
	if( m_pstaVHSI != NULL )
	{
		delete m_pstaVHSI ;
		m_pstaVHSI = NULL ;
	}
	if( m_pstaEAS != NULL )
	{
		delete m_pstaEAS ;
		m_pstaEAS = NULL ;
	}
	if( m_pstaFutures != NULL )
	{
		delete m_pstaFutures ;
		m_pstaFutures = NULL ;
	}
	if( m_pedtCash != NULL )
	{
		delete m_pedtCash ;
		m_pedtCash = NULL ;
	}
	if( m_pedtVHSI != NULL )
	{
		delete m_pedtVHSI ;
		m_pedtVHSI = NULL ;
	}
	if( m_pedtEAS != NULL )
	{
		delete m_pedtEAS ;
		m_pedtEAS = NULL ;
	}
	if( m_pedtFutures != NULL )
	{
		delete m_pedtFutures ;
		m_pedtFutures = NULL ;
	}
	if( m_pDataBuf != NULL )
	{
		delete [] m_pDataBuf ;
		m_pDataBuf = NULL ;
	}
	if(m_hAdviseThread != NULL)
	{
		CloseHandle(m_hAdviseThread);
		m_hAdviseThread=NULL;
	}

	DeleteCriticalSection(&m_cs);
}
/*CButton* CTTOptions::NewMyButton(int nID,CRect rect,int nStyle)
{
	CString m_Caption;
	m_Caption.LoadString( nID ); //ȡ��ť����
	CButton *p_Button = new CButton();
	ASSERT_VALID(p_Button);
//	p_Button->Create( m_Caption, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | nStyle, rect, this, nID ); //������ť
	return p_Button;
} */
STDMETHODIMP CTTOptions::InitObject()
{
	CComQIPtr<ITTObject,&IID_ITTObject> pObj(m_pMainFrm);
	if(pObj == NULL)
		S_FALSE;

	LoadValue() ;
	GetDvdInfo();

	//ʵ�ּ���OptionϵͳĬ�ϱ�����ɫ
	LoadValueColor();
	LoadDataColor();
	UpdataView();


	//���������ʼֵ,������ٻظ�����ʼ��ʾ״̬
	for(int i =0; i< MACRO_MaxSubItems ; i++)
	{
		m_pList1->SetColsOriginWidthValue(i,m_pList1->GetColumnWidth(i));
	}

	ResetCtrls() ;

	OnSelectColumnWidth(); //�����п�����ֹ������ʱ��optionÿ�еĿ��ȱ�������Ļ�������û���ݵļ���              Keeping 2014-11-7
	ResizeHeaderCtrl();    //���¼����ⲿ��ͷ���ȣ����ػ��ⲿ��ͷ���ⲿ��ͷ�Ŀ����Ǹ���CListCtrl��ͷ�Ŀ�����ֵ��
	
	ResetView();

	return S_OK;

}
STDMETHODIMP CTTOptions::Activate(int nState)
{
	switch(nState)
	{
	case MACRO_CmdStart: //Activate the object
		{
			
			if(AdviseDataProxy(TRUE))
			{
				
			}						
		}
		break;
	case MACRO_CmdStop:  //Deactivte the object
		//ShowControls(FALSE);
		SendEndFrame();
		SendDFChlFrame(FALSE);
		if( m_pwndCls!=NULL )
		{
			for( int i=0;i<m_pwndCls->m_StgyList.GetSize();i++ )
			{
				long lTransdate = m_pwndCls->m_StgyList[i].m_lExpTime/100;
				if( m_pwndCls->m_ExtList[i].b_weekly==1 )
					lTransdate = m_pwndCls->m_StgyList[i].m_lExpTime;
				SendUpdateRP(FALSE,m_pwndCls->m_StgyList[i].m_szCode,lTransdate);
				if( m_pwndCls->m_ExtList[i].cald.lMonth2!=0 )
				{
					long lm = m_pwndCls->m_ExtList[i].cald.lMonth2;
					if( m_pwndCls->m_ExtList[i].b_Mth2_Weekly==0 )
						lm = lm/100;
					SendUpdateRP(FALSE,m_pwndCls->m_StgyList[i].m_szCode,lm);
				}
			}
		}
		AdviseDataProxy(FALSE);
		//SaveLastPage();
		//m_bActive = FALSE;
		//WriteStorage();
		break;
	default:
		break;
	}
	
	return S_OK;
}
STDMETHODIMP CTTOptions::GetState(int* pnState)
{
	if (pnState == NULL)
		return E_POINTER;
	return E_NOTIMPL;
}
STDMETHODIMP CTTOptions::GetByID(int nID, VARIANT** ppVar)
{
	if (ppVar == NULL)
		return E_POINTER;
	switch(nID)
	{
	case TTPID_GetCtrlItemCode:
		{
			DOUBLE dbVal;
			memcpy(&dbVal,m_szItemCode,8);
			(*ppVar)->vt = VT_R8  ;
			(*ppVar)->dblVal = dbVal;
			return S_OK;
		}
		break;			
	case TTPID_Window_TYPE:
		//#define WINDOW_TYPE_OPTIONS		(10)
		(*ppVar)->vt = VT_I4  ;
		(*ppVar)->lVal = 10   ;
		return S_OK;
		break;
	case TTPID_SystemObject:
		break;
	case TTPID_Container:

		break;
	case TTPID_RootStorage:
		break;
	case TTPID_ContainerStorage:
		break;
	case TTPID_Storage:
		break;
	case TTPID_Stream:
		break;
	case TTPID_Exception:
		break;
	case TTPID_DataProxy:
		break;
	case TTPID_MainFrame:
		break;
	case TTPID_SystemDefault:
		break;
	case TTPID_UserStg:
		break;
	case TTPID_DataFrameMAS:
		break;
	case TTPID_GiveMeUTitle:
		{
			(*ppVar)->vt = VT_BSTR;
			CComBSTR bstrName = _T("Options");
			if(m_iLangType == 2)
			{
				bstrName =_T("���v");
			}
			else if(m_iLangType ==1)
			{
				bstrName = _T("��Ȩ");
			}
			
			if( strlen(m_szItemCode)>0 )
			{
				CString szTemp(m_szItemCode) ;
				szTemp.TrimRight( ' ' ) ;

				bstrName.Append( _T(".") ) ;
				bstrName.Append( szTemp ) ;
				if( strlen(m_szText)>0 )
				{
					bstrName.Append( _T(".") ) ;
					bstrName.Append( m_szText ) ;
				}

			}
			(*ppVar)->bstrVal = bstrName;
			return S_OK;
		}
		break;	
	default:
		break;
	}		
	return E_NOTIMPL;
}

STDMETHODIMP CTTOptions::PutByID(int nID, VARIANT* pVar)
{
	if (pVar == NULL)
		return E_POINTER;
	switch(nID)
	{
	case TTPID_OptionsFiles:
		{
			switch(pVar->vt)
			{
			case 1:           //clmcurr.csv
				//WriteLogFile("clmcurr.csv");
				ReadMarginFile();
				RefreshFile();
				break;
			case 2:           //options.exp
				//WriteLogFile("options.exp");
				ReadExpiryDateListFile();
				if( m_pwndCls!=NULL && m_pwndCls->IsWindowVisible() )
				{
					m_pwndCls->m_nRetn = m_pwndCls->PrePaint();
					
					
					if( m_pwndCls->m_nRetn==0 )
						break;
					
					m_pwndCls->SetListMode();
					m_pwndCls->SelectType();
					if( m_pwndCls->m_bMode!=1 )
					{
						m_pwndCls->DrawIncomeLine();
					}
				}
				break;
			case 3:           //hkstock.occ
				break;
			case 4:           //hkstock2.occ
				//WriteLogFile("hkstock2.occ");
				ReadHKStockOccFile();
				RefreshFile();
				break;
			}
		}
		break;
	case TTPID_ItemCodeEx:
		{
			SpeedCode spCode;
			memcpy(&spCode,pVar->pcVal,sizeof(spCode)); 

			OnSelectItemCode2(spCode.dbICode);
		}
		break;
	case TTPID_SystemObject:
		{
			m_pSystemObj = pVar->punkVal;
			if(m_pSystemObj == NULL)
			{
				AtlTrace(_T("OptionsTab: Can't get SystemObj\n"));
				return S_FALSE;
			}
			CComQIPtr<ITTObject,&IID_ITTObject> pObj(m_pSystemObj);
			if(pObj == NULL)
			{
				AtlTrace(_T("OptionsTab: Can't get interface ITTObject of SystemObject\n"));
				return S_FALSE;
			}
			VARIANT var;
			var.vt = VT_UNKNOWN;
			VARIANT *pVar1;
			pVar1= &var;
			pObj->GetByID(TTPID_DataProxy,&pVar1);
			m_pDataProxy = pVar1->punkVal;
			if(m_pDataProxy == NULL)
			{
				AtlTrace(_T("OptionsTab: Can't get DataProxy from SystemObject\n"));
				return S_FALSE;
			}
			var.vt = VT_I4;
			pVar1= &var;
			pObj->GetByID( TTPID_ObjGlobalID,&pVar1);
			m_dwID = pVar1->lVal;
			var.vt = VT_UNKNOWN;
			pVar = &var;
			pObj->GetByID(TTPID_GroupsMng,&pVar1);
			if(pVar1->punkVal == NULL)
				return S_FALSE;
			m_pGrpMng = pVar1->punkVal;
			pObj->GetByID(TTPID_MainFrame,&pVar1);
			if(pVar1->punkVal == NULL)
				return S_FALSE;
			m_pMainFrm = pVar1->punkVal;
			
			CComQIPtr<ITTObject,&IID_ITTObject> pMainFrm(m_pMainFrm);
			if(m_pMainFrm ==NULL)
				return S_FALSE;
			pMainFrm->GetByID(TTPID_IS_SYSTEM_DESKTOP,&pVar1);

			m_bSystemdesktop=pVar1->boolVal;

			//�ڵ����ɫ�尴ťʱ������m_pICfgCenter��ֵ������������ɫ�尴ť������   2014-9-8  Keeping
			CComQIPtr<ITTObject> pIObject(m_pMainFrm);
			if(pIObject != NULL)
			{
				var.vt = VT_UNKNOWN;
				pVar1 = &var;
				if(pIObject->GetByID(TTPID_ConfigCenter,&pVar1) == S_OK)
				{
					m_pICfgCenter = pVar1->punkVal;
					TRACE(_T("Get CfgCenter object addr: 0x%x\n"), m_pICfgCenter);
				}
			}
			//////////////////////////////////////////
			   

		}
		break;
	case TTPID_Container:

		break;
	case TTPID_RootStorage:
		break;
	case TTPID_ContainerStorage:
		break;
	case TTPID_Storage:
		break;
	case TTPID_Stream:
		break;
	case TTPID_Exception:
		break;
	case TTPID_DataProxy:
		m_pDataProxy = pVar->punkVal;
		break;
	case TTPID_MainFrame:
		break;
	case TTPID_SystemDefault:
		break;
	case TTPID_UserStg:
		break;
	case TTPID_DataFrameMAS:		
		break;
	case TTPID_ControlStorage:
		break;
	case TTPID_MainCommand:
			{
				//�������ñ�����ɫ����Ϣ
				long nCommand = pVar->lVal;	
				if( nCommand == TT_BT_SETUP )
				{
					Setup();
				}
				
	

				BOOL bDirty = TRUE ;
				int nValu = (long)pVar->lVal;

				if( nValu==TT_CD_SAVESETTING )
				{
					SaveValue() ;
					//add 2014.9.25   Keeping
					SaveValueColor();
					SaveDataColor();
					//////////////////////////
				}
				else
				if((nValu == TT_BT_FZOOMIN) || (nValu == TT_BT_FZOOMOUT))
				{
					Zoom(nValu);
				}
				else
				if((nValu == TT_BT_LANGENG) || (nValu == TT_BT_LANGCNS) ||
					(nValu == TT_BT_LANGCNT))
				{
					switch( nValu )
					{
						case TT_BT_LANGENG:
							if( m_iLangType!=0 )
							{
								m_iLangType = 0 ;
								m_pbtnItemCode->m_pToolTipCtrl1->UpdateTipText(TOOLTIP1_ENG,m_pbtnItemCode);
								m_pbtnOptMonth->m_pToolTipCtrl1->UpdateTipText(TOOLTIP2_ENG, m_pbtnOptMonth); 
								m_pbtnHighPrice->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_HIGH_ENG,m_pbtnHighPrice);
//								m_pbtnColumnWidth->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_COLUMN_ENG, m_pbtnColumnWidth); 
								m_pbtnIVMode->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_IV_ENG, m_pbtnIVMode); 
								m_pbtnExportCSV->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_ExportCSV_ENG, m_pbtnExportCSV); 
								m_pbtnSimple->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_Simple_ENG, m_pbtnSimple);
								m_pbtnStra->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_Stra_ENG, m_pbtnStra);
								bDirty = TRUE ;
							}
							break;
						case TT_BT_LANGCNS:
							if( m_iLangType!=1 )
							{
								m_iLangType = 1 ;
								m_pbtnItemCode->m_pToolTipCtrl1->UpdateTipText(TOOLTIP1_CNS,m_pbtnItemCode);
								m_pbtnOptMonth->m_pToolTipCtrl1->UpdateTipText(TOOLTIP2_CNS, m_pbtnOptMonth);
								m_pbtnHighPrice->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_HIGH_CNS,m_pbtnHighPrice);
//								m_pbtnColumnWidth->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_COLUMN_CNS, m_pbtnColumnWidth); 
								m_pbtnIVMode->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_IV_CNS, m_pbtnIVMode); 
								m_pbtnExportCSV->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_ExportCSV_CNS, m_pbtnExportCSV); 
								m_pbtnSimple->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_Simple_CNS, m_pbtnSimple);
								m_pbtnStra->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_Stra_CNS, m_pbtnStra);
								bDirty = TRUE ;
							}
							break;
						case TT_BT_LANGCNT:
							if( m_iLangType!=2 )
							{
								m_iLangType = 2 ;
								m_pbtnItemCode->m_pToolTipCtrl1->UpdateTipText(TOOLTIP1_CNT,m_pbtnItemCode);
								m_pbtnOptMonth->m_pToolTipCtrl1->UpdateTipText(TOOLTIP2_CNT, m_pbtnOptMonth);
								m_pbtnHighPrice->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_HIGH_CNT,m_pbtnHighPrice);
//								m_pbtnColumnWidth->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_COLUMN_CNT, m_pbtnColumnWidth); 
								m_pbtnIVMode->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_IV_CNT, m_pbtnIVMode); 
								m_pbtnExportCSV->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_ExportCSV_CNT, m_pbtnExportCSV); 
								m_pbtnSimple->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_Simple_CNT, m_pbtnSimple);
								m_pbtnStra->m_pToolTipCtrl1->UpdateTipText(TOOLTIP_Stra_CNT, m_pbtnStra);
								bDirty = TRUE ;
							}
							break;
						default:
							break;
					}
					if( bDirty==TRUE )
					{
						//SendTitle();
						SetLang() ;
					}
					
				}//end if( Lang. )

			}//end block.
			break;

		case  TTPID_ControlID:
			m_nControlID = pVar->lVal;
			break;
		case TT_CD_PRINTDC:
			OnOptionsPrint((LPVOID)pVar->lVal);
			break;
		case TT_CD_PRINTINFO:
			OnSetOptionsPrintInfo((LPVOID)pVar->lVal);
			break;
		case TTPID_HELP:
			HtmlHelp(this->m_hWnd,".\\wtt.chm::/chap1/tele_detail_future.htm",
							HH_DISPLAY_TOPIC,NULL);
		break;
		default:
			break;
	}
	return S_OK;
}
STDMETHODIMP CTTOptions::GetByName(BSTR strName, VARIANT** ppVar)
{
	if (ppVar == NULL)
		return E_POINTER;
	
	return E_NOTIMPL;
}
STDMETHODIMP CTTOptions::PutByName(BSTR strName, VARIANT* pVar)
{
	if (pVar == NULL)
		return E_POINTER;

	return E_NOTIMPL;
}

LRESULT CTTOptions::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	// TODO : Add Code for message handler. Call DefWindowProc if necessary.
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	RECT rect ;

	m_pwndBgn->Create( CwndBgn::m_strMyClass, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN , rect, CWnd::FromHandle(m_hWnd), NULL ) ;
	//::SetClassLong( m_pwndBgn->m_hWnd, GCL_HBRBACKGROUND, (long)GetStockObject(LTGRAY_BRUSH) ) ;
	m_pwndBgn->m_pOwner = this ;

	m_pstaItemName->Create( "", WS_CHILD | WS_VISIBLE | SS_CENTERIMAGE, rect, m_pwndBgn, 0xffff );
	m_pstaCash->Create( "", WS_CHILD | WS_VISIBLE  | SS_CENTERIMAGE | SS_RIGHT, rect, m_pwndBgn, 0xffff );
	m_pstaFutures->Create( "", WS_CHILD | WS_VISIBLE  | SS_CENTERIMAGE | SS_RIGHT, rect, m_pwndBgn, 0xffff );
	m_pstaVHSI->Create( "", WS_CHILD | WS_VISIBLE  | SS_CENTERIMAGE | SS_RIGHT, rect, m_pwndBgn, 0xffff );
	m_pstaEAS->Create( "", WS_CHILD | WS_VISIBLE  | SS_CENTERIMAGE | SS_RIGHT, rect, m_pwndBgn, 0xffff );
	m_pstaExpiryDate->Create( "", WS_CHILD | WS_VISIBLE  | SS_CENTERIMAGE | SS_LEFT, rect, m_pwndBgn, 0xffff );

	m_pHeader->Create( WS_CHILD|WS_VISIBLE|HDS_HORZ|WS_DISABLED, rect, m_pwndBgn, MACRO_HeaderID ) ;
	m_pHeader->ModifyStyleEx( 0, WS_EX_CLIENTEDGE ) ;//�޸Ĵ��ڷ��
	HDITEM item ;
	item.mask = HDI_TEXT | HDI_WIDTH | HDI_FORMAT ;
	item.cxy = 200 ;
	item.fmt = HDF_STRING | HDF_CENTER;
	item.pszText = "" ;
	m_pHeader->InsertItem( 0, &item ) ;
	item.cxy = 80 ;
	m_pHeader->InsertItem( 1, &item ) ;
	item.cxy = 200 ;
	m_pHeader->InsertItem( 2, &item ) ;

	
	DWORD dwStyle = WS_CHILD | WS_BORDER | LVS_REPORT | LVS_SINGLESEL | LVS_OWNERDATA | LVS_NOSORTHEADER |LVS_OWNERDRAWFIXED;

	//DWORD dwStyle = WS_VISIBLE|WS_CHILD | /*WS_BORDER |*/ LVS_REPORT /*| LVS_SINGLESEL | LVS_SHOWSELALWAYS*/ | LVS_OWNERDATA | LVS_NOSORTHEADER /*|WS_CLIPSIBLINGS*/ ;
	m_pList1->Create( dwStyle, rect, m_pwndBgn, MACRO_List1ID );	
	m_pList1->SetExtendedStyle( m_pList1->GetExtendedStyle()|LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT | LVS_REPORT ) ;

	if (m_nColorMode==_COLORMODE_BK_WHITE) 
	{
		m_pList1->SetExtendedStyle( m_pList1->GetExtendedStyle()|LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT|LVS_EX_HEADERDRAGDROP ) ;
		m_pList1->SetBkColor(RGB(0xff,0xff,0xff));
	}
	else
	{
		DWORD dwStyle = m_pList1->GetExtendedStyle()|LVS_EX_FULLROWSELECT|LVS_EX_HEADERDRAGDROP;
		dwStyle = dwStyle&(~LVS_EX_GRIDLINES);
		m_pList1->SetExtendedStyle( dwStyle ) ;
		m_pList1->SetBkColor(RGB(0,0,0));
	}

	//m_pList1->GetDlgItem(0)->ModifyStyle( 0, WS_CLIPSIBLINGS ) ;
	m_pLstHeadsInfo->CreateLstHead( *m_pList1 ) ; //������ͷ
	m_pList1->SetHead();

	::SetClassLong( m_pList1->m_hWnd, GCL_HBRBACKGROUND, (long)GetStockObject(NULL_BRUSH) ) ;
	m_pList1->m_pOwner = this ;

	//dwStyle = m_pList1->GetDlgItem(0)->GetStyle() |  ;
	m_pList1->GetDlgItem(0)->ModifyStyle( 0, HDS_DRAGDROP ) ;
	//m_pList1->GetDlgItem(0)->EnableWindow( FALSE ) ;

	m_pList1->ShowWindow( SW_SHOW ) ;

	m_pbtnItemCode->Create( "", WS_CHILD|WS_VISIBLE, rect, m_pwndBgn, MACRO_BtnItemCodeID ) ;
	m_pbtnItemCode->m_pToolTipCtrl1->Create( m_pbtnItemCode, 0 ) ;
/*
	m_pbtnItemCode->m_pToolTipCtrl1->SetDelayTime( 200 ) ;
	MSG msg ;
	msg.hwnd = m_pbtnItemCode->m_hWnd ;
	msg.message = WM_MOUSEMOVE ;
	m_pbtnItemCode->m_pToolTipCtrl1->RelayEvent( &msg ) ;
*/
	switch(m_iLangType)
	{
	case TT_LANG_ENG:
		m_pbtnItemCode->m_pToolTipCtrl1->AddTool( m_pbtnItemCode, TOOLTIP1_ENG) ;
		break;
	case TT_LANG_CNS:
		m_pbtnItemCode->m_pToolTipCtrl1->AddTool( m_pbtnItemCode, TOOLTIP1_CNS) ;
		break;
	case TT_LANG_CNT:
		m_pbtnItemCode->m_pToolTipCtrl1->AddTool( m_pbtnItemCode, TOOLTIP1_CNT ) ;
		break;
	default:
		m_pbtnItemCode->m_pToolTipCtrl1->AddTool( m_pbtnItemCode, TOOLTIP1_ENG) ;
		break;
	}

	m_pbtnOptMonth->Create( "", WS_CHILD|WS_VISIBLE, rect, m_pwndBgn, MACRO_BtnOptMonthID ) ;
	m_pbtnOptMonth->m_pToolTipCtrl1->Create( m_pbtnOptMonth, 0 ) ;
/*
	m_pbtnOptMonth->m_pToolTipCtrl1->SetDelayTime( 200 ) ;
	msg.hwnd = m_pbtnOptMonth->m_hWnd ;
	msg.message = WM_MOUSEMOVE ;
	m_pbtnOptMonth->m_pToolTipCtrl1->RelayEvent( &msg ) ;
*/
	switch(m_iLangType)
	{
		case TT_LANG_ENG:
			m_pbtnOptMonth->m_pToolTipCtrl1->AddTool( m_pbtnOptMonth, TOOLTIP2_ENG) ;
			break;
		case TT_LANG_CNS:
			m_pbtnOptMonth->m_pToolTipCtrl1->AddTool( m_pbtnOptMonth, TOOLTIP2_CNS) ;
			break;
		case TT_LANG_CNT:
			m_pbtnOptMonth->m_pToolTipCtrl1->AddTool( m_pbtnOptMonth, TOOLTIP2_CNT) ;
			break;
		default:
			m_pbtnOptMonth->m_pToolTipCtrl1->AddTool( m_pbtnOptMonth, TOOLTIP2_ENG) ;
			break;
	}

//andy add 2009.05.13
	m_pbtnHighPrice->Create( "", WS_CHILD|WS_VISIBLE, rect, m_pwndBgn, MACRO_BtnHighPriceID ) ;
	m_pbtnHighPrice->m_pToolTipCtrl1->Create( m_pbtnHighPrice, 0 ) ;

	switch(m_iLangType)
	{
		case TT_LANG_ENG:
			m_pbtnHighPrice->m_pToolTipCtrl1->AddTool( m_pbtnHighPrice, TOOLTIP_HIGH_ENG) ;
			break;
		case TT_LANG_CNS:
			m_pbtnHighPrice->m_pToolTipCtrl1->AddTool( m_pbtnHighPrice, TOOLTIP_HIGH_CNS) ;
			break;
		case TT_LANG_CNT:
			m_pbtnHighPrice->m_pToolTipCtrl1->AddTool( m_pbtnHighPrice, TOOLTIP_HIGH_CNT) ;
			break;
		default:
			m_pbtnHighPrice->m_pToolTipCtrl1->AddTool( m_pbtnHighPrice, TOOLTIP_HIGH_ENG) ;
			break;
	}


//	m_pbtnColumnWidth->Create( "", WS_CHILD|WS_VISIBLE, rect, m_pwndBgn, MACRO_BtnColumnWidthID ) ;
//	m_pbtnColumnWidth->m_pToolTipCtrl1->Create( m_pbtnColumnWidth, 0 ) ;
	
/*	switch(m_iLangType)
	{
	case TT_LANG_ENG:
		m_pbtnColumnWidth->m_pToolTipCtrl1->AddTool( m_pbtnColumnWidth, TOOLTIP_COLUMN_ENG) ;
		break;
	case TT_LANG_CNS:
		m_pbtnColumnWidth->m_pToolTipCtrl1->AddTool( m_pbtnColumnWidth, TOOLTIP_COLUMN_CNS) ;
		break;
	case TT_LANG_CNT:
		m_pbtnColumnWidth->m_pToolTipCtrl1->AddTool( m_pbtnColumnWidth, TOOLTIP_COLUMN_CNT) ;
		break;
	default:
		m_pbtnColumnWidth->m_pToolTipCtrl1->AddTool( m_pbtnColumnWidth, TOOLTIP_COLUMN_ENG) ;
		break;
	}*/

	//andy 2012.02.03 Add for IV Mode
	m_pbtnIVMode->Create( "", WS_CHILD|WS_VISIBLE, rect, m_pwndBgn, MACRO_Btn_IV_ID ) ;
	m_pbtnIVMode->m_pToolTipCtrl1->Create( m_pbtnIVMode, 0 ) ;
	
	switch(m_iLangType)
	{
	case TT_LANG_ENG:
		m_pbtnIVMode->m_pToolTipCtrl1->AddTool( m_pbtnIVMode, TOOLTIP_IV_ENG) ;
		break;
	case TT_LANG_CNS:
		m_pbtnIVMode->m_pToolTipCtrl1->AddTool( m_pbtnIVMode, TOOLTIP_IV_CNS) ;
		break;
	case TT_LANG_CNT:
		m_pbtnIVMode->m_pToolTipCtrl1->AddTool( m_pbtnIVMode, TOOLTIP_IV_CNT) ;
		break;
	default:
		m_pbtnIVMode->m_pToolTipCtrl1->AddTool( m_pbtnIVMode, TOOLTIP_IV_ENG) ;
		break;
	}

	//andy 2012.03.13 Add for Export CSV
	m_pbtnExportCSV->Create( "", WS_CHILD|WS_VISIBLE, rect, m_pwndBgn, MACRO_Btn_ExportCSV_ID ) ;
	m_pbtnExportCSV->m_pToolTipCtrl1->Create( m_pbtnExportCSV, 0 ) ;

	switch(m_iLangType)
	{
	case TT_LANG_ENG:
		m_pbtnExportCSV->m_pToolTipCtrl1->AddTool( m_pbtnExportCSV, TOOLTIP_ExportCSV_ENG) ;
		break;
	case TT_LANG_CNS:
		m_pbtnExportCSV->m_pToolTipCtrl1->AddTool( m_pbtnExportCSV, TOOLTIP_ExportCSV_CNS) ;
		break;
	case TT_LANG_CNT:
		m_pbtnExportCSV->m_pToolTipCtrl1->AddTool( m_pbtnExportCSV, TOOLTIP_ExportCSV_CNT) ;
		break;
	default:
		m_pbtnExportCSV->m_pToolTipCtrl1->AddTool( m_pbtnExportCSV, TOOLTIP_ExportCSV_ENG) ;
		break;
	}

	//Ben 2017.03.01 Add for Simple Mode
	m_pbtnSimple->Create( "", WS_CHILD|WS_VISIBLE, rect, m_pwndBgn, MACRO_Btn_Simple_ID ) ;
	m_pbtnSimple->m_pToolTipCtrl1->Create( m_pbtnSimple, 0 ) ;
//	m_pbtnSimple->EnableWindow(FALSE);
	m_pbtnStra->Create( "", WS_CHILD/*|WS_VISIBLE*/, rect, m_pwndBgn, MACRO_Btn_Stra_ID ) ;
	m_pbtnStra->m_pToolTipCtrl1->Create( m_pbtnStra, 0 ) ;

	switch(m_iLangType)
	{
	case TT_LANG_ENG:
		m_pbtnSimple->m_pToolTipCtrl1->AddTool( m_pbtnSimple, TOOLTIP_Simple_ENG) ;
		m_pbtnStra->m_pToolTipCtrl1->AddTool( m_pbtnStra, TOOLTIP_Stra_ENG) ;
		break;
	case TT_LANG_CNS:
		m_pbtnSimple->m_pToolTipCtrl1->AddTool( m_pbtnSimple, TOOLTIP_Simple_CNS) ;
		m_pbtnStra->m_pToolTipCtrl1->AddTool( m_pbtnStra, TOOLTIP_Stra_CNS) ;
		break;
	case TT_LANG_CNT:
		m_pbtnSimple->m_pToolTipCtrl1->AddTool( m_pbtnSimple, TOOLTIP_Simple_CNT) ;
		m_pbtnStra->m_pToolTipCtrl1->AddTool( m_pbtnStra, TOOLTIP_Stra_CNT) ;
		break;
	default:
		m_pbtnSimple->m_pToolTipCtrl1->AddTool( m_pbtnSimple, TOOLTIP_Simple_ENG) ;
		m_pbtnStra->m_pToolTipCtrl1->AddTool( m_pbtnStra, TOOLTIP_Stra_ENG) ;
		break;
	}

//andy add 2009.05.13
	
	m_pedtCash->Create( "", WS_CHILD|WS_VISIBLE, rect,  m_pwndBgn, MACRO_EdtCashID ) ;
	m_pedtCash->ModifyStyleEx( 0, WS_EX_CLIENTEDGE ) ;
	m_pedtVHSI->Create( "", WS_CHILD|WS_VISIBLE, rect,  m_pwndBgn, MACRO_EdtCashID ) ;
	m_pedtVHSI->ModifyStyleEx( 0, WS_EX_CLIENTEDGE ) ;
	m_pedtEAS->Create( "", WS_CHILD|WS_VISIBLE, rect,  m_pwndBgn, MACRO_EdtCashID ) ;
	m_pedtEAS->ModifyStyleEx( 0, WS_EX_CLIENTEDGE ) ;
	//m_pedtCash->SetMargins( 5,5 ) ;
	m_pedtFutures->Create( "", WS_CHILD|WS_VISIBLE, rect,  m_pwndBgn, MACRO_EdtFuturesID ) ;
	m_pedtFutures->ModifyStyleEx( 0, WS_EX_CLIENTEDGE ) ;
	//m_pedtFutures->SetMargins( 5,5 ) ;
		
	SetAllFont(m_strFontName, m_nFontSize);


	m_pbtnOptMonth->ShowWindow(SW_HIDE);
	m_pstaExpiryDate->ShowWindow(SW_HIDE);
	

	return 0;	
}

LRESULT CTTOptions::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	// TODO : Add Code for message handler. Call DefWindowProc if necessary.
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	
	CRect rect ;
	GetClientRect( rect ) ;

	m_pwndBgn->MoveWindow( rect ) ;
	m_pwndBgn->GetClientRect( rect ) ;

	CRect rectbtn( rect ) ;
	rectbtn.left++ ;  //���Ͻ�Xλ��
	rectbtn.top++ ;   //���Ͻ�Yλ��
	rectbtn.right  = rectbtn.left+80 ; //���½� X λ��
	rectbtn.bottom = rectbtn.top+20 ;  //���½� Y λ��
	m_pbtnItemCode->MoveWindow( rectbtn ) ;//����λ�ô�С
	int nPreX = rectbtn.right ;	

	rectbtn.left += rect.Width()/15 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+145 ;
	m_pstaItemName->MoveWindow( rectbtn ) ; //����m_pstaItemName����̬��ǩ����λ��
	nPreX = rectbtn.right ;	

	rectbtn.left +=  rect.Width()/16;				//���ò��Ե�λ��
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+80 ;
	m_pbtnStra->MoveWindow( rectbtn ) ; 
	nPreX = rectbtn.right ;	

	rectbtn.left += 80 + 10 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+80 ;
	m_pbtnOptMonth->MoveWindow( rectbtn ) ; //����ѡ���·ݰ�ť��λ��
	nPreX = rectbtn.right ;	

	rectbtn.left = rectbtn.right+2 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	
	rectbtn.right = rectbtn.left+140 ; //120
	m_pstaExpiryDate->MoveWindow( rectbtn ) ;//���� ������ ��λ��
	nPreX = rectbtn.right ;	

	//////////////////////////////////////////////////////////////////////////////
	//���ֻ����ڻ���λ�õ�����ʱ��ĺ���
	rectbtn.left += 80 ;//+ 20 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+40 ;  //55
	m_pstaCash->MoveWindow( rectbtn ) ;   //�����ֻ�����̬��ǩ����λ��
	nPreX = rectbtn.right ;	

	rectbtn.left = rectbtn.right ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+60 ;  //70
	m_pedtCash->MoveWindow( rectbtn ) ; //�����ֻ���ֵ��λ��	
	nPreX = rectbtn.right ;	

	rectbtn.left = rectbtn.right;   //rect.right-145 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left + 100 ;
	m_pstaFutures->MoveWindow( rectbtn ) ; //�����ڻ�����̬��ǩ����λ��
	nPreX = rectbtn.right ;	

	rectbtn.left = rectbtn.right ;
	if( rectbtn.left<nPreX )
	{
		rectbtn.left = nPreX ;
	}
	rectbtn.right = rectbtn.left+60  ;  //70
	m_pedtFutures->MoveWindow( rectbtn ) ; //�����ڻ���ֵ��λ��
	nPreX = rectbtn.right ;	

	rectbtn.left = rectbtn.right;   
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left + 40 ;  //55
	m_pstaVHSI->MoveWindow( rectbtn ) ; //����VHSI����̬��ǩ����λ��
	nPreX = rectbtn.right ;	

	rectbtn.left = rectbtn.right+3 ;
	if( rectbtn.left<nPreX )
	{
		rectbtn.left = nPreX ;
	}
	rectbtn.right = rectbtn.left+50  ;
	m_pedtVHSI->MoveWindow( rectbtn ) ; //����VHSI��ֵ��λ��
	nPreX = rectbtn.right ;	

	rectbtn.left = rectbtn.right;   
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left + 40 ;  //55
	m_pstaEAS->MoveWindow( rectbtn ) ; //����EAS����̬��ǩ����λ��
	nPreX = rectbtn.right ;	
	
	rectbtn.left = rectbtn.right+3 ;
	if( rectbtn.left<nPreX )
	{
		rectbtn.left = nPreX ;
	}
	rectbtn.right = rectbtn.left+50  ;
	m_pedtEAS->MoveWindow( rectbtn ) ; //����EAS��ֵ��λ��
	nPreX = rectbtn.right ;	

////////////////////////////////////////////////////////////////////////////////
	rectbtn.left += 70 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+40 ;
	m_pbtnHighPrice->MoveWindow( rectbtn ) ; //�������ظߵ͵�λ��
	nPreX = rectbtn.right ;	

/*	rectbtn.left += 40 + 10 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+40 ;
	m_pbtnColumnWidth->MoveWindow( rectbtn ) ;//���õ����п���λ��
	nPreX = rectbtn.right ;	*/

	rectbtn.left += 40 + 10 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+50 ;
	m_pbtnIVMode->MoveWindow( rectbtn ) ; //����IVģʽ��λ��
	nPreX = rectbtn.right ;
	
	rectbtn.left += 50 + 10 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+50 ;
	m_pbtnSimple->MoveWindow( rectbtn ) ; //���þ���ģʽ��λ��
	nPreX = rectbtn.right ;

	rectbtn.left += 50 + 10 ;
	if( rectbtn.left<nPreX )
		rectbtn.left = nPreX ;
	rectbtn.right = rectbtn.left+40 ;
	m_pbtnExportCSV->MoveWindow( rectbtn ) ; //����CSV��λ��
	nPreX = rectbtn.right ;	

	
//////////////////////////////////////////////////////////////////////////////////

	CRect headerect ;
	m_pList1->GetDlgItem(0)->GetWindowRect(headerect) ;
	int hi = headerect.Height() ;	

	CRect rectheader( rect ) ;
	rectheader.top = rectbtn.bottom+5 ;
	rectheader.bottom = rectheader.top+hi+4 ;
	m_pHeader->MoveWindow( rectheader ) ;

	CRect rectlst( rectheader ) ;
	rectlst.left   += 2 ;
	rectlst.right  -= 2 ;
	rectlst.top = rectlst.bottom-2 ;
	rectlst.bottom = rect.bottom ;
	m_pList1->MoveWindow( rectlst ) ;

	CRect temp ;
	m_pList1->GetHeaderCtrl()->GetWindowRect( temp ) ;
	m_pList1->ScreenToClient( temp ) ;
	if( temp.left!=0 )
	{
		rectheader.left += temp.left ;
		rectheader.right += temp.right+2 ;
		m_pHeader->MoveWindow( rectheader ) ;
	}		

	ResizeHeaderCtrl();
	return 0;

}

BOOL CTTOptions::AdviseDataProxy(BOOL bAdvise)
{
	if(m_pDataProxy == NULL)
		return FALSE;
	
	DWORD dwThreadID;
	m_bAdvise = bAdvise;
	if(m_hAdviseThread!=NULL)
	{
		CloseHandle(m_hAdviseThread);
		m_hAdviseThread=NULL;
	}
	m_hAdviseThread = CreateThread( NULL,
				0,
				(LPTHREAD_START_ROUTINE)AdviseThread,
				(LPVOID)this,
				NULL,
				&dwThreadID);
	return TRUE;	
}

void CTTOptions::SetLang()
{
	m_pLstHeadsInfo->ResetLang( m_iLangType, *m_pList1 ) ;
	UpdateTitle();
	if( m_pwndCls!=NULL && m_pwndCls->IsWindowVisible() )
	{
		RECT frmrect;
		m_pwndCls->m_frame.GetWindowRect(&frmrect);
		ScreenToClient(&frmrect);
		m_pwndCls->m_nRetn = m_pwndCls->PrePaint();
		if( m_pwndCls->m_nRetn==0 )
			return;
		if( m_pwndCls->m_bMode!=1 )
			m_pwndCls->DrawIncomeLine();
		else
			m_pwndCls->InvalidateRect(&frmrect);

		m_pwndCls->m_iLangType = m_iLangType;
		m_pwndCls->SetLang();
	}
	else
	{
		if( m_pwndCls!=NULL )
		{
			for( int i=0;i<m_pwndCls->m_StgyList.GetSize();i++ )
			{
				long lTransdate = m_pwndCls->m_StgyList[i].m_lExpTime/100;
				if( m_pwndCls->m_ExtList[i].b_weekly==1 )
					lTransdate = m_pwndCls->m_StgyList[i].m_lExpTime;
				SendUpdateRP(FALSE,m_pwndCls->m_StgyList[i].m_szCode,lTransdate);
				if( m_pwndCls->m_ExtList[i].cald.lMonth2!=0 )
				{
					long lm = m_pwndCls->m_ExtList[i].cald.lMonth2;
					if( m_pwndCls->m_ExtList[i].b_Mth2_Weekly==0 )
						lm = lm/100;
					SendUpdateRP(FALSE,m_pwndCls->m_StgyList[i].m_szCode,lm);
				}
			}
			delete m_pwndCls;
			m_pwndCls = NULL;
		}
	}

}

void CTTOptions::GetNameText()
{
	if(m_pGrpMng == NULL)
		return;
	CComQIPtr<ITTGroupsMng,&IID_ITTGroupsMng> pGrp(m_pGrpMng);
	if(pGrp == NULL)
		return;
	long lID;
	pGrp->FindItem('A',(BYTE*)m_szItemCode,&lID);

	m_szItemName[0] = _T('\0');
	if(m_iLangType==0) // english
		pGrp->GetItemPara(lID,ItemID_Lang1Descrip,(BYTE*)m_szItemName,30);
	else if(m_iLangType== 1) // simplified chinese
	{
		pGrp->GetItemPara(lID,ItemID_Lang3Descrip,(BYTE*)m_szItemName,30);
	}
	else if(m_iLangType== 2) // traditional chinese
	{
		pGrp->GetItemPara(lID,ItemID_Lang2Descrip,(BYTE*)m_szItemName,30);
	}

	if(!m_szItemName[0]) // if could not find specified language name, then english
		pGrp->GetItemPara(lID, ItemID_Lang1Descrip, (BYTE*)m_szItemName,30);
}

void CTTOptions::GetExpiryDateText()
{
	memset(m_szExpiryDateText,0,sizeof(m_szExpiryDateText));
	
	if(m_lExpiryTime != 0)
	{
		if(m_iLangType==0) // english
			sprintf(m_szExpiryDateText,"EXP :%d",m_lExpiryTime);
		else if(m_iLangType== 1) // simplified chinese
			sprintf(m_szExpiryDateText,"������:%d",m_lExpiryTime);
		else if(m_iLangType== 2) // traditional chinese
			sprintf(m_szExpiryDateText,"�����:%d",m_lExpiryTime);

		if( m_lTransdate>10000000 )
			sprintf(m_szExpiryDateText,"%s(W)",m_szExpiryDateText);
	}
}

void CTTOptions::UpdateTitle()
{
	CString title ;

	if( m_pbtnItemCode->m_hWnd!=NULL )
		m_pbtnItemCode->SetWindowText( m_szItemCode ) ;
	if( m_pbtnOptMonth->m_hWnd!=NULL )
		m_pbtnOptMonth->SetWindowText( m_szText ) ;
	if( m_pstaItemName->m_hWnd!=NULL )
	{
		GetNameText() ;
		m_pstaItemName->SetWindowText( m_szItemName);
	}
	if( m_pstaExpiryDate->m_hWnd!=NULL )
	{
		GetExpiryDateText() ;
		
		m_pstaExpiryDate->SetWindowText( m_szExpiryDateText);
	}

	short lang = m_iLangType ;
	if( lang<0 || lang>=3 )
		lang = 0 ;

	short show = m_bShowHighPrice ;
	if( show<0 || show >1 )
		show = 1 ;
	
	static CString szHighPrice[6] = {
			"H/L",//"Show H/L",
			"�ߵ�",//"��ʾ�ߵ�",
			"���C",//"��ܰ��C",
			"H/L",//"Hide H/L",
			"�ߵ�",//"���ظߵ�",
			"���C"//"���ð��C"
		};
	if( m_pbtnHighPrice->m_hWnd!=NULL )
		m_pbtnHighPrice->SetWindowText( szHighPrice[lang+show*3]) ;

	static CString szColumnWidth[3] = {
			"Reformat",
			"�п�",//"�����п�",
			"�C�e"//"�վ�C�e"
		};
	if( m_pbtnColumnWidth->m_hWnd!=NULL )
		m_pbtnColumnWidth->SetWindowText( szColumnWidth[lang] ) ;

	show = m_bIVMode ;
	if( show<0 || show >5 )
		show = 0 ;
	static CString szIVMode[18] = {
			"Normal",//"Normal",
			"����",//"����ģʽ",
			"���`",//"���`�Ҧ�",
			"IV",//"IV Mode",
			"IV",//"IVģʽ",
			"IV",//"IV�Ҧ�",
			"PB",//"PB Mode",
			"����",//"���ʷ���",
			"���v",//"���v���t",
			"Greeks",
			"Greeks",
			"Greeks",
			"OI",
			"δƽ",
			"����",
			"Margin",
			"����",
			"����"
		};
	if( m_pbtnIVMode->m_hWnd!=NULL )
		m_pbtnIVMode->SetWindowText( szIVMode[lang+show*3] ) ;

	static CString szExportCSV[3] = {
			"CSV",
			"CSV",
			"CSV"
		};
	if( m_pbtnExportCSV->m_hWnd!=NULL )
		m_pbtnExportCSV->SetWindowText( szExportCSV[lang]) ;

	static CString szStra[3] = {
			"Stgy/PV",
			"����/ʹֵ",
			"����/�h��"
		};
	if( m_pbtnStra->m_hWnd!=NULL )
		m_pbtnStra->SetWindowText( szStra[lang]) ;

	short simp = m_bSimple ;
	static CString szSimple[6] = {
			"Simple",//"Simple",
			"����",//"����ģʽ",
			"��²",//"��²�Ҧ�",
			"Full",//"Full",
			"����",//"����ģʽ",
			"����"//"����Ҧ�"
		};
	if( m_pbtnSimple->m_hWnd!=NULL )
		m_pbtnSimple->SetWindowText( szSimple[lang+simp*3]) ;


	static CString szCashs[3] = {
			"Cash",
			"�ֻ�",
			"�{�f"
		};
	if( m_pstaCash->m_hWnd!=NULL )
		m_pstaCash->SetWindowText( szCashs[lang] ) ;

	static CString szFutures[3] = {
			"Futures",
			"�ڻ�",
			"���f"
		};
	if( m_pstaFutures->m_hWnd!=NULL )
	{
		CString str;
		long ldate = m_lTransdate;
		if( ldate>10000000 )
			ldate = ldate/100;
		int nMM = ldate%100;
		int nYY = ldate/100;
		
		if( m_bUseNtMth )
		{
			if( nMM==12 )
			{
				nMM = 1;
				nYY += 1;
			}
			else
				nMM += 1;
		}
		
		str.Format("%d/%d ",nYY,nMM);
		str += szFutures[lang];
		m_pstaFutures->SetWindowText( str ) ;
		//m_pstaFutures->SetWindowText( szFutures[lang] ) ;
	}

	static CString szVHSI[3] = {
			"VHSI",
			"VHSI",
			"VHSI"
		};
	if( m_pstaVHSI->m_hWnd!=NULL )
		m_pstaVHSI->SetWindowText( szVHSI[lang] ) ;


	
	if( m_pstaEAS->m_hWnd!=NULL )
		m_pstaEAS->SetWindowText( "EAS" ) ;

	
	static char* szHeader1[3] = {
			"Calls",
			"�Ϲ���Ȩ",
			"�{�ʴ��v"
		};
	static char* szHeader2[3] = {
			"Puts",
			"�Ϲ���Ȩ",
			"�{�f���v"
		};


//	char szCallheader[30];
//	sprintf(szCallheader,"%s left 10 days",szHeader1[lang]);

	m_pHeader->m_HChar.RemoveAll();//���m_pHeader�е��ı�
	if( m_pHeader->m_hWnd!=NULL )
	{
		HDITEM item ;
		item.mask = HDI_TEXT ;
		//item.pszText = szCallheader;
		item.pszText = szHeader1[lang] ;
		m_pHeader->SetItem( 0, &item ) ;

		item.pszText = m_szPCR ;
		m_pHeader->SetItem( 1, &item ) ;

		item.pszText = szHeader2[lang] ;
		m_pHeader->SetItem( 2, &item ) ;

		//����m_pHeader��ǰ����
		m_pHeader->m_HChar.Add(  szHeader1[lang] ); 
		m_pHeader->m_HChar.Add(  m_szPCR ); 
		m_pHeader->m_HChar.Add(  szHeader2[lang] ); 
	}

}

STDMETHODIMP CTTOptions::OnNewFrame(short wDataType, IStream *pIStream,unsigned long dwID)
{
	if(pIStream == NULL || (dwID != 0 && dwID != m_dwID))
		return S_FALSE;

	if( wDataType=='SY' )
	{
		// seek begin.
		LARGE_INTEGER	temp ;
		temp.QuadPart = 0 ;
		ULARGE_INTEGER  addr ;
		pIStream->Seek( temp, STREAM_SEEK_SET, &addr );    

		// read frame length.
		ULONG	lRead ;	
		unsigned short iLength ;
		if( pIStream->Read( &iLength, sizeof(unsigned short), &lRead )!=S_OK )
			return S_FALSE ;
		if( lRead!=sizeof(unsigned short) )
			return S_FALSE ;

		// read head.
		if( iLength<5 )		// head size.
			return S_FALSE ;
		char szHead[100];
		if( pIStream->Read( &szHead, iLength, &lRead )!=S_OK )
			return S_FALSE ;
		if( iLength!=lRead )
			return S_FALSE ;
		BYTE cGroupCpde = szHead[2] ;
		if( cGroupCpde!='A' && cGroupCpde!=0xff ) // 0xff mean all groups.
			return S_FALSE ;

		unsigned short*	ipEleType = (unsigned short*)(szHead+3);
		switch( *ipEleType )
		{
			case 'IN':	// reinit.
				ClearData() ;
//				SendDFRequestFrame();
				return S_OK ;
			case 'ST':
//				SendDFRequestFrame();
				return S_OK ;

			case 'DO': // data channel is ready
				SendRequestFrame();
				SendDFRequestFrame();
				return S_OK;

			default:
				return S_OK;

		}//end switch.	

	}//end if( SY )

	switch(wDataType)
	{
	case 'DO':
		ReadDOFrame(pIStream,dwID);
		break;
	case 'DS':
		ReadDSFrame(pIStream);
		break;
	case 'DP':
		ReadDPFrame(pIStream);
		break;
	case 'DF':
		ReadDFFrame(pIStream);
		break;
/*
	case 'OU':
		{
			PostMessage(CM_UNLOCKWINDOWUPDATE);
		}
		break;
*/
	default:
		return S_FALSE;
	}
	return S_OK;
}

int floatToInt(float f)
{  
    int i = 0;  
    if(f>0) //����  
		i = (f*10 + 5)/10;  
    else if(f<0) //����  
		i = (f*10 - 5)/10;  
	else i = 0;  
	
    return i;  
	
}  

/*
// ����5���EAS��Ϣ.
BYTE	byEasIndicator[5] ;
float	fEASs[5] ;

  memset( byEasIndicator, 0, sizeof(byEasIndicator) ) ;	
  memset( fEASs, 0, sizeof(fEASs) ) ;	
  pIStream->Read(byEasIndicator,sizeof(byEasIndicator),NULL);
  pIStream->Read(fEASs,sizeof(fEASs),NULL);
  
				char log[100];
				sprintf(log,"%d,%d,%d,%d,%d",floatToInt(fEASs[0]),floatToInt(fEASs[1]),floatToInt(fEASs[2]),floatToInt(fEASs[3]),floatToInt(fEASs[4]));
				WriteLogFile(log);
*/

HRESULT CTTOptions::ReadDFFrame(IStream *pIStream)
{
	BOOL		bFrameIN=0;
	FrameLen	framelen;
	FrameHead	framehead;
	DSFrameID	frameid;
	ElementType elementtype;
	LARGE_INTEGER largeint;
	largeint.QuadPart = 0;
	pIStream->Seek(largeint,STREAM_SEEK_SET,NULL);
	pIStream->Read(&framelen,sizeof(FrameLen),NULL);
	
	if(framelen <= 0)
		return S_FALSE;
	pIStream->Read(&framehead,sizeof(FrameHead),NULL);	
	if(framehead.wFrameType != 'DF')
		return S_FALSE;
	pIStream->Read(&frameid,sizeof(DSFrameID),NULL);
	
	pIStream->Read(&elementtype,sizeof(ElementType),NULL);
	
	if( elementtype=='EA' )
	{
		// ����5���EAS��Ϣ.
		BYTE	byEasIndicator[5] ;
		float	fEASs[5] ;
		
		memset( byEasIndicator, 0, sizeof(byEasIndicator) ) ;	
		memset( fEASs, 0, sizeof(fEASs) ) ;	
		pIStream->Read(byEasIndicator,sizeof(byEasIndicator),NULL);
		pIStream->Read(fEASs,sizeof(fEASs),NULL);
	//	CString str;
	//	str.Format("%d,%d,%d,%d,%d",floatToInt(fEASs[0]),floatToInt(fEASs[1]),floatToInt(fEASs[20]),floatToInt(fEASs[3]),floatToInt(fEASs[4]));
	//	AfxMessageBox(str);
		m_iEAS1 = floatToInt(fEASs[0]);
		m_iEAS2 = floatToInt(fEASs[1]);
		sprintf(m_szEAS,"");
		if( memcmp(m_szItemCode,"HSI    ",7)==0  || memcmp(m_szItemCode,"MHI    ",7)==0 )
		{
			sprintf(m_szEAS,"%d",m_iEAS1);
		}
		else if( memcmp(m_szItemCode,"HSCEI  ",7)==0 || memcmp(m_szItemCode,"MCH    ",7)==0 )
		{
			sprintf(m_szEAS,"%d",m_iEAS2);
		}
		::PostMessage(m_hWnd,CM_SETWINDOWTEXT,3,0);
	}
	
	
	return S_OK;
}

void CTTOptions::ReadDPFrame(IStream *pIStream)
{
	int i, iflag,j;
	iflag = -1;
	FrameLen	framelen;
	FrameHead	framehead;
	FrameID		frameid;
	ElementType elementtype;
	float       fValue;
	unsigned char cbIndicator;
	unsigned char cbCP;
	BOOL        bCab,bThoery;
	CodeDate codedate;
	LastPrice lastp;
	
	LARGE_INTEGER largeint;
	largeint.QuadPart = 0;
	pIStream->Seek(largeint, STREAM_SEEK_SET,NULL);

	pIStream->Read(&framelen,sizeof(FrameLen),NULL);
	if(framelen < 0)
		return;
	pIStream->Read(&framehead,sizeof(FrameHead),NULL);
	if(framehead.wFrameType != 'DP')
		return;
	
	if(pIStream->Read(&frameid,sizeof(FrameID),NULL) != S_OK)
		return;

	EnterCriticalSection(&m_cs);
	
	for( i=0;i<m_arrCD.GetSize();i++ )
	{
		if( strcmp(m_arrCD[i].szCode,frameid.szItemCode)==0&&m_arrCD[i].lDate==frameid.lTransdate )
		{
			iflag = i;
			break;
		}
	}
	if( i==m_arrCD.GetSize() || m_arrCD.GetSize()==0 )
	{
		codedate.lDate = frameid.lTransdate;
		memcpy(codedate.szCode,frameid.szItemCode,8);
		m_arrCD.Add(codedate);
	}


	cbCP = frameid.cbOrder;

	BYTE nRow;
	unsigned char cb;
	float fStrike,fCall,fPut;
	char sz[100] = {0};
	
	pIStream->Read(&elementtype,sizeof(ElementType),NULL);
	
	static int refh = 1;
	switch(elementtype)
	{
	case 'XP':
		pIStream->Read(&nRow,sizeof(BYTE),NULL);
		if( iflag==-1 )
		{
			iflag = m_arrCD.GetSize()-1;
		}
		else
		{
			if( nRow!=1 )
				m_arrLP[iflag].RemoveAll();
		}
		for( i=0;i<nRow;i++ )
		{
			pIStream->Read(&fStrike,sizeof(float),NULL);
			pIStream->Read(&fCall,sizeof(float),NULL);
			pIStream->Read(&cb,sizeof(unsigned char),NULL);
			pIStream->Read(&fPut,sizeof(float),NULL);
			pIStream->Read(&cb,sizeof(unsigned char),NULL);
			
			if( iflag<=100 )
			{
				lastp.fStrike = fStrike;
				lastp.fCall = fCall;
				lastp.fPut = fPut;
				if( nRow!=1 )
				{
					m_arrLP[iflag].Add(lastp);
				}
				else
				{
					for( j=0;j<m_arrLP[iflag].GetSize();j++ )
					{
						if( m_arrLP[iflag][j].fStrike==fStrike )
						{
							m_arrLP[iflag][j].fCall = fCall;
							m_arrLP[iflag][j].fPut = fPut;
						}
					}
				}
			}
		}
		break;
	}

	LeaveCriticalSection( &m_cs );
}

void CTTOptions::ReadDOFrame(IStream *pIStream,unsigned long dwID)
{
	int nIndex;
	int nIndex2; // simple mode

	FrameLen	framelen;
	FrameHead	framehead;
	FrameID		frameid;
	ElementType elementtype;
	float       fValue;
	unsigned char cbIndicator;
//	TCHAR       szText[8];
	unsigned char cbCP;
	BOOL        bCab,bThoery;
	int         nLen;
	
	LARGE_INTEGER largeint;
	largeint.QuadPart = 0;
	pIStream->Seek(largeint, STREAM_SEEK_SET,NULL);

//	BYTE cbBuf[128];
//	HRESULT hRes = pIStream->Read(cbBuf, sizeof(cbBuf), NULL);
//	pIStream->Seek(largeint, STREAM_SEEK_SET,NULL);

	pIStream->Read(&framelen,sizeof(FrameLen),NULL);
	if(framelen < 0)
	{
		
		return;
	}
	pIStream->Read(&framehead,sizeof(FrameHead),NULL);
	if(framehead.wFrameType != 'DO')
	{
		
		return;
	}
	if(pIStream->Read(&frameid,sizeof(FrameID),NULL) != S_OK)
	{
		
		return;
	}
	
	if(IsClearScreenFrame(pIStream))
	{
		if(frameid.cbGroupCode == m_cbGroupCode
			&& memcmp(&frameid.szItemCode, &m_szItemCode,8) == 0
			&& m_lTransdate == frameid.lTransdate)  //andy add 2004.04.09 ���жϻ���������
			ClearScreen();
		
		return;
	}
		
	if(frameid.cbGroupCode != m_cbGroupCode || memcmp(&frameid.szItemCode, &m_szItemCode,8)//)
		|| frameid.lTransdate != m_lTransdate)	
	{
		CString str;
		str.Format("frame.group=%d,m_group=%d;frame.code=%s,m_code=%s;frame.date=%d,m_date=%d",
			frameid.cbGroupCode,m_cbGroupCode,frameid.szItemCode,m_szItemCode,frameid.lTransdate,m_lTransdate);
	//	OutputDebugString(str);
		return;
	}
	cbCP = frameid.cbOrder;

	BOOL bInsert = FALSE;
OutputDebugString("show");
	m_pbtnOptMonth->ShowWindow(SW_SHOW);
	m_pstaExpiryDate->ShowWindow(SW_SHOW);
	
	/*��ʱδ֪��DP,�ĵ�DP��ִ��
	if((nIndex = FindRow(frameid.fStrikePrice)) == -1)
	{
		
		nIndex =InsertRow(frameid.fStrikePrice);
		if(nIndex != -1)
		{
			bInsert = TRUE;
			//ListView_SortItems(m_ctlSysListView32,(PFNLVCOMPARE)CompareFunc,NULL);
		}
	}
	*/
	if(!::IsWindow(m_pList1->GetSafeHwnd()))
		return ;

	int nAddr ;
	int nAddrPB;
	char* pDest ;
	char* pDest2;  //simple mode
	char szDest[20] ;	
	char* pDestIV ;
	char szDestIV[20] ;	
	char sz[100] = {0};
	char ch;
	BYTE iOI;
	float f1,f2,f3;
	int i;
	if(dwID)
	{
		//m_pList1->ShowWindow(SW_HIDE);
		m_pList1->LockWindowUpdate();
	}

	do
	{
		pIStream->Read(&elementtype,sizeof(ElementType),NULL);

		SYSTEMTIME now;
		GetLocalTime(&now);
		char szTmp[3];
		memcpy(szTmp,&elementtype,2);
//		ATLTRACE("ReadDOFrame Time=%02d:%02d.%03d %c%c wdid=%d\r\n ",
//			now.wMinute,now.wSecond,now.wMilliseconds,szTmp[1],szTmp[0],dwID);

		 //2009.05.06 dixon:  O/I, vol, last qty, bid qty, ask qty�ض��]��С��λ

		static int refh = 1;
		OptPreOI optoi;
		float fCallOI = 0;
		float fPutOI = 0;
		switch(elementtype)
		{
		case 'PO':
			m_arrPreOI.RemoveAll();
			pIStream->Read(&iOI,sizeof(BYTE),NULL);
			for( i=0;i<iOI;i++ )
			{
				memset(&optoi,0,sizeof(optoi));
				pIStream->Read(&f1,sizeof(float),NULL);
				pIStream->Read(&f2,sizeof(float),NULL);
				pIStream->Read(&f3,sizeof(float),NULL);
				optoi.m_fStrike = f1;
				optoi.m_fPre_CallOI = f2;
				optoi.m_fPre_PutOI = f3;
				fCallOI += f2;
				fPutOI += f3;
				m_arrPreOI.Add(optoi);
				if( i==iOI-1 )
				{
					optoi.m_fStrike = 0.0;
					optoi.m_fPre_CallOI = fCallOI;
					optoi.m_fPre_PutOI = fPutOI;
					m_arrPreOI.InsertAt(0,optoi);
				}
			}
			break;
		case 'IV':
			pIStream->Read(&ch,sizeof(ch),NULL);
			pIStream->Read(&fValue,sizeof(float),NULL);
			m_fBF = fValue;
			break;
		case 'ST': // A full history data
			{
				ReadFullData(pIStream);
				if (m_bIVMode > 0 && m_bIVMode<4)
				{
					CalcAllIVData();
			//		m_pList1->RecalcColumnWidthIVMode(0);  //���µ����п�

				}
			/*	else if (m_bIVMode == 0)
				{
					m_pList1->RecalcColumnWidth(0);  //���µ����п�
				}
				else if (m_bIVMode == 2)
				{
					CalcAllIVData();
					m_pList1->RecalcColumnWidthPBMode(0);  //���µ����п�
				}*/
				
				if( memcmp(m_szOptCode,"HSI  ",5)==0 && memcmp(m_szItemCode,"HSI     ",8)!=0  )
				{
					ReadHKStockOccFile();
				}
				if( strcmp(m_szOptCode,"")==0 )
				{
					ReadHKStockOccFile();
				}
				GetMarginTxt();

				int iNum = ClosestCashNum();
				if( m_bSimple==1 )
				{
					m_pList1->SelectSimpleMode(m_bSimple, iNum);
				}
				else
					m_pList1->PostMessage(MACRO_MsgRedrawItem, (WPARAM)0xFFFFFFFE, 0);

				m_pbtnStra->ShowWindow(SW_SHOW);

				OnSelectColumnWidth();
				
			}
			break;
		case 'OI': //O/I
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			if( (cbCP==1 && fValue!=m_pDataBuf[nIndex].m_fCalls_OI) ||
				(cbCP==2 && fValue!=m_pDataBuf[nIndex].m_fPuts_OI) )
			{ 
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_OI) : (&m_pDataBuf[nIndex].m_fPuts_OI) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? /*1*/POS_CALL_OI : POS_PUT_OI ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;
				strcpy(szDest,pDest);
				GetTextEx(pDest,fValue,0);
				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode!=2&&m_bIVMode!=3 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode!=2&&m_bIVMode!=3 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode!=2&&m_bIVMode!=3 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0  )
					{
						if( m_bIVMode!=2&&m_bIVMode!=3 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	
			break;
		case 'PH': //High
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			if( (cbCP==1 && fValue!=m_pDataBuf[nIndex].m_fCalls_High) ||
				(cbCP==2 && fValue!=m_pDataBuf[nIndex].m_fPuts_High) )
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_High) : (&m_pDataBuf[nIndex].m_fPuts_High) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_HIGH : POS_PUT_HIGH ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;
				strcpy(szDest,pDest);
				GetTextEx(pDest,fValue,m_cbDecimal);
				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode==0 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode==0 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode==0 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode==0 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	
			break;
		case 'PL': //Low
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			if( (cbCP==1 && fValue!=m_pDataBuf[nIndex].m_fCalls_Low) ||
				(cbCP==2 && fValue!=m_pDataBuf[nIndex].m_fPuts_Low) )
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_Low) : (&m_pDataBuf[nIndex].m_fPuts_Low) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_LOW : POS_PUT_LOW ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;
				strcpy(szDest,pDest);
				GetTextEx(pDest,fValue,m_cbDecimal);
				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode==0 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode==0 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode==0 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode==0 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	
			break;
		case 'PT': //Vol
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			if( (cbCP==1 && fValue!=m_pDataBuf[nIndex].m_fCalls_Vol) ||
				(cbCP==2 && fValue!=m_pDataBuf[nIndex].m_fPuts_Vol) )
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_Vol) : (&m_pDataBuf[nIndex].m_fPuts_Vol) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_VOL:POS_PUT_VOL;//1 : 13 ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;
				strcpy(szDest,pDest);
				GetTextEx(pDest,fValue,0);
				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode==0 || m_bIVMode==4 || m_bIVMode==5 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode==0 || m_bIVMode==4 || m_bIVMode==5 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode==0 || m_bIVMode==4 || m_bIVMode==5 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode==0 || m_bIVMode==4 || m_bIVMode==5 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	
			break;
		case 'PA': //Ask
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			pIStream->Read(&cbIndicator,sizeof(char),NULL);
			bThoery = (cbIndicator & 0x01);
			//if( (cbCP==1 && fValue!=m_pDataBuf[nIndex].m_fCalls_Ask) ||
			//	(cbCP==2 && fValue!=m_pDataBuf[nIndex].m_fPuts_Ask) )
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_Ask) : (&m_pDataBuf[nIndex].m_fPuts_Ask) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_ASK:POS_PUT_ASK;//6 : 9 ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;				
				strcpy(szDest,pDest);
				GetText(pDest,fValue,m_cbDecimal,FALSE,bThoery);
				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode!=2 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode!=2 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
				}
				
				//andy add 2012.02.14
				if (m_bIVMode == 1 || m_bIVMode==3)
				{
					CalcIVData(nIndex,m_pDataBuf[nIndex],nAddr);
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						memcpy(&m_pList1->m_buf_simple[nIndex2], &m_pList1->m_buf[nIndex], sizeof(ItemOptionsText));
						//m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode!=2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode!=2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	

			break;
		case 'PB': //Bid
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			pIStream->Read(&cbIndicator,sizeof(char),NULL);
			bThoery = (cbIndicator & 0x01);
			bCab = (cbIndicator & 0x02) >> 1;
			//if( (cbCP==1 && fValue!=m_pDataBuf[nIndex].m_fCalls_Bid) ||
			//	(cbCP==2 && fValue!=m_pDataBuf[nIndex].m_fPuts_Bid) )
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_Bid) : (&m_pDataBuf[nIndex].m_fPuts_Bid) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_BID:POS_PUT_BID;//5 : 8 ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;	
				strcpy(szDest,pDest);
				GetText(pDest,fValue,m_cbDecimal,bCab,bThoery);
				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode!=2 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode!=2 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
				}
				
				if (m_bIVMode == 1 ||m_bIVMode==3 )
				{
					CalcIVData(nIndex,m_pDataBuf[nIndex],nAddr);
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						memcpy(&m_pList1->m_buf_simple[nIndex2], &m_pList1->m_buf[nIndex], sizeof(ItemOptionsText));
						//m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode!=2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode!=2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	

			break;
		case 'PN'://Last
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			pIStream->Read(&cbIndicator,sizeof(char),NULL);
			bCab = (cbIndicator & 0x02) >> 1;
			//if( (cbCP==1 && fValue!=m_pDataBuf[nIndex].m_fCalls_Nominal) ||
			//	(cbCP==2 && fValue!=m_pDataBuf[nIndex].m_fPuts_Nominal) )
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_Nominal) : (&m_pDataBuf[nIndex].m_fPuts_Nominal) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_LAST:POS_PUT_LAST;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;
				//��������ģʽ�µ�nAddrȡ����
				if( m_bIVMode==2 )
					nAddrPB = (cbCP==1) ? 6:8;
				if(bCab)
				{
					strcpy(szDest,pDest);
					GetText(pDest,fValue,m_cbDecimal,bCab,FALSE);
					//m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);								
				}
				else 
				{
					strcpy(szDest,pDest);
					GetTextEx(pDest,fValue,m_cbDecimal);
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
						strcpy(pDest2,pDest);
						if( m_bIVMode==2 )
							m_pList1->SetReflectItemTextColor(nIndex2,nAddrPB,pDest,szDest);
						else
							m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
					}
					else
					{
						if( m_bIVMode==2 )
							m_pList1->SetReflectItemTextColor(nIndex,nAddrPB,pDest,szDest);
						else
							m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
					}
				}	
				
				
				if (m_bIVMode == 1 || m_bIVMode==2 || m_bIVMode==3 )
				{
					CalcIVData(nIndex,m_pDataBuf[nIndex],nAddr);
					if( m_bSimple==1 && nIndex2!=-1 )
						memcpy(&m_pList1->m_buf_simple[nIndex2], &m_pList1->m_buf[nIndex], sizeof(ItemOptionsText));

					//ben 2017.07.18 ���ϳɼ۵�IVˢ��
					//if(nAddr == 5)     //�°����к� �ɼ� ���±�ֵΪ5
					//{
						if( m_bSimple==1 && nIndex2!=-1 )
						{
							if( (m_bIVMode==1||m_bIVMode==2) && nAddr==5 )
							{
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 1 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 2 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 3 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 4 ) ; 
							}
							else if( (m_bIVMode==1||m_bIVMode==2) && nAddr==15 )
							{
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 16 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 17 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 18 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 19 ) ;
							}
							else if( m_bIVMode==2 && nAddrPB==6 )
							{
								//m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 0 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 1 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 2 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 3 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 4 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 5 ) ;
							}
							else if( m_bIVMode==2 && nAddrPB==8 )
							{
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 9 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 10 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 11 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 12 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 13 ) ;
								//m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, 14 ) ;
							}
							
						}
						else if( m_bSimple==0 )
						{
							if( (m_bIVMode==1||m_bIVMode==2) && nAddr==5 )
							{
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 1 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 2 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 3 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 4 ) ;
							}
							else if( (m_bIVMode==1||m_bIVMode==2) && nAddr==15 )
							{
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 16 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 17 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 18 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 19 ) ;
							}
							else if( m_bIVMode==2 && nAddrPB==6 )
							{
								//m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 0 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 1 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 2 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 3 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 4 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 5 ) ;
							}
							else if( m_bIVMode==2 && nAddrPB==8 )
							{
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 9 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 10 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 11 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 12 ) ;
								m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 13 ) ;
								//m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, 14 ) ;
							}
						}				
				}

				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode==2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddrPB ) ;
						else
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode==2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddrPB ) ;
						else
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	
			break; 
		case 'QA':		//Ask Qty
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			//pIStream->Read(&cbIndicator,sizeof(char),NULL);
			cbIndicator=0;// for test
			bThoery = (cbIndicator & 0x01);
			bCab = (cbIndicator & 0x02) >> 1;
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_AskQty) : (&m_pDataBuf[nIndex].m_fPuts_AskQty) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_ASKQ:POS_PUT_ASKQ;//5 : 8 ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;				
				strcpy(szDest,pDest);
				//GetText(pDest,fValue,m_cbDecimal,bCab,0);
				GetTextEx(pDest,fValue,0);  //andy modify 2009.05.06

				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode!=2 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode!=2 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);	
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode!=2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode!=2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	
			break;
		case 'QB':		//Bid Qty
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			//pIStream->Read(&cbIndicator,sizeof(char),NULL);
			cbIndicator=0; //for test
			bThoery = (cbIndicator & 0x01);
			bCab = (cbIndicator & 0x02) >> 1;
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_BidQty) : (&m_pDataBuf[nIndex].m_fPuts_BidQty) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_BIDQ:POS_PUT_BIDQ;//5 : 8 ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;				
				strcpy(szDest,pDest);
				//GetText(pDest,fValue,m_cbDecimal,bCab,0);
				GetTextEx(pDest,fValue,0);  //andy modify 2009.05.06

				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode!=2 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode!=2 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);	
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode!=2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode!=2 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	
			break;
		case 'QN':		//Nominal Qty
			if( nIndex<0 )
				return ;
			pIStream->Read(&fValue,sizeof(float),NULL);
			//pIStream->Read(&cbIndicator,sizeof(char),NULL);
			cbIndicator=0; //for test
			bThoery = (cbIndicator & 0x01);
			bCab = (cbIndicator & 0x02) >> 1;
			{
				float* pfData = (cbCP==1) ? (&m_pDataBuf[nIndex].m_fCalls_NominalQty) : (&m_pDataBuf[nIndex].m_fPuts_NominalQty) ;
				*pfData = fValue ;
				nAddr = (cbCP==1) ? POS_CALL_LASTQ:POS_PUT_LASTQ;//5 : 8 ;
				pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
				ASSERT( pDest!=NULL ) ;
				strcpy(szDest,pDest);
				//GetText(pDest,fValue,m_cbDecimal,bCab,0);
				GetTextEx(pDest,fValue,0);  //andy modify 2009.05.06

				if( m_bSimple==1 && nIndex2!=-1 )
				{
					pDest2 = m_pList1->GetReflectItemText( m_pList1->m_buf_simple+nIndex2, nAddr ) ;
					strcpy(pDest2,pDest);
					if( m_bIVMode==0||m_bIVMode==4||m_bIVMode==5 )
						m_pList1->SetReflectItemTextColor(nIndex2,nAddr,pDest,szDest);
				}
				else if( m_bSimple==0 )
				{
					if( m_bIVMode==0||m_bIVMode==4||m_bIVMode==5 )
						m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);	
				}
				if(( bInsert==FALSE )&&(!dwID))
				{
					if( m_bSimple==1 && nIndex2!=-1 )
					{
						if( m_bIVMode==0||m_bIVMode==4||m_bIVMode==5 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex2, nAddr ) ;
					}
					else if( m_bSimple==0 )
					{
						if( m_bIVMode==0||m_bIVMode==4||m_bIVMode==5 )
							m_pList1->PostMessage( MACRO_MsgRedrawItem, nIndex, nAddr ) ;
					}
				}
			}	
			break;
		case 'DP': //Decimal
			pIStream->Read(&cbIndicator,sizeof(char),NULL);
			//if(m_bReply)
			//	PostMessage(CM_UNLOCKWINDOWUPDATE);
			m_cbDecimal = cbIndicator;
			if((nIndex = FindRow(frameid.fStrikePrice)) == -1)
			{
				
				nIndex =InsertRow(frameid.fStrikePrice);
				if(nIndex != -1)
				{
					bInsert = TRUE;
					//ListView_SortItems(m_ctlSysListView32,(PFNLVCOMPARE)CompareFunc,NULL);
				}
			}
			else
			{
				if( m_bSimple==1 )
				{
					if( nIndex<m_pList1->m_nStart || nIndex>m_pList1->m_nEnd )
						nIndex2 = -1;
					else
						nIndex2 = nIndex - m_pList1->m_nStart+1;
				}
			}
			
			
			break;
		case 'CM': //Delete Month
			{
				RemoveMonth(frameid.lTransdate);
				ResetTable();
				return;
			}
			
		case 'CS': //Delete Strike
			if( DeleteRow(frameid.fStrikePrice)>=0 )
				bInsert=TRUE ; // reset list.
			break;
		case 'DT': // month list
			{
				FillMonthList(pIStream);
				
				if(m_bClick_SelMonth)
				{
					CdlgMonth::AddItemCode(frameid.szItemCode);
					PostMessage(CM_SHOWMONTHDLG);				
					m_bClick_SelMonth = FALSE;
				}
			}
			break;			
		default:
			if(dwID)
			{
				ULONG ulSize=0;
				ULARGE_INTEGER ulargeint;
				largeint.QuadPart=-2;
				pIStream->Seek(largeint,STREAM_SEEK_CUR,&ulargeint);
				pIStream->Read(&frameid,sizeof(FrameID),&ulSize);
				largeint.QuadPart=0;
				if(!ulSize)
				{
					break;
				}
				
				if(frameid.cbGroupCode != m_cbGroupCode || memcmp(&frameid.szItemCode, &m_szItemCode,8)
					|| frameid.lTransdate != m_lTransdate)
					return;
				cbCP = frameid.cbOrder;
				
				BOOL bInsert = FALSE;
			}
			break;			

		}//end of switch()
		ULARGE_INTEGER ulargeint;
		pIStream->Seek(largeint,STREAM_SEEK_CUR,&ulargeint);
		nLen = (int) ulargeint.QuadPart - sizeof(short);
	}while(nLen < framelen);

	if(dwID)
	{
		//m_pList1->ShowWindow(SW_SHOW);
		m_pList1->UnlockWindowUpdate();
	}
	if(bInsert && m_pList1->m_hWnd != NULL)
	{
		BYTE DirtyBuf[MACRO_MaxItems];
		memset( DirtyBuf, 1, sizeof(DirtyBuf) ) ;
		m_pList1->SetItemsTotal( m_nDataTotal, DirtyBuf ) ;
		if(dwID)
		{
		//	Sleep(10);//����ͬʱˢ�ºķ���Դ
		}
	}
}

void CTTOptions::ReadDSFrame(IStream *pIStream)
{
	FrameLen	framelen;
	FrameHead	framehead;
	DSFrameID	frameid;
	//ElementType elementtype;
	short        elementtype;
	float       fValue;

	LARGE_INTEGER largeint;
	largeint.QuadPart = 0;
	pIStream->Seek(largeint, STREAM_SEEK_SET,NULL);
	pIStream->Read(&framelen,sizeof(FrameLen),NULL);
	if(framelen < 0)
		return;
	pIStream->Read(&framehead,sizeof(FrameHead),NULL);
	if(framehead.wFrameType != 'DS')
		return;
	pIStream->Read(&frameid,sizeof(DSFrameID),NULL);
	int nIdx = -1;
//	if(memcmp(frameid.szItemCode, m_szItemCode,8) == 0)
	//AfxMessageBox(m_szVHSICode);
	if(memcmp(frameid.szItemCode, m_szItemCashCode,8) == 0)  //andy modify 20090604 ʹ��cashcode ,����MHI��cashcode��HSI
	{
		nIdx =0;
	}
	else if(memcmp(frameid.szItemCode, m_szFuturesCode,8) == 0)
	{
		nIdx = 1;
	}
	else if(memcmp(frameid.szItemCode, m_szVHSICode,8) == 0)
	{
		nIdx = 2;
	}
	else if(memcmp(frameid.szItemCode, m_szFuturesNightCode,8) == 0)
	{
		nIdx = 3;
	}

	if( nIdx==-1&&m_pwndCls!=NULL )
	{
		BOOL bFind = FALSE;
		char code[9] = {0};
		for( int i=0;i<m_pwndCls->m_arrITC.GetSize();i++ )
		{
			if( memcmp(m_pwndCls->m_arrITC[i].cashcode,frameid.szItemCode,8)==0 )
			{
				bFind = TRUE;
				memcpy(code,m_pwndCls->m_arrITC[i].itemcode,8);
				break;
			}
		}
		if( bFind )
		{
			CodeCash codecash;
			memset(&codecash,0,sizeof(CodeCash));
			memcpy(codecash.szCode,frameid.szItemCode,8);
			pIStream->Read(&elementtype,sizeof(short),NULL);
			if(elementtype == 'SN')
			{
				pIStream->Read(&fValue,sizeof(float),NULL);	
				if( m_pwndCls->IsIndex_Ext(code) )
				{
					CString str;
					str.Format("%.0f",fValue);
					fValue = atof(str);
					if( codecash.szCode[0]=='X' )
					{
						memmove(codecash.szCode,codecash.szCode+1,7);
						codecash.szCode[7] = frameid.szItemCode[7];
					}
				}
				codecash.fCash = fValue;
				EnterCriticalSection(&m_cs);
				for( int k=0;k<m_arrCash.GetSize();k++ )
				{
					if( memcmp(m_arrCash[k].szCode,codecash.szCode,8)==0 )
					{	
						m_arrCash[k].fCash = codecash.fCash;
						break;
					}
				}
				if( k==m_arrCash.GetSize() )
				{
					m_arrCash.Add(codecash);
				}
				LeaveCriticalSection( &m_cs );
			}
		}
	}

	if(frameid.cbGroupCode != m_cbGroupCode || nIdx == -1)
		return;
	pIStream->Read(&elementtype,sizeof(short),NULL);
	if(elementtype == 'SN')
	{
		pIStream->Read(&fValue,sizeof(float),NULL);	
		if( nIdx==0 || nIdx==1 || nIdx==3 )
		{
			CodeCash codecash;
			memset(&codecash,0,sizeof(CodeCash));
			memcpy(codecash.szCode,frameid.szItemCode,8);
			if( IsIndex() )
			{
				CString str;
				str.Format("%.0f",fValue);
				fValue = atof(str);
				if( codecash.szCode[0]=='X' )
				{
					memmove(codecash.szCode,codecash.szCode+1,7);
					codecash.szCode[7] = frameid.szItemCode[7];
				}
			}
			codecash.fCash = fValue;
			EnterCriticalSection(&m_cs);
			for( int k=0;k<m_arrCash.GetSize();k++ )
			{
				if( memcmp(m_arrCash[k].szCode,codecash.szCode,8)==0 )
				{
					m_arrCash[k].fCash = codecash.fCash;
					break;
				}
			}
			if( k==m_arrCash.GetSize() )
			{
				m_arrCash.Add(codecash);
			}
			LeaveCriticalSection( &m_cs );
		}
		if(nIdx == 0)
		{
			GetTextEx(m_szCash,fValue,m_cbDecimal);
			::PostMessage(m_hWnd,CM_SETWINDOWTEXT,0,0);
			BOOL bCalc = FALSE;
			int tempDivi = m_nDivision;
			int tempNum = ClosestCashNum();
			if( tempDivi!=m_nDivision && !IsIndex() )
			{
				bCalc = TRUE;
			}
			if( m_bSimple==1 && !IsIndex() )
			{
				if( m_pList1->m_iNum==-1&&tempNum!=-1 )
					bCalc = TRUE;
				if( m_pList1->m_iNum!=-1&&tempNum!=-1&&strcmp(m_pList1->m_buf[tempNum].m_szStrike, m_pList1->m_buf[m_pList1->m_iNum].m_szStrike)!=0 )
					bCalc = TRUE;
			}
			if( bCalc )
			{
				CalcAllIVData();
				m_pList1->SelectSimpleMode(m_bSimple, tempNum);
//				OnSelectColumnWidth();
			}

		}
		else if(nIdx == 1 || nIdx == 3)
		{
			CString szFutures = m_szFutures;
			GetTextEx(m_szFutures,fValue,m_cbDecimal);
			::PostMessage(m_hWnd,CM_SETWINDOWTEXT,1,0);
			BOOL bCalc = FALSE;
			CString strtemp = m_szCash;
			int tempDivi = m_nDivision;
			if( m_bCash && IsIndex() )
			{
				bCalc = TRUE;
			}
			int tempNum = ClosestCashNum();
			
			if( szFutures=="" )
			{
				bCalc = TRUE;
			}
			if( tempDivi!=m_nDivision )
			{
				if( IsIndex() || (!IsIndex() && strtemp=="") )
					bCalc = TRUE;
			}
			if( m_bSimple==1 )
			{
				if( IsIndex() || (!IsIndex() && strtemp=="") )
				{
					if( m_pList1->m_iNum==-1 &&tempNum!=-1)
						bCalc = TRUE;
					if( m_pList1->m_iNum==-1&&tempNum!=-1&&strcmp(m_pList1->m_buf[tempNum].m_szStrike, m_pList1->m_buf[m_pList1->m_iNum].m_szStrike)!=0 )
						bCalc = TRUE;
				}
			}
			if( bCalc )
			{
				CalcAllIVData();
				m_pList1->SelectSimpleMode(m_bSimple, tempNum);
//				OnSelectColumnWidth();
			}
		}
		else if( nIdx==2 )
		{
			GetTextEx(m_szVHSI,fValue,2);
			::PostMessage(m_hWnd,CM_SETWINDOWTEXT,2,0);
		}
	}
}

LRESULT CTTOptions::OnResetTable(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	ResetTable();
	return 0;
}

void CTTOptions::ResetTable()
{
	m_nDataTotal = 0 ;
	if( m_pList1->m_hWnd != NULL )
		m_pList1->SetItemsTotal( 0, NULL) ;
}

int CTTOptions::FindRow(float fStrike)
{
	if(fStrike == 0.0)
		return -1;

	
	ATLASSERT( m_nDataTotal<=MACRO_MaxItems ) ;
	for( int i = 0; i < m_nDataTotal; i++)
	{
		if(fStrike == m_pDataBuf[i].m_fStrike )
			return i ;
	}
	return -1;
	
}

int CTTOptions::DeleteRow(float fStrike)
{
	if(fStrike == 0.0 )
		return -1;
	for(int i = 0; i< m_nDataTotal; i++)
	{
		if( m_pDataBuf[i].m_fStrike==fStrike )
		{
			m_nDataTotal-- ;
			for(int j = i; j < m_nDataTotal; j ++)
			{
				m_pDataBuf[j] = m_pDataBuf[j+1];
				memcpy( m_pList1->m_buf+j, m_pList1->m_buf+j+1, sizeof(ItemOptionsText) ) ; 
			}
			return i ;
		}

	}
	return -1 ;
	
}

int CTTOptions::InsertRow(float fStrike)
{
	if(fStrike == 0.0)//�Ƚ��е㲻�װ�
		return -1;
	BOOL bInsert = FALSE;
	int i;
	if( m_nDataTotal>=MACRO_MaxItems )
		return -1;
	int cnt  = m_nDataTotal;
	for(i = 0; i< cnt ; i++) //����С�����˳�����
	{
		if(m_pDataBuf[i].m_fStrike == fStrike)
			return i;
		else
		{
			if(m_pDataBuf[i].m_fStrike < fStrike)
				continue;
			else
			{
				bInsert = TRUE;
				if( m_nDataTotal<MACRO_MaxItems )
					m_nDataTotal++;
				for(int j = m_nDataTotal ; j> i; j--)
				{
					if( j<MACRO_MaxItems )
					{
						m_pDataBuf[j] = m_pDataBuf[j-1]; 
						memcpy( m_pList1->m_buf+j, m_pList1->m_buf+j-1, sizeof(ItemOptionsText) ) ; 
					}	
				}
				m_pDataBuf[i].ReInit();
				m_pList1->m_buf[i].ReInit() ;
				m_pDataBuf[i].m_fStrike = fStrike;
				GetTextEx( m_pList1->m_buf[i].m_szStrike, fStrike, 0 );
				return i;

			}
		}
	}
	if( bInsert==FALSE && m_nDataTotal<MACRO_MaxItems )
	{	
		m_pDataBuf[m_nDataTotal].ReInit() ;
		m_pList1->m_buf[m_nDataTotal].ReInit() ;
		m_pDataBuf[m_nDataTotal].m_fStrike = fStrike;
		GetTextEx( m_pList1->m_buf[m_nDataTotal].m_szStrike, fStrike, m_cbDecimal );
		m_nDataTotal++;
		return (m_nDataTotal -1);
	}
	return -1;
	
}

HRESULT CTTOptions::ResetFrmTitle()
{
	//  +++++++++++++++++ Get TTMainFrame's IUnknown  ++++++++++++
	VARIANT var;
	var.vt = VT_UNKNOWN;
	VARIANT *pVar = &var;
	
	CComQIPtr<ITTObject,&IID_ITTObject> pObj(m_pMainFrm);
	if(pObj == NULL)
		S_FALSE;

	var.vt = VT_I4;
	var.lVal = TT_RQ_SETTITLE;
	pObj->PutByID(TTPID_MainCommand, &var);

	return S_OK;
}


void CTTOptions::SaveLastPage()
{
	m_pList1->SaveLastPage();
}

void CTTOptions::FindOIRow()
{
	float iCallUp[2],iPutUp[2],iCallDw[2],iPutDw[2],iCallMax[2],iPutMax[2];
	float temp;
	int row,i,j;

	for(i=1;i<m_nDataTotal;i++)
	{
		CString strCall,strPut;
		strCall = (m_pList1->m_buf+i)->m_szCalls_OI;
		strPut = (m_pList1->m_buf+i)->m_szPuts_OI;
		int n1,n2;
		n1 = strCall.Find('(');
		n2 = strCall.Find(')');
		if( n1!=-1 && n2!=-1 )
		{
			strCall = strCall.Mid(n1+1,n2-n1-1);
			strCall.Remove(' ');
			if(strCall!="0" && strCall.Find('+')!=-1)
				strCall = strCall.Right(strCall.GetLength()-1);
			m_fCallOIDiff[i] = atof(strCall);
		}

		n1 = strPut.Find('(');
		n2 = strPut.Find(')');
		if( n1!=-1 && n2!=-1 )
		{
			strPut = strPut.Mid(n1+1,n2-n1-1);
			strPut.Remove(' ');
			if(strPut!="0" && strPut.Find('+')!=-1 )
				strPut = strPut.Right(strPut.GetLength()-1);
			m_fPutOIDiff[i] = atof(strPut);
		}
	}

	for( j=0;j<2;j++ )
	{
		iCallUp[j] = 0;
		iPutUp[j] = 0;
		iCallDw[j] = 0;
		iPutDw[j] = 0;
		iCallMax[j] = 0;
		iPutMax[j] = 0;
		m_iCallOIUpRow[j] = 0;
		m_iCallOIDwRow[j] = 0;
		m_iPutOIUpRow[j] = 0;
		m_iPutOIDwRow[j] = 0;
		m_iCallMaxRow[j] = 0;
		m_iPutMaxRow[j] = 0;
	}
	for(i=1;i<m_nDataTotal;i++)
	{
		for( j=0;j<2;j++ )
		{
			if( m_pDataBuf[i].m_fCalls_OI>iCallMax[j] )
			{
				temp = iCallMax[j];
				row = m_iCallMaxRow[j];
				iCallMax[j] = m_pDataBuf[i].m_fCalls_OI;
				m_iCallMaxRow[j] = i;
				if(j==0)
				{
					iCallMax[1] = temp;
					m_iCallMaxRow[1] = row;
				}
				break;
			}
		}

		for( j=0;j<2;j++ )
		{
			if( m_pDataBuf[i].m_fPuts_OI>iPutMax[j] )
			{
				temp = iPutMax[j];
				row = m_iPutMaxRow[j];
				iPutMax[j] = m_pDataBuf[i].m_fPuts_OI;
				m_iPutMaxRow[j] = i;
				if(j==0)
				{
					iPutMax[1] = temp;
					m_iPutMaxRow[1] = row;
				}
				break;
			}
		}

		for( j=0;j<2;j++ )
		{
			if( m_fCallOIDiff[i]>iCallUp[j] )
			{
				temp = iCallUp[j];
				row = m_iCallOIUpRow[j];
				iCallUp[j] = m_fCallOIDiff[i];
				m_iCallOIUpRow[j] = i;
				if(j==0)
				{
					iCallUp[1] = temp;
					m_iCallOIUpRow[1] = row;
				}
				break;
			}
		}
		for( j=0;j<2;j++ )
		{
			if( m_fPutOIDiff[i]>iPutUp[j] )
			{
				temp = iPutUp[j];
				row = m_iPutOIUpRow[j];
				iPutUp[j] = m_fPutOIDiff[i];
				m_iPutOIUpRow[j] = i;
				if(j==0)
				{
					iPutUp[1] = temp;
					m_iPutOIUpRow[1] = row;
				}
				break;
			}
		}

		for( j=0;j<2;j++ )
		{
			if( m_fCallOIDiff[i]<iCallDw[j] )
			{
				temp = iCallDw[j];
				row = m_iCallOIDwRow[j];
				iCallDw[j] = m_fCallOIDiff[i];
				m_iCallOIDwRow[j] = i;
				if(j==0)
				{
					iCallDw[1] = temp;
					m_iCallOIDwRow[1] = row;
				}
				break;
			}
		}
		for( j=0;j<2;j++ )
		{
			if( m_fPutOIDiff[i]<iPutDw[j] )
			{
				temp = iPutDw[j];
				row = m_iPutOIDwRow[j];
				iPutDw[j] = m_fPutOIDiff[i];
				m_iPutOIDwRow[j] = i;
				if(j==0)
				{
					iPutDw[1] = temp;
					m_iPutOIDwRow[1] = row;
				}
				break;
			}
		}

//		char cc[50];
//		sprintf(cc,"%d:%.0f,%d:%.0f",m_iCallOIUpRow[0],iCallUp[0],m_iCallOIUpRow[1],iCallUp[1]);
//		WriteLogFile(cc);
	}

}

BOOL CTTOptions::ReadFullData(IStream* pIStream)
{
	if(!pIStream)
		return FALSE;

	BYTE nStrikes;
	HRESULT hr = pIStream->Read(&nStrikes, sizeof(nStrikes), NULL);
	if(FAILED(hr))
		return FALSE;

	m_nDataTotal = (nStrikes > MACRO_MaxItems) ? MACRO_MaxItems : nStrikes;
	if(m_nDataTotal == 0) // clear buffer and screen
	{
		::PostMessage(m_pList1->GetSafeHwnd(), LVM_DELETEALLITEMS, 0, 0);
		m_pList1->m_nTotal = 0;
		m_pList1->Invalidate(FALSE);

		return TRUE;
	}

	BYTE FlagBuf[MACRO_MaxItems];
	memset( FlagBuf, 1, sizeof(FlagBuf) ) ;
	
	m_pList1->SetItemsTotal( m_nDataTotal, FlagBuf ) ;

	float fCallOI = 0;
	float fPutOI = 0;
	for(int i=0;i<MACRO_MaxItems;i++)
	{
		m_fCallOIDiff[i] = 0.0;
		m_fPutOIDiff[i] = 0.0;
	}
	EnterCriticalSection(&m_cs);
	m_nDataTotal++;
	for(i = 0; i < m_nDataTotal; i++)
	{
		if( i==0 )
			continue;

		OPTIONSDATA data;
		if((hr = pIStream->Read(&data, sizeof(data), NULL)) != S_OK)
			break;
		m_cbDecimal = data.cbDecimal; 
		fCallOI += data.fCall_OI;
		fPutOI += data.fPut_OI;
		ConvertHelper(i, &data, &m_pDataBuf[i]);

		m_pDataBuf[i].m_fCalls_Margin = 0.0;
		m_pDataBuf[i].m_fPuts_Margin = 0.0;
	}
	{
		m_pDataBuf[0].m_fStrike = 0.0;
		char ch[10] = {0};
		if( m_lTransdate>10000000 )
		{
			CString str = m_szFuturesCode;
			str.Replace(" ","");
			strcpy(ch,str);
			sprintf(ch,"%s(%d)",ch,m_lTransdate%100);
			memcpy((m_pList1->m_buf + 0)->m_szStrike,ch,strlen(ch));
		}
		else
			memcpy((m_pList1->m_buf + 0)->m_szStrike,m_szFuturesCode,7);

		GetTextOI((m_pList1->m_buf + 0)->m_szCalls_OI, fCallOI, 0.0,TRUE);
		GetTextOI((m_pList1->m_buf + 0)->m_szPuts_OI, fPutOI, 0.0,FALSE);
		if( fCallOI!=0&&fPutOI!=0 )
		{
			sprintf(m_szPCR,"PCR=%.2f",fPutOI/fCallOI);
			UpdateTitle();
		}
	}

	LeaveCriticalSection( &m_cs );
	
	FindOIRow();
	
	m_pList1->Invalidate(FALSE);  

	return TRUE;
}

void CTTOptions::ConvertHelper(int nIdx,const OPTIONSDATA* pData, ItemOptions* pStore)
{
	// Calls part
	pStore->m_fCalls_Ask = pData->fCall_Ask;
	BOOL bThoery = (pData->cbAskFlag & 0x01);
	GetText((m_pList1->m_buf + nIdx)->m_szCalls_Ask, pData->fCall_Ask,m_cbDecimal,FALSE,bThoery);
	// GetText(pDest,fValue,m_cbDecimal,FALSE,bThoery)

	pStore->m_fCalls_AskQty = pData->fCall_AQty;
	GetText((m_pList1->m_buf + nIdx)->m_szCalls_AskQty, pData->fCall_AQty,0,FALSE,FALSE);

	pStore->m_fCalls_Bid = pData->fCall_Bid;
	bThoery = (pData->cbBidFlag & 0x01);
	GetText((m_pList1->m_buf + nIdx)->m_szCalls_Bid, pData->fCall_Bid,m_cbDecimal,FALSE,bThoery);

	pStore->m_fCalls_BidQty = pData->fCall_BQty;
	GetText((m_pList1->m_buf + nIdx)->m_szCalls_BidQty, pData->fCall_BQty,0,FALSE,FALSE);

	pStore->m_fCalls_High = pData->fCall_High;
	GetText((m_pList1->m_buf + nIdx)->m_szCalls_High, pData->fCall_High,m_cbDecimal,FALSE,FALSE);

	pStore->m_fCalls_Low = pData->fCall_Low;
	GetText((m_pList1->m_buf + nIdx)->m_szCalls_Low, pData->fCall_Low,m_cbDecimal,FALSE,FALSE);

	pStore->m_fCalls_Nominal = pData->fCall_Last;
	bThoery = (pData->cbLastFlag & 0x01);
	GetText((m_pList1->m_buf + nIdx)->m_szCalls_Nominal, pData->fCall_Last,m_cbDecimal,FALSE,bThoery);

	pStore->m_fCalls_NominalQty = pData->fCall_LQty;
	GetText((m_pList1->m_buf + nIdx)->m_szCalls_NominalQty, pData->fCall_LQty,0,FALSE,FALSE);

	pStore->m_fCalls_OI = pData->fCall_OI;
	//GetTextEx((m_pList1->m_buf + nIdx)->m_szCalls_OI, pData->fCall_OI, 0);
	GetTextOI((m_pList1->m_buf + nIdx)->m_szCalls_OI, pData->fCall_OI, pData->fStrike,TRUE);

	pStore->m_fCalls_Vol = pData->fCall_Vol;
	GetTextEx((m_pList1->m_buf + nIdx)->m_szCalls_Vol, pData->fCall_Vol, 0);
	
	// Puts part
	pStore->m_fPuts_Ask = pData->fPut_Ask;
	bThoery = (pData->cbAskFlag2 & 0x01);
	GetText((m_pList1->m_buf + nIdx)->m_szPuts_Ask, pData->fPut_Ask,m_cbDecimal,FALSE,bThoery);

	pStore->m_fPuts_AskQty = pData->fPut_AQty;
	GetText((m_pList1->m_buf + nIdx)->m_szPuts_AskQty, pData->fPut_AQty,0,FALSE,FALSE);

	pStore->m_fPuts_Bid = pData->fPut_Bid;
	bThoery = (pData->cbBidFlag2 & 0x01);
	GetText((m_pList1->m_buf + nIdx)->m_szPuts_Bid, pData->fPut_Bid,m_cbDecimal,FALSE,bThoery);

	pStore->m_fPuts_BidQty = pData->fPut_BQty;
	GetText((m_pList1->m_buf + nIdx)->m_szPuts_BidQty, pData->fPut_BQty,0,FALSE,FALSE);

	pStore->m_fPuts_High = pData->fPut_High;
	GetText((m_pList1->m_buf + nIdx)->m_szPuts_High, pData->fPut_High,m_cbDecimal,FALSE,FALSE);

	pStore->m_fPuts_Low = pData->fPut_Low;
	GetText((m_pList1->m_buf + nIdx)->m_szPuts_Low, pData->fPut_Low,m_cbDecimal,FALSE,FALSE);

	pStore->m_fPuts_Nominal = pData->fPut_Last;
	bThoery = (pData->cbLastFlag2 & 0x01);
	GetText((m_pList1->m_buf + nIdx)->m_szPuts_Nominal, pData->fPut_Last,m_cbDecimal,FALSE,bThoery);

	pStore->m_fPuts_NominalQty = pData->fPut_LQty;
	GetText((m_pList1->m_buf + nIdx)->m_szPuts_NominalQty, pData->fPut_LQty,0,FALSE,FALSE);

	pStore->m_fPuts_OI = pData->fPut_OI;
	//GetTextEx((m_pList1->m_buf + nIdx)->m_szPuts_OI, pData->fPut_OI, 0);
	GetTextOI((m_pList1->m_buf + nIdx)->m_szPuts_OI, pData->fPut_OI, pData->fStrike,FALSE);

	pStore->m_fPuts_Vol = pData->fPut_Vol;
	GetTextEx((m_pList1->m_buf + nIdx)->m_szPuts_Vol, pData->fPut_Vol, 0);

	pStore->m_fStrike = pData->fStrike;
//	GetText((m_pList1->m_buf + nIdx)->m_szStrike, pData->fStrike, 0, FALSE,FALSE);
	GetText((m_pList1->m_buf + nIdx)->m_szStrike, pData->fStrike, m_cbDecimal, FALSE,FALSE); //andy 2009.05.07

}

// ���յ� 'DO'->'DT'֡�����m_lstMonths���ݽṹ
// (����Ϊ���ñ�����ǰ�Ѿ�������"Element Type"�ֶ�)
BOOL CTTOptions::FillMonthList(IStream* pIStream)
{
	if(!pIStream)
		return FALSE;

	m_pbtnOptMonth->ShowWindow(SW_SHOW);
	m_pstaExpiryDate->ShowWindow(SW_SHOW);

	HRESULT hr;
	BYTE cbMonth;
	if((hr = pIStream->Read(&cbMonth, sizeof(cbMonth), NULL)) != S_OK)
		return FALSE;
	if(cbMonth < 1)
		return FALSE;

	m_lstMonths.RemoveAll(); // clear previous month list
	BOOL Brealky=FALSE;
	BOOL Brealkyd=FALSE;
	LONG thedate= CTime::GetCurrentTime().GetYear()*100 + CTime::GetCurrentTime().GetMonth();
	LONG rmonth=0;
	BOOL Brmonth=TRUE;
	LONG theMonth;
	for(int i = 0; i < (int)cbMonth; i++)
	{
		if((hr = pIStream->Read(&theMonth, sizeof(theMonth), NULL)) != S_OK)
			break;
		if(Brmonth){rmonth=theMonth;
		Brmonth=FALSE;}
		if(rmonth>theMonth)rmonth=theMonth;
		if(m_PTransdate==theMonth)Brealky=TRUE;
		if(thedate==theMonth)Brealkyd=TRUE;
		m_lstMonths.AddTail(theMonth);
	}
	 if(!Brealky)//2011.12.29 daniel ���Ĺ����·�
	{

		SendUpdateRQ(FALSE);
		if(Brealkyd)m_lTransdate=thedate;
		else
		m_lTransdate=rmonth;
		sprintf(m_szText, "%2d/%4d",m_lTransdate%100,m_lTransdate/100);
		m_pbtnOptMonth->SetWindowText(m_szText);	//modify				
		::SetWindowText( m_pedtFutures->m_hWnd,_T(""));
		
		ResetTable() ;
		SendRequestFrame();
		ResetFrmTitle() ;
		SaveValue() ;

		//SaveValueColor();//add 2014.9.25 Keeping
//		m_bClick_SelMonth = FALSE;
	}
	SendTeleHisRQ(); //2003.02.20 andy add for request future

	

	GetExpiryTime(); 
		UpdateTitle();

	return SUCCEEDED(hr);
}

BOOL CTTOptions::RemoveMonth(LONG theMonth)
{
	int nMonths;
	if((nMonths = m_lstMonths.GetCount()) < 1)
		return FALSE;

	for(int i = 0; i < nMonths; i++)
	{
		POSITION pos = m_lstMonths.FindIndex(i);
		LONG month = m_lstMonths.GetAt(pos);
		if(month == theMonth)
		{
			m_lstMonths.RemoveAt(pos);
			break;
		}
	}

	return (i < nMonths);
}

BOOL CTTOptions::IsClearScreenFrame(IStream* pIStream)
{
	ASSERT(pIStream);

	BOOL bRet = FALSE;

	int nOffset = 0;
	WORD wElemType;
	HRESULT hr = pIStream->Read(&wElemType, sizeof(wElemType), NULL);
	if(SUCCEEDED(hr))
	{
		nOffset += sizeof(wElemType);
		if(wElemType == 'ST')
		{
			BYTE nCount;
			hr = pIStream->Read(&nCount, sizeof(nCount), NULL);
			if(SUCCEEDED(hr))
			{
				nOffset += sizeof(nCount);
				bRet = (nCount == 0);
			}
		}
	}

	if(nOffset > 0 && !bRet)
	{
		LARGE_INTEGER pos;
		pos.QuadPart = -1 * nOffset;
		pIStream->Seek(pos, STREAM_SEEK_CUR, NULL);
	}

	return bRet;
}

void CTTOptions::ClearScreen()
{
	//m_nDataTotal = 0; 

	//::PostMessage(m_pList1->GetSafeHwnd(), LVM_DELETEALLITEMS, 0, 0);
	//m_pList1->m_nTotal = 0;
	//m_pList1->Invalidate(FALSE);
	ResetTable();
	ResetView();

	/*static int time = 0;
	time++;
	if( time==2 )
	{
		time = 0;

		if( m_iLangType==0 )
			::MessageBox(NULL,_T("No Options Data."),_T("Tips"),MB_OK);
		else if( m_iLangType==1 )
			::MessageBox(NULL,_T("û����Ȩ����."),_T("Tips"),MB_OK);
		else if( m_iLangType==2 )
			::MessageBox(NULL,_T("�S�����v�ƾ�."),_T("Tips"),MB_OK);
	}*/
	//SendMonthRequestFrame();
}

BYTE CTTOptions::ReadExpiryDateListFile()
{
	m_fRiskInterest  = 0.0446;

	m_ExpiryDateMap.RemoveAll();
	m_ItemSharesMap.RemoveAll();

	CString strItem;
	OptionsExpiryDateInfo expInfo;
	OptionsItemShares     itemshares;

	char fbuff[MAX_PATH];
	sprintf( fbuff, "%sdata\\Options.Exp", m_szRootPath );
	HANDLE hFile = CreateFile(fbuff,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
		OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		//Beep(0x300,100);
		MessageBeep(MB_OK);
//		if(m_iLangType == 2)
//			::MessageBox(NULL,_T("���} Options.Exp ����."),_T("���~!"),MB_OK);
//		else if(m_iLangType == 1)
//			::MessageBox(NULL,_T("�� Options.Exp ʧ��."),_T("����!"),MB_OK);
//		else
//			::MessageBox(NULL,_T("Open Options.Exp failed."),_T("Error!"),MB_OK);
		return 1;
	}
	OptionsExpiryDateFileHead txthead;
	OptionsExpiryDateItem     txt;
	OptionsExpiryDate  expDate;
	DWORD dwTm;
		
	if(ReadFile(hFile,&txthead,sizeof(OptionsExpiryDateFileHead),&dwTm,NULL) !=0)		
	{
		if (memcmp(txthead.m_szFileID,DE_FILEID,strlen(DE_FILEID)) != 0)
		{
			CloseHandle(hFile);
			return 1;
		}

		m_fRiskInterest = txthead.m_fInterestRate;

		for(int i = 0; i< txthead.m_nItemCount; i++)
		{
			expInfo.expList.RemoveAll();

			if(!ReadFile(hFile,&txt,sizeof(OptionsExpiryDateItem),&dwTm,NULL))
			{
				CloseHandle(hFile);
				return 1;
			}	

			char szItem[10];
			memset(szItem,0,sizeof(szItem));
			szItem[0] = txt.cGroup;
			memcpy(&szItem[1],txt.szItemCode,8);
			strItem = szItem;

			itemshares.Shares = txt.m_lShares;
			m_ItemSharesMap.SetAt((LPCSTR)strItem, itemshares);

			for (int j = 0; j < txt.nMonthCount; j++)
			{
				if(!ReadFile(hFile,&expDate,sizeof(OptionsExpiryDate),&dwTm,NULL))
				{				
					CloseHandle(hFile);
					return 1;
				}	
				
				expInfo.expList.Add(expDate);
			}

			m_ExpiryDateMap.SetAt((LPCSTR)strItem,expInfo); 

		}//end of for				
	}//end of if	
	 
	CloseHandle(hFile);

	return 0;

}

byte CTTOptions::CalcAllIVData()
{
	for(int i = 0; i < m_nDataTotal; i++)
	{	
		CalcIVData(i,m_pDataBuf[i],POS_CALL_LAST);
		CalcIVData(i,m_pDataBuf[i],POS_CALL_BID);
		CalcIVData(i,m_pDataBuf[i],POS_CALL_ASK);
		CalcIVData(i,m_pDataBuf[i],POS_PUT_LAST);
		CalcIVData(i,m_pDataBuf[i],POS_PUT_BID);
		CalcIVData(i,m_pDataBuf[i],POS_PUT_ASK);	
	}
	

	return 0;
}

byte CTTOptions::CalcIV()
{
	int		m_nCalType;
	int		m_nModelType;
	int		m_nWarrantType;
	double	m_dAssetPrice;
	double	m_dR;
	double	m_dSD;
	double	m_dStrikePrice;
	double	m_dT_t;
	double	m_dWarrantPrice;
	double	m_dConversionRatio;

	m_nCalType = 0;
	m_nModelType = 0;
	m_nWarrantType = 0;
	m_dAssetPrice = 125.9375;	// ���ɼ�
	m_dR = 0.0446;				// �޷�������
	m_dSD = 0.83;				// ��׼��
	m_dStrikePrice = 125.0;		// ��ʹ��
	m_dT_t = 0.0959;			// ʱ��( ʣ��ʱ�� �� 365���еı��� )
	m_dWarrantPrice = 13.21;	// Ȩ֤��
	m_dConversionRatio = 1.0;
	double R_Percent = 0.0;



	BOOL bCall = ( m_nWarrantType==0 ) ? TRUE : FALSE ;
	WARRANTOPT opt ;
	BSMCALINFO calinfo ;

	opt.bCallOption		= bCall ;
	opt.warrantPrice	= m_dWarrantPrice ;
	opt.conversionRatio	= m_dConversionRatio ;
	opt.currentAssetPrice = m_dAssetPrice ;
	opt.R				= R_Percent ;
	opt.exercisePrice   = m_dStrikePrice ;
	opt.T_t				= m_dT_t ;
	opt.riskFreeInterestRate = m_dR ;
	opt.sd				= m_dSD ;
	if( m_nModelType==0 )	// Black-Scholes Model		
	{
		if( m_nCalType==0 )		// bi section.
		{			
			CBSMWrapper::CalIV_BySection( opt, calinfo ) ;	
		}
		else
		{
			CBSMWrapper::CalIV_ByCalculous( opt, calinfo ) ;	
		}

	}
	else	// Black Model 1976
	{
		if( m_nCalType==0 )		// bi section.
		{			
			CBM1976Wrapper::CalIV_BySection( opt, calinfo ) ;	
		}
		else
		{
			CBM1976Wrapper::CalIV_ByCalculous( opt, calinfo ) ;	
		}

	}

	return 0;
}

double CTTOptions::ModelPrice(BOOL bOption,   //call or put option   		  
					double dStrike,   //��ʹ��
					double dMaket,    //�г���
					int	   iExpDay,   //ʣ�ൽ����
					int    nAddr,     //index
					BSMCALINFO& calinfo,
					BYTE bPos)     
{
	double  dIV = 0.83;//������

	double	m_dAssetPrice;
	double	m_dR;
	double	m_dSD;
	double	m_dStrikePrice;
	double	m_dT_t;
	double	m_dWarrantPrice;
	double	m_dConversionRatio;

	m_dConversionRatio = 1.0;

	if( dMaket==0.0 )
	{
		if( strcmp(m_szFutures,"")==0&&IsIndex()  )
		{
			memset(&calinfo,0,sizeof(calinfo));
			return 0;
		}

		m_dAssetPrice = GetCorrStockPrice(FALSE);// ���ɼ�
		if( m_pwndCls!=NULL && (m_pwndCls->m_nIndex==17||m_pwndCls->m_nIndex==18) && IsIndex() )
		{
		/*	CCashArray temparr;
			temparr.RemoveAll();
			EnterCriticalSection(&m_cs);
			temparr.Copy(m_arrCash);
			LeaveCriticalSection( &m_cs );
			char code[9] = {0};
			if( bPos==0 )
				GetCashOrFuturesCode(m_szItemCode,m_pwndCls->m_lCaldExpDate1, code);
			else
				GetCashOrFuturesCode(m_szItemCode,m_pwndCls->m_lCaldExpDate2, code);
			for( int k=0;k<m_arrCash.GetSize();k++ )
			{
				if( memcmp(m_arrCash[k].szCode,code,8)==0 )
				{	
					m_dAssetPrice = m_arrCash[k].fCash;
					break;
				}
			}*/
			if( bPos==0 )
				m_dAssetPrice = m_pwndCls->GetMonthPrice(m_pwndCls->m_lCaldExpDate1);
			else
				m_dAssetPrice = m_pwndCls->GetMonthPrice(m_pwndCls->m_lCaldExpDate2);
		}
		m_dR = m_fRiskInterest;  	// �޷�������
		
		m_dSD = dIV;						// ��׼�� ������־���Ҫ�����IV,������
		m_dStrikePrice = dStrike;	// ��ʹ��
		m_dT_t = m_lExpiryDays / 365.0;	// ʱ��( ʣ��ʱ�� �� 365���еı��� )
		if( m_pwndCls!=NULL && (m_pwndCls->m_nIndex==17 || m_pwndCls->m_nIndex==18) )
		{
			m_dT_t = iExpDay / 365.0;
		}

		
		switch(nAddr)
		{
		case POS_CALL_LAST:
			m_dWarrantPrice = m_pDataBuf[FindRow(dStrike)].m_fCalls_Nominal;
			break;
		case  POS_CALL_BID:   //CALL�� ���� ֵ
			m_dWarrantPrice = m_pDataBuf[FindRow(dStrike)].m_fCalls_Bid;	// Ȩ֤��
			break;
		case  POS_CALL_ASK:   //CALL�� ���� ֵ
			m_dWarrantPrice = m_pDataBuf[FindRow(dStrike)].m_fCalls_Ask;	// Ȩ֤��
			break;
		case POS_PUT_LAST:
			m_dWarrantPrice = m_pDataBuf[FindRow(dStrike)].m_fPuts_Nominal;
			break;
		case  POS_PUT_BID:    //PUT��  ���� ֵ
			m_dWarrantPrice = m_pDataBuf[FindRow(dStrike)].m_fPuts_Bid;	// Ȩ֤��
			break;
		case  POS_PUT_ASK:    //PUT��  ���� ֵ
			m_dWarrantPrice = m_pDataBuf[FindRow(dStrike)].m_fPuts_Ask;	// Ȩ֤��
			break;
		default:
			break;
		}

		if( m_pwndCls!=NULL && (m_pwndCls->m_nIndex==17 || m_pwndCls->m_nIndex==18) )
		{
			if( bPos==0 || bPos==1 )
				m_dWarrantPrice = m_pwndCls->m_fiSignPrice[bPos];
			else
			{
				for( int i=0;i<m_arrCD.GetSize();i++ )
				{
					if( m_arrCD[i].lDate==m_pwndCls->m_cald.lMonth1 && strcmp(m_arrCD[i].szCode,m_szItemCode) )
						break;
				}
				if( i!=m_arrCD.GetSize() )
				{
					for( int j=0;j<m_arrLP[i].GetSize();j++ )
					{
						if( dStrike==m_arrLP[i][j].fStrike )
						{
							if( bOption )
								m_dWarrantPrice = m_arrLP[i][j].fCall;
							else
								m_dWarrantPrice = m_arrLP[i][j].fPut;
							break;
						}
					}
				}
			}
		}
		
		if( m_dWarrantPrice==0.0 && dMaket==0.0 )
		{
			memset(&calinfo,0,sizeof(calinfo));
			return 0;
		}
		
		double R_Percent = 0.0;
		BOOL bCall = ( bOption ) ? TRUE : FALSE ;
		WARRANTOPT opt ;
		
		opt.PaiXi_1 = m_dPaiXi_1;
		opt.PaiXi_2 = m_dPaiXi_2;
		opt.bIndex = IsIndex();
		opt.bCallOption		= bCall ;
		opt.warrantPrice	= m_dWarrantPrice ;
		opt.conversionRatio	= m_dConversionRatio ;
		opt.currentAssetPrice = m_dAssetPrice ;
		opt.R				= R_Percent ;
		opt.exercisePrice   = m_dStrikePrice ;
		opt.T_t				= m_dT_t ;
		opt.riskFreeInterestRate = m_dR ;
		opt.sd				= m_dSD ;
		
		if( (m_dStrikePrice*m_dAssetPrice*m_dSD*m_dT_t)==0.0 )
		{
			memset(&calinfo,0,sizeof(calinfo));
			return 0;
		}
		
		
		CBM1976Wrapper::CalIV_BySection( opt, calinfo ) ;
		return 0;
	
	}


	CString str;
	switch( m_pwndCls->m_iOdr )
	{
	case 1:
	case 4:
		m_pwndCls->m_editIV1.GetWindowText(str);
		dIV = atof(str)/100.0;
		break;
	case 2:
		m_pwndCls->m_editIV2.GetWindowText(str);
		dIV = atof(str)/100.0;
		break;
	case 3:
		m_pwndCls->m_editIV3.GetWindowText(str);
		dIV = atof(str)/100.0;
		break;
//	case 4:
//		dIV = m_pwndCls->m_fTheoIV/100.0;
		/*if( IsIndex() && m_fBF>1.0 )
			dIV = m_fBF/100.0;
		else if( !IsIndex() && m_fBF>0.01 )
			dIV = m_fBF;*/
	}
	m_pwndCls->m_iOdr = -1;
	
	double MOP;
	double F = dMaket;
	double sd = dIV;
	double X = dStrike ;
	double r = m_fRiskInterest*0.01 ;
	double dT_t = iExpDay/365.0;
	double time_sqrt = sqrt(dT_t) ;

	double vega,gamma,delta,theta;

	if(!IsIndex()&&m_dPaiXi_1!=0)
	{
		double PaiXi_1,PaiXi_2;
		PaiXi_1 = m_dPaiXi_1;
		PaiXi_2 = m_dPaiXi_2;
		PaiXi_1 -= int(PaiXi_1/100)*100;
		PaiXi_2 -= int(PaiXi_2/100)*100; 
		F = F-PaiXi_1-PaiXi_2;
	}
	
	if( (F*X*sd*time_sqrt)==0.0 )
	{
		memset(&calinfo,0,sizeof(calinfo));
		return 0;
	}

	double d1 = ( log( F/X ) + (r+0.5*sd*sd)*dT_t ) /  ( sd*time_sqrt ) ;
	double d2 = d1 - sd*time_sqrt ;

	double N_d1  =  ( d1>0.0) ? CBM1976Wrapper::N(d1) : 1.0-CBM1976Wrapper::N(fabs(d1)) ;			// 
	double N_d2  =  ( d2>0.0) ? CBM1976Wrapper::N(d2) : 1.0-CBM1976Wrapper::N(fabs(d2)) ;			// 
	double Np_d1 =	pow( MathE, -0.5*d1*d1 ) / ( sqrt( 2.0*MathPI ) ) ;

	double MOP1 = ( F*N_d1 )- (pow( MathE, -1.0*r*dT_t )*X*N_d2 );
	double MOP2 = MOP1 + X*pow( MathE, -1.0*r*dT_t )-F;
	// BS���� ��֤�۸�.
	
	if( bOption==TRUE )
	{
		MOP = MOP1;
	}
	else
	{
		MOP = MOP2 ;	
	}

////////////////////////////////////
/*	if( !IsIndex() )
	{
		double PaiXi_1,PaiXi_2;
		PaiXi_1 = m_dPaiXi_1;
		PaiXi_2 = m_dPaiXi_2;
		double D_t = dT_t/CONST_STEP;
		double sd_u = exp(sd*sqrt(D_t));
		double sd_d = exp(-1.0*sd*sqrt(D_t));
	//	double p = (exp(r*D_t)-sd_d)/(sd_u-sd_d);
		double p = (1.0+r*D_t-sd_d)/(sd_u-sd_d);
		int i,j,k;
		double Binominal[CONST_STEP][CONST_STEP];
		double MOP_Step[CONST_STEP];
		double Price_Step[CONST_STEP+1];
		memset(MOP_Step,0,CONST_STEP*sizeof(double));
		memset(Price_Step,0,(CONST_STEP+1)*sizeof(double));
		memset(Binominal,0,CONST_STEP*CONST_STEP*sizeof(double));
		double MOPStep2;
		double Delta_Step1_1,Delta_Step1_2;
		double opt_u,opt_d;
		double S_u = F*sd_u;
		double S_d = F*sd_d;
		int nStep1,nStep2;
		if( PaiXi_1==0.0 )
		{
			Price_Step[0] = F;
			nStep1 = 0;
		}
		else
		{
			nStep1 = int(PaiXi_1/100);
			nStep2 = int(PaiXi_2/100);
			PaiXi_1 -= nStep1*100;
			PaiXi_2 -= nStep2*100;   
			if( nStep1<2 )
			{
				nStep1 = 2;  //�������greeks
			}
			else if( nStep1==CONST_STEP )
			{
				nStep1 = 0;
				Price_Step[0] = F;
				PaiXi_2 += PaiXi_1;
			}
		}
		for( i=nStep1;i>0;i-- )
		{
			Price_Step[nStep1-i] = F*pow(sd_u,i)*pow(sd_d,nStep1-i)-PaiXi_1;
			i--;
			Price_Step[nStep1-i] = F*pow(sd_u,i)*pow(sd_d,nStep1-i)-PaiXi_1;
			i++;
		}

		double tempPrice = 0.0;
		if( bOption==TRUE )
		{
			for( j=0;j<=nStep1;j++ )
			{
				for( i=CONST_STEP;i>nStep1;i-- )
				{
					opt_u = Price_Step[j]*pow(sd_u,i-nStep1)*pow(sd_d,CONST_STEP-i)-X-PaiXi_2;
					if( opt_u<0.0 )
						opt_u = 0.0;
	
					i--;
					opt_d = Price_Step[j]*pow(sd_u,i-nStep1)*pow(sd_d,CONST_STEP-i)-X-PaiXi_2;
					if( opt_d<0.0 )
						opt_d = 0.0;
					i++;

					tempPrice = Price_Step[j]*pow(sd_u,i-nStep1-1)*pow(sd_d,CONST_STEP-i);
					Binominal[j][CONST_STEP-i] = (opt_u*p+opt_d*(1.0-p))/(1.0+r*D_t);
					if( Binominal[j][CONST_STEP-i]<(tempPrice-X) )
					{
						Binominal[j][CONST_STEP-i] = tempPrice-X;
					}
				}
			}
		}
		else
		{
			for( j=0;j<=nStep1;j++ )
			{
				for( i=CONST_STEP;i>nStep1;i-- )
				{
					opt_u = X-Price_Step[j]*pow(sd_u,i-nStep1)*pow(sd_d,CONST_STEP-i)-PaiXi_2;
					if( opt_u<0.0 )
						opt_u = 0.0;
					
					i--;
					opt_d = X-Price_Step[j]*pow(sd_u,i-nStep1)*pow(sd_d,CONST_STEP-i)-PaiXi_2;
					if( opt_d<0.0 )
						opt_d = 0.0;
					i++;

					tempPrice = Price_Step[j]*pow(sd_u,i-nStep1-1)*pow(sd_d,CONST_STEP-i);
					Binominal[j][CONST_STEP-i] = (opt_u*p+opt_d*(1.0-p))/(1.0+r*D_t);
					if( Binominal[j][CONST_STEP-i]<(X-tempPrice) )
					{
						Binominal[j][CONST_STEP-i] = X-tempPrice;
					}
				}
			}
		}

		int nCount = 0;
		if( nStep1==0 )
		{
			nCount = CONST_STEP-1;
			for( i=0;i<CONST_STEP;i++ )
			{
				MOP_Step[i] = Binominal[0][i];
			}
		}
		else
		{
			nCount = nStep1;
			for( i=0;i<=nStep1;i++ )
			{
				for( j=CONST_STEP-nStep1-1;j>0;j-- )
				{
					for( k=j;k>0;k-- )
					{
						tempPrice = Price_Step[i]*pow(sd_u,k-1)*pow(sd_d,j-k);
						if( j==1 )
							tempPrice = Price_Step[i]+PaiXi_1;
						Binominal[i][j-k] = (Binominal[i][j-k]*p+Binominal[i][j-k+1]*(1.0-p))/(1.0+r*D_t);
						if( bOption==TRUE )
						{
							if( Binominal[i][j-k]<tempPrice-X )
								Binominal[i][j-k] = tempPrice-X;
						}
						else
						{
							if( Binominal[i][j-k]<X-tempPrice )
								Binominal[i][j-k] = X-tempPrice;
						}
					}
				}
				MOP_Step[i] = Binominal[i][0];
			}
		}
		

		for( i=nCount;i>0;i-- )
		{
			if( i==2 )
			{
				Delta_Step1_1 = (MOP_Step[0]-MOP_Step[1])/(S_u*sd_u-S_u*sd_d);
				Delta_Step1_2 = (MOP_Step[1]-MOP_Step[2])/(S_u*sd_d-S_d*sd_d);
				MOPStep2 = MOP_Step[1];
			}
			if( i==1 )
				delta = (MOP_Step[0]-MOP_Step[1])/(S_u-S_d);
			for( j=i;j>0;j-- )
			{
				tempPrice = F*pow(sd_u,j-1)*pow(sd_d,i-j);
				MOP_Step[i-j] = (MOP_Step[i-j]*p+MOP_Step[i-j+1]*(1.0-p))/(1.0+r*D_t);
				if( i!=1 )
				{
					if( bOption==TRUE )
					{
						if( MOP_Step[i-j]<tempPrice-X )
						{
							MOP_Step[i-j] = tempPrice-X;
						}
					}
					else
					{
						if( MOP_Step[i-j]<X-tempPrice )
						{
							MOP_Step[i-j] = X-tempPrice;
						}
					}
				}
			}
		}
		MOP = MOP_Step[0];
		theta = (MOPStep2-MOP)/(D_t*2*365);
		gamma = (Delta_Step1_1-Delta_Step1_2)/(S_u-S_d);
	}*/

	vega  = F*time_sqrt*Np_d1*0.01/m_dConversionRatio  ;	// paul, 2008-4-30, *0.01/conversionRatio
//	if( IsIndex() )
	{
	delta = ( bOption==TRUE ) ? N_d1 : N_d1-1.0 ;	// ÿ�� �Գ�ֵ
	gamma = Np_d1 / ( F*sd*time_sqrt ) ;
	theta = ( bOption==TRUE ) ? 
						-1.0*( F*Np_d1*sd / (2.0*time_sqrt) ) - r*X*pow( MathE, -1.0*r*dT_t )*N_d2 : 
						-1.0*( F*Np_d1*sd / (2.0*time_sqrt) ) + r*X*pow( MathE, -1.0*r*dT_t )*( 1-N_d2 ) ; 	
	theta = theta/(365.0*m_dConversionRatio) ;	// paul, 2008-4-30
											// ben 2017.6.29   252��Ϊ365
	}

	calinfo.delta = delta;
	calinfo.gamma = gamma;
	calinfo.vega = vega;
	calinfo.theta = theta;
	calinfo.ITM = N_d2;

	return MOP;
}

byte CTTOptions::CalcIVData(int nIndex,ItemOptions& Item, int nSubItem)
{
	int		m_nCalType;
	int		m_nModelType;
	int		m_nWarrantType;
	double	m_dAssetPrice;
	double	m_dR;
	double	m_dSD;
	double	m_dStrikePrice;
	double	m_dT_t;
	double	m_dWarrantPrice;
	double	m_dConversionRatio;

	m_nCalType = 0;
	m_nModelType = 1;
//	m_nWarrantType = 0;
	m_dAssetPrice = GetCorrStockPrice(FALSE);// ���ɼ�
	m_dR = m_fRiskInterest;  //0.0446;	// �޷�������


	m_dSD = 0.83;						// ��׼�� ������־���Ҫ�����IV,������
	m_dStrikePrice = Item.m_fStrike;	// ��ʹ��
	m_dT_t = m_lExpiryDays / 365.0;	// ʱ��( ʣ��ʱ�� �� 365���еı��� )

	switch(nSubItem)
	{
	case  POS_CALL_LAST:  //CALL�� �ɼ� ֵ
		m_dWarrantPrice = Item.m_fCalls_Nominal;	// Ȩ֤��
		break;
	case  POS_CALL_BID:   //CALL�� ���� ֵ
		m_dWarrantPrice = Item.m_fCalls_Bid;	// Ȩ֤��
		break;
	case  POS_CALL_ASK:   //CALL�� ���� ֵ
		m_dWarrantPrice = Item.m_fCalls_Ask;	// Ȩ֤��
		break;
	case  POS_PUT_LAST:   //PUT��  �ɼ� ֵ
		m_dWarrantPrice = Item.m_fPuts_Nominal;	// Ȩ֤��
		break;
	case  POS_PUT_BID:    //PUT��  ���� ֵ
		m_dWarrantPrice = Item.m_fPuts_Bid;	// Ȩ֤��
		break;
	case  POS_PUT_ASK:    //PUT��  ���� ֵ
		m_dWarrantPrice = Item.m_fPuts_Ask;	// Ȩ֤��
		break;
	default:
		return 1;
	}

	if( m_dWarrantPrice==0.0 )
		return 1;
	
	m_dConversionRatio = 1.0;


	double  R_Percent = 0.0;

	BOOL bCall = ( nSubItem < 10 ) ? TRUE : FALSE ;
	if( m_bIVMode==2 )
		bCall = ( nSubItem < 7 ) ? TRUE : FALSE ;

	WARRANTOPT opt ;
	BSMCALINFO calinfo ;
	memset(&calinfo,0,sizeof(BSMCALINFO));

	opt.PaiXi_1 = m_dPaiXi_1;
	opt.PaiXi_2 = m_dPaiXi_2;
	opt.bCallOption		= bCall ;
	opt.bIndex = IsIndex();
	opt.warrantPrice	= m_dWarrantPrice ;
	opt.conversionRatio	= m_dConversionRatio ;
	opt.currentAssetPrice = m_dAssetPrice ;
	opt.R				= R_Percent ;
	opt.exercisePrice   = m_dStrikePrice ;
	opt.T_t				= m_dT_t ;
	opt.riskFreeInterestRate = m_dR ;
	opt.sd				= m_dSD ;

	if( strcmp(m_szFutures,"")==0&&IsIndex() )
		;
	else
	{
		if( m_nModelType==0 )	// Black-Scholes Model		
		{
			if( m_nCalType==0 )		// bi section.
			{			
				CBSMWrapper::CalIV_BySection( opt, calinfo ) ;	
			}
			else
			{
				CBSMWrapper::CalIV_ByCalculous( opt, calinfo ) ;	
			}
			
		}
		else	// Black Model 1976
		{
			if( m_nCalType==0 )		// bi section.
			{			
				CBM1976Wrapper::CalIV_BySection( opt, calinfo ) ;	
			}
			else
			{
				CBM1976Wrapper::CalIV_ByCalculous( opt, calinfo ) ;	
			}
			
		}
	}

#ifdef _IV_LOG    //ʵʱ��¼��־�ļ�
	char szLog[1000];
	sprintf(szLog,"Strike=%.2f Call=%d Sub=%d Warrant=%.2f ConRatio=%f Asset=%.2f PaiXi=%.2f T-t=%.4f(%d) Interset=%.4f sd=%.2f",
		m_dStrikePrice,bCall,nSubItem,m_dWarrantPrice,m_dConversionRatio,m_dAssetPrice,R_Percent,m_dT_t,m_lExpiryDays,m_dR,m_dSD);
	WriteLogFile(szLog);
	sprintf(szLog,"Result : IV=%.6f delta=%.6f gamma=%.6f theta=%.6f vega=%.6f OptionPrice=%.6f",
		calinfo.impliedVolitility,calinfo.delta,calinfo.gamma,calinfo.theta,calinfo.vega,calinfo.modelledOptionPrice);
	WriteLogFile(szLog);
	WriteLogFile("   ");
#endif

	int nAddr ;
	char* pDest ;
	char* pDest2;
	char szDest[50] ;
	char szBidAsk[50] ;
	char szIV[50] ;
	char szBA_IV[50] ;
	char szLast[50];
	char szLast_IV[50];
	//Calls
	if(nSubItem == POS_CALL_LAST)
	{			
		//�óɽ��ۼ�����4������
		//Vega
		nAddr = 100 + 1;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextVega(pDest,calinfo.vega,2);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");
		
		//Theta
		nAddr = 100 + 2;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextVega(pDest,calinfo.theta,2);   //20170405 Ben  Vega��theta����
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");
		
		
		//Gamma
		nAddr = 100 + 3;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextEx(pDest,calinfo.gamma,4);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");
		
		//Delta
		nAddr = 100 + 4;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextEx(pDest,calinfo.delta,2);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");

		//Call Last (IV)
		
		nAddr = 100+5;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		
		memset(szLast,0,sizeof(szLast));
		GetTextEx(szLast,Item.m_fCalls_Nominal,m_cbDecimal);
		
		memset(szIV,0,sizeof(szIV));
		GetTextIV(szIV,calinfo.impliedVolitility*100,1);
		
		if(strlen(szIV) >0)
			sprintf(szLast_IV,"%s(%s)",szLast,szIV);
		else
			sprintf(szLast_IV,"%s( 0.0)",szLast);
		
		strcpy(pDest,szLast_IV);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,szLast);
		if(strlen(szLast) == 0)
			strcpy(pDest,"");


		// Call ITM

		nAddr = 22;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextEx(pDest,calinfo.ITM,4);
		if( calinfo.ITM>0.9999 || m_dWarrantPrice==0.0 || strlen(szIV)<=0)
			strcpy(pDest,"");

		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");
		
	}
	
	//Bid (IV)
	if(nSubItem == POS_CALL_BID)
	{
		//���� CALL ���벨��
		nAddr = 100 + 7;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		
		memset(szBidAsk,0,sizeof(szBidAsk));
		GetTextEx(szBidAsk,Item.m_fCalls_Bid,m_cbDecimal);
		
		memset(szIV,0,sizeof(szIV));
		GetTextIV(szIV,calinfo.impliedVolitility*100,1);
		
		if(strlen(szIV) >0)
			sprintf(szBA_IV,"%s(%s)",szBidAsk,szIV);
		else
			sprintf(szBA_IV,"%s( 0.0)",szBidAsk);
		
		//sprintf(szBA_IV,"%s(%d%%)",szBidAsk,nIndex);
		strcpy(pDest,szBA_IV);

		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,szBidAsk);
		
		if(strlen(szBidAsk) == 0)
			strcpy(pDest,"");

		
		//m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
	}
	
	//Ask (IV)
	if(nSubItem == POS_CALL_ASK)
	{		
		//���� CALL ����������
		nAddr = 100 + 8;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		
		memset(szBidAsk,0,sizeof(szBidAsk));
		GetTextEx(szBidAsk,Item.m_fCalls_Ask,m_cbDecimal);
		
		memset(szIV,0,sizeof(szIV));
		GetTextIV(szIV,calinfo.impliedVolitility*100,1);
		
		if(strlen(szIV) >0)
			sprintf(szBA_IV,"%s(%s)",szBidAsk,szIV);
		else
			sprintf(szBA_IV,"%s( 0.0)",szBidAsk);
		
		//sprintf(szBA_IV,"%s(%d%%)",szBidAsk,100-nIndex);
		strcpy(pDest,szBA_IV);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,szBidAsk);
		
		if(strlen(szBidAsk) == 0)
			strcpy(pDest,"");

		
		//m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);			
	}
	
	//Puts
	if(nSubItem == POS_PUT_LAST)
	{
		//��PUT�ĳɽ��ۼ������ĸ�ֵ
		//Vega
		nAddr = 100 + 19;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextVega(pDest,calinfo.vega,2);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");
		
		//sprintf(pDest,"%d V ",nIndex);
		//m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
		
		//Theta
		nAddr = 100 + 18;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextVega(pDest,calinfo.theta,2);       //20170405 Ben  Vega��theta����
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");
		
		//sprintf(pDest,"%d T ",nIndex);
		//m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
		
		//Gamma
		nAddr = 100 + 17;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextEx(pDest,calinfo.gamma,4);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");
		
		//sprintf(pDest,"%d G ",nIndex);
		//m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
		
		//Delta
		nAddr = 100 + 16;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextEx(pDest,calinfo.delta,2);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");

		//Put Last (IV)
		
		nAddr = 100+15;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		
		memset(szLast,0,sizeof(szLast));
		GetTextEx(szLast,Item.m_fPuts_Nominal,m_cbDecimal);
		
		memset(szIV,0,sizeof(szIV));
		GetTextIV(szIV,calinfo.impliedVolitility*100,1);
		
		if(strlen(szIV) >0)
			sprintf(szLast_IV,"%s(%s)",szLast,szIV);
		else
			sprintf(szLast_IV,"%s( 0.0)",szLast);
		
		strcpy(pDest,szLast_IV);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,szLast);
		if(strlen(szLast) == 0)
			strcpy(pDest,"");

		//Put ITM
		nAddr = 23;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		GetTextEx(pDest,1.0-calinfo.ITM,4);
		if( calinfo.ITM>0.9999 || m_dWarrantPrice==0.0 || strlen(szIV)<=0 )
			strcpy(pDest,"");

		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,"");
		
	}


	//Bid (IV)
	if(nSubItem == POS_PUT_BID)
	{
		
		nAddr = 100 + 12;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		
		memset(szBidAsk,0,sizeof(szBidAsk));
		GetTextEx(szBidAsk,Item.m_fPuts_Bid,m_cbDecimal);
		
		memset(szIV,0,sizeof(szIV));
		GetTextIV(szIV,calinfo.impliedVolitility*100,1);
		
		if(strlen(szIV) >0)
			sprintf(szBA_IV,"%s(%s)",szBidAsk,szIV);
		else
			sprintf(szBA_IV,"%s( 0.0)",szBidAsk);
		
		//sprintf(szBA_IV,"%s(%d%%)",szBidAsk,nIndex);
		strcpy(pDest,szBA_IV);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,szBidAsk);

		if(strlen(szBidAsk) == 0)
			strcpy(pDest,"");
		
		
		//m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);
	}


	//Ask (IV)
	if(nSubItem == POS_PUT_ASK)
	{
		
		nAddr = 100 + 13;
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+nIndex, nAddr ) ;
		strcpy(szDest,pDest);
		
		memset(szBidAsk,0,sizeof(szBidAsk));
		GetTextEx(szBidAsk,Item.m_fPuts_Ask,m_cbDecimal);
		
		memset(szIV,0,sizeof(szIV));
		GetTextIV(szIV,calinfo.impliedVolitility*100,1);
				
		if(strlen(szIV) >0)
			sprintf(szBA_IV,"%s(%s)",szBidAsk,szIV);
		else
			sprintf(szBA_IV,"%s( 0.0)",szBidAsk);
		//sprintf(szBA_IV,"%s(%d%%)",szBidAsk,100-nIndex);
		strcpy(pDest,szBA_IV);
		if( strcmp(m_szFutures,"")==0&&IsIndex() )
			strcpy(pDest,szBidAsk);
		
		if(strlen(szBidAsk) == 0)
			strcpy(pDest,"");

		
		//m_pList1->SetReflectItemTextColor(nIndex,nAddr,pDest,szDest);	
	}

	
	return 0;
}




double CTTOptions::GetCorrStockPrice(BOOL flag,BYTE bInx)
{
	double dbVal;
	
	dbVal = atof(m_szCash);
	if( dbVal==0.0 )
		dbVal = atof(m_szFutures);
	
	if( dbVal==0.0 && !IsIndex() )
		m_bCash = TRUE;
	

	if( flag==FALSE && IsIndex() )
	{
		dbVal = atof(m_szFutures);
		if( dbVal==0.0 && bInx!=0 )
		{
			dbVal = atof(m_szCash);
			m_bCash = TRUE;
		}
		if( dbVal==0.0 )
			m_bCash = TRUE;
	}
	return dbVal;

}

void CTTOptions::GetItemShares()
{
	CString strItem;
	strItem.Format("%c%s",m_cbGroupCode,m_szItemCode);

	BOOL bFind = FALSE;
	OptionsItemShares itemshares;
	if(m_ItemSharesMap.Lookup((LPCTSTR)strItem,itemshares)== TRUE)
	{	
		m_lShares = itemshares.Shares;
		bFind = TRUE;	
	}

	if(bFind == FALSE)  //ȡDefaultֵ
	{
		strItem = "ADEFAULT ";
		if(m_ItemSharesMap.Lookup((LPCTSTR)strItem,itemshares)== TRUE)
		{	
			m_lShares = itemshares.Shares;
			bFind = TRUE;	
		}
	}

	
}

byte CTTOptions::GetExpiryTime()
{
	m_lExpiryTime = 0;

	
	CString strItem;
	strItem.Format("%c%s",m_cbGroupCode,m_szItemCode);
	
	BOOL bFind = FALSE;
	OptionsExpiryDateInfo expInfo;
	if(m_ExpiryDateMap.Lookup((LPCTSTR)strItem,expInfo)== TRUE)
	{
		for(int i=0;i<expInfo.expList.GetSize();i++)
		{
			if (expInfo.expList.ElementAt(i).lMonth == m_lTransdate)
			{
				m_lExpiryTime = expInfo.expList.ElementAt(i).lExpiryDate;
				bFind = TRUE;
				break;
			}	
		}	
	}

	if(bFind == FALSE)  //ȡDefaultֵ
	{
		strItem = "ADEFAULT ";
		if(m_ExpiryDateMap.Lookup((LPCTSTR)strItem,expInfo)== TRUE)
		{
			for(int i=0;i<expInfo.expList.GetSize();i++)
			{
				if (expInfo.expList.ElementAt(i).lMonth == m_lTransdate)
				{
					m_lExpiryTime = expInfo.expList.ElementAt(i).lExpiryDate;
					bFind = TRUE;
					break;
				}
			}
		}
	}

#ifdef _IV_LOG
	char szMsg[100];
	sprintf(szMsg,"GetExpiryDate: %s month=%d , expiryDate=%d",m_szItemCode,m_lTransdate,m_lExpiryTime);
	WriteLogFile(szMsg);
#endif

	if (bFind == FALSE)  //ȡhardcodeֵ
	{		
		switch(m_lTransdate)
		{
		case 201202:
			m_lExpiryTime = 20120228;
			break;
		case 201203:
			m_lExpiryTime = 20120329;
			break;
		case 201204:
			m_lExpiryTime = 20120427;
			break;
		case 201205:
			m_lExpiryTime = 20120530;
			break;
		case 201206:
			m_lExpiryTime = 20120628;
			break;
		case 201207:
			m_lExpiryTime = 20120730;
			break;
		case 201208:
			m_lExpiryTime = 20120830;
			break;
		case 201209:
			m_lExpiryTime = 20120929;
			break;
		case 201210:
			m_lExpiryTime = 20121030;
			break;
		case 201211:
			m_lExpiryTime = 20121129;
			break;
		case 201212:
			m_lExpiryTime = 20121228;
			break;
		default:
			m_lExpiryTime = 0;
			break;
		}

#ifdef _IV_LOG
		char szMsg[100];
		sprintf(szMsg,"GetExpiryDate (HardCode): %s month=%d , expiryDate=%d",m_szItemCode,m_lTransdate,m_lExpiryTime);
		WriteLogFile(szMsg);
#endif
	}

	if( m_lTransdate>10000000 )
		m_lExpiryTime = m_lTransdate;

	GetExpiryDays();
	return 0;
}

BYTE CTTOptions::GetExpiryDays()
{
	m_lExpiryDays = 0.0;

    if(IsDateValid(m_lExpiryTime) == TRUE)
	{

		SYSTEMTIME SysTime;
		GetSystemTime(&SysTime);
		long lToday = SysTime.wYear*10000 + SysTime.wMonth*100 + SysTime.wDay;

		if(DateDiff(m_lExpiryTime,lToday,m_lExpiryDays) == TRUE)
		{
			m_lExpiryDays = abs(m_lExpiryDays);
			return 1;
		}
	}

	return 0;
}

BOOL CTTOptions::IsDateValid(DWORD dt)
{
	char szDate[100];
	COleDateTime oleDt;
	if(dt < 10000000 || dt > 99991231) 
	{	
		return FALSE;
	}

	sprintf(szDate,"%d/%d/%d",(dt%10000)%100,(dt%10000)/100,dt/10000);
	if(oleDt.ParseDateTime(szDate,VAR_DATEVALUEONLY) == FALSE)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL  CTTOptions::DateDiff(DWORD dt1,DWORD dt2,int& iDiff)
{
	
	COleDateTime tm1,tm2;
	COleDateTimeSpan tms;

	tm1.SetDate(dt1/10000,(dt1%10000)/100,dt1%100);
	if(tm1.GetStatus()!=COleDateTime::valid)
	{
		return FALSE;
	}
	tm2.SetDate(dt2/10000,(dt2%10000)/100,dt2%100);
	if(tm2.GetStatus()!=COleDateTime::valid)
	{
		return FALSE;
	}

    tms=tm1-tm2;
	if(tms.GetStatus()!=COleDateTimeSpan::valid)
	{
		return FALSE;
	}
	
	iDiff = tms.GetDays();
	iDiff += 1;

	return TRUE;
}

void CTTOptions::OnOptionsPrint(LPVOID p)
{

	BOOL bPrintingOK = TRUE;
	CDC* pDC = (CDC *)p;
	int i;

	for(i= 0 ; i < 21;i++)
	{
		iPrintColumn[i]=0;	//��ǰ��ӡ������

	}

/*
	int len = m_pList1->GetItemCount();
	int y = pDC->GetDeviceCaps(VERTRES);

	int vol,iVol[21];
	int itemp;
	int x = pDC->GetDeviceCaps(HORZRES);
	vol = 21;			//��

	int nFontSize = m_nFontSize/8;
	LOGFONT logFont;
	memset(&logFont,0,sizeof(logFont));
//	m_font.GetLogFont(&logFont);
	logFont.lfHeight = -MulDiv(nFontSize,-pDC->GetDeviceCaps(LOGPIXELSY),72);  //  3/4th inch high in MM_LOENGLISH
							// (1/100th inch)
	CFont *pOldFont  = NULL;
	CFont font;
	if (font.CreateFontIndirect(&logFont))
		pOldFont = pDC->SelectObject(&font);

	CSize sizeFont = pDC->GetTextExtent("ƽ");
	int pageline = (y-sizeFont.cy*1.5-sizeFont.cy*3)/(sizeFont.cy+12);
	int pagey = len/pageline +1;	//	�����ӡҳ��

	CString tt;
	tt.Format("font width:%d",sizeFont.cx);
	OutputDebugString(tt);
*/
	//added by Steven
/*
 *	����ʵ���ַ����ĳ��ȺͿ�����������б�ÿ�зֱ�ĳ���
 */
/*
	for(int j = 0; j < vol ;j++)//��
	{
		int nLenMax = 0;
		CString strText;
		int iLang = m_pLstHeadsInfo->m_nCurLang;
		strText = m_pLstHeadsInfo->m_pBuf[j].m_szText[iLang];
		int nLen = pDC->GetTextExtent(strText+"    ").cx;
		nLenMax = nLen;

		CString st;
		st.Format("print:'%s' %d,nLenMax:%d",strText,j,nLenMax);
		OutputDebugString(st);
		for(int i = 0; i < m_pList1->GetItemCount(); i++)//��
		{
			strText = m_pList1->GetItemText(i,j);
			nLen = pDC->GetTextExtent(strText+"    ").cx;
			nLenMax = nLen>nLenMax?nLen:nLenMax;
			if(j>0)
				iVol[j] = iVol[j-1]+nLenMax;
			else
				iVol[j] = nLenMax;
		}
	}
	pDC->SelectObject(pOldFont);
	font.DeleteObject();
*/

/*
	int pagex = (iVol[20] / x) + 1;	//�����ӡҳ��
	int pages = pagex * pagey;		//�ܵĴ�ӡҳ��
	pInfo->SetMaxPage(pages);
*/


/*
	itemp = 0;
	j = 1 ;
	for(i = 0; i < vol; i++)
	{
		if(iVol[i]-itemp > (x-20))
		{
			itemp =  iVol[i-1];
			iPrintColumn[j] = i-1;
			j++;		
		}
	}
	iPrintColumn[j] = 21;

*/
/*
	CString s;
	s.Format("printinfo currentPage:%d,m_nFontSize:%d",pInfo->m_nCurPage,m_nFontSize);
	OutputDebugString(s);
	int k=0;
*/

/*
	for(;k<=vol;k++)
	{
		s.Format("printinfo iVol[%d]:%d",k,iVol[k]);	
		OutputDebugString(s);
	}

*/
/*
	int j=1;
	for(k=0;k<=j;k++)
	{
		s.Format("printinfo iPrintColumn[%d]:%d",k,iPrintColumn[k]);	
		OutputDebugString(s);
	}
	
*/
	OnPrint(pDC, pInfo); // Call your "Print page" function
/*
	if(pInfo->m_nCurPage>=pages)
	{
		pInfo->m_bContinuePrinting = FALSE;
	}	
	else
		pInfo->m_bContinuePrinting = TRUE;
*/
	return;
}
void CTTOptions::OnSetOptionsPrintInfo(LPVOID p)
{
	pInfo = (CPrintInfo *)p;
	pInfo->SetMinPage(1);
	return;
}
void CTTOptions::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	char* szHeader1[3] = {
			"Calls",
			"������Ȩ",
			"�R�ɴ��v"
		};
	char* szHeader2[3] = {
			"Puts",
			"�����Ȩ",
			"�R�^���v"
		};
	int i,j;
	CRect rect;
	CString str;
	CString strText;
	UINT nFormat = DT_RIGHT ;

	CFont font1;		//��������
	CFont* pOldFont1;
	int nFontSize1;
	LOGFONT logFont1;

	CFont font2;		//�б�����
	CFont* pOldFont2;
	int nFontSize2;
	LOGFONT logFont2;

	int iCount = m_pList1->GetItemCount();
	//��ӡ����
	int hTitle = 120;
	if(pInfo->m_nCurPage == 1)
	{
		strText.Empty();
		m_pbtnItemCode->GetWindowText(str);
		strText += str;

		m_pstaItemName->GetWindowText(str);
		strText += "          ";
		if(str.IsEmpty())
			strText += "           ";
		else
			strText += str;

		m_pbtnOptMonth->GetWindowText(str);
		strText += "                            ";
		strText += str;

		m_pstaCash->GetWindowText(str);
		strText += "                        ";
		strText += str;
		m_pedtCash->GetWindowText(str);
		strText += " ";
		strText += str;

		m_pstaFutures->GetWindowText(str);
		strText += "     ";
		strText += str;
		m_pedtFutures->GetWindowText(str);
		strText += " ";
		strText += str;
		pDC->SetMapMode(MM_TEXT);
		memset(&logFont1, 0, sizeof(LOGFONT));
		  //  3/4th inch high in MM_LOENGLISH
		nFontSize1 = 12;
		logFont1.lfHeight = -MulDiv(nFontSize1,-pDC->GetDeviceCaps(LOGPIXELSY),72);  //  3/4th inch high in MM_LOENGLISH
								// (1/100th inch)
		hTitle = pDC->GetTextExtent("ƽ").cy*1.5;

		pOldFont1 = NULL;
		if (font1.CreateFontIndirect(&logFont1))
			pOldFont1 = pDC->SelectObject(&font1);

		pDC->TextOut(10,10,strText);
		pDC->SelectObject(pOldFont1);
		pOldFont1->DeleteObject();
	}

	int vol;
	int iVol[21];//�ӱ�����ߵ������ұߵĿ���
	int itemp;
	int x = pDC->GetDeviceCaps(HORZRES);  //������Ļ����
	int y = pDC->GetDeviceCaps(VERTRES);  //������Ļ�߶�

	vol = 21;			//��

	//added by Steven
/*
 *	����ʵ���ַ����ĳ��ȺͿ�����������б�ÿ�зֱ�ĳ���
 */
	for(j = 0; j < vol;j++)
	{
		int nLenMax = 0;
		CString strText;
		int iLang = m_pLstHeadsInfo->m_nCurLang;               //����
		strText = m_pLstHeadsInfo->m_pBuf[j].m_szText[iLang];  //��ͷ�ı�
		int nLen = pDC->GetTextExtent(strText+"    ").cx;
		nLenMax = nLen>nLenMax?nLen:nLenMax;     //��������ֵ
		if(j>0)
			iVol[j] = iVol[j-1]+nLenMax;
		else
			iVol[j] = nLenMax;
		for(int i = 0; i < m_pList1->GetItemCount(); i++)
		{
			strText = m_pList1->GetItemText(i,j);
			nLen = pDC->GetTextExtent(strText+"    ").cx;
			nLenMax = nLen>nLenMax?nLen:nLenMax; //���ÿ���������ֵ
			if(j>0)
				iVol[j] = iVol[j-1]+nLenMax;
			else
				iVol[j] = nLenMax;
		}
	}

	int pagex = (iVol[20] / x) + 1; //�����ӡҳ��
	pDC->SetMapMode(MM_TEXT);  //ÿ���߼���λת��Ϊһ��ͼ�أ�X���������ң�Y����������
	memset(&logFont2, 0, sizeof(LOGFONT));
	  //  3/4th inch high in MM_LOENGLISH
	nFontSize2 = m_nFontSize/8;
//	m_font.GetLogFont(&logFont2);
	logFont2.lfHeight = -MulDiv(nFontSize2,-pDC->GetDeviceCaps(LOGPIXELSY),72);  //  3/4th inch high in MM_LOENGLISH
							// (1/100th inch)
	pOldFont2 = NULL;
	if (font2.CreateFontIndirect(&logFont2))
		pOldFont2 = pDC->SelectObject(&font2);

	CSize sizeFont = pDC->GetTextExtent("ƽ");
	int hFont = sizeFont.cy;
	int len = m_pList1->GetItemCount();
	int pageline = (y-sizeFont.cy*1.5-hFont*3)/(hFont+12);//����ÿҳ������
	int pagey = len/pageline +1;	//	�����ӡҳ��

	int pages = pagex * pagey;		//�ܵĴ�ӡҳ��
	pInfo->SetMaxPage(pages); //ָ�����һҳ������

	if(pInfo->m_nCurPage>=pages)
	{
		pInfo->m_bContinuePrinting = FALSE;  //��ǰҳ������pages���Ѿ���ӡ���
	}	
	else
		pInfo->m_bContinuePrinting = TRUE;   //��ǰҳ��С��pages����û��ӡ���


	itemp = 0;
	j = 1 ;
	for(i = 0; i < vol; i++)
	{
		if(iVol[i]-itemp > (x-20))
		{
			itemp =  iVol[i-1];
			iPrintColumn[j] = i-1;  //��ǰ��ӡ������
			j++;		
		}
	}
	iPrintColumn[j] = 21;


	//��ӡ����
	int iCurrenpage;

	if((pInfo->m_nCurPage % pagex) == 0)
	{
		j = iPrintColumn[pagex-1];
		iCurrenpage= pagex-1;

	}
	else
	{
		j = iPrintColumn[pInfo->m_nCurPage%pagex -1];
		iCurrenpage = pInfo->m_nCurPage%pagex -1;
	}

	j = iPrintColumn[iCurrenpage];
	for(; j < iPrintColumn[iCurrenpage+1];j++)
	{
		strText = m_pLstHeadsInfo->m_pBuf[j].m_szText[m_iLangType];
		rect.top = hTitle+ hFont+ 12;
		rect.bottom = (hFont+12)*2+hTitle;
		if(j == 0)
		{
			rect.left = 10;
			nFormat = DT_CENTER;
		}
		else
		{
			if(iPrintColumn[iCurrenpage] ==0)
				rect.left = iVol[j-1];
			else
				rect.left = iVol[j-1] - iVol[iPrintColumn[iCurrenpage ]-1];

			nFormat = DT_CENTER;
		}
		if(iPrintColumn[iCurrenpage] ==0)
			rect.right = iVol[j];
		else
			rect.right = iVol[j] - iVol[iPrintColumn[iCurrenpage ]-1];

		pDC->DrawText(strText,&rect,nFormat);

		if(j ==5 )
		{
			rect.left -= 100;
			rect.right += 100;
			rect.top = hTitle;
			rect.bottom = hTitle+ hFont+ 12;
			pDC->DrawText(szHeader1[m_iLangType],&rect,nFormat);
		}

		if(j ==15)
		{
			rect.left -= 100;
			rect.right += 100;
			rect.top = hTitle;
			rect.bottom = 140 + hFont;
			pDC->DrawText(szHeader2[m_iLangType],&rect,nFormat);
		}

	}

	//��ӡ��������
	int iCurrenRow; //������
	if((pInfo->m_nCurPage % pagex) == 0)
		iCurrenRow = ( (pInfo->m_nCurPage / pagex)-1) * pageline;
	else
		iCurrenRow = ( (pInfo->m_nCurPage / pagex)) * pageline;
	int line;
//	int pages = pagex * pagey;		//�ܵĴ�ӡҳ��
	
	for(line = 0; line < pageline; line++,iCurrenRow++)
	{
		if((iCurrenRow > len) && (pInfo->m_nCurPage == pages)) //��ӡ���
		{
			pInfo->m_bContinuePrinting = FALSE;
			break;
		}
		if(iCurrenRow > len)
			break;

		j = iPrintColumn[iCurrenpage];

		for(;j < iPrintColumn[iCurrenpage+1]; j++)
		{
			strText = m_pList1->GetItemText(iCurrenRow,j);
			

			rect.top = (line+1)*(hFont+12)+hTitle+ hFont+ 12;
			rect.bottom = (line+2)*(hFont+12)+hTitle+ hFont+ 12;
			if(j == 0)
			{
				rect.left = 10;
				nFormat = DT_CENTER;
			}
			else
			{
				if(iPrintColumn[iCurrenpage] ==0)
					rect.left = iVol[j-1];
				else
					rect.left = iVol[j-1] - iVol[iPrintColumn[iCurrenpage ]-1];

				nFormat = DT_CENTER;
			}
			if(iPrintColumn[iCurrenpage] ==0)
				rect.right = iVol[j];
			else
				rect.right = iVol[j] - iVol[iPrintColumn[iCurrenpage ]-1];
			pDC->DrawText(strText,&rect,nFormat);
		}
	}

	
		//��ӡ�߿�
		pDC->MoveTo(10,hTitle);
		pDC->LineTo(10,rect.bottom);
		pDC->MoveTo(rect.right,hTitle);
		pDC->LineTo(rect.right,rect.bottom);
		i= iPrintColumn[iCurrenpage];
		
		for(;i < iPrintColumn[iCurrenpage+1]; i++)//������
		{
			
			if(i == 9 || i == 10)
			{
				pDC->MoveTo(iVol[i],hTitle);
				pDC->LineTo(iVol[i],rect.bottom);
				//			continue;
			}
			
			
			if(i ==0||i==iPrintColumn[iCurrenpage])
			{
				//			pDC->MoveTo(iVol[i],hTitle+ hFont+ 12);
				//			pDC->LineTo(iVol[i],rect.bottom);
			}
			else
			{
				//			if(pInfo->m_nCurPage%pagex ==0)
				{
					pDC->MoveTo(iVol[i]-iVol[iPrintColumn[iCurrenpage]],hTitle+ hFont+ 12);
					pDC->LineTo(iVol[i]-iVol[iPrintColumn[iCurrenpage]],rect.bottom);
				}
				/*			else
				{
				pDC->MoveTo(iVol[i]-iVol[iPrintColumn[iCurrenpage]-1],hTitle+ hFont+ 12);
				pDC->LineTo(iVol[i]-iVol[iPrintColumn[iCurrenpage]-1],rect.bottom);
				}
				*/
			}
			//		if(i == vol -1)
			//		{
			//			pDC->MoveTo(iVol[i]-iVol[iPrintColumn[iCurrenpage]-1],hTitle);
			//			pDC->LineTo(iVol[i]-iVol[iPrintColumn[iCurrenpage]-1],rect.bottom);
			//		}
		}
		
		pDC->MoveTo(10,hTitle);
		pDC->LineTo(rect.right,hTitle);
		for(i = 0 ;i < line + 2 ; i++)//������
		{
			pDC->MoveTo(10,i*(hFont+12)+hTitle+ hFont+ 12);
			pDC->LineTo(rect.right,i*(hFont+12)+hTitle+ hFont+ 12);
		}

	
	pDC->SelectObject(pOldFont2);
	font2.DeleteObject();
		
	str.Format(" %d - %d", pInfo->m_nCurPage,pInfo->GetMaxPage());
	pDC->TextOut(x/2-hFont*2,y-hFont,str);

	return;
}

HRESULT CTTOptions::WriteLogFile(LPTSTR strLog)
{
	char strTime[100];
	SYSTEMTIME sysTime;
	GetLocalTime(&sysTime);

	HANDLE m_hLogFile;
	char strFileDir[200];
	char strTemp[50];
	sprintf(strTemp,"\\W2TOptionsIV-%04d%02d%02d.LOG",sysTime.wYear,sysTime.wMonth,sysTime.wDay);
	
	memset(strFileDir, 0, sizeof(strFileDir));
	GetCurrentDirectory(200, strFileDir);
	strcat(strFileDir, strTemp);
	
	m_hLogFile = CreateFile(strFileDir, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE,
		NULL, OPEN_ALWAYS, 0, NULL);
	
	if(m_hLogFile == INVALID_HANDLE_VALUE)
		return 1;
	
	SetFilePointer(m_hLogFile, 0, NULL, FILE_END);
	
	unsigned long nByteWrite = 0;
	char strMsg[1000];
	memset(strMsg, 0, sizeof(strMsg));
	
//	char strTime[100];
//	SYSTEMTIME sysTime;
//	GetLocalTime(&sysTime);
	
	sprintf(strTime, "%d-%02d-%02d %02d:%02d:%02d", sysTime.wYear, sysTime.wMonth, 
		sysTime.wDay, sysTime.wHour, sysTime.wMinute, sysTime.wSecond);
	
	lstrcpy(strMsg, strTime);
	lstrcat(strMsg, "     ");
	lstrcat(strMsg, strLog);
	lstrcat(strMsg, "\r\n");
	
	WriteFile(m_hLogFile, strMsg, lstrlen(strMsg), &nByteWrite, NULL);
	
	CloseHandle(m_hLogFile);
	return S_OK;
}

void CTTOptions::GetRootPath()
{
	memset( m_szRootPath, 0, MAX_PATH );
	GetModuleFileName( NULL, m_szRootPath, MAX_PATH );
	int i = 0;
	int nlen = strlen( m_szRootPath ) - 1;
	while( nlen>=0 )
	{
		if( m_szRootPath[nlen]=='\\' )
		{
			i++;
			if( i>=2 )
				break;
		}
		m_szRootPath[nlen] = 0;
		nlen--;
	}
}



void CTTOptions::UpdataView()
{
	UpdateTitle();//ȷ����ͷ�� m_HChar ����������ȷ�ı�ͷ�ı�
	m_pList1->SetColorMode(m_nColorMode);//�޸ı��ı�����ɫ�����ػ����ͷ
	
	m_pList1->Scroll(CSize(0,-1000)); // scroll to top	

	m_pList1->RedrawWindow();
	//::PostMessage( m_pList1->m_hWnd, MACRO_MsgRedrawItem, (WPARAM)0xFFFFFFFE, 0 ) ;
	//WARNIG: release�棬��List���������, �����PostMessageȥ��.
	if( m_hWnd!=NULL )
		::PostMessage( m_hWnd, MACRO_MsgRedrawItem, 0, TRUE ) ;

	ResizeHeaderCtrl();  //���¼����ⲿ��ͷ���ȣ����ػ��ⲿ��ͷ
}


void CTTOptions::Setup()
{
	ASSERT(m_pICfgCenter!=NULL);
	if (m_pICfgCenter==NULL)
		return ;
	SaveDataColor();    
	SaveValueColor();   //SaveValue();
	CComQIPtr<ITTCfgCenter> pCfg(m_pICfgCenter);
	int nLang = 0;
	if (m_iLangType==1) {

		nLang = 2;
	}
	else if (m_iLangType==2) {
		nLang = 1;
	}
	pCfg->OpenConfigDlg(nLang,CFGID_OPTIONS,CFGID_OPTIONS_COLOR,m_nControlID,NULL);//���޸�Option������ɫ�Ľ���
	LoadDataColor();    
	LoadValueColor();   //LoadValue();
	UpdataView();
}

void CTTOptions::SaveDataColor()
{
	ASSERT(m_pICfgCenter!=NULL);
	if (m_pICfgCenter==NULL)
		return ;
/*	if (m_nFontSize<_FONTSIZE_Min) {
		m_nFontSize = _FONTSIZE_Min;
	}
	if (m_nFontSize>_FONTSIZE_Max) 
		m_nFontSize=_FONTSIZE_Max;
*/	
	CComQIPtr<ITTCfgCenter> pCfg(m_pICfgCenter);
	BYTE *pBuf = NULL;
	int nLen = sizeof(m_nColorMode);
	pBuf = new BYTE[nLen];
	memcpy(pBuf,&m_nColorMode,sizeof(m_nColorMode));
	pCfg->SaveSettings(CFGID_OPTIONS,CFGID_OPTIONS_COLOR,m_nControlID,pBuf,nLen);
	delete []pBuf;

/*	nLen = FONT_NAME_WIDTH+4+4;
	pBuf = new BYTE[nLen];
	strcpy((char*)pBuf,m_strFontName);
	int nFontsize = m_nFontSize/10;
	memcpy(pBuf+FONT_NAME_WIDTH,&nFontsize,sizeof(nFontsize));
	memcpy(pBuf+FONT_NAME_WIDTH+4,&m_bFontBold,sizeof(m_bFontBold));
	pCfg->SaveSettings(CFGID_785,CFGID_785_FONT,m_nControlID,pBuf,nLen);
	delete []pBuf;
*/
}

//����column��Ϣ
STDMETHODIMP CTTOptions::SaveValueColor()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	USES_CONVERSION;

	ULONG len = 0;

//	if(m_pCtrlStg == NULL)
//		return 1;
	// --- Add request by Hope
	IStorage* pCtrlStg = NULL;
	if(GetControlStg((IUnknown**)&pCtrlStg) != S_OK)
		return E_FAIL;
	// --- Add request by Hope

	pCtrlStg->CreateStream(L"OptionsValue", STGM_CREATE | STGM_READWRITE | 
		STGM_SHARE_EXCLUSIVE, 0, 0, &m_pCStream);
	if( m_pCStream==NULL )
	{
		PutControlStg();
		return E_FAIL;
	}

//	m_pCStream->Write(&m_nFontSize, sizeof(short), &len);
//	m_pCStream->Write(&m_strFontName, 100, &len);

	// first save lst.
	if( this->m_pList1->m_hWnd!=NULL )
	{
		short iTotal = GetColumnsTotal( *m_pList1 ) ;
		LVCOLUMN col ;
		col.mask = LVCF_WIDTH ;
		for( short i=0;i<iTotal;i++ )
		{
			m_pList1->GetColumn( i, &col ) ;
			short cx = col.cx ;
			m_pLstHeadsInfo->m_pBuf[i].m_nWidth = cx ;
		}

	}

	short iTotal = (short)m_pLstHeadsInfo->m_nBufTotal ;
	m_pCStream->Write(&iTotal, 2, &len);
	for( short i=0;i<iTotal;i++ )
	{
		short cx ;
		cx = (short)m_pLstHeadsInfo->m_pBuf[i].m_nWidth ;
/*
		WORD wElementType = m_pLstHeadsInfo->m_pBuf[i]. m_wElemType ;
		m_pCStream->Write(&wElementType, sizeof(wElementType), &len);
*/
		m_pCStream->Write(&cx, 2, &len);
	}



	m_pLstHeadsInfo->GetColumnOrder(*m_pList1);
	for(i=0;i<m_pLstHeadsInfo->m_Orders.GetSize();i++)
	{
		DWORD dwOrder = m_pLstHeadsInfo->m_Orders[i];
		m_pCStream->Write(&dwOrder,sizeof(dwOrder),&len);

	}

	m_pCStream->Release();

	// --- Add request by Hope
	PutControlStg();
	// --- Add request by Hope
	
	return S_OK;
}

STDMETHODIMP CTTOptions::LoadValueColor()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
//	if(m_pCtrlStg == NULL)
//		return 1;

	// --- Add request by Hope
	IStorage* pCtrlStg = NULL;
	if(GetControlStg((IUnknown**)&pCtrlStg) != S_OK)
		return E_FAIL;
	// --- Add request by Hope

	ULONG len = 0;
	if(pCtrlStg->OpenStream(L"OptionsValue", 0, STGM_READWRITE | STGM_SHARE_EXCLUSIVE, 
		0, &m_pCStream) == S_OK)
	{
//		m_pCStream->Read(&m_nFontSize, sizeof(short), &len);
//		m_pCStream->Read(m_strFontName, 100, &len);

	//	m_font.DeleteObject() ;
	//	m_font.CreatePointFont( m_nFontSize, m_strFontName ) ;

		short iTotal = 0 ;
		m_pCStream->Read(&iTotal, 2, &len);
		if( len==2 )
		{
			for( short i=0;i<iTotal && i<m_pLstHeadsInfo->m_nBufTotal;i++ )
			{
				short cx ;
/*
				WORD wElementType;
				m_pCStream->Read(&wElementType,sizeof(wElementType),&len);
				if (len<sizeof(wElementType))
					goto Error_Flag;
				m_pLstHeadsInfo->m_pBuf[i].m_wElemType = wElementType ;
*/

				m_pCStream->Read(&cx, 2, &len);
				if(len<sizeof(cx))
					goto Error_Flag;
				m_pLstHeadsInfo->m_pBuf[i].m_nWidth = cx ;


			}

			for(i=0;i<m_pLstHeadsInfo->m_Orders.GetSize();i++)
			{	
				DWORD dwOrder;
				m_pCStream->Read(&dwOrder,sizeof(dwOrder),&len);
				if(len<sizeof(dwOrder))
					goto Error_Flag;
				m_pLstHeadsInfo->m_Orders[i] = dwOrder;
			}
			m_pLstHeadsInfo->SetColumnOrder(*m_pList1);

		}
		

		// +++++++++ Kenny Add ++++++++++++++++ 99-10-15
/*
		if(m_bHtmlIsLoad)
		{
			SendTitle();
		}
*/
		// +++++++++ Kenny Add ++++++++++++++++ 99-10-15
	}
	else
	{
		pCtrlStg->CreateStream(L"OptionsValue", STGM_CREATE | STGM_READWRITE |
			STGM_SHARE_EXCLUSIVE, 0, 0, &m_pCStream);
		
//		m_pCStream->Write(&m_nFontSize, sizeof(short), &len);
//		m_pCStream->Write(m_strFontName, 100, &len);

		// first save lst.
		if( m_pList1->m_hWnd!=NULL )
		{
			short iTotal = GetColumnsTotal( *m_pList1 ) ;
			LVCOLUMN col ;
			col.mask = LVCF_WIDTH ;
			for( short i=0;i<iTotal;i++ )
			{
				m_pList1->GetColumn( i, &col ) ;
				short cx = col.cx ;
				m_pLstHeadsInfo->m_pBuf[i].m_nWidth = cx ;
			}

		}

		short iTotal = (short)m_pLstHeadsInfo->m_nBufTotal ;
		m_pCStream->Write(&iTotal, 2, &len);
		for( short i=0;i<iTotal;i++ )
		{
		//	WORD wElementType = 9999;//m_pLstHeadsInfo->m_pBuf[i]. m_wElemType ;����785�Ĵ��룬��ֵһ����λ����
		//	m_pCStream->Write(&wElementType, sizeof(wElementType), &len);
			short cx ;
			cx = (short)m_pLstHeadsInfo->m_pBuf[i].m_nWidth ;
			m_pCStream->Write(&cx, 2, &len);
		}

		// +++++++++ Kenny Add ++++++++++++++++ 99-10-15
/*
		if(m_bHtmlIsLoad)
		{		
			SendTitle();
		}
*/

	}

Error_Flag:
	m_pCStream->Release();

	// --- Add request by Hope
	PutControlStg();
	// --- Add request by Hope

	return S_OK;
}


BOOL CTTOptions::LoadDataColor()
{
	ASSERT(m_pICfgCenter!=NULL);
	if (m_pICfgCenter==NULL)
		return FALSE;
	CComQIPtr<ITTCfgCenter> pCfg(m_pICfgCenter);
	BYTE *pBuf = NULL;
	int nLen = 0;
	int nPos = 0;
	//TCHAR szFontName [FONT_NAME_WIDTH];
	//memset(szFontName,0,sizeof(szFontName));
	if(pCfg->GetSettings(CFGID_OPTIONS,CFGID_OPTIONS_COLOR,m_nControlID,&pBuf,&nLen)==S_OK
		&&pBuf!=NULL&&nLen!=0)
	{
		memcpy(&m_nColorMode,pBuf+nPos,sizeof(WORD));
//		delete []pBuf;
		pBuf = NULL;
		nLen = 0;
	}


/*	if(pCfg->GetSettings(CFGID_785,CFGID_785_FONT,m_nControlID,&pBuf,&nLen)==S_OK
		&&pBuf!=NULL&&nLen!=0)
	{
		nPos = 0;
		ZeroMemory(szFontName,sizeof(szFontName));
		memcpy(szFontName,pBuf,sizeof(szFontName));
		memcpy(&m_nFontSize,pBuf+sizeof(szFontName),sizeof(m_nFontSize));
		memcpy(&m_bFontBold,pBuf+sizeof(szFontName)+4,sizeof(m_bFontBold));
		strcpy(m_strFontName,szFontName);
		m_nFontSize = m_nFontSize*10;
//		delete []pBuf;
	}

	if (m_nFontSize<_FONTSIZE_Min||m_nFontSize>_FONTSIZE_Max) 
		m_nFontSize = 110;
	if(strlen(m_strFontName)<=0)
		_tcscpy(m_strFontName, _T("Courier New"));

*/
	return TRUE;


}

void CTTOptions::ResetView()
{
	//Johnny 20151030
	m_pList1->DeleteAllItems();
	memset(m_pList1->m_buf,0,sizeof(ItemOptionsText)*MACRO_MaxItems);
	memset(m_pList1->m_buf_simple,0,sizeof(ItemOptionsText)*MACRO_SmpItems);

	BYTE DirtyBuf[MACRO_MaxItems];
	memset( DirtyBuf, 1, sizeof(DirtyBuf) ) ;
	int nTotal=20;
	if( m_bSimple==1 )
		nTotal = 11;
	m_pList1->SetItemsTotal( nTotal, DirtyBuf ) ;

	//for (int i=0;i<nTotal;i++)
	//{
	//	int nRow = m_pList1->InsertItem(i, "");//������
//		m_pList1->SetItemText(nRow, i, "");//��������
	//}
	m_pList1->UpdateData(FALSE);
	m_pList1->UpdateWindow();
}
