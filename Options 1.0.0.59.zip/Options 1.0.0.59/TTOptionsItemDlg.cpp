// TTOptionsItemDlg.cpp: implementation of the CTTOptionsItemDlg class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "TTOptionsItemDlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTTOptionsItemDlg::CTTOptionsItemDlg(int iLangType/* = 0*/)
{
	m_nText = 0;
	m_bOver = FALSE;
	m_nSel = -1;
	m_hwndParent =NULL;
	m_iLangType = iLangType;
}

CTTOptionsItemDlg::~CTTOptionsItemDlg()
{

}

int  CTTOptionsItemDlg::AddItemString(LPCTSTR pszText)
{
	//if(m_nText <0 || m_nText >= 20)
	if(m_nText <0 || m_nText >= MAX_OPTIONS_COUNT)
		return -1;
	lstrcpy(m_szText[m_nText],pszText);
	m_nText++;
	return m_nText-1;
}

void CTTOptionsItemDlg::AddName(int nIndex, LPCTSTR pszName)
{
	//if(nIndex < 0 || nIndex >= 10)
	if(nIndex < 0 || nIndex >= MAX_OPTIONS_COUNT)
		return;
	lstrcpy(m_szName[nIndex],pszName);
}

void CTTOptionsItemDlg::AddFutText(int nIndex,LPCTSTR pszFutText)
{
	//if(nIndex < 0 || nIndex >= 10)
	if(nIndex < 0 || nIndex >= MAX_OPTIONS_COUNT)
		return;
	//lstrcpy(m_szFutText[nIndex],pszFutText);
	memcpy(m_szFutText[nIndex],pszFutText,8);
}

void CTTOptionsItemDlg::AddCashCode(int nIndex,LPCTSTR pszCashCode)
{
	//if(nIndex < 0 || nIndex >= 10)
	if(nIndex < 0 || nIndex >= MAX_OPTIONS_COUNT)
		return;
	//lstrcpy(m_szFutText[nIndex],pszFutText);
	memcpy(m_szCashCode[nIndex],pszCashCode,8);
}

void CTTOptionsItemDlg::AddOptCode(int nIndex,LPCTSTR pszCashCode)
{
	//if(nIndex < 0 || nIndex >= 10)
	if(nIndex < 0 || nIndex >= MAX_OPTIONS_COUNT)
		return;
	//lstrcpy(m_szFutText[nIndex],pszFutText);
	memcpy(m_szOptCode[nIndex],pszCashCode,5);
}