
//////////////////////////////////////////////////////////////////////
//
//	System:			
//	Modul:		Group File
//	Descripe:		
//
//	List:
//			1.>struct GeneralHeader
//			2.>struct Offset
//			3.>struct Item
//			4.>struct Parameter
//
//	File:			GroupFile.cpp
//	Last Version:	1999-05-16.
//
////////////////////////////////////////////////////////////////


#include	"stdafx.h"
#include	"GroupFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////
// General Header.

GeneralHeader::GeneralHeader()
{
	ReInit() ;
}

void GeneralHeader::ReInit()
{
	memset( this, 0, sizeof(*this) );
}

BOOL GeneralHeader::ReadFile( CFile& file )
{
	UINT size = sizeof(*this) ;

	try
	{
		size = file.Read( (void*)this, size );
		if( size!=sizeof(*this) )
		{
			ReInit() ;
			return FALSE ;
		}

	}
	catch( CFileException* /* e */ )
	{
		//throw( e );
		return FALSE ;
		
	}
	return TRUE ;

}

BOOL GeneralHeader::WriteFile( CFile& file )
{
	try
	{
		file.Write( (void*)this, sizeof(*this) );
	}
	catch( CFileException* /* e */ )
	{
		ReInit() ;
		//throw( e );
		return FALSE ;
		
	}
	return TRUE ;
}

// end General Header.
////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////
// Offset.

Offset::Offset()
{
	ReInit() ;
}

void Offset::ReInit()
{
	memset( this, 0, sizeof(*this) );
}

BOOL Offset::ReadFile( CFile& file )
{
	UINT size = sizeof(*this) ;

	try
	{
		size = file.Read( (void*)this, size );
		if( size!=sizeof(*this) )
		{
			ReInit() ;
			return FALSE ;
		}

	}
	catch( CFileException* /* e */ )
	{
		//throw( e );
		return FALSE ;
		
	}
	return TRUE ;

}

BOOL Offset::WriteFile( CFile& file )
{
	try
	{
		file.Write( (void*)this, sizeof(*this) );
	}
	catch( CFileException* /* e */ )
	{
		ReInit() ;
		//throw( e );
		return FALSE ;		
	}
	return TRUE ;
}

// end Offset.
////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////
// Item.

Item::Item()
{		
	ReInit() ;
}

BOOL Item::operator = ( const Item& obj ) 
{
	memcpy( this, &obj, sizeof(Item) );
	return TRUE ;
}

void Item::ReInit()
{
	memset( this, 0, sizeof(*this) );
}


BOOL Item::ReadFile( CFile& file )
{
	UINT size = sizeof(*this) ;

	try
	{
		size = file.Read( (void*)this, size );
		if( size!=sizeof(*this) )
		{
			ReInit() ;
			return FALSE ;
		}

	}
	catch( CFileException* /* e */ )
	{
		ReInit() ;
		//throw( e );
		return FALSE ;
		
	}
	return TRUE ;

}

BOOL Item::WriteFile( CFile& file )
{
	try
	{
		file.Write( (void*)this, sizeof(*this) );
	}
	catch( CFileException* /* e */ )
	{
		//throw( e );
		return FALSE ;
		
	}
	return TRUE ;

}

// end Item.
////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////
// RecalcFrame.
void RecalcFrame::ReInit()
{
	memset( this, 0, sizeof(*this) );
}

BOOL RecalcFrame::ReadFile( CFile& file )
{
	UINT size = sizeof(*this) ;

	try
	{
		size = file.Read( (void*)this, size );
		if( size!=sizeof(*this) )
		{
			ReInit() ;
			return FALSE ;
		}

	}
	catch( CFileException* /* e */ )
	{
		ReInit() ;
		//throw( e );
		return FALSE ;
		
	}
	return TRUE ;

}

BOOL RecalcFrame::WriteFile( CFile& file )
{
	try
	{
		file.Write( (void*)this, sizeof(*this) );
	}
	catch( CFileException* /* e */ )
	{
		//throw( e );
		return FALSE ;
		
	}
	return TRUE ;

}

// end RecalcFrame.
////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////
// CGroupFile.

CGroupFile::CGroupFile()
{
	m_pItemBuf = NULL ;
	m_nItemBufTotal = 0 ;
	m_pParaList = NULL;
}

CGroupFile::~CGroupFile()
{
	ReInit() ;
}

void CGroupFile::ReInit()
{
	m_Header.ReInit() ;
	m_Offset.ReInit() ;
	if( m_pItemBuf!=NULL )
	{
		delete [] m_pItemBuf ;
		m_pItemBuf = NULL ;
	}
	if(m_pParaList !=NULL)
	{
		delete [] m_pParaList ;
		m_pParaList = NULL ;
	}
	m_nItemBufTotal = 0 ;
}

void CGroupFile::ClearBuf()
{
	memset( &m_Offset, 0, sizeof(m_Offset)) ;
	if( m_pItemBuf!=NULL )
	{
		delete [] m_pItemBuf ;
		m_pItemBuf = NULL ;
	}
	if(m_pParaList !=NULL)
	{
		delete [] m_pParaList ;
		m_pParaList = NULL ;
	}
	m_nItemBufTotal = 0 ;
}

BOOL CGroupFile::CreateItemBuf()
{
	if( m_pItemBuf!=NULL )
	{
		delete [] m_pItemBuf ;
		m_pItemBuf = NULL ;
	}

	m_nItemBufTotal = CalItemsTotal() ;
	if( m_nItemBufTotal<=0 )
		return TRUE ;
	
	m_pItemBuf = new Item[m_nItemBufTotal] ;
	ASSERT( m_pItemBuf!=NULL );
	if( m_pItemBuf==NULL )
	{
		m_nItemBufTotal = 0 ;
		return FALSE ;
	}

	m_pParaList = new ParaList[m_nItemBufTotal];
	ASSERT( m_pParaList!=NULL );
	if(m_pParaList ==NULL)
	{
		delete [] m_pItemBuf ;
		m_pItemBuf = NULL ;
		m_nItemBufTotal = 0 ;
		return FALSE;
	}
	return TRUE ;
}

BOOL CGroupFile::ReadFile( LPCSTR szFile )
{
CFile f;
CFileException e;

	if( !f.Open( szFile, CFile::modeRead, &e ) )
	{
#ifdef _DEBUG
	   afxDump << "File could not be opened " << e.m_cause << "\n";
#endif
	   return FALSE ;
	}
		
	int nTotal ;
	int i,j;
	try
	{
		if( m_Header.ReadFile( f )==FALSE )
			goto ErrExit ;
		if( m_Offset.ReadFile( f )==FALSE )
			goto ErrExit ;
		m_nItemBufTotal = m_Offset.m_lLengthOfItem / sizeof(Item);
		if( CreateItemBuf()==FALSE )
			goto ErrExit ;

		nTotal = m_nItemBufTotal; 
		for( i=0;i<nTotal;i++ )
		{
			if( m_pItemBuf[i].ReadFile( f )==FALSE )
				goto ErrExit ;
		}

		RecalcFrame rclFrame;
		for( i=0;i<nTotal;i++ )
		{
			for(j=0; j<m_pItemBuf[i].m_iNumOfParam;j++) 
			{
				if(rclFrame.ReadFile( f )==FALSE )
					goto ErrExit ;
				m_pParaList[i].Add(rclFrame);
			}
		}
	}
	catch( CFileException* /* e */ )
	{
		ReInit() ;
		f.Close() ;
		//throw( e );
		return FALSE ;		
	}
	f.Close() ;
	return TRUE ;

ErrExit:
	ReInit() ;
	f.Close() ;
	return FALSE ;
	
}

BOOL CGroupFile::WriteFile( LPCSTR szFile )
{
CFile f;
CFileException e;

	if( !f.Open( szFile, CFile::modeCreate | CFile::modeWrite, &e ) )
	{
#ifdef _DEBUG
	   afxDump << "File could not be opened " << e.m_cause << "\n";
#endif
	   return FALSE ;
	}
		
	int nTotal ;
	int i,j ;
	try
	{
		if( m_Header.WriteFile( f )==FALSE )
			goto ErrExit ;
		if( m_Offset.WriteFile( f )==FALSE )
			goto ErrExit ;

		nTotal = m_nItemBufTotal; 
		if( nTotal>0 && m_pItemBuf==NULL )
		{
			ASSERT( FALSE ) ;  // item's buf info not match!
			goto ErrExit ;
		}
		for( i=0;i<nTotal;i++ )
		{
			if( m_pItemBuf[i].WriteFile( f )==FALSE )
				goto ErrExit ;
		}
		for( i=0;i<nTotal;i++ )
		{
			for(j = 0 ;j < m_pParaList[i].GetSize();j++)	
			{
				if( m_pParaList[i][j].WriteFile( f )==FALSE )
					goto ErrExit ;
			}
		}

	}
	catch( CFileException* /* e */ )
	{
		f.Close() ;
		//throw( e );
		return FALSE ;
		
	}
	f.Close() ;
	return TRUE ;

ErrExit:
	f.Close() ;
	return FALSE ;
	
}

int	 CGroupFile::CalItemsTotal()
{
	if( m_Offset.m_lLengthOfItem == 0 )
		return 0 ;

	int nTotal = m_Offset.m_lLengthOfItem / sizeof(Item); ;
	return nTotal ;

}

int	 CGroupFile::FindItem( char* pItemCode )
{
	if( pItemCode==NULL )
		return -1 ;
	
	if( m_pItemBuf==NULL || m_nItemBufTotal<=0 )
		return -1 ;

	for( int i=0;i<m_nItemBufTotal;i++ )
	{
		int nResult = memcmp( pItemCode, m_pItemBuf[i].m_szItemCode, 8 ) ;
		if( nResult==0 )
			return i ;
		if( nResult<0 )
			return -1 ;

	}
	return -1 ;

}

int	CGroupFile::FindItem( int nID )
{
	if( nID<0 || nID>=100000000 )
		return -1 ;

	char szTemp[9] ;
	memset( szTemp, ' ', 9 );
	sprintf( szTemp, "%04d", nID ) ;
	int len = strlen( szTemp ) ;
	if( len<8 )
		szTemp[len] = ' ' ;
	return FindItem( szTemp );

}

// end CGroupFile.
////////////////////////////////////////////////////////////////////

void SafeStrCpy( char* pDest, LPCSTR  pSource, int nDestBufLen )
{
	memset( pDest, ' ', nDestBufLen ) ;		
	if( strlen( pSource )<nDestBufLen ) 	// DestBuf����>=Source����+1
		strcpy( pDest, pSource ) ;	// �㹻��ȫ, strcpy.
	else
		memcpy( pDest, pSource, nDestBufLen ) ;
	
}

LPCSTR	GetSafeStr( char* pSource, int nSourceLen )
{
static char szTemp[100] ;

	memset( szTemp, 0, 100 );
	memcpy( szTemp, pSource, nSourceLen ) ;
	return szTemp ;

}