
//////////////////////////////////////////////////////////////////////
//
//	System:			
//	Modul:		Group File
//	Descripe:		
//
//	List:
//			1.>struct GeneralHeader
//			2.>struct Offset
//			3.>struct Item
//			4.>struct Paramater
//
//	File:			GroupFile.h
//	Last Version:	1999-05-16.
//
////////////////////////////////////////////////////////////////


//WARNING:  
//Compile Option: 
//	struct allign: 1 byte .

#ifndef	_GROUPFILE_H_
#define	_GROUPFILE_H_

#include <afxtempl.h>

#pragma pack (1)

// General Header.
struct GeneralHeader
{
public:
	GeneralHeader() ;

	void ReInit();

	//stream API. 
	BOOL	ReadFile( CFile& file );
	BOOL	WriteFile( CFile& file );

public:
	unsigned short m_iFileID ;
	unsigned short m_iLenOfHeader ;	
	unsigned char  m_cGroupCode ;		
	unsigned long  m_lOffset ;
	long		   m_lLastModifiedDate;
	unsigned short m_lLastModifiedTime;
	char		   m_szReserve[113] ;		
};

// Offset struct.
struct Offset
{
public:
	Offset() ;

	void ReInit();

	//stream API. 
	BOOL	ReadFile( CFile& file );
	BOOL	WriteFile( CFile& file );

public:
	unsigned short m_iLength ;	
	unsigned short m_iOffsetNumber ;
	unsigned long  m_lOffsetOfItem ;
	unsigned long  m_lLengthOfItem ;
	unsigned long  m_lOffsetOfParam ;		
	unsigned long  m_lLengthOfParam ;
	char		   m_szReserve[108] ;	
};

struct Item
{
public:
	Item() ;
	BOOL operator = ( const Item& obj ) ;

	//basic.
	void	ReInit();

	//stream API. 
	BOOL	ReadFile( CFile& file );
	BOOL	WriteFile( CFile& file );	

public:	
	char			m_szItemCode[8] ;
	unsigned short	m_iNumOfParam ;
	unsigned long	m_lOffsetOfParam ;
	long			m_lMaxDate;
	char			m_Reserved[2];
};

struct RecalcFrame
{
	USHORT itemindex;    //for verify
	WORD method;
	float param1;
	float param2;
	float param3;
	DWORD FromDate;
	DWORD ToDate;
	BYTE  SeqNo;
	USHORT PriceFlag:1;
	USHORT VolumeFlag:1;
	USHORT Reserve:14;
	char Reserve2[3];

	//basic.
	void	ReInit();

	//stream API. 
	BOOL	ReadFile( CFile& file );
	BOOL	WriteFile( CFile& file );	

	const void operator=(const RecalcFrame & Data)
	{
		itemindex = Data.itemindex; 
		method = Data.method;
		param1 = Data.param1;
		param2 = Data.param2;
		param3 = Data.param3;
		FromDate = Data.FromDate;
		ToDate = Data.ToDate;
		SeqNo = Data.SeqNo; 
		PriceFlag = Data.PriceFlag;
		VolumeFlag = Data.VolumeFlag;
		memset(Reserve2,0,sizeof(Reserve2));
	}
};

typedef CArray<RecalcFrame,RecalcFrame &> ParaList;

class CGroupFile
{
public:
	CGroupFile();
	~CGroupFile() ;

	//basic
	void	ReInit() ;
	void	ClearBuf() ;	// �ͷ�buf.	

	BOOL	CreateItemBuf() ;			// create Item's buf.

	// ����Item.
	int		FindItem( char* pItemCode );	
	int		FindItem( int	nID );

	//stream API. 
	BOOL	ReadFile( LPCSTR szFile );
	BOOL	WriteFile( LPCSTR szFile );

public:
	GeneralHeader	m_Header ;
	Offset			m_Offset ;
	Item*			m_pItemBuf ;		//
	int				m_nItemBufTotal ;	// item buf.
	ParaList*		m_pParaList;
public:
	int		CalItemsTotal() ;
};

#pragma pack (8)

void	SafeStrCpy( char* pDest, LPCSTR  pSource, int nDestBufLen ) ;
	  // GroupFile�кܶ��ַ������� '\0'��β��.		
	  // ������ȫ����!	

LPCSTR	GetSafeStr( char* pSource, int nSourceLen ) ;
	  // �õ���'\0'��β���ַ���.	

#endif