#if !defined(AFX_CONFDLG_H__34673F86_0A81_4EB6_8719_76D741E5E0A2__INCLUDED_)
#define AFX_CONFDLG_H__34673F86_0A81_4EB6_8719_76D741E5E0A2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConfDlg.h : header file
//
#include "Strategy.h"
/////////////////////////////////////////////////////////////////////////////
// CConfDlg dialog
//class CStrategy;
class CConfDlg : public CDialog
{
// Construction
public:
	CConfDlg(CWnd* pParent = NULL);   // standard constructor

	~CConfDlg();
// Dialog Data
	//{{AFX_DATA(CConfDlg)
	enum { IDD = IDD_CONFDLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	CBrush  m_brush;
	CFont   m_font;
	CStrategy *m_pStgy;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConfDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CConfDlg)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFDLG_H__34673F86_0A81_4EB6_8719_76D741E5E0A2__INCLUDED_)
