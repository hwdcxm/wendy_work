#if !defined(AFX_DIAGONAL_H__7A2D4D55_968D_4DDB_8F23_A69957BE8002__INCLUDED_)
#define AFX_DIAGONAL_H__7A2D4D55_968D_4DDB_8F23_A69957BE8002__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Diagonal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDiagonal dialog
#include "Strategy.h"

class CDiagonal : public CDialog
{
// Construction
public:
	CDiagonal(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDiagonal)
	enum { IDD = IDD_DIAGONALDLG };
	CStatic	m_near;
	CStatic	m_far;
	CComboBox	m_CmbStk2;
	CComboBox	m_CmbStk1;
	CComboBox	m_CmbMth2;
	CComboBox	m_CmbMth1;
	CComboBox	m_CmbDebit;
	CComboBox	m_CmbCall;
	//}}AFX_DATA

	CStrategy *m_pStgy;
	Calend  cald;
	float  m_fStrike2_Spread;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDiagonal)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDiagonal)
	virtual void OnOK();
	afx_msg void OnSelchangeCmbcall();
	afx_msg void OnSelchangeCmbdebit();
	afx_msg void OnSelchangeCmbmonth1();
	afx_msg void OnSelchangeCmbmonth2();
	afx_msg void OnSelchangeCmbstrike1();
	afx_msg void OnSelchangeCmbstrike2();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIAGONAL_H__7A2D4D55_968D_4DDB_8F23_A69957BE8002__INCLUDED_)
