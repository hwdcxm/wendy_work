// TTOptions.h : Declaration of the CTTOptions

#ifndef __TTOPTIONS_H_
#define __TTOPTIONS_H_

#include "resource.h"       // main symbols
#include <atlctl.h>
#include "updateflag.h"
#include "..\common\DataProxy.h"
#include "..\common\GroupsMng.h"
#include "Optionsdatastruct.h"
#include "Options.h"
#include "MyStatic.h"

#include "BM1976.h"
#include "BSM.h"

#include <afxcmn.h>

#define MACRO_MaxSubItems 21
// msg.
#define CM_SETWINDOWTEXT WM_USER + 0x0100
#define CM_RESETTABLE	WM_USER + 0x0101
#define CM_SHOWMONTHDLG  WM_USER + 0x0103

#define TOOLTIP1_ENG			"Click here to select option"
#define TOOLTIP1_CNS			"���˴�ѡ����Ȩ"
#define TOOLTIP1_CNT			"�����B��ܴ��v"

#define TOOLTIP2_ENG			"Click here to select month"
#define TOOLTIP2_CNS			"���˴�ѡ���·�"
#define TOOLTIP2_CNT			"�����B��ܤ��"

#define TOOLTIP_HIGH_ENG		"Show/Hide High Low Price"
#define TOOLTIP_HIGH_CNS		"��ʾ/���������ͼ�"
#define TOOLTIP_HIGH_CNT		"���/���ó̰��̧C��"

#define TOOLTIP_COLUMN_ENG		"Reformat column widths"
#define TOOLTIP_COLUMN_CNS		"�����п�"
#define TOOLTIP_COLUMN_CNT		"����C�e"

#define TOOLTIP_IV_ENG		"PB/IV/Normal Mode"
#define TOOLTIP_IV_CNS		"PB/IV/����ģʽ"
#define TOOLTIP_IV_CNT		"PB/IV/���`�Ҧ�"

#define TOOLTIP_ExportCSV_ENG		"Export to CSV"
#define TOOLTIP_ExportCSV_CNS		"������CSV"
#define TOOLTIP_ExportCSV_CNT		"�ɥX��CSV"

#define TOOLTIP_Simple_ENG		"Simple/Full Mode"
#define TOOLTIP_Simple_CNS		"����/����ģʽ"
#define TOOLTIP_Simple_CNT		"��²/����Ҧ�"

#define TOOLTIP_Stra_ENG		"Strategy"
#define TOOLTIP_Stra_CNS		"����/ʹֵ"
#define TOOLTIP_Stra_CNT		"����/�h��"




#pragma pack(1)

typedef struct	tagSpeedCode
{
	char cGCode;  
	double dbICode;
	WORD Period; // 0 - Tick.  1~60 - 1~60 minutes.  66 - Daily. 
				 // 77 - Weekly.  88 - Monthly.  99 - Yearly.
	WORD Multi;  // 1~99
	BYTE Price;  // n or 1 - Nominal. 
	             // b or 2 - Bid.
				 //	a or 3 - Ask.
				 // t or 4 - Trade ticker.
		         // ba or 5 - Bid & ask.
	BYTE fGCode:1;   //�Ƿ������Щ�ֶΡ�
	BYTE fItemcode:1;
	BYTE fPeriod:1;
	BYTE fMulti:1;
	BYTE fPrice:1;
	BYTE Reserve:3;

}SpeedCode;

typedef struct tagOPTIONSDATA
{
	float fCall_OI;  
	float fCall_Vol; 
	float fCall_High; 
	float fCall_Low; 
	float fCall_Last; 
	BYTE  cbLastFlag; 
	float fCall_LQty; 
	float fCall_BQty; 
	float fCall_Bid; 
	BYTE  cbBidFlag; 
	float fCall_Ask; 
	BYTE  cbAskFlag; 
	float fCall_AQty; 
//++++++++++++++++++++
	float fStrike; 
	BYTE  cbDecimal; 
//--------------------
	float fPut_OI;  
	float fPut_Vol; 
	float fPut_High; 
	float fPut_Low; 
	float fPut_Last; 
	BYTE  cbLastFlag2; 
	float fPut_LQty; 
	float fPut_BQty; 
	float fPut_Bid; 
	BYTE  cbBidFlag2; 
	float fPut_Ask; 
	BYTE  cbAskFlag2; 
	float fPut_AQty; 
}OPTIONSDATA;

#pragma pack()


struct  ItemOptions
{
public:
	ItemOptions() ;

	void ReInit() ;

public:
	float   m_fCalls_PreOI ;
	float	m_fCalls_OI ;
	float	m_fCalls_Vol ;
	float	m_fCalls_High ;
	float	m_fCalls_Low ;
	float	m_fCalls_Nominal ;
	float	m_fCalls_NominalQty ;
	float	m_fCalls_BidQty ;
	float	m_fCalls_Bid ;
	float	m_fCalls_Ask ;
	float	m_fCalls_AskQty ;
	int     m_fCalls_Margin;

	float	m_fStrike ;

	int     m_fPuts_Margin;
	float	m_fPuts_BidQty ;
	float	m_fPuts_Bid ;
	float	m_fPuts_Ask ;
	float	m_fPuts_AskQty ;
	float	m_fPuts_NominalQty ;
	float	m_fPuts_Nominal ;
	float	m_fPuts_High ;
	float	m_fPuts_Low ;
	float	m_fPuts_Vol ;
	float	m_fPuts_OI ;
	float   m_fPuts_PreOI ;

};
typedef CArray<ItemOptions, ItemOptions&> CArrayItem;

struct PainValue
{
	float  m_fStrike;
	double m_dValue;
	double m_dCV;
	double m_dPV;
};
typedef CArray<PainValue, PainValue&> CArrayValue;

#define MAX_OPTIONS_COUNT 500

/////////////////////////////////////////////////////////////////////////////
// CTTOptions
struct LstHeadsInfo ;
class ClistctrlOptions ;
class CHeaderCtrlOptions;
class CwndBgn ;
class CdlgMonth ;
class CbtnWithTip ;
class CStrategy;
class ATL_NO_VTABLE CTTOptions : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatchImpl<_ITTDataProxyEvents,&IID__ITTDataProxyEvents, &LIBID_DATAPROXYLib>,
	public IDispatchImpl<ITTOptions, &IID_ITTOptions, &LIBID_OPTIONSLib>,
	public CComControl<CTTOptions>,
	public IPersistStreamInitImpl<CTTOptions>,
	public IOleControlImpl<CTTOptions>,
	public IOleObjectImpl<CTTOptions>,
	public IOleInPlaceActiveObjectImpl<CTTOptions>,
	public IViewObjectExImpl<CTTOptions>,
	public IOleInPlaceObjectWindowlessImpl<CTTOptions>,
	public ISupportErrorInfo,
	public IPersistStorageImpl<CTTOptions>,
	public ISpecifyPropertyPagesImpl<CTTOptions>,
	public IQuickActivateImpl<CTTOptions>,
	public IDataObjectImpl<CTTOptions>,
	public IProvideClassInfo2Impl<&CLSID_TTOptions, NULL, &LIBID_OPTIONSLib>,
	public CComCoClass<CTTOptions, &CLSID_TTOptions>,
	public ITTObject
{
public:
	CTTOptions() ;
	~CTTOptions() ;

	// Э��API.
	BOOL  AdviseDataProxy(BOOL bAdvise);
	STDMETHOD( OnNewFrame)(short wDataType,IStream* pIStream,unsigned long dwID) ;
	void ReadDSFrame(IStream* pIStream);	// ����'DS'(Tele) Э��	
	void ReadDOFrame(IStream* pIStream,unsigned long dwID);	// ����Options Э��	
	void ReadDPFrame(IStream* pIStream);    //����'DP'��ͬitemcode+date�м� Э��  2017.9.28 ben
	void SendRequestFrame() ;				// ������������.
	void SendEndFrame() ;					// ����Ͽ���DO����.  ??
	void SendMonthRequestFrame() ;			// query month list.

	HRESULT ReadDFFrame(IStream *pIStream);
	void SendDFChlFrame( BOOL bConnect ); 
	void SendDFRequestFrame();

public:
	int iPrintColumn[21];
	void OnOptionsPrint(LPVOID p);
	void OnSetOptionsPrintInfo(LPVOID p);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	CPrintInfo * pInfo;
	// ITTObject�������.
	IUnknown*		m_pDataProxy;
	IUnknown*		m_pSystemObj;	
	IUnknown*		m_pGrpMng;
	IUnknown*		m_pMainFrm;
	int				m_nControlID;		// control ��MainFrame�еı�ʶID.		
	unsigned long	m_dwID;				// control ��DO�еı�ʶID.		
	HANDLE			m_hAdviseThread;	// advise thread hande. Warning: not CloseHandle()
	DWORD			m_dwAdvise;			// Advise����ֵ, δ��.
	BOOL			m_bAdvise;			// �������� or �̿���������.		
	LONG            m_PTransdate;           //��ȡ����ĵ�ǰOptions������.
	// Options's data.
	ItemOptions* m_pDataBuf ;	//
	int			 m_nDataTotal ;	// data.
	char	m_szItemCashCode[G_GENCODELEN+1]; // ��ǰItem��Cash	Code.
	char	m_szItemCode[G_GENCODELEN+1]; // ��ǰItem��	Code.
	char	m_szVHSICode[G_GENCODELEN+1]; // ��ǰItem��VHSI Code.
	long	m_lTransdate;				  // ��ǰOptions������.	
	char	m_szFuturesCode[G_GENCODELEN+1];	// future's item code.
	char	m_szFuturesTitle[6];				// future's �̶�title.
	char    m_szOptCode[5];   //��׼��
	char    m_theM[100];
	BYTE	m_cbGroupCode;		// Items's group code.
	BYTE	m_cbDecimal;		// list text's ��ʾ����.
	
	
	MarginArray     m_arrMargin[MAX_OPTIONS_COUNT];  //=MAX_OPTIONS_COUNT
	CLPArray		m_arrLP[500];
	CCDArray		m_arrCD;
	CCashArray		m_arrCash;
	OccList         m_OccList;
	float   m_fBF;    //CStrategy ��IV
	BYTE    m_bStgyMode;
	BOOL    m_bChanged;
	BOOL    m_bCash;
	// wnds.
	ClistctrlOptions*	m_pList1 ;
	//CHeaderCtrl*	m_pHeader ;
	CHeaderCtrlOptions*	m_pHeader ;
	CwndBgn*		m_pwndBgn ;
	CStrategy*		m_pwndCls;		
//	CRect           m_RectStgy;//����λ�õ����˵�
	CPreOIArray     m_arrPreOI;

	CbtnWithTip*	m_pbtnItemCode ;   // button for select item.
	CbtnWithTip*	m_pbtnOptMonth ;   // button for select month.		
	CbtnWithTip*    m_pbtnMini;
	CbtnWithTip*	m_pbtnHighPrice ;   // button for hide/show High Low Price.
	CbtnWithTip*	m_pbtnColumnWidth ; // button for reformat column width.		
	CbtnWithTip*	m_pbtnIVMode ; // button for IV mode.		Andy 2012.02.03
 	CbtnWithTip*	m_pbtnExportCSV ; // button for export to CSV.		Andy 2012.02.03
    CbtnWithTip*    m_pbtnSimple;  //button for Simple mode    Ben 2017.03.01
	CbtnWithTip*    m_pbtnStra;    //button for Strategy    Ben 2017.06.05

	CStatic*		m_pstaItemName ;
	CStatic*		m_pstaCash ;   //�ֻ�
	CStatic*		m_pstaFutures ;  //�ڻ�
	CStatic*		m_pstaVHSI;
	CStatic*		m_pstaExpiryDate ;  //andy 2012.03.07
	CStatic*		m_pstaEAS;

	CStatic*		m_pedtCash ;  //�ֻ���ֵ
	CStatic*		m_pedtFutures ;  //�ڻ���ֵ
	CStatic*		m_pedtVHSI;
	CStatic*		m_pedtEAS;

	CRITICAL_SECTION  m_cs;
	StgyHistoryFile   m_StgyFile;
	int				  m_nDivision;
	CGroupFile        m_GroupFile;
	ParaList		  m_ParaList;
	double	m_dPaiXi_1;
	double  m_dPaiXi_2;

	// wnds data.
	LstHeadsInfo*	m_pLstHeadsInfo ;
	int				m_nColDefWidth[ MACRO_MaxSubItems ]; //�б�,21��,��ͷ����Ĭ�Ͽ���
	char			m_szCash[20] ;		// Cash's Text.
	char			m_szFutures[20] ;	// Future's Text.
	char			m_szVHSI[20];
	char			m_szItemName[30];	// staItemName's Text.
	char			m_szExpiryDateText[30];	// staItemName's Text.
	char			m_szText[12];		// btnOptMonth's Text.
	char			m_szEAS[20];  //EAS's Text;

	char    m_szFuturesNightCode[9];  //ҹ����Ȩcode

	// font, lang.
	short	m_iLangType	;		// ����.
				// 0 --> English.
				// 1 --> Chinese Simple.
				// 2 --> Chinese Traditional.
	short	m_nFontSize;   //�����С
	char	m_strFontName[100]; //��������
	CFont	m_font ;

	int m_bShowHighPrice; 
	int m_bIVMode;   //0���� 1 IV 2 ���ʷ���
	int m_bSimple;
	BYTE  m_bSelectWin;   //����itemcode�Ի���ʱ��ѡ��   0 ��Ȩ����  1 ����ʹֵ����
	char    m_szPCR[8];
	int m_iCallOIUpRow[2];
	int m_iPutOIUpRow[2];
	int m_iCallOIDwRow[2];
	int m_iPutOIDwRow[2];
	int m_iCallMaxRow[2];
	int m_iPutMaxRow[2];
	float m_fCallOIDiff[300];   //MACRO_MaxItems = 300
	float m_fPutOIDiff[300];

	float m_fRiskInterest;  //��ȫ����
	int   m_iEAS1;
	int   m_iEAS2;
	BOOL  m_bUseNtMth;   //for weekly option future price
	OptionsExpiryDateMap m_ExpiryDateMap;
	OptionsItemSharesMap m_ItemSharesMap;
	BYTE ReadExpiryDateListFile(); 
	BYTE ExportToExcel(char* pszFilePath);
	BYTE GetExportToExcelData(int nItem,int nSubItem,BYTE* pData,long& pos);
	BYTE GetExportToExcelDataOneLine(int nItem,BYTE* pData,long& pos);
	void ReadHKStockOccFile();
	void ReadMarginFile();
	void ReadRclFile();
	void GetMarginTxt();
	void GetDvdInfo();
	void Split(CString source, CStringArray& dest, CString division);

	// storage.
	IStream* m_pCStream;

	// others.
	BOOL	m_bClick_SelMonth ;		//	��ǰClick�� Select month button.

	CList<LONG,LONG&> m_lstMonths;	// Months link list

public:

	static BOOL SeekFromBegin(IStream* pIStream, UINT nOffset)
	{
		LARGE_INTEGER pos;
		ULARGE_INTEGER newPos;
		pos.QuadPart = nOffset;
		return (S_OK == pIStream->Seek(pos, STREAM_SEEK_SET, &newPos));	
	}

		
	// list API.
	int  FindRow(float fStrike);		// find row in data buf.
	int  InsertRow(float fStrike);		// insert row in data buf.
	int	 DeleteRow(float fStrike) ;		// delete row in data buf.
	char* MakeFutCode( char* pEchoItemCode, char* pTitleCode, int nMM, int nYY ) ;
	BOOL GetText(LPTSTR pszText, float fValue, unsigned char cbDecimal,BOOL bCab,BOOL bThoery) ;
			// float ---> text.
	BOOL GetTextEx(LPTSTR pszText,float fValue,BYTE cbDecimal);
			// float ---> text.
	BOOL GetTextIV(LPTSTR pszText,float fValue,BYTE cbDecimal);
			// float ---> text.
	BOOL GetTextVega(LPTSTR pszText,float fValue,BYTE cbDecimal);
			// float ---> text.
	BOOL GetTextOI(LPTSTR pszText,float fValue,float fStrike,BOOL bCall);


	void ResetTable() ;			// clear list.
	void SetColsMinWidth() ;	// set list's column's min width.
	void SetColsMinWidthIVMode() ;
	void SetColsMinWidthPBMode() ;
	void GetNameText() ;		// get Item's Name from GroupMng.
	void GetExpiryDateText();   //andy add 2012.03.07
	void ResizeHeaderCtrl() ;	// resize binding headerctrl.
	CButton* CTTOptions::NewMyButton(int nID,CRect rect,int nStyle);
	// msg.
	void OnSelectItemCode2(DOUBLE dbItem) ;	// change item code .
	void OnSelectItemCode() ;	// change item code .
	void OnSelectMonth() ;		// change month .
	void OnLstHScr() ;			// lst Hor scroll.
	void OnSelectHighPrice() ;	// show/hide High&low price.
	void OnSelectColumnWidth();	// reformat column width.
	void OnSelectIVMode();		//IV Mode
	void OnSelectSimple();      //Simple Mode
	void OnSelectExportCSV();		//Export CSV
	void OnSelectStrategy();
	void NotifyItemChanged();
	void OnSelectModeMenu();
	void PopMenu();
	BOOL IsIndex();
	BOOL HaveFutures(char *code, long lExpiry);
	void FindOIRow();

	// wnds API.
	void ClearData() ;			// �������.
	void ResetCtrls() ;			// ��������ctrls.
	HRESULT ResetFrmTitle() ;	// request reset MDIWindow's text.
	void UpdateTitle() ;		// update subwindow's title.

	void SwitchListHearTitle();
	void UpdateListHearTitle() ;// �л�IVģʽʱ��Ҫ�޸�Title

	void OnStgyDbClick(char* ItemCode, long lTransdate);
	int  ClosestCashNum();
	void RefreshFile();
	//���㲻ͬʣ�����������ۼ۸�  ben add 2017.7.26
	double ModelPrice(BOOL bOption, double dStrike, double dMaket, int iExpDay, int nAddr, BSMCALINFO& calinfo, BYTE bPos=0);
	// font, lang API.
	void	SetLang() ;		// ����Language.
	HRESULT Zoom(long nType);
	HRESULT SetAllFont(LPCTSTR fontname,short fontsize);
	HRESULT AdjustSize() ;
	BOOL m_bSystemdesktop; //�ж��Ƿ�Ϊϵͳ����
	BOOL SendUpdateRQ(BOOL bConnect);
	BOOL SendUpdateRP(BOOL bConnect, char *code, long lDate);
	BOOL SendHistoryRQ();
	BOOL SendHistoryRI();
	BOOL SubmitRQ(IStream* pIStream, short wDataType = 'DO'); // helper function, call ITTDataProxy::TranslateQueryFrame()
	BOOL SendTeleHisRQ(); // send 'DS' history frame, to get nominal price
	BOOL SendTeleUpdateRQ(BOOL bConnect); // send 'DS' update frame

	BOOL SendTeleHisCash( char* code );//����Order�µĹ�Ʊ�ּ�
	void GetCashOrFuturesCode( char* itemcode, long ldate, char* returncode );

	BOOL ReadFullData(IStream* pIStream);
	void ConvertHelper(int nIdx,const OPTIONSDATA* pData, ItemOptions* pStore);

	BOOL FillMonthList(IStream* pIStream);
	BOOL RemoveMonth(LONG theMonth); // remove such month from link list
	BOOL IsClearScreenFrame(IStream* pIStream); // �Ƿ�����������֡
	void ClearScreen(); // ����

	void GetItemShares();
	byte CalcIV();
	byte CalcIVData(int nIndex,ItemOptions& Item, int nSubItem);
	byte CalcAllIVData();
	double GetCorrStockPrice(BOOL falg=TRUE,BYTE bInx=0);
	BYTE GetExpiryDays();
	long m_lExpiryTime;
	int m_lExpiryDays;
	long m_lShares;
	byte GetExpiryTime();
	HRESULT WriteLogFile(LPTSTR strLog);
	void GetRootPath();
	char         m_szRootPath[MAX_PATH];

	BOOL DateDiff(DWORD dt1,DWORD dt2,int& iDiff);
	BOOL IsDateValid(DWORD dt);	

	// storage.
	STDMETHOD(LoadValue)();
	STDMETHOD(SaveValue)();
	STDMETHOD(GetPrivateStg)(/*[out]*/ IUnknown** punk);
	STDMETHOD(PutPrivateStg)();
	STDMETHOD(GetControlStg)(/*[out]*/ IUnknown** punk);
	STDMETHOD(PutControlStg)();

public:
DECLARE_REGISTRY_RESOURCEID(IDR_TTOPTIONS)
DECLARE_NOT_AGGREGATABLE(CTTOptions)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTTOptions)
	COM_INTERFACE_ENTRY(ITTOptions)
	COM_INTERFACE_ENTRY2(IDispatch,ITTOptions)
	COM_INTERFACE_ENTRY(_ITTDataProxyEvents)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY(ITTObject)
END_COM_MAP()

BEGIN_PROP_MAP(CTTOptions)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_MSG_MAP(CTTOptions)
	CHAIN_MSG_MAP(CComControl<CTTOptions>)
	DEFAULT_REFLECTION_HANDLER()
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SIZE, OnSize)
	MESSAGE_HANDLER(CM_RESETTABLE,OnResetTable)
	MESSAGE_HANDLER(CM_SHOWMONTHDLG,OnShowMonthDlg)
	MESSAGE_HANDLER(CM_SETWINDOWTEXT,SetWindowTextEx)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		static const IID* arr[] = 
		{
			&IID_ITTOptions,
		};
		for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		{
			if (InlineIsEqualGUID(*arr[i], riid))
				return S_OK;
		}
		return S_FALSE;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// ITTOptions
public:	
	void ResetView(); //Johnny 20151030 �޸�������ʱҳ��ˢ������
	STDMETHOD(LoadValueColor)();
	STDMETHOD(SaveValueColor)();
	static IUnknown* m_pICfgCenter;
	void Setup(); //�������õı�����ɫ
	void UpdataView();//���ݽ��յı�����ɫ���ñ���
	void SaveLastPage();

	int m_nColorMode;   //��ɫ

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled) ;
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled) ;
	LRESULT OnResetTable(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnShowMonthDlg(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT SetWindowTextEx(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);


// ITTObject
	STDMETHOD(InitObject)();	
	STDMETHOD(Activate)(int nState);
	STDMETHOD(GetState)(int* pnState);
	STDMETHOD(GetByID)(int nID, VARIANT** ppVar);	
	STDMETHOD(PutByID)(int nID, VARIANT* pVar);
	STDMETHOD(GetByName)(BSTR strName, VARIANT** ppVar);
	STDMETHOD(PutByName)(BSTR strName, VARIANT* pVar);
protected:
	void SaveDataColor();
	BOOL LoadDataColor();
};

#endif //__TTOPTIONS_H_
