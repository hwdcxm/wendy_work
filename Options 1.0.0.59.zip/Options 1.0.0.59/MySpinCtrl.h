#if !defined(AFX_MYSPINCTRL_H__B2DA9FDB_55FB_41CF_88C3_0C508BD5A591__INCLUDED_)
#define AFX_MYSPINCTRL_H__B2DA9FDB_55FB_41CF_88C3_0C508BD5A591__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MySpinCtrl.h : header file
//
#include <afxcmn.h>
/////////////////////////////////////////////////////////////////////////////
// CMySpinCtrl window
#define MACRO_Btn_Spin_ID           614

class CStrategy;
class CMySpinCtrl : public CSpinButtonCtrl
{
// Construction
public:
	CMySpinCtrl();
	CStrategy *m_pStgy;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMySpinCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMySpinCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMySpinCtrl)
	afx_msg void OnDeltapos(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSPINCTRL_H__B2DA9FDB_55FB_41CF_88C3_0C508BD5A591__INCLUDED_)
