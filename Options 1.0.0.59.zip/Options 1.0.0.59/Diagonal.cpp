// Diagonal.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "Diagonal.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDiagonal dialog


CDiagonal::CDiagonal(CWnd* pParent /*=NULL*/)
	: CDialog(CDiagonal::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDiagonal)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDiagonal::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDiagonal)
	DDX_Control(pDX, IDC_STATIC_NEAR1, m_near);
	DDX_Control(pDX, IDC_STATIC_FAR2, m_far);
	DDX_Control(pDX, IDC_CMBSTRIKE2, m_CmbStk2);
	DDX_Control(pDX, IDC_CMBSTRIKE1, m_CmbStk1);
	DDX_Control(pDX, IDC_CMBMONTH2, m_CmbMth2);
	DDX_Control(pDX, IDC_CMBMONTH1, m_CmbMth1);
	DDX_Control(pDX, IDC_CMBDEBIT, m_CmbDebit);
	DDX_Control(pDX, IDC_CMBCALL, m_CmbCall);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDiagonal, CDialog)
	//{{AFX_MSG_MAP(CDiagonal)
	ON_CBN_SELCHANGE(IDC_CMBCALL, OnSelchangeCmbcall)
	ON_CBN_SELCHANGE(IDC_CMBDEBIT, OnSelchangeCmbdebit)
	ON_CBN_SELCHANGE(IDC_CMBMONTH1, OnSelchangeCmbmonth1)
	ON_CBN_SELCHANGE(IDC_CMBMONTH2, OnSelchangeCmbmonth2)
	ON_CBN_SELCHANGE(IDC_CMBSTRIKE1, OnSelchangeCmbstrike1)
	ON_CBN_SELCHANGE(IDC_CMBSTRIKE2, OnSelchangeCmbstrike2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDiagonal message handlers

void CDiagonal::OnOK() 
{
	long lM[2];
	lM[0] = cald.lMonth1;
	lM[1] = cald.lMonth2;
	for( int j=0;j<2;j++ )
	{
		if( lM[j]<10000000 )
		{
			CString strItem;
			strItem.Format("%c%s",m_pStgy->m_TTOptions->m_cbGroupCode,m_pStgy->m_TTOptions->m_szItemCode);
			
			OptionsExpiryDateInfo expInfo;
			if(m_pStgy->m_TTOptions->m_ExpiryDateMap.Lookup((LPCTSTR)strItem,expInfo)== TRUE)
			{
				for(int i=0;i<expInfo.expList.GetSize();i++)
				{
					if (expInfo.expList.ElementAt(i).lMonth == lM[j])
					{
						lM[j] = expInfo.expList.ElementAt(i).lExpiryDate;
						break;
					}	
				}
			}
		}
	}
	if( lM[0]>=lM[1] )
	{
		AfxMessageBox("Month (far) should greater than Month (near)");
		return;
	}
	if( cald.fStrike==m_fStrike2_Spread )
	{
		AfxMessageBox("The two Strikes should not be equal.");
		return;
	}
	Calend tempcald = m_pStgy->m_cald;
	m_pStgy->m_cald = cald;
	m_pStgy->m_fStrike2_Spread = m_fStrike2_Spread;
	BYTE rs = m_pStgy->CheckData() ;
	CString str,szStrike;
	m_pStgy->GetPriceTxt(cald.fStrike,szStrike);
	switch(rs)
	{
	case 1:
	case 2:
		if( m_pStgy->m_iLangType==1 )
			str.Format("[%d] δ��ȡ����Ȩ���ݣ����Ժ����Ի�ѡ�������·�",cald.lMonth1);
		else if( m_pStgy->m_iLangType==2 )
			str.Format("[%d] ���������v�ƾڡA�еy��A�թο�ܨ�L���",cald.lMonth1);
		else
			str.Format("[%d] No Options Data,Please Try Again Later",cald.lMonth1);
		break;
	case 3:
		if( m_pStgy->m_iLangType==1 )
			str.Format("[%d] ��Ϊû�и�����ָ����ѡ�������·�",cald.lMonth1);
		else if( m_pStgy->m_iLangType==2 )
			str.Format("[%d] �]���S���Ӥ�����A�п�ܨ�L���",cald.lMonth1);
		else
			str.Format("[%d] Have no futures,Please Choose Another Month",cald.lMonth1);
		break;
	case 4:
		if( m_pStgy->m_iLangType==1 )
			str.Format("[%d] ��Ϊ����û����ָ����ѡ�������·�",cald.lMonth2);
		else if( m_pStgy->m_iLangType==2 )
			str.Format("[%d] �]���Ӥ�S�������A�п�ܨ�L���",cald.lMonth2);
		else
			str.Format("[%d] Have no futures,Please Choose Another Month",cald.lMonth2);
		break;
	case 5:
		if( m_pStgy->m_iLangType==1 )
			str.Format("%d Strike:%s���޳ɼۣ����Ժ����Ի�ѡ�������·ݺ���ʹ��",cald.lMonth1,szStrike);
		else if( m_pStgy->m_iLangType==2 )
			str.Format("%d Strike:%s���o�Ƀr��Ո������ԇ���x�������·ݺ���ʹ�r",cald.lMonth1,szStrike);
		break;
	case 6:
		if( m_pStgy->m_iLangType==1 )
			str.Format("%d Strike:%s���޳ɼۣ����Ժ����Ի�ѡ�������·ݺ���ʹ��",cald.lMonth2,szStrike);
		else if( m_pStgy->m_iLangType==2 )
			str.Format("%d Strike:%s���o�Ƀr��Ո������ԇ���x�������·ݺ���ʹ�r",cald.lMonth2,szStrike);
		break;
	}
	if( rs!=0 )
	{
		m_pStgy->m_cald = tempcald;
		AfxMessageBox(str);
		return;
	}
	
	CDialog::OnOK();
}

void CDiagonal::OnSelchangeCmbcall() 
{
	cald.bCall = m_CmbCall.GetCurSel();
}

void CDiagonal::OnSelchangeCmbdebit() 
{
	cald.bDebit = m_CmbDebit.GetCurSel();

	if( cald.bDebit==0 )
	{
		m_near.SetWindowText("( Short )");
		m_far.SetWindowText("( Long )");
	}
	else
	{
		m_far.SetWindowText("( Short )");
		m_near.SetWindowText("( Long )");
	}
}

void CDiagonal::OnSelchangeCmbmonth1() 
{
	int inx = m_CmbMth1.GetCurSel();
	CString str;
	m_CmbMth1.GetLBText(inx,str);
	cald.lMonth1 = atoi(str);
}

void CDiagonal::OnSelchangeCmbmonth2() 
{
	int inx = m_CmbMth2.GetCurSel();
	CString str;
	m_CmbMth2.GetLBText(inx,str);
	cald.lMonth2 = atoi(str);
}

void CDiagonal::OnSelchangeCmbstrike1() 
{
	int inx = m_CmbStk1.GetCurSel();
	CString str;
	m_CmbStk1.GetLBText(inx,str);
	cald.fStrike = atof(str);
}

void CDiagonal::OnSelchangeCmbstrike2() 
{
	int inx = m_CmbStk2.GetCurSel();
	CString str;
	m_CmbStk2.GetLBText(inx,str);
	m_fStrike2_Spread = atof(str);
}

BOOL CDiagonal::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	int i=0,nPos1 = -1,nPos2 = -1;
	CString str;
	for( i=0;i<m_pStgy->m_arrItem.GetSize();i++ )
	{
		m_pStgy->GetPriceTxt(m_pStgy->m_arrItem[i].m_fStrike,str);
		m_CmbStk1.InsertString(i,str);
		m_CmbStk2.InsertString(i,str);
		if( m_pStgy->m_arrItem[i].m_fStrike==m_pStgy->m_cald.fStrike )
		{
			cald.fStrike = m_pStgy->m_cald.fStrike;
			nPos1 = i;
		}
		if( m_pStgy->m_arrItem[i].m_fStrike==m_pStgy->m_fStrike2_Spread )
		{
			m_fStrike2_Spread = m_pStgy->m_fStrike2_Spread;
			nPos2 = i;
		}
	}
	if( nPos1==-1 )
		m_CmbStk1.SetCurSel(m_pStgy->m_nPos+1);
	else
		m_CmbStk1.SetCurSel(nPos1);

	if( nPos2==-1 )
		m_CmbStk2.SetCurSel(m_pStgy->m_nPos-1);
	else
		m_CmbStk2.SetCurSel(nPos2);

	m_CmbCall.InsertString(0,"Call");
	m_CmbCall.InsertString(1,"Put");
	m_CmbCall.SetCurSel(m_pStgy->m_cald.bCall);
	cald.bCall = m_pStgy->m_cald.bCall;
	m_CmbDebit.InsertString(0,"Long");
	m_CmbDebit.InsertString(1,"Short");
	m_CmbDebit.SetCurSel(m_pStgy->m_cald.bDebit);
	cald.bDebit = m_pStgy->m_cald.bDebit;
	
	int nMonths;
	if((nMonths = m_pStgy->m_TTOptions->m_lstMonths.GetCount()) < 1)
		return 1;
	
	POSITION pos = m_pStgy->m_TTOptions->m_lstMonths.GetHeadPosition();
	int nIdx1,nIdx2;
	for(i = 0; i < nMonths; i++)
	{
		LONG theMonth = m_pStgy->m_TTOptions->m_lstMonths.GetNext(pos);
		str.Format("%d",theMonth);
		nIdx1 = m_CmbMth1.AddString(str);
		nIdx2 = m_CmbMth2.AddString(str);
		m_CmbMth1.SetItemData(nIdx1,theMonth);
		m_CmbMth2.SetItemData(nIdx2,theMonth);
	}
	
	cald.lMonth1 = m_pStgy->m_cald.lMonth1;
	cald.lMonth2 = m_pStgy->m_cald.lMonth2;
	CString str1,str2;
	str1.Format("%d",cald.lMonth1);
	str2.Format("%d",cald.lMonth2);
	m_CmbMth1.SetCurSel(m_CmbMth1.FindString(-1,str1));
	m_CmbMth2.SetCurSel(m_CmbMth2.FindString(-1,str2));

	if( cald.bDebit==0 )
	{
		m_near.SetWindowText("( Short )");
		m_far.SetWindowText("( Long )");
	}
	else
	{
		m_far.SetWindowText("( Short )");
		m_near.SetWindowText("( Long )");
	}
	
	GetDlgItem(IDOK)->SetFocus();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
