#if !defined(AFX_MYEDIT_H__153019B8_E7CD_4583_89B7_D5DE2357CB05__INCLUDED_)
#define AFX_MYEDIT_H__153019B8_E7CD_4583_89B7_D5DE2357CB05__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyEdit.h : header file
//
#define IDC_EDIT_CREATEID			613

/////////////////////////////////////////////////////////////////////////////
// CMyEdit window
class CStrategy;
class CMyEdit : public CEdit
{
// Construction
public:
	CMyEdit();

// Attributes
public:
	CStrategy *m_pStgy;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMyEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMyEdit)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetfocus();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYEDIT_H__153019B8_E7CD_4583_89B7_D5DE2357CB05__INCLUDED_)
