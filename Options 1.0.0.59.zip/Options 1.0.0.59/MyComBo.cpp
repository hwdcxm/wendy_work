// MyComBo.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "MyComBo.h"
#include "Strategy.h"
#include "MySpinCtrl.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyComBo

CMyComBo::CMyComBo()
{
}

CMyComBo::~CMyComBo()
{
}


BEGIN_MESSAGE_MAP(CMyComBo, CComboBox)
	//{{AFX_MSG_MAP(CMyComBo)
	ON_CONTROL_REFLECT(CBN_SELCHANGE, OnSelchange)
	ON_WM_TIMER()
	ON_CONTROL_REFLECT(CBN_KILLFOCUS, OnKillfocus)
	ON_CONTROL_REFLECT(CBN_SELENDCANCEL, OnSelendcancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyComBo message handlers

void CMyComBo::OnSelchange() 
{
	BOOL  bChange = FALSE;
	int ix = GetCurSel();
	int item = m_pStgy->m_ComboItem;
	int subitem = m_pStgy->m_ComboSubItem;
	if( subitem==1 )
	{
		if( ix!=m_pStgy->m_nCustomIx[item-2] )
		{
			m_pStgy->m_bAlterPrice[item-2] = FALSE;
			m_pStgy->m_bAlterPrice2[item-2] = FALSE;
			if( m_pStgy->m_nCustomIx[item-2]==6 )
			{
				m_pStgy->m_nCustomCount[item-2] = -1*pow(-1,m_pStgy->m_nCustomIx[ix]);
			}
			else if( ix==6 )
			{
				m_pStgy->m_nCustomCount[item-2] = 0;
				m_pStgy->m_fiSignPrice[item-2] = 0.0;
			}
			
			m_pStgy->m_nCustomIx[item-2] = ix;
			if( ix==4 )
			{
				if( !m_pStgy->m_bHaveCrt_Spin_C )
					m_pStgy->CreateSpin(&m_pStgy->m_list,m_pStgy->m_pSpin_C,item,1,m_pStgy->m_bHaveCrt_Spin_C);
			}
			else
			{
				int count = 0;
				for(int i=0;i<6;i++)
				{
					if(m_pStgy->m_nCustomIx[i]==4)
						count++;
				}
				if( m_pStgy->m_bHaveCrt_Spin_C && count==0 )
					m_pStgy->DestroySpin(m_pStgy->m_pSpin_C,m_pStgy->m_bHaveCrt_Spin_C);
			}
			for( int i=0;i<3;i++ )
			{
				m_pStgy->m_bResetBF[i] = TRUE;	
			}
		}
	}
	else if( subitem==3 )
	{
		switch( item )
		{
		case 2:
			if( ix!=m_pStgy->m_nIxStrike )
			{
				m_pStgy->m_nIxStrike = ix;
				m_pStgy->m_bAlterPrice[0] = FALSE;
				m_pStgy->m_bAlterPrice2[0] = FALSE;
				bChange = TRUE;
			}
			break;
		case 3:
			if( ix!=m_pStgy->m_nIxStrike2 )
			{
				m_pStgy->m_nIxStrike2 = ix;
				m_pStgy->m_bAlterPrice[1] = FALSE;
				m_pStgy->m_bAlterPrice2[1] = FALSE;
				bChange = TRUE;
			}
			break;
		case 4:
			if( ix!=m_pStgy->m_nIxStrike3 )
			{
				m_pStgy->m_nIxStrike3 = ix;
				m_pStgy->m_bAlterPrice[2] = FALSE;
				m_pStgy->m_bAlterPrice2[2] = FALSE;
				bChange = TRUE;
			}
			break;
		case 5:
			if( ix!=m_pStgy->m_nIxStrike4 )
			{
				m_pStgy->m_nIxStrike4 = ix;
				m_pStgy->m_bAlterPrice[3] = FALSE;
				m_pStgy->m_bAlterPrice2[3] = FALSE;
				bChange = TRUE;
			}
			break;
		case 6:
			if( ix!=m_pStgy->m_nIxStrike5 )
			{
				m_pStgy->m_nIxStrike5 = ix;
				m_pStgy->m_bAlterPrice[4] = FALSE;
				m_pStgy->m_bAlterPrice2[4] = FALSE;
				bChange = TRUE;
			}
			break;
		case 7:
			if( ix!=m_pStgy->m_nIxStrike6 )
			{
				m_pStgy->m_nIxStrike6 = ix;
				m_pStgy->m_bAlterPrice[5] = FALSE;
				m_pStgy->m_bAlterPrice2[5] = FALSE;
				bChange = TRUE;
			}
			break;
		}
		if( bChange )
		{
			for( int i=0;i<3;i++ )
			{
				m_pStgy->m_bResetBF[i] = TRUE;	
			}
		}
	}
	else if( subitem==2 )
	{
		int temp = -1*pow(-1,m_pStgy->m_nCustomIx[item-2]);
		switch(ix)
		{
		case 0:
			if( m_pStgy->m_nIndex==STGY_CUSTOM )
				m_pStgy->m_nCustomCount[item-2] = 10*temp;
			else
				m_pStgy->m_nOrderCount = 10;
			break;
		case 1:
			if( m_pStgy->m_nIndex==STGY_CUSTOM )
				m_pStgy->m_nCustomCount[item-2] = 20*temp;
			else
				m_pStgy->m_nOrderCount = 20;
			break;
		case 2:
			if( m_pStgy->m_nIndex==STGY_CUSTOM )
				m_pStgy->m_nCustomCount[item-2] = 30*temp;
			else
				m_pStgy->m_nOrderCount = 30;
			break;
		case 3:
			if( m_pStgy->m_nIndex==STGY_CUSTOM )
				m_pStgy->m_nCustomCount[item-2] = 50*temp;
			else
				m_pStgy->m_nOrderCount = 50;
			break;
		case 4:
			if( m_pStgy->m_nIndex==STGY_CUSTOM )
				m_pStgy->m_nCustomCount[item-2] = 100*temp;
			else
				m_pStgy->m_nOrderCount = 100;
			break;
		}
		m_pStgy->m_nRetn = m_pStgy->PrePaint();
		if( m_pStgy->m_nRetn==1 )
		{
			m_pStgy->DrawIncomeLine();
		}
	}
	SetTimer(7777,10,NULL);
}

void CMyComBo::OnTimer(UINT nIDEvent) 
{
	if( nIDEvent==7777 )
	{
		int item = m_pStgy->m_ComboItem;
		int subitem = m_pStgy->m_ComboSubItem;
		m_pStgy->DestroyCombo(&m_pStgy->m_list,m_pStgy->m_pCombo,m_pStgy->m_bCrtCombo);
		KillTimer(7777);
		if( subitem==2 )
		{
			if( m_pStgy->m_nIndex==STGY_CUSTOM&&item>2 )
				m_pStgy->m_pSpinEx[item-3]->ShowWindow(SW_SHOW);
			else
				m_pStgy->m_pSpin->ShowWindow(SW_SHOW);
		}
	}
	CComboBox::OnTimer(nIDEvent);
}

void CMyComBo::OnKillfocus() 
{
	// TODO: Add your control notification handler code here
	if( m_pStgy->m_bCrtCombo )
	{
		int item = m_pStgy->m_ComboItem;
		int subitem = m_pStgy->m_ComboSubItem;
		m_pStgy->m_pCombo->DestroyWindow();
		m_pStgy->m_bCrtCombo = FALSE;
		if( subitem==2 )
		{
			if( m_pStgy->m_nIndex==STGY_CUSTOM&&item>2 )
				m_pStgy->m_pSpinEx[item-3]->ShowWindow(SW_SHOW);
			else
				m_pStgy->m_pSpin->ShowWindow(SW_SHOW);
		}
	}
}

void CMyComBo::OnSelendcancel() 
{
	// TODO: Add your control notification handler code here
	if( m_pStgy->m_bCrtCombo )
	{
		int item = m_pStgy->m_ComboItem;
		int subitem = m_pStgy->m_ComboSubItem;
		m_pStgy->m_pCombo->DestroyWindow();
		m_pStgy->m_bCrtCombo = FALSE;
		if( subitem==2 )
		{
			if( m_pStgy->m_nIndex==STGY_CUSTOM&&item>2 )
				m_pStgy->m_pSpinEx[item-3]->ShowWindow(SW_SHOW);
			else
				m_pStgy->m_pSpin->ShowWindow(SW_SHOW);
		}
	}
}
