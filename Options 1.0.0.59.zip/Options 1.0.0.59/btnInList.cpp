// btnInList.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "btnInList.h"
#include "Strategy.h"
#include "ConfDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CbtnInList

CbtnInList::CbtnInList()
{
	m_pStgy = NULL;
}

CbtnInList::~CbtnInList()
{
}


BEGIN_MESSAGE_MAP(CbtnInList, CButton)
	//{{AFX_MSG_MAP(CbtnInList)
	ON_CONTROL_REFLECT(BN_CLICKED, OnClicked)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CbtnInList message handlers
char* szSaveTip0[3] = {"Save this record?","���������¼?","�O�s�����O��?"};
char* szSaveTip1[3] = {"Some Strikes have no premium, please input again","��ǰ��¼�гɼ�Ϊ0,�����������ٱ���","���e�O����������0,�Э��s��J�A�O�s"};
char* szSaveTip2[3] = {"Please choose at least one option","������ѡ��һ����Ȩ���ٱ���","�Цܤֿ�ܤ@�Ӵ��v��A�O�s"};

void CbtnInList::OnClicked() 
{
	int i;
	if( this == m_pStgy->m_pBtn )
	{
		CString strStrike;
		StgyHistoryFile stgyfile;
		StgyFileExt extfile;
		memset(&stgyfile,0,sizeof(stgyfile));
		memset(&extfile,0,sizeof(extfile));
		CTime time = CTime::GetCurrentTime();
		int nYear = time.GetYear();
		int nMonth = time.GetMonth();
		int nDay = time.GetDay();
		int nHour = time.GetHour();
		int nMin = time.GetMinute();
		
		memcpy(stgyfile.m_szCode,m_pStgy->m_TTOptions->m_szItemCode,9);
		stgyfile.m_lDate = nYear*10000+nMonth*100+nDay;
		stgyfile.m_iTime = nHour*100+nMin;
		//stgyfile.m_iStgyIx = m_pStgy->m_nIndex;
		stgyfile.m_fCapital = m_pStgy->m_fCapitalS;
		stgyfile.m_iCustomIx[7] = m_pStgy->m_nIndex;
		stgyfile.m_lExpTime = m_pStgy->m_TTOptions->m_lExpiryTime;
		if( m_pStgy->m_nIndex==17 || m_pStgy->m_nIndex==18 )
			stgyfile.m_lExpTime = m_pStgy->m_lCaldExpDate1;
		stgyfile.m_lShares = m_pStgy->m_lShares/m_pStgy->m_nOrderCount;
		stgyfile.m_nCount = m_pStgy->m_nOrderCount;

		CString str;
		str = m_pStgy->m_list.GetItemText(m_pStgy->m_nRow+3,4);
		stgyfile.m_ExpValue = m_pStgy->m_ExpValueS;
		stgyfile.m_fPB = m_pStgy->m_fStgyPB;
		stgyfile.m_iCustomIx[6] = 1;

		if( m_pStgy->m_nIndex==STGY_CUSTOM )
		{
			int iOpt = 0;
			for( i=0;i<6;i++ )
			{
				stgyfile.m_iCustomCount[i] = m_pStgy->m_nCustomCount[i];
				stgyfile.m_iCustomIx[i] = m_pStgy->m_nCustomIx[i];
				if( m_pStgy->m_nCustomIx[i]!=6 )
					iOpt++;
			}
			if( iOpt==0 )
			{
				MessageBox(szSaveTip2[m_pStgy->m_TTOptions->m_iLangType],"Tips",MB_OK);
				return;
			}
		}

		for( i=0;i<m_pStgy->m_nRow;i++ )
		{
			if( i>3 )
				stgyfile.m_fPriceEx[i-4] = m_pStgy->m_fLPrice[i];
			else
				stgyfile.m_fPrice[i] = m_pStgy->m_fLPrice[i];
			if( m_pStgy->m_fLPrice[i]==0.0 && m_pStgy->m_nIndex!=STGY_CUSTOM )
			{
				MessageBox(szSaveTip1[m_pStgy->m_TTOptions->m_iLangType],"Tips",MB_OK);
				return;
			}
			else if( m_pStgy->m_nIndex==STGY_CUSTOM && m_pStgy->m_nCustomIx[i]!=6 && m_pStgy->m_fLPrice[i]==0.0 )
			{
				MessageBox(szSaveTip1[m_pStgy->m_TTOptions->m_iLangType],"Tips",MB_OK);
				return;
			}
		}
		for( i=2;i<m_pStgy->m_nRow+2;i++ )
		{
			strStrike = m_pStgy->m_list.GetItemText(i,3);
			if( strStrike=="" && m_pStgy->m_nIndex==STGY_CUSTOM )
				continue;

			if( i>5 )
				stgyfile.m_fStrikeEx[i-6] = atof(strStrike);
			else
				stgyfile.m_fStrike[i-2] = atof(strStrike);
		}
		
		if( m_pStgy->m_nIndex==17 || m_pStgy->m_nIndex==18 )
		{
			memcpy(&extfile.cald,&m_pStgy->m_cald,sizeof(extfile.cald));
			extfile.cald.lMonth2 = m_pStgy->m_lCaldExpDate2; //  Calendar month2�浽���գ��������һ�ε�����
			if( m_pStgy->m_cald.lMonth2>10000000 )
				extfile.b_Mth2_Weekly = 1;
			extfile.m_fStrike2_Spread = m_pStgy->m_fStrike2_Spread;
		}
		if( m_pStgy->m_bTarget==1 )
		{
			extfile.b_RNG = 1;
			extfile.f_Lo = m_pStgy->m_fTargetLo;
			extfile.f_Up = m_pStgy->m_fTargetUp;
			extfile.f_PP = m_pStgy->m_PP;
			extfile.d_ER = m_pStgy->m_ER;
		}
		if( (m_pStgy->m_TTOptions->m_lTransdate>10000000 &&m_pStgy->m_nIndex<17) || (m_pStgy->m_nIndex>=17&&m_pStgy->m_cald.lMonth1>10000000) )
			extfile.b_weekly = 1;
		if( m_pStgy->m_TTOptions->m_lTransdate>10000000 &&m_pStgy->m_nIndex==STGY_CUSTOM) 
			extfile.b_weekly = 1;
/////////////////////////////////////////////

		/*if( IDNO==MessageBox(szSaveTip0[m_pStgy->m_TTOptions->m_iLangType],"Tips",MB_YESNO) )
			return;*/
		CConfDlg dlg;
		dlg.m_pStgy = m_pStgy;
		if( dlg.DoModal()!=IDOK )
			return;
/////////////////////////////////////////////

		if( m_pStgy->m_ExtList.GetSize()==0 )
		{
			StgyFileExt fileext;
			memset(&fileext,0,sizeof(fileext));
			for( i=0;i<m_pStgy->m_StgyList.GetSize();i++  )
				m_pStgy->m_ExtList.Add(fileext);
		}
		m_pStgy->m_StgyList.Add(stgyfile);
		m_pStgy->m_ExtList.Add(extfile);
		m_pStgy->SaveStgyHistoryFile();

		StgyHistoryList StgyList;
		StgyFileExtList ExtList;
		StgyList.RemoveAll();
		ExtList.RemoveAll();
		for( i=0;i<m_pStgy->m_StgyList.GetSize();i++ )
		{
			StgyHistoryFile file;
			StgyFileExt  ext;
			memset(&file,0,sizeof(file));
			memset(&ext,0,sizeof(ext));
			int stgyinx;
			if( m_pStgy->m_StgyList[i].m_iCustomIx[6]==1 )
				stgyinx = m_pStgy->m_StgyList[i].m_iCustomIx[7];
			else
				stgyinx = m_pStgy->m_StgyList[i].m_fCapital;
			
			memcpy(&file,&m_pStgy->m_StgyList[i],sizeof(file));
			memcpy(&ext,&m_pStgy->m_ExtList[i],sizeof(ext));
			StgyList.Add(file);
			ExtList.Add(ext);
			if( stgyinx==17 || stgyinx==18 )
			{
				file.m_lExpTime = m_pStgy->m_ExtList[i].cald.lMonth2;
				StgyList.Add(file);
				ExtList.Add(ext);
			}
		}

		BOOL bSend = TRUE;
		BOOL bSend2 = TRUE;
		for( i=0;i<StgyList.GetSize();i++ )
		{	
			if( stgyfile.m_lExpTime==StgyList[i].m_lExpTime 
				&&strcmp(stgyfile.m_szCode,StgyList[i].m_szCode)==0
				&&extfile.b_weekly==ExtList[i].b_weekly)
			{
				bSend = FALSE;
			}
			if( strcmp(stgyfile.m_szCode,StgyList[i].m_szCode)==0 )
			{
				if( !m_pStgy->IsIndex_Ext(stgyfile.m_szCode) || (m_pStgy->IsIndex_Ext(stgyfile.m_szCode)&&stgyfile.m_lExpTime==StgyList[i].m_lExpTime) )
					bSend2 = FALSE;
			}
		}

	/*	if( m_pStgy->m_ExtList.GetSize()==0 )
		{
			StgyFileExt fileext;
			memset(&fileext,0,sizeof(fileext));
			for( i=0;i<m_pStgy->m_StgyList.GetSize();i++  )
				m_pStgy->m_ExtList.Add(fileext);
		}
		m_pStgy->m_StgyList.Add(stgyfile);
		m_pStgy->m_ExtList.Add(extfile);
		m_pStgy->SaveStgyHistoryFile();*/

		if( bSend )
		{
			long lTransdate = stgyfile.m_lExpTime/100;
			if( extfile.b_weekly==1 )
				lTransdate = stgyfile.m_lExpTime;
			m_pStgy->m_TTOptions->SendUpdateRP(TRUE,stgyfile.m_szCode,lTransdate);
			if( m_pStgy->m_ExtList[i].cald.lMonth2!=0 )
			{
				long lm = m_pStgy->m_ExtList[i].cald.lMonth2;
				if( m_pStgy->m_ExtList[i].b_Mth2_Weekly==0 )
					lm = lm/100;
				m_pStgy->m_TTOptions->SendUpdateRP(FALSE,m_pStgy->m_StgyList[i].m_szCode,lm);
			}
		}
		if( bSend2 )
		{
			char code[9] = {0};
			m_pStgy->m_TTOptions->GetCashOrFuturesCode(stgyfile.m_szCode,stgyfile.m_lExpTime, code);
			ItemToCash itc;
			memcpy(itc.itemcode,stgyfile.m_szCode,8);
			memcpy(itc.cashcode,code,8);
			itc.ldate = stgyfile.m_lExpTime;
			m_pStgy->m_arrITC.Add(itc);
			m_pStgy->m_TTOptions->SendTeleHisCash(code);
			if( m_pStgy->m_ExtList[i].cald.lMonth2!=0 )
			{
				m_pStgy->m_TTOptions->GetCashOrFuturesCode(stgyfile.m_szCode,stgyfile.m_lExpTime, code);
				memcpy(itc.itemcode,stgyfile.m_szCode,8);
				memcpy(itc.cashcode,code,8);
				itc.ldate = stgyfile.m_lExpTime;
				m_pStgy->m_arrITC.Add(itc);
				m_pStgy->m_TTOptions->SendTeleHisCash(code);
			}
		}

		if( m_pStgy->m_bOrder )
		{
			Sleep(1000);
			m_pStgy->LoadData();
		}
	}
}
