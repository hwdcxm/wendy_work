// MyEdit.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "MyEdit.h"
#include "Strategy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern CStrategy *g_pDlg;
extern HHOOK   g_hHook;
/////////////////////////////////////////////////////////////////////////////
// CMyEdit

CMyEdit::CMyEdit()
{
}

CMyEdit::~CMyEdit()
{
}


BEGIN_MESSAGE_MAP(CMyEdit, CEdit)
	//{{AFX_MSG_MAP(CMyEdit)
	ON_WM_KILLFOCUS()
	ON_CONTROL_REFLECT(EN_SETFOCUS, OnSetfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyEdit message handlers

LRESULT CALLBACK HookProc(int nCode, WPARAM wParam, LPARAM lParam);

void CMyEdit::OnKillFocus(CWnd* pNewWnd) 
{
	//CEdit::OnKillFocus(pNewWnd);
	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
	if( m_pStgy->m_bHaveCrt )
	{
		m_pStgy->DestroyEdit(&m_pStgy->m_list, m_pStgy->m_editCrt, m_pStgy->m_nItem, m_pStgy->m_nSubItem,m_pStgy->m_bHaveCrt);	
	}
}

void CMyEdit::OnSetfocus() 
{
	// TODO: Add your control notification handler code here
	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
	g_pDlg = m_pStgy;
	g_hHook = ::SetWindowsHookEx(WH_KEYBOARD, HookProc, 0, ::GetCurrentThreadId());
}
