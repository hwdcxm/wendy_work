




#ifndef _LISTCTRLOPTIONS_H_
#define _LISTCTRLOPTIONS_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// listctrlOptions.h : header file
//
#include <afxcmn.h>



#define	MACRO_MaxSubItems	21		//add one
#define	MACRO_PBMaxSubItems	15      //PB��
struct	ItemOptionsText
{
public:
	ItemOptionsText() ;

	void ReInit() ;

public:
	char	m_szCalls_OI[20] ;
	char	m_szCalls_Vol[10] ;
	char	m_szCalls_High[10] ;
	char	m_szCalls_Low[10] ;
	char	m_szCalls_Nominal[10] ;
	char	m_szCalls_NominalQty[10];			//Add
	char	m_szCalls_BidQty[10];			//Add
	char	m_szCalls_Bid[10] ;
	char	m_szCalls_Ask[10] ;
	char	m_szCalls_AskQty[10];			//add

	char	m_szStrike[10] ;

	char	m_szPuts_BidQty[10];			//Add
	char	m_szPuts_Bid[10] ;
	char	m_szPuts_Ask[10] ;
	char	m_szPuts_AskQty[10];			//Add
	char	m_szPuts_NominalQty[10];			//Add
	char	m_szPuts_Nominal[10] ;
	char	m_szPuts_High[10] ;
	char	m_szPuts_Low[10] ;
	char	m_szPuts_Vol[10] ;
	char	m_szPuts_OI[20] ;

//andy add 2012.02.14 for IV Data
	char    m_szCalls_Vega[10];
	char    m_szCalls_Theta[10];
	char    m_szCalls_Gamma[10];
	char    m_szCalls_Delta[10];
	char    m_szCalls_Bid_IV[20];
	char    m_szCalls_Ask_IV[20];
	char    m_szCalls_Nominal_IV[20];
	char    m_szCalls_Margin[10];
	char    m_szCalls_ITM[10];

	char    m_szPuts_Vega[10];
	char    m_szPuts_Theta[10];
	char    m_szPuts_Gamma[10];
	char    m_szPuts_Delta[10];
	char    m_szPuts_Bid_IV[20];
	char    m_szPuts_Ask_IV[20];
	char    m_szPuts_Nominal_IV[20];
	char    m_szPuts_Margin[10];
	char    m_szPuts_ITM[10];
};

struct	ItemOptionsTextColor
{
public:
	ItemOptionsTextColor() ;

	void ReInit() ;

public:
	short m_iColor[21] ;  //0 - ��ɫ 1 - ��,��ɫ 2 - ��,��ɫ
	short m_iTime[21];    //3�뵹��ʱ,��0��ʱ��ָ���ɫ	
};


#define		MACRO_MsgRedrawItem		2000
#define		MACRO_MsgSetItemsTotal	2001


/////////////////////////////////////////////////////////////////////////////
// ClistctrlOptions window

//��ɫģ�ͣ��׵׺ͺڵ�
#define		_COLORMODE_BK_WHITE		0
#define		_COLORMODE_BK_BLACK		1

#define  COLOR_CHANGE_TIME 3

//johnny 20151208
//#define	MACRO_MaxItems	200
#define	MACRO_MaxItems	300
#define MACRO_SmpItems  12

#define IDC_HAND            MAKEINTRESOURCE(32649)

class CTTOptions ;

class ClistctrlOptions;

//���ر�ͷ��ʵ��"�Ϲ���Ȩ","�Ϲ���Ȩ"��ͷ���ػ�
class CHeaderCtrlOptions : public CHeaderCtrl
{
	DECLARE_DYNAMIC(CHeaderCtrlOptions)

	public:
		CHeaderCtrlOptions();
		virtual ~CHeaderCtrlOptions();
		//BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);

		int m_nColorMode;
		void SetColorMode(int colMode);


		

	protected:
		DECLARE_MESSAGE_MAP()

	public:
		int m_R;
		int m_G;
		int m_B;
		int m_Gradient;	// �����屳��������ϵ��������Ҫ����滭������Ϊ0


		CStringArray m_HChar;//��ǰͷ������

		CTTOptions* m_TTOptions;//��CTTOptions����
		
		afx_msg void OnPaint();//�ػ溯��
	
};

//���ر�ͷ��ʵ�ֱ�ͷ���ػ�,CLIstCtrl�б�ͷ�ػ�
class CHeaderCtrlCl : public CHeaderCtrl
{
	DECLARE_DYNAMIC(CHeaderCtrlCl)

	public:
		CHeaderCtrlCl();
		virtual ~CHeaderCtrlCl();

	protected:
		DECLARE_MESSAGE_MAP()

	public:
		int m_R;
		int m_G;
		int m_B;
		int m_Gradient;	// �����屳��������ϵ��������Ҫ����滭������Ϊ0

		ClistctrlOptions * m_plist;

		CStringArray m_HChar;//��ǰͷ������
		
		afx_msg void OnPaint();//�ػ溯��

		int m_nColorMode;
		void SetColorMode( int colMode );


	
};







class ClistctrlOptions : public CListCtrl
{
public:
	int m_Max_Min_Flag;  //��ֹ���ִ���ı�־

public:
	CHeaderCtrlCl m_Head;  //��ͷ

	//BOOL m_Flag;  //TRUE:��ʾ�¹���Ķ���Ҫ������ֱ��������λ��      FALSE:��ʾ���账����ֱ��������λ��

	//void fun();

// Construction
public:
	ClistctrlOptions();

	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);

// Attributes
public:
	ItemOptionsText m_buf[MACRO_MaxItems] ; //�����е�����
	int	m_nTotal ;

	//����ģʽ����ʱ����
	ItemOptionsText m_buf_simple[MACRO_SmpItems] ; 
	int	m_nTotal_simple ;
	int m_nStart;
	int m_nEnd;
	int m_iNum;
	int m_iNumST;

	ItemOptionsTextColor m_Color[MACRO_MaxItems] ;
	void CheckColor();
	COLORREF GetTextColor( int nItem, int nSubItem);
	void SetHead(); //������ͷ��ʵ�ֱ�ͷ���ػ�
	
	CTTOptions* m_pOwner ;

	HANDLE m_hColorThread;
	BOOL m_bStopColorThread;
	BOOL m_bStoppedColorThread;

	int m_bShowHighPrice; 
	int	m_nColorMode;//��ɫģʽ:0.�׵ף�1:�ڵ�  2:��ɫ
	int	m_nColDefWidth[ MACRO_MaxSubItems ];

	int m_iColumnMode;
	int m_bIVMode;
	int m_bSimpleMode;

	CTTOptions* m_TTOptions;//��CTTOptions����
	
// Operations
public:

	void SetItemsTotal( int nTotal, BYTE* pDirtyBuf ) ;
	char* GetReflectItemText( ItemOptionsText* pObj, int nSubItem ) ;  //����б���ͷ
	void  SetReflectItemTextColor( int nItem, int nSubItem,char* pNew,char* pOld) ;
	
	BYTE CheckColumnWidth( int nItem, int nSubItem,char* pNew,char* pOld) ;
	BYTE AdjustColumnWidth();
	BYTE RecalcColumnWidth(int iMode);
	void SetColsMinWidth();
	void SetColsOriginWidthValue(int i,int iWidth);

	BYTE AdjustColumnWidthIVMode();
	BYTE RecalcColumnWidthIVMode(int iMode);

	BYTE AdjustColumnWidthPBMode();
	BYTE RecalcColumnWidthPBMode(int iMode);
	void SetColsMinWidthPBMode();
	char* GetReflectItemTextPB( ItemOptionsText* pObj, int nSubItem ) ;

	void SetColsMinWidthIVMode();
	char* GetReflectItemTextIV( ItemOptionsText* pObj, int nSubItem ) ;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ClistctrlOptions)
	public:
	//}}AFX_VIRTUAL

// Implementation
public:
	void ShowHighPrice(int bShow);
	void SelectIVMode(int bMode);
	void SelectSimpleMode(int bMode, int iNum);
	void SaveLastPage();
	void LoadLastPage();
	virtual ~ClistctrlOptions();

	void SetColorMode(int nColMode);  //������ɫģʽ

	// Generated message map functions
protected:
	//{{AFX_MSG(ClistctrlOptions)
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnGetdispinfo(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnHScroll( UINT nSBCode, UINT nPos, CScrollBar* pScrollBar );
	afx_msg void OnTrack(NMHDR * pNotifyStruct, LRESULT * result);
	afx_msg void OnDestroy();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	afx_msg LRESULT OnMyRedrawItem(WPARAM, LPARAM);
	afx_msg LRESULT OnMySetItemsTotal(WPARAM, LPARAM);
	afx_msg void MeasureItem( LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	afx_msg   LRESULT   OnSetFont(WPARAM   wParam,   LPARAM);
	DECLARE_MESSAGE_MAP()
	//virtual void PreSubclassWindow();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTCTRL785_H__E0B6CDA3_B41F_11D3_AF21_00A0CC23E698__INCLUDED_)
