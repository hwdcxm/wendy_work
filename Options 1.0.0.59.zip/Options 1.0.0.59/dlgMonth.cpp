// dlgMonth.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "dlgMonth.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CdlgMonth dialog

long  CdlgMonth::m_lMonth[24] ;
long  CdlgMonth::m_lSelMonth ;
BYTE  CdlgMonth::m_cbMonthNum ;
char  CdlgMonth::m_szItemCode[9] ;
int   CdlgMonth::m_nSel ;

CdlgMonth::CdlgMonth(CWnd* pParent, /*=NULL*/int iLangType /* = 0*/)
	: CDialog(CdlgMonth::IDD, pParent)
{
	//{{AFX_DATA_INIT(CdlgMonth)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bInit = TRUE ;
	m_iLangType = iLangType;
}

void CdlgMonth::ClearMonth()
{
	m_cbMonthNum = 0;
}

void CdlgMonth::AddMonth(long lMonth)
{
	if(m_cbMonthNum <0 || m_cbMonthNum >= 24)
		return;
	m_lMonth[m_cbMonthNum] = lMonth;
	m_cbMonthNum ++;
	//m_hwndParent = NULL;
}

void CdlgMonth::AddItemCode(LPCTSTR pszItemCode)
{
	if(pszItemCode == NULL)
		return;

	memcpy(m_szItemCode,pszItemCode,8);
	m_szItemCode[8] = 0;
}


void CdlgMonth::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CdlgMonth)
	DDX_Control(pDX, IDC_LB_MONTH, m_listboxMonth);
	DDX_Control(pDX, IDC_EB_ITEM, m_edtItem);
	//}}AFX_DATA_MAP
/*
	if( m_bInit==TRUE )
	{
		m_bInit = FALSE ;
		int nIndex ;
		for(int i =0; i< m_cbMonthNum; i++)
		{
			TCHAR szMonth[10];
			_stprintf(szMonth,_T("%6d"),m_lMonth[i]);
			nIndex = m_listboxMonth.AddString(szMonth);
			m_listboxMonth.SetItemData( nIndex,m_lMonth[i] );
		}
//		m_edtItem.SetWindowText(m_szItemCode);
		m_edtItem.PostMessage(WM_SETTEXT, 0, (LPARAM)m_szItemCode);

	}
*/
}


BEGIN_MESSAGE_MAP(CdlgMonth, CDialog)
	//{{AFX_MSG_MAP(CdlgMonth)
	ON_LBN_DBLCLK(IDC_LB_MONTH, OnDblclkLbMonth)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CdlgMonth::OnInitDialog()
{
	CDialog::OnInitDialog();

	for(int i =0; i< m_cbMonthNum; i++)
	{
		TCHAR szMonth[10];
		_stprintf(szMonth,_T("%6d"),m_lMonth[i]);
		int nIdx = m_listboxMonth.AddString(szMonth);
		m_listboxMonth.SetItemData(nIdx,m_lMonth[i]);
	}
	m_edtItem.SetWindowText(m_szItemCode);
//	m_edtItem.PostMessage(WM_SETTEXT, 0, (LPARAM)m_szItemCode);
	CWnd * pCwnd;
	if(m_iLangType == 2)
	{
		pCwnd = GetDlgItem(IDC_STATIC_ITEMCODE);
		pCwnd->SetWindowText("�ӫ~�N�X");		
		pCwnd = GetDlgItem(IDC_STATIC_AVAMONTH);
		pCwnd->SetWindowText("�i���/�P");

		pCwnd = GetDlgItem(IDOK);
		pCwnd->SetWindowText("�T�w");		
		pCwnd = GetDlgItem(IDCANCEL);
		pCwnd->SetWindowText("����");

		SetWindowText("���v");
	}
	else if(m_iLangType == 1 )
	{
		pCwnd = GetDlgItem(IDC_STATIC_ITEMCODE);
		pCwnd->SetWindowText("��Ʒ����");		
		pCwnd = GetDlgItem(IDC_STATIC_AVAMONTH);
		pCwnd->SetWindowText("��ѡ��/��");

		pCwnd = GetDlgItem(IDOK);
		pCwnd->SetWindowText("ȷ��");		
		pCwnd = GetDlgItem(IDCANCEL);
		pCwnd->SetWindowText("ȡ��");

		SetWindowText("��Ȩ");
	}

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CdlgMonth message handlers

void CdlgMonth::OnOK() 
{
	// TODO: Add extra validation here
	int	nSel = m_listboxMonth.GetCurSel() ;
	if( nSel<0 )
		CDialog::OnCancel();
	else
	{
		m_lSelMonth = m_listboxMonth.GetItemData( nSel ) ;
		CDialog::OnOK();
	}

}

void CdlgMonth::OnDblclkLbMonth() 
{
	// TODO: Add your control notification handler code here
		OnOK();
}
