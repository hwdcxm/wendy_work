// TTOptions.cpp : Implementation of CTTOptions

#include "stdafx.h"
#include "Options.h"
#include "TTOptions.h"
#include "listctrlOptions.h"
#include "LstCfg.h"
#include "wndBgn.h"
#include "..\common\common.h"
#include "dlgMonth.h"
#include "TTOptionsItemDlg.h"
#include "btnWithTip.h"
#include "Strategy.h"
#include <math.h>
#include "afxdlgs.h"

#define MEMSIZE 1000

char *szCaption[15] = {"Strategy","����","����","PV","ʹֵ","�h��","Strategy","����","����","Strategy","����","����","Strategy","����","����"};
char* szModeStgy[3] = {"Stgy","����","����"};
char* szModePain[3] = {"PV","ʹֵ","�h��"};

/////////////////////////////////////////////////////////////////////////////
// CTTOptions

LRESULT CTTOptions::OnShowMonthDlg(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)//��ʾѡ���·�
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

		
	static BYTE bDlgActive = 0 ;
	if(bDlgActive != 0)
		return 0;

	bDlgActive = 1 ;

	int nMonths;
	if((nMonths = m_lstMonths.GetCount()) < 1)
		return 1;

	CdlgMonth::ClearMonth();
	POSITION pos = m_lstMonths.GetHeadPosition();
	for(int i = 0; i < nMonths; i++)
	{
		LONG theMonth = m_lstMonths.GetNext(pos);
		CdlgMonth::AddMonth(theMonth);
	}

	CdlgMonth dlg(NULL,m_iLangType) ;
	if( dlg.DoModal() == IDOK && m_lTransdate != dlg.m_lSelMonth)
	{
/*
		m_lTransdate = 0;
//		m_lTransdate = dlg.m_lSelMonth;	lawrence modify ��Ϊԭ���ĸ����·�ʱ�ᵼ�����ݴ�����					
*/
		//andy add 2003.10.16  �ȶϿ�ԭ�ȵ�DO����
		SendUpdateRQ(FALSE);
		//andy add 2003.10.16

		m_lTransdate = dlg.m_lSelMonth; //andy 2003.02.20��ԭ
		sprintf(m_szText, "%2d/%4d",m_lTransdate%100,m_lTransdate/100);
		m_pbtnOptMonth->SetWindowText(m_szText);	//modify				
		::SetWindowText( m_pedtFutures->m_hWnd,_T(""));
		MakeFutCode(m_szFuturesCode,m_szFuturesTitle,m_lTransdate % 100, (m_lTransdate/100)%100);

		ClearData(); 
		//ResetTable() ;
		ResetFrmTitle() ;
		SaveValue() ;
		//SaveValueColor();//add 2014.9.25 Keeping
		GetExpiryTime();
		UpdateTitle();
		GetDvdInfo();
		SendRequestFrame();

		if( m_pwndCls!=NULL && m_pwndCls->IsWindowVisible() )
		{
			if( m_pwndCls->m_nIndex==17 || m_pwndCls->m_nIndex==18 )
			{
				m_pwndCls->m_bFillList = FALSE;
				OnSelectStrategy();
				bDlgActive = 0 ;
				return 0;
			}
			m_pwndCls->m_nIxStrike = -1;
			m_pwndCls->m_nIxStrike2 = -1;
			m_pwndCls->m_nIxStrike3 = -1;
			m_pwndCls->m_nIxStrike4 = -1;
			m_pwndCls->m_nIxStrike5 = -1;
			m_pwndCls->m_nIxStrike6 = -1;
			m_pwndCls->ClearFlag();
			if( m_pwndCls->m_bMode!=1 )
				m_pwndCls->SwitchCtrl();
			if( m_pwndCls->m_bUseRecord )
			{
				m_pwndCls->m_bUseRecord = FALSE;
				if( m_pwndCls->m_bMode==0 )
				{
					m_pwndCls->CreateBtn();
					m_pwndCls->CreateSpin(&m_pwndCls->m_list,m_pwndCls->m_pSpin,2,
						2,m_pwndCls->m_bHaveCrt_Spin);
					if( m_pwndCls->m_nIndex==STGY_CUSTOM )
					{
						for( int j=0;j<5;j++ )
							m_pwndCls->CreateSpin(&m_pwndCls->m_list,m_pwndCls->m_pSpinEx[j],j+3,2,m_pwndCls->m_bHaveCrt_Spin);
					}
				}
			}
			for( int i=0;i<3;i++ )
			{
				m_pwndCls->m_bResetBF[i] = TRUE;	
			}
			for( i=0;i<6;i++ )
			{
				m_pwndCls->m_bAlterPrice[i] = FALSE;
				m_pwndCls->m_bAlterPrice2[i] = FALSE;
			}

//			m_pwndCls->m_nRetn = 0;
			OnSelectStrategy();
		}
		else
		{
			if( m_pwndCls!=NULL )
			{
				for( int i=0;i<m_pwndCls->m_StgyList.GetSize();i++ )
				{
					long lTransdate = m_pwndCls->m_StgyList[i].m_lExpTime/100;
					if( m_pwndCls->m_ExtList[i].b_weekly==1 )
						lTransdate = m_pwndCls->m_StgyList[i].m_lExpTime;
					SendUpdateRP(FALSE,m_pwndCls->m_StgyList[i].m_szCode,lTransdate);
					if( m_pwndCls->m_ExtList[i].cald.lMonth2!=0 )
					{
						long lm = m_pwndCls->m_ExtList[i].cald.lMonth2;
						if( m_pwndCls->m_ExtList[i].b_Mth2_Weekly==0 )
							lm = lm/100;
						SendUpdateRP(FALSE,m_pwndCls->m_StgyList[i].m_szCode,lm);
					}
				}
				delete m_pwndCls;
				m_pwndCls = NULL;
				m_bStgyMode = -1;
			}
		}
		
	}

	bDlgActive = 0 ;
	return 0;
}

void CTTOptions::SendRequestFrame()
{
	SendUpdateRQ(TRUE);
	SendHistoryRQ();
	//SendHistoryRI();
//	SendHistoryRQ();
//	SendUpdateRQ(TRUE);
	SendTeleHisRQ();
	SendTeleUpdateRQ(TRUE);
	
}

char* CTTOptions::MakeFutCode( char* pEchoItemCode, char* pTitleCode, int nMM, int nYY )
{

	m_bUseNtMth = FALSE;

	//andy add 2003.02.13 for future always display first month
	memset(pEchoItemCode,' ',G_GENCODELEN);
	if(m_lstMonths.GetCount() <= 0)
	{
		return pEchoItemCode;
	}

//	POSITION pos = m_lstMonths.GetHeadPosition();
//	LONG theMonth = m_lstMonths.GetAt(pos) ;

//	nMM = theMonth % 100;
//	nYY =  (theMonth/100)%100;
	//andy add 2003.02.13 for future always display first month

	//ben  modify 2018.03.22 ��Ϊ��Ӧ�·�
	LONG theMonth = m_lTransdate;
	if( theMonth>10000000 )
		theMonth = theMonth/100;
	//weekly option������ > ����option������   �������Ҫ�ж�
	CString strItem;
	strItem.Format("%c%s",m_cbGroupCode,m_szItemCode);
	BOOL bFind = FALSE;
	long temp_lExpiryTime = 0;
	OptionsExpiryDateInfo expInfo;
	if(m_ExpiryDateMap.Lookup((LPCTSTR)strItem,expInfo)== TRUE)
	{
		for(int i=0;i<expInfo.expList.GetSize();i++)
		{
			if (expInfo.expList.ElementAt(i).lMonth == theMonth)
			{
				temp_lExpiryTime = expInfo.expList.ElementAt(i).lExpiryDate;
				bFind = TRUE;
				break;
			}	
		}	
	}


	nMM = theMonth%100;
	nYY = (theMonth/100)%100;
	if(bFind)
	{
		if( m_lTransdate>temp_lExpiryTime )
		{
			m_bUseNtMth = TRUE;
			if( nMM==12 )
			{
				nMM = 1;
				nYY += 1;
			}
			else
				nMM += 1;
		}
	}

	TCHAR szBuf[9];
	char szMonthCode[] = "FGHJKMNQUVXZ";
	int	nCodeLen = strlen(pTitleCode);
	if (nCodeLen > G_GENCODELEN - 3 || nMM < 1 || nMM > 12 || nYY < 0)
		return NULL;
	if (nYY > 99)
		nYY = 0;
	sprintf( szBuf, "%s%c%02d%*s", _strupr(pTitleCode), szMonthCode[nMM - 1], nYY, G_GENCODELEN - 3 - nCodeLen, " " );

	if( IsIndex() )
	{
		char ch = 'X';
		sprintf( m_szFuturesNightCode, "%c%s%c%02d%*s", ch,_strupr(pTitleCode), szMonthCode[nMM - 1], nYY, G_GENCODELEN - 3 - nCodeLen, " " );
	}
	else
		sprintf(m_szFuturesNightCode,"");

	memcpy(pEchoItemCode,szBuf,G_GENCODELEN);

	GetExpiryTime();  //andy add 2012.02.17 ÿ���ڵõ�futureCode֮��ȥIGP��ȡexpiryDate;
	return pEchoItemCode;
}

BOOL CTTOptions::SubmitRQ(IStream* pIStream, short wDataType)
{
	if(m_pDataProxy == NULL)
	{
		AtlTrace(_T("OptionsTab: Can't get DataProxy!\n"));
		return FALSE;
	}
	CComQIPtr<ITTDataProxy> pObj(m_pDataProxy);
	if(pObj == NULL)
	{
		AtlTrace(_T("OptionsTab: Can't get interface ITTDataProxy!\n"));
		return FALSE;
	}	
	
	HRESULT hr = pObj->TranslateQueryFrame(wDataType, pIStream, m_dwID);
	return (hr == S_OK);
}

BOOL CTTOptions::SendUpdateRQ(BOOL bConnect)
{
	if( bConnect )
		m_fBF = 0.0;

	FrameLen    framelen;
	FrameHead	framehead;
	FrameID		frameid;
	unsigned short	wElemType;

	framelen = sizeof(FrameHead) + sizeof(FrameID) + sizeof(short); // +sizeof(char);
	memset(&framehead, 0, sizeof(framehead));
	framehead.wFrameType = 'DO';
	frameid.cbGroupCode = m_cbGroupCode;
	memcpy(frameid.szItemCode,m_szItemCode,G_GENCODELEN);  //���Ƿ���OptionsDO��,��Ȼʹ��Itemcode
	frameid.lTransdate = m_lTransdate;
	wElemType = bConnect ? 'UC' : 'UD';
	CString str;
	str.Format("SendUpdateRQ:%s",m_szItemCode);
	OutputDebugString(str);

	CComPtr<IStream> pIStream;
	CreateStreamOnHGlobal(NULL,TRUE,&pIStream);
	ULARGE_INTEGER size;
	size.QuadPart = framelen + sizeof(framelen);
	pIStream->SetSize(size);
	SeekFromBegin(pIStream, 0);

	HRESULT hr = pIStream->Write(&framelen, sizeof(framelen), NULL);
	hr = pIStream->Write(&framehead, sizeof(framehead), NULL);
	hr = pIStream->Write(&frameid, sizeof(frameid), NULL);
	hr = pIStream->Write(&wElemType, sizeof(wElemType), NULL);
	
	return SubmitRQ(pIStream);
}

BOOL CTTOptions::SendUpdateRP(BOOL bConnect, char *code, long lDate)
{
	FrameLen    framelen;
	FrameHead	framehead;
	FrameID		frameid;
	unsigned short	wElemType;

	framelen = sizeof(FrameHead) + sizeof(FrameID) + sizeof(short); 
	memset(&framehead, 0, sizeof(framehead));
	framehead.wFrameType = 'DP';
	frameid.cbGroupCode = m_cbGroupCode;
	memcpy(frameid.szItemCode,code,G_GENCODELEN);   
	frameid.lTransdate = lDate;
	wElemType = bConnect ? 'UX' : 'UY';

	CComPtr<IStream> pIStream;
	CreateStreamOnHGlobal(NULL,TRUE,&pIStream);
	ULARGE_INTEGER size;
	size.QuadPart = framelen + sizeof(framelen);
	pIStream->SetSize(size);
	SeekFromBegin(pIStream, 0);

	HRESULT hr = pIStream->Write(&framelen, sizeof(framelen), NULL);
	hr = pIStream->Write(&framehead, sizeof(framehead), NULL);
	hr = pIStream->Write(&frameid, sizeof(frameid), NULL);
	hr = pIStream->Write(&wElemType, sizeof(wElemType), NULL);
	
	return SubmitRQ(pIStream, 'DP');
}

BOOL CTTOptions::SendHistoryRI()
{
	FrameLen    framelen;
	FrameHead	framehead;
	FrameID		frameid;
	unsigned short	wElemType;

	framelen = sizeof(FrameHead) + sizeof(FrameID) + sizeof(short) + sizeof(char);
	memset(&framehead, 0, sizeof(framehead));
	framehead.wFrameType = 'DO';
	frameid.cbGroupCode = m_cbGroupCode;
	memcpy(frameid.szItemCode,m_szItemCode,G_GENCODELEN);
	frameid.lTransdate = m_lTransdate;  

	wElemType = 'RQ';

	CComPtr<IStream> pIStream;
	CreateStreamOnHGlobal(NULL,TRUE,&pIStream);
	ULARGE_INTEGER size;
	size.QuadPart = framelen + sizeof(framelen);
	pIStream->SetSize(size);
	SeekFromBegin(pIStream, 0);

	HRESULT hr = pIStream->Write(&framelen, sizeof(framelen), NULL);
	hr = pIStream->Write(&framehead, sizeof(framehead), NULL);
	hr = pIStream->Write(&frameid, sizeof(frameid), NULL);
	hr = pIStream->Write(&wElemType, sizeof(wElemType), NULL);
	BYTE tail = 'I';
	char sz[100] = {0};
	hr = pIStream->Write(&tail, sizeof(tail), NULL);
	
	return SubmitRQ(pIStream);
}

BOOL CTTOptions::SendHistoryRQ()
{
	FrameLen    framelen;
	FrameHead	framehead;
	FrameID		frameid;
	unsigned short	wElemType;

	framelen = sizeof(FrameHead) + sizeof(FrameID) + sizeof(short) + sizeof(char);
	memset(&framehead, 0, sizeof(framehead));
	framehead.wFrameType = 'DO';
	frameid.cbGroupCode = m_cbGroupCode;
	memcpy(frameid.szItemCode,m_szItemCode,G_GENCODELEN);
	frameid.lTransdate = 0;//m_lTransdate;  //andy 2003.02.20 ���������·ݵ����ݡ�
										//ben  2017.9.1�Ļ�����ǰ�����·����¿�

	CString str;
	str.Format("SendHistoryRQ:%s",m_szItemCode);
	OutputDebugString(str);

	wElemType = 'RQ';

	CComPtr<IStream> pIStream;
	CreateStreamOnHGlobal(NULL,TRUE,&pIStream);
	ULARGE_INTEGER size;
	size.QuadPart = framelen + sizeof(framelen);
	pIStream->SetSize(size);
	SeekFromBegin(pIStream, 0);

	HRESULT hr = pIStream->Write(&framelen, sizeof(framelen), NULL);
	hr = pIStream->Write(&framehead, sizeof(framehead), NULL);
	hr = pIStream->Write(&frameid, sizeof(frameid), NULL);
	hr = pIStream->Write(&wElemType, sizeof(wElemType), NULL);
	BYTE tail = 'H';
	hr = pIStream->Write(&tail, sizeof(tail), NULL);
	
	return SubmitRQ(pIStream);
}

BOOL CTTOptions::SendTeleHisCash( char* code )
{
	FrameLen    framelen;
	FrameHead	framehead;
	DSFrameID   dsframeid;

	framelen = sizeof(FrameHead) + sizeof(DSFrameID)+ sizeof(short) + sizeof(char)
		+ sizeof(char) + sizeof(short);
	framehead.wFrameType = 'DS';
	dsframeid.cbGroupCode = m_cbGroupCode;
	
	memcpy(dsframeid.szItemCode,code,G_GENCODELEN); 

	CComPtr<IStream> pIStream;
	HRESULT hr = CreateStreamOnHGlobal(NULL,TRUE,&pIStream);

	ULARGE_INTEGER bigInt;
	bigInt.QuadPart = framelen + sizeof(framelen);
	hr = pIStream->SetSize(bigInt);
	SeekFromBegin(pIStream, 0);	
	hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
	hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
	hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
	unsigned short	wElemType = 'RT';
	hr = pIStream->Write(&wElemType,sizeof(wElemType),NULL);
	const BYTE bHisFlag = 'H';
	hr = pIStream->Write(&bHisFlag, sizeof(bHisFlag), NULL);

	unsigned char cbNum = 1;
	pIStream->Write(&cbNum,sizeof(char),NULL);
	wElemType = 'SN';
	pIStream->Write(&wElemType,sizeof(short),NULL);	
	BOOL bSucc = SubmitRQ(pIStream, 'DS');

	return bSucc;
}

BOOL CTTOptions::SendTeleHisRQ()
{
	FrameLen    framelen;
	FrameHead	framehead;
	DSFrameID dsframeid;

	framelen = sizeof(FrameHead) + sizeof(DSFrameID)+ sizeof(short) + sizeof(char)
		+ sizeof(char) + sizeof(short);
	framehead.wFrameType = 'DS';
	dsframeid.cbGroupCode = m_cbGroupCode;
//	memcpy(dsframeid.szItemCode,m_szItemCode,G_GENCODELEN);
	memcpy(dsframeid.szItemCode,m_szItemCashCode,G_GENCODELEN); //andy modify 20090604 ʹ��cashcode ,����MHI��cashcode��HSI

	CString str;
	str.Format("SendTeleHisRQ1:%s",m_szItemCashCode);
	OutputDebugString(str);

	CComPtr<IStream> pIStream;
	HRESULT hr = CreateStreamOnHGlobal(NULL,TRUE,&pIStream);

	ULARGE_INTEGER bigInt;
	bigInt.QuadPart = framelen + sizeof(framelen);
	hr = pIStream->SetSize(bigInt);
	SeekFromBegin(pIStream, 0);	
	hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
	hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
	hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
	unsigned short	wElemType = 'RT';
	hr = pIStream->Write(&wElemType,sizeof(wElemType),NULL);
	const BYTE bHisFlag = 'H';
	hr = pIStream->Write(&bHisFlag, sizeof(bHisFlag), NULL);

	unsigned char cbNum = 1;
	pIStream->Write(&cbNum,sizeof(char),NULL);
	wElemType = 'SN';
	pIStream->Write(&wElemType,sizeof(short),NULL);	
	BOOL bSucc = SubmitRQ(pIStream, 'DS');

//	ATLTRACE("SendTeleHisRQ : DS-RT %s\r\n",m_szItemCashCode);

	// send 'DS' history request for future item
	MakeFutCode(m_szFuturesCode,m_szFuturesTitle,m_lTransdate % 100, (m_lTransdate/100)%100);
	memcpy(dsframeid.szItemCode,m_szFuturesCode,G_GENCODELEN);

	str.Format("SendTeleHisRQ2:%s",m_szFuturesCode);
	OutputDebugString(str);

	SeekFromBegin(pIStream, 0);
	hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
	hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
	hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
	wElemType = 'RT';
	hr = pIStream->Write(&wElemType,sizeof(short),NULL);
	hr = pIStream->Write(&bHisFlag,sizeof(char),NULL);
	hr = pIStream->Write(&cbNum,sizeof(char),NULL);
	wElemType = 'SN';
	hr = pIStream->Write(&wElemType,sizeof(short),NULL);	
	bSucc = SubmitRQ(pIStream, 'DS');


	if( IsIndex() )
	{
		memcpy(dsframeid.szItemCode,m_szFuturesNightCode,G_GENCODELEN);

		str.Format("SendTeleHisRQ3:%s",m_szFuturesNightCode);
	OutputDebugString(str);
		
		SeekFromBegin(pIStream, 0);
		hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
		hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
		hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
		wElemType = 'RT';
		hr = pIStream->Write(&wElemType,sizeof(short),NULL);
		hr = pIStream->Write(&bHisFlag,sizeof(char),NULL);
		hr = pIStream->Write(&cbNum,sizeof(char),NULL);
		wElemType = 'SN';
		hr = pIStream->Write(&wElemType,sizeof(short),NULL);	
		bSucc = SubmitRQ(pIStream, 'DS');         //night futures
	}

	//
	memcpy(dsframeid.szItemCode,m_szVHSICode,G_GENCODELEN);
	str.Format("SendTeleHisRQ4:%s",m_szVHSICode);
	OutputDebugString(str);

	SeekFromBegin(pIStream, 0);
	hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
	hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
	hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
	wElemType = 'RT';
	hr = pIStream->Write(&wElemType,sizeof(short),NULL);
	hr = pIStream->Write(&bHisFlag,sizeof(char),NULL);
	hr = pIStream->Write(&cbNum,sizeof(char),NULL);
	wElemType = 'SN';
	hr = pIStream->Write(&wElemType,sizeof(short),NULL);	
	bSucc = SubmitRQ(pIStream, 'DS');

//	ATLTRACE("SendTeleHisRQ : DS-RT %s\r\n",m_szFuturesCode);
	return bSucc;
}

BOOL CTTOptions::SendTeleUpdateRQ(BOOL bConnect)
{
	FrameLen    framelen;
	FrameHead	framehead;
	DSFrameID   dsframeid;

	framelen = sizeof(FrameHead) + sizeof(DSFrameID)+ sizeof(short) + sizeof(char)
		+ sizeof(char); // + sizeof(short);
	framehead.wFrameType = 'DS';
	dsframeid.cbGroupCode = m_cbGroupCode;
//  memcpy(dsframeid.szItemCode,m_szItemCode,G_GENCODELEN);
	memcpy(dsframeid.szItemCode,m_szItemCashCode,G_GENCODELEN);   //andy modify 20090604 ʹ��cashcode ,����MHI��cashcode��HSI

	CComPtr<IStream> pIStream;
	HRESULT hr = CreateStreamOnHGlobal(NULL,TRUE,&pIStream); 

	ULARGE_INTEGER bigInt;
	bigInt.QuadPart = framelen + sizeof(framelen);
	hr = pIStream->SetSize(bigInt);
	SeekFromBegin(pIStream, 0);
	hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
	hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
	hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
	const WORD	wRT = 'RT';
	hr = pIStream->Write(&wRT,sizeof(wRT),NULL);
	//unsigned short wElemType = bConnect ? 'UC' : 'UD';
	unsigned short wElemType = bConnect ? 'CU' : 'DU';  //trans�����Э��������,��������Ҳ�ķ� andy2009.06.04
	hr = pIStream->Write(&wElemType, sizeof(wElemType), NULL);
	BOOL bSucc = SubmitRQ(pIStream, 'DS');   /////////cash

	ATLTRACE("SendTeleUpdateRQ : DS-%d %s\r\n",bConnect,m_szItemCashCode);

	// send 'DS' update request for future item
	MakeFutCode(m_szFuturesCode,m_szFuturesTitle,m_lTransdate % 100, (m_lTransdate/100)%100);
	memcpy(dsframeid.szItemCode,m_szFuturesCode,G_GENCODELEN);

	SeekFromBegin(pIStream, 0);
	hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
	hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
	hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
	hr = pIStream->Write(&wRT,sizeof(wRT),NULL);
	hr = pIStream->Write(&wElemType,sizeof(wElemType),NULL);
	bSucc = SubmitRQ(pIStream, 'DS');     ////////futures

	if( IsIndex() )
	{
		memcpy(dsframeid.szItemCode,m_szFuturesNightCode,G_GENCODELEN);
		
		SeekFromBegin(pIStream, 0);
		hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
		hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
		hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
		hr = pIStream->Write(&wRT,sizeof(wRT),NULL);
		hr = pIStream->Write(&wElemType,sizeof(wElemType),NULL);
		bSucc = SubmitRQ(pIStream, 'DS');  /////////night furutes

	}


	memcpy(dsframeid.szItemCode,m_szVHSICode,G_GENCODELEN);

	SeekFromBegin(pIStream, 0);
	hr = pIStream->Write(&framelen,sizeof(FrameLen),NULL);
	hr = pIStream->Write(&framehead,sizeof(FrameHead),NULL);
	hr = pIStream->Write(&dsframeid,sizeof(DSFrameID),NULL);
	hr = pIStream->Write(&wRT,sizeof(wRT),NULL);
	hr = pIStream->Write(&wElemType,sizeof(wElemType),NULL);
	bSucc = SubmitRQ(pIStream, 'DS');
	
	ATLTRACE("SendTeleUpdateRQ : DS-%d %s\r\n",bConnect,m_szFuturesCode);

	return bSucc;
}

BOOL CTTOptions::GetText(LPTSTR pszText, float fValue, unsigned char cbDecimal,BOOL bCab,BOOL bThoery)
{
	if(bCab)
	{
		if(bThoery)
			lstrcpy(pszText,_T("  Cab*"));
		else
			lstrcpy(pszText,_T("  Cab "));
		return TRUE;
	}
	if(cbDecimal < 0 || pszText == NULL )
		return FALSE;
	if(fabs(fValue + 1.0) < 0.0001)
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}
	else if(fabs(fValue) < 0.0001)
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}
	switch(cbDecimal)
	{
	case 0:
		if(bThoery)
			_stprintf(pszText,_T("%.0f*"),fValue);
		else
			_stprintf(pszText,_T("%.0f "),fValue);
		break;
	case 1:
		if(bThoery)
			_stprintf(pszText,_T("%.1f*"),fValue);
		else
			_stprintf(pszText,_T("%.1f "),fValue);
		break;
	case 2:
		if(bThoery)
			_stprintf(pszText,_T("%.2f*"),fValue);
		else
			_stprintf(pszText,_T("%.2f "),fValue);
		break;
	case 3:
		if(bThoery)
			_stprintf(pszText,_T("%.3f*"),fValue);
		else
			_stprintf(pszText,_T("%.3f "),fValue);
		break;
	case 4:
		if(bThoery)
			_stprintf(pszText,_T("%.4f*"),fValue);
		else
			_stprintf(pszText,_T("%.4f "),fValue);
		break;
	default:
		lstrcpy(pszText,_T(""));
		break;
	}
	return TRUE;
}

BOOL CTTOptions::GetTextEx(LPTSTR pszText, float fValue, BYTE cbDecimal)
{
	
	if(cbDecimal < 0 || pszText == NULL )
		return FALSE;
	if(fabs(fValue + 1.0) < 0.0001)
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}
	else if(fabs(fValue) < 0.0001)
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}

	DWORD	hibyte = 0;
	HANDLE hFile;
		

	switch(cbDecimal)
	{
	case 0:
//		_stprintf(pszText,_T("%.0f"),fValue);
		_stprintf(pszText,_T("%.0f "),fValue);
		break;
	case 1:
//		_stprintf(pszText,_T("%.1f"),fValue);
		_stprintf(pszText,_T("%.1f "),fValue);
		break;
	case 2:
		_stprintf(pszText,_T("%.2f "),fValue);
		break;
	case 3:
		_stprintf(pszText,_T("%.3f "),fValue);    
		break;
	case 4:
		_stprintf(pszText,_T("%.4f "),fValue);
		break;
	default:
		lstrcpy(pszText,_T(""));
		break;
	}
	return TRUE;
}

BOOL CTTOptions::GetTextOI(LPTSTR pszText, float fValue,float fStrike,BOOL bCall)
{
	if( pszText==NULL )
		return FALSE;

	if( fValue==0.0 )
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}
	else if( m_arrPreOI.GetSize()==0  )
	{
		_stprintf(pszText,_T("%.0f "),fValue);
		return TRUE;
	}

	int i;
	for( i=0;i<m_arrPreOI.GetSize();i++ )
	{
		if( fStrike==m_arrPreOI[i].m_fStrike )
			break;
	}
	if( i==m_arrPreOI.GetSize() )
	{
		_stprintf(pszText,_T("%.0f "),fValue);
		return TRUE;
	}

	if( bCall )
	{
		CString str;
		float fDiff;
		fDiff = fValue-m_arrPreOI[i].m_fPre_CallOI;
	//	m_fCallOIDiff[i] = fDiff;
		str.Format("%.0f",fDiff);
		if( fDiff>0 )
			str = "+"+str;
		for( i=str.GetLength();i<5;i++ )
			str = " "+str;
		_stprintf(pszText,_T("%.0f (%s)"),fValue,str);
	}
	else
	{
		CString str;
		float fDiff;
		fDiff = fValue-m_arrPreOI[i].m_fPre_PutOI;
	//	m_fPutOIDiff[i] = fDiff;
		str.Format("%.0f",fDiff);
		if( fDiff>0 )
			str = "+"+str;
		for( i=str.GetLength();i<5;i++ )
			str = " "+str;
		_stprintf(pszText,_T("%.0f (%s)"),fValue,str);
	}

	//WriteLogFile(pszText);

	return TRUE;
}

BOOL CTTOptions::GetTextIV(LPTSTR pszText, float fValue, BYTE cbDecimal)
{
	
	if(cbDecimal < 0 || pszText == NULL )
		return FALSE;
	if(fabs(fValue + 1.0) < 0.0001)
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}
	else if(fabs(fValue) < 0.0001)
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}
	switch(cbDecimal)
	{
	case 0:
//		_stprintf(pszText,_T("%.0f"),fValue);
		_stprintf(pszText,_T("%.0f"),fValue);
		break;
	case 1:
//		_stprintf(pszText,_T("%.1f"),fValue);
		_stprintf(pszText,_T("%.1f"),fValue);
		break;
	case 2:
		_stprintf(pszText,_T("%.2f"),fValue);
		break;
	case 3:
		_stprintf(pszText,_T("%.3f"),fValue);
		break;
	case 4:
		_stprintf(pszText,_T("%.4f"),fValue);
		break;
	default:
		lstrcpy(pszText,_T("0.0"));
		break;
	}
	return TRUE;
}

BOOL CTTOptions::GetTextVega(LPTSTR pszText, float fValue, BYTE cbDecimal)  //20170405 Ben  Vega��theta����
{ //vega=���<1,���@ʾС����4λ��>1���@ʾС����2λ;
	
	if(cbDecimal < 0 || pszText == NULL )
		return FALSE;
	if(fabs(fValue + 1.0) < 0.0001)
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}
	else if(fabs(fValue) < 0.0001)
	{
		lstrcpy(pszText,_T(""));
		return TRUE;
	}

	if(fabs(fValue)<1.0)
		cbDecimal = 4;
	else
		cbDecimal = 2;

	switch(cbDecimal)
	{
	case 0:
//		_stprintf(pszText,_T("%.0f"),fValue);
		_stprintf(pszText,_T("%.0f "),fValue);
		break;
	case 1:
//		_stprintf(pszText,_T("%.1f"),fValue);
		_stprintf(pszText,_T("%.1f "),fValue);
		break;
	case 2:
		_stprintf(pszText,_T("%.2f "),fValue);
		break;
	case 3:
		_stprintf(pszText,_T("%.3f "),fValue);
		break;
	case 4:
		_stprintf(pszText,_T("%.4f "),fValue);
		break;

	default:
		lstrcpy(pszText,_T(""));
		break;
	}
	return TRUE;
}

void CTTOptions::OnSelectHighPrice()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
	if(m_bShowHighPrice == 1)
		m_bShowHighPrice = 0;
	else
		m_bShowHighPrice = 1;

	m_pList1->ShowHighPrice(m_bShowHighPrice);	

	UpdateTitle();
	
	ResizeHeaderCtrl();  //ȷ���ⲿ��ͷ���¼������      Keeping  2014-11-7
	OnLstHScr(); //ʹ�ⲿ��ͷ��λ�ø���CListCtrl��λ�ñ仯     Keeping   2011-11-11
	
	
}

BOOL  CTTOptions::IsIndex()
{
	if( memcmp(m_szItemCode,"HSI    ",7)==0 
		|| memcmp(m_szItemCode,"HSCEI  ",7)==0 
		|| memcmp(m_szItemCode,"MHI    ",7)==0 
		|| memcmp(m_szItemCode,"MCH    ",7)==0 )
		return TRUE;

	return FALSE;
}

BOOL CTTOptions::HaveFutures(char *code, long lExpiry)
{
	if( memcmp(code,"HSI    ",7)!=0 
		&& memcmp(code,"HSCEI  ",7)!=0 
		&& memcmp(code,"MHI    ",7)!=0 
		&& memcmp(code,"MCH    ",7)!=0 )
	{
		return TRUE;
	}

	long lDate = lExpiry/100;
	unsigned short sMonth;
	unsigned short sSeason = 0;
	int nMonths = m_lstMonths.GetCount();
	POSITION pos = m_lstMonths.GetHeadPosition();
	for(int i = 0; i < nMonths; i++)
	{
		LONG theMonth = m_lstMonths.GetNext(pos);
		if( i<2 && theMonth==lDate )
		{
			return TRUE;
		}
		else if( i>=2 )
		{
			sMonth = theMonth%100;
			if( sMonth%3==0 )
			{
				sSeason++;
				if( lDate==theMonth && sSeason<=2 )
				{
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

void CTTOptions::PopMenu()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 

	CMenu menu; 
	CRect rect;
	m_pbtnStra->GetWindowRect(&rect);
	menu.LoadMenu(IDR_MENU2); 
	CMenu   *pContextMenu=menu.GetSubMenu(0); 
	pContextMenu->ModifyMenu(IDC_MENU_STGY,MF_BYCOMMAND|MF_STRING,IDC_MENU_STGY,szModeStgy[m_iLangType]);
	pContextMenu->ModifyMenu(IDC_MENU_PAIN,MF_BYCOMMAND|MF_STRING,IDC_MENU_PAIN,szModePain[m_iLangType]);
	RECT rect1;
	rect1.left = rect.left;
	rect1.right = rect.right;
	rect1.top = rect.top;
	pContextMenu->TrackPopupMenu(TPM_LEFTALIGN,rect.left,rect.bottom,m_pbtnStra,&rect1);
}

void CTTOptions::OnSelectStrategy()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 

	if( m_pwndCls==NULL )
	{
		m_pwndCls = new CStrategy();
		m_pwndCls->m_TTOptions = this;
		m_pwndCls->Create(IDD_STRATEGY);
		m_pwndCls->ShowWindow(SW_SHOW);
	}
	else if( !m_pwndCls->IsWindowVisible() )
		m_pwndCls->ShowWindow(SW_SHOW);

	if( m_nDataTotal==0 || m_pwndCls->m_bDrawing )
	{
		m_pwndCls->m_nRetn = 0;
		return;
	}

	if( m_bChanged )
		m_pwndCls->m_bMode = m_bStgyMode;

	if( m_bStgyMode==1 )
		m_pwndCls->OnModePain();

	m_pwndCls->m_nRetn = m_pwndCls->PrePaint();
	if( m_pwndCls->m_nRetn==0 )
		return;

	CString str;
	str = szCaption[int(m_pwndCls->m_bMode)*3+m_iLangType];
	str +="(";
	str += m_szItemCode;
	str += ")";
	m_pwndCls->SetWindowText(str);
	
	RECT frmrect;
	m_pwndCls->m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);

	m_pwndCls->SetListMode();
	if( m_bChanged && !m_pwndCls->m_bUseRecord )
	{
		m_pwndCls->m_nIxStrike = -1;
		m_pwndCls->m_nIxStrike2 = -1;
		m_pwndCls->m_nIxStrike3 = -1;
		m_pwndCls->m_nIxStrike4 = -1;
		m_pwndCls->m_nIxStrike5 = -1;
		m_pwndCls->m_nIxStrike6 = -1;
		m_pwndCls->m_bUseRecord = FALSE;
		for( int i=0;i<6;i++ )
		{
			m_pwndCls->m_bAlterPrice[i] = FALSE;
			m_pwndCls->m_bAlterPrice2[i] = FALSE;
		}
	}
	if( m_pwndCls->m_nIxStrike==-1&&m_pwndCls->m_nIxStrike2==-1
		&&m_pwndCls->m_nIxStrike3==-1&&m_pwndCls->m_nIxStrike4==-1
		&&m_pwndCls->m_nIxStrike5==-1&&m_pwndCls->m_nIxStrike6==-1)
	{
		m_pwndCls->SelectType();
		m_pwndCls->ClearFlag();
	}
	else
	{
		m_pwndCls->SelectType();
	}
	m_pwndCls->InitDays();
	if( m_pwndCls->m_bMode!=1 )
	{
		if( m_bChanged )
			m_pwndCls->OnModeStgy();

		m_pwndCls->DrawIncomeLine();
	}
	else
	{
		m_pwndCls->Invalidate();
	}

	
	m_bChanged = FALSE;
}

void CTTOptions::OnSelectColumnWidth()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
	
	if(m_bIVMode == 0 || m_bIVMode == 4 || m_bIVMode == 5) 
		m_pList1->AdjustColumnWidth(); //����ģʽ�µ����п�
	else if(m_bIVMode == 1 || m_bIVMode == 3) 
		m_pList1->AdjustColumnWidthIVMode();
	else if(m_bIVMode == 2) 
		m_pList1->AdjustColumnWidthPBMode();

	OnLstHScr(); //ʹ�ⲿ��ͷ��λ�ø���CListCtrl��λ�ñ仯     Keeping   2011-11-11
}

void CTTOptions::OnSelectModeMenu()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 

	if( m_bIVMode==2 )
	{
		m_pbtnHighPrice->EnableWindow(FALSE);  //��ֹ ����ʾ�ߵ͡� ��ť���ռ����������
		CalcAllIVData();
	}
	else if(m_bIVMode == 0)
	{
		m_pbtnHighPrice->EnableWindow(TRUE);  //���� ����ʾ�ߵ͡� ��ť���ռ����������
	
	}
	else if( m_bIVMode==1 || m_bIVMode==3 )
	{
		m_pbtnHighPrice->EnableWindow(FALSE);  //��ֹ ����ʾ�ߵ͡� ��ť���ռ����������
		
		CalcAllIVData();

		if( m_bSimple==1 )
		{
			int iNum = ClosestCashNum();
			m_pList1->SelectSimpleMode(m_bSimple, iNum);
		}
	}
	else if( m_bIVMode==4 || m_bIVMode==5 )
	{
		m_pbtnHighPrice->EnableWindow(FALSE);
	}

	UpdateListHearTitle();

	m_pList1->SelectIVMode(m_bIVMode);

	ResizeHeaderCtrl();  //ȷ���ⲿ��ͷ���¼������      Keeping  2014-11-7
	OnLstHScr(); //ʹ�ⲿ��ͷ��λ�ø���CListCtrl��λ�ñ仯     Keeping   2011-11-11
}

void CTTOptions::OnSelectIVMode()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 

	

	char *szNormal[3] = {"Normal","����ģʽ","���`�Ҧ�"};
	char *szIV[3] = {"IV Mode","IVģʽ","IV�Ҧ�"};
	char *szPB[3] = {"PB Mode","���ʷ���","���v���t"};
	char *szGreeks = "Greeks";
	char *szOI[] = {"OI Mode","δƽ�ֺ�Լ","�����ܦX��"};
	char *szMargin[] = {"Margin", "����", "����"};

	CMenu   menu; 
	CRect rect;
	m_pbtnIVMode->GetWindowRect(&rect);
	menu.LoadMenu(IDR_MENU3); 
	CMenu   *pContextMenu=menu.GetSubMenu(0); 
	pContextMenu->ModifyMenu(IDC_MENU_NORMAL,MF_BYCOMMAND|MF_STRING,IDC_MENU_NORMAL,szNormal[m_iLangType]);
	pContextMenu->ModifyMenu(IDC_MENU_IV,MF_BYCOMMAND|MF_STRING,IDC_MENU_IV,szIV[m_iLangType]);
	pContextMenu->ModifyMenu(IDC_MENU_PB,MF_BYCOMMAND|MF_STRING,IDC_MENU_PB,szPB[m_iLangType]);
	pContextMenu->ModifyMenu(IDC_MENU_GK,MF_BYCOMMAND|MF_STRING,IDC_MENU_GK,szGreeks);
	pContextMenu->ModifyMenu(IDC_MENU_OI,MF_BYCOMMAND|MF_STRING,IDC_MENU_OI,szOI[m_iLangType]);
	pContextMenu->ModifyMenu(IDC_MENU_MG,MF_BYCOMMAND|MF_STRING,IDC_MENU_MG,szMargin[m_iLangType]);
	RECT rect1;
	rect1.left = rect.left;
	rect1.right = rect.right;
	rect1.top = rect.top;
	pContextMenu->TrackPopupMenu(TPM_LEFTALIGN,rect.left,rect.bottom,m_pbtnIVMode,&rect1);

	/*
	if( m_bIVMode==1 )
	{
		m_pbtnHighPrice->EnableWindow(FALSE);  //��ֹ ����ʾ�ߵ͡� ��ť���ռ����������
		CalcAllIVData();
		m_bIVMode = 2;
	}
	else if(m_bIVMode == 2)
	{
		m_pbtnHighPrice->EnableWindow(TRUE);  //���� ����ʾ�ߵ͡� ��ť���ռ����������

		m_bIVMode = 0;		
	}
	else if( m_bIVMode==0 )
	{
		m_pbtnHighPrice->EnableWindow(FALSE);  //��ֹ ����ʾ�ߵ͡� ��ť���ռ����������
		
		m_bIVMode = 1;
		CalcAllIVData();

		if( m_bSimple==1 )
		{
			int iNum = ClosestCashNum();
			m_pList1->SelectSimpleMode(m_bSimple, iNum);
		}
	}

	UpdateListHearTitle();

	m_pList1->SelectIVMode(m_bIVMode);

	ResizeHeaderCtrl();  //ȷ���ⲿ��ͷ���¼������      Keeping  2014-11-7
	OnLstHScr(); //ʹ�ⲿ��ͷ��λ�ø���CListCtrl��λ�ñ仯     Keeping   2011-11-11
	*/
}

void CTTOptions::OnStgyDbClick(char* ItemCode, long lTransdate)
{	
	if( memcmp(ItemCode,m_szItemCode,8)!=0 || lTransdate!=m_lTransdate )
	{
		BOOL bFind = FALSE;
		char szItemCode[9];
		char szItemName[31];
		memset(szItemCode,0,sizeof(szItemCode));
		memset(szItemName,0,sizeof(szItemName));
		
		memcpy(szItemCode,ItemCode,8);
		
		char fbuff[MAX_PATH];
		sprintf( fbuff, "%sdata\\hkstock2.occ", m_szRootPath );
		HANDLE hFile = CreateFile(fbuff,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if(hFile == INVALID_HANDLE_VALUE)
		{
			return ;
		}
		g_txtoccheadS txthead;
		g_txtoccS      txt;
		DWORD dwTm;
		
		if(ReadFile(hFile,&txthead,sizeof(g_txtoccheadS),&dwTm,NULL) !=0 &&
			txthead.id == G_TXTOCCFILEID&&txthead.reserved == 0x1A)
		{
			for(int i = 0; i< txthead.numitem; i++)
			{
				if(!ReadFile(hFile,&txt,sizeof(g_txtoccS),&dwTm,NULL))
				{
					CloseHandle(hFile);
					return ;
				}
				
				if(memcmp(txt.itemcode,szItemCode,8) == 0)
				{
					bFind = TRUE;
					
					if(m_pGrpMng == NULL)
						return ;				
					CComQIPtr< ITTGroupsMng,&IID_ITTGroupsMng> pGrp(m_pGrpMng);
					if(pGrp == NULL)
						return ;
					
					long lID;
					pGrp-> FindItem('A',(BYTE*)szItemCode,&lID);
					TCHAR szName[30];
					if( m_iLangType==0 )
						pGrp->GetItemPara(lID,ItemID_Lang1Descrip,(BYTE*)szItemName,30);
					else
						if( m_iLangType==1 )
							pGrp->GetItemPara(lID,ItemID_Lang3Descrip,(BYTE*)szItemName,30);
						else
							if( m_iLangType==2 )
								pGrp->GetItemPara(lID,ItemID_Lang2Descrip,(BYTE*)szItemName,30);
							
							break;					
				}
				
			}//end of for				
		}//end of if		
		CloseHandle(hFile);
		
		
		if(bFind == TRUE)
		{
			SendEndFrame();  
			m_lTransdate = lTransdate;
			memset(m_szItemCode,0,sizeof(m_szItemCode));
			memcpy(m_szItemCode,txt.itemcode,8);
			
			memset(m_szFuturesTitle,0,sizeof(m_szFuturesTitle));
			memcpy(m_szFuturesTitle,txt.fcode,6);

			memset(m_szOptCode,0,sizeof(m_szOptCode));
			memcpy(m_szOptCode,txt.optcode,5);
			
			memset(m_szItemCashCode,0,sizeof(m_szItemCashCode));
			memcpy(m_szItemCashCode,txt.cashitemcode,8);
			
			MakeFutCode(m_szFuturesCode,m_szFuturesTitle,
				m_lTransdate % 100, (m_lTransdate/100)%100);
			TCHAR szCode[9];
			memcpy(szCode,m_szItemCode,8);
			szCode[8] = 0;
			ResetFrmTitle() ;
			lstrcpy(m_szItemName,szItemName);
			
			GetExpiryTime();
			UpdateTitle() ;
			m_pedtCash->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
			m_pedtFutures->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
			m_pedtVHSI->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
			sprintf(m_szText, "%2d/%4d",m_lTransdate%100,m_lTransdate/100);
			m_pbtnOptMonth->SetWindowText(m_szText);	//modify

			ClearData(); 
			SaveValue() ;
			GetDvdInfo();
			
			m_pbtnOptMonth->ShowWindow(SW_HIDE);
			m_pstaExpiryDate->ShowWindow(SW_HIDE);
			
			SendMonthRequestFrame();
			SendRequestFrame();
		}
	}
	
}

void CTTOptions::RefreshFile()
{
	GetMarginTxt();

	int iNum = ClosestCashNum();
	if( m_bSimple==1 )
	{
		m_pList1->SelectSimpleMode(m_bSimple, iNum);
	}
	else
		m_pList1->PostMessage(MACRO_MsgRedrawItem, (WPARAM)0xFFFFFFFE, 0);
}

int CTTOptions::ClosestCashNum()
{
	m_bCash = FALSE;
	float fCash;
	if( IsIndex() )
		fCash = GetCorrStockPrice(FALSE,1);
	else
		fCash = GetCorrStockPrice();
	if( fCash==0.0 )
		return -1;

	int iPos = -1;
	for( int i=0;i<m_nDataTotal;i++ )
	{
		if( m_pDataBuf[i].m_fStrike>fCash )
		{
			iPos = i;
			m_nDivision = i;
			break;
		}
	}
	if( iPos==0 || iPos==-1)
		return iPos;
	int res = ( (m_pDataBuf[iPos].m_fStrike-fCash)<=(fCash-m_pDataBuf[iPos-1].m_fStrike) )? iPos:iPos-1;
	return res;
}

void CTTOptions::OnSelectSimple()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 

	if( m_bSimple==1 )
	{
		m_bSimple = 0;
	}
	else
	{
		m_bSimple = 1;
	}

	if(m_bIVMode == 1)
	{
		CalcAllIVData();
	}
	
	UpdateTitle();
	
	int iNum = ClosestCashNum();
	

	m_pList1->SelectSimpleMode(m_bSimple, iNum);
}

void CTTOptions::OnSelectExportCSV()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
	
	char fbuff[MAX_PATH];
	sprintf( fbuff, "%sdata\\Options.csv", m_szRootPath );

	CFileDialog dlg(FALSE, "csv", NULL,
	OFN_OVERWRITEPROMPT|OFN_HIDEREADONLY,
	"CSV File(*.csv)|*.csv||", NULL);
	dlg.m_ofn.lpstrTitle = _T("Export to CSV file");
	dlg.m_ofn.lpstrInitialDir = m_szRootPath;
	if (dlg.DoModal() == IDOK)
	{
		CString fileName = dlg.GetPathName();
		ExportToExcel((char*)(LPCTSTR)fileName);
	}

}


BYTE CTTOptions::ExportToExcel(char* pszFilePath)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	FILE *f = fopen ( (const char*)pszFilePath , "wb");	
	if( f==NULL )
	{
		return S_FALSE;
	}

	DWORD dwt1 = GetTickCount();

	BYTE* lptstrCopy = new BYTE[MEMSIZE];

	long pos = 0;
	//����
	DWORD dwFX,dwHK;
	char  szBuff[20];
	int   nYear ;
	CString str,szrf = "\r\n";
	CString strComma = ",";
	char*  szRpDate[]={"Date:  ","����:  ","���:  "};
	char*  szFXDate[]={"Itemcode:  ","��Ȩ����:  ","���v�N�X:  "};
	char*  szHKDate[]={"Month:    ","�·�:  ","���:  "};
	char*  szExpDate[]={"Remaining Days:    ","ʣ�ൽ������:  ","�Ѿl������:  "};

	dwFX = m_lTransdate;
	dwHK = m_lTransdate;

	//date
	memcpy( (BYTE*)lptstrCopy+pos, szRpDate[m_iLangType], strlen(szRpDate[m_iLangType]) ); 
	pos += strlen(szRpDate[m_iLangType]);
	
	SYSTEMTIME now;
	GetLocalTime(&now);
	sprintf( szBuff,"%04d-%02d-%02d", now.wYear,now.wMonth,now.wDay);
	memcpy( (BYTE*)lptstrCopy+pos, szBuff, strlen(szBuff) ); 
	pos += strlen(szBuff);
	memcpy( (BYTE*)lptstrCopy+pos, (const void*)LPCTSTR(szrf), 2 ); 
	pos += 2;

	fwrite(lptstrCopy,pos,1,f);
	pos = 0;	

	//fx
	memcpy( (BYTE*)lptstrCopy+pos, szFXDate[m_iLangType], strlen(szFXDate[m_iLangType]) ); 
	pos += strlen(szFXDate[m_iLangType]);
	nYear = dwFX/10000;
	sprintf( szBuff,"%s %s", m_szItemCode ,m_szItemName);
	memcpy( (BYTE*)lptstrCopy+pos, szBuff, strlen(szBuff) ); 
	pos += strlen(szBuff);
	memcpy( (BYTE*)lptstrCopy+pos, (const void*)LPCTSTR(szrf), 2 ); 
	pos += 2;

	fwrite(lptstrCopy,pos,1,f);
	pos = 0;

	//hk
	memcpy( (BYTE*)lptstrCopy+pos, szHKDate[m_iLangType], strlen(szHKDate[m_iLangType]) ); 
	pos += strlen(szHKDate[m_iLangType]);	
	sprintf( szBuff,"%06d ", m_lTransdate);
	memcpy( (BYTE*)lptstrCopy+pos, szBuff, strlen(szBuff) ); 
	pos += strlen(szBuff);
	
	memcpy( (BYTE*)lptstrCopy+pos, szExpDate[m_iLangType], strlen(szExpDate[m_iLangType]) ); 
	pos += strlen(szExpDate[m_iLangType]);	
	sprintf( szBuff,"%d ", m_lExpiryDays);
	memcpy( (BYTE*)lptstrCopy+pos, szBuff, strlen(szBuff) ); 
	pos += strlen(szBuff);

	memcpy( (BYTE*)lptstrCopy+pos, (const void*)LPCTSTR(szrf), 2 ); 
	pos += 2;

	fwrite(lptstrCopy,pos,1,f);
	pos = 0;

	//
	CString szCall;
	if(m_bIVMode == 0 || m_bIVMode==4 || m_bIVMode==5)
		szCall =  ",,,,Call,,,,,,,,,,,Put,,";
	else if( m_bIVMode==1 || m_bIVMode==3 )
		szCall =  ",,,,,,,Call,,,,,,,,,,,,,,,,,,Put,,";
	else if( m_bIVMode==2 )
		szCall =  ",,,Call,,,,,,,,Put,,,";
		

	memcpy( (BYTE*)lptstrCopy+pos, (const void*)LPCTSTR(szCall), szCall.GetLength() ); 
	pos += szCall.GetLength();
	memcpy( (BYTE*)lptstrCopy+pos, (const void*)LPCTSTR(szrf), 2 ); 
	pos += 2;
	fwrite(lptstrCopy,pos,1,f);
	pos = 0;

	//title
	static CString szTitle[3] = {
	"O/I,I/D, High, Low, Vol, L.Qty,Last, B.Qty, Bid, Ask, A.Qty, Strike, B.Qty, Bid, Ask, A.Q,  Last, L.Qty,  Vol,High, Low, O/I,I/D",
	"δƽ,����,���,���,����,����,�ɼ�, ����,����, ����, ����, ��ʹ��,����, ����,����,����,�ɼ�,����,����,���,���,δƽ,����",
	"����,�W��,�̰�,�̧C,�`��,���i,����, �R�i,�R�J, ��X, ��i,��ϻ�, �R�i, �R�J,��X,��i,����,���i,�`��,�̰�,�̧C,����,�W��"	
	};

	static CString szTitleMG[3] = {
	"O/I,I/D,Margin, High, Low, Vol, L.Qty,Last, B.Qty, Bid, Ask, A.Qty, Strike, B.Qty, Bid, Ask, A.Q,  Last, L.Qty,  Vol,High, Low, Margin, O/I,I/D",
	"δƽ,����,����(��),���,���,����,����,�ɼ�, ����,����, ����, ����, ��ʹ��,����, ����,����,����,�ɼ�,����,����,���,���,����(��),δƽ,����",
	"����,�W��,����(��),�̰�,�̧C,�`��,���i,����, �R�i,�R�J, ��X, ��i,��ϻ�, �R�i, �R�J,��X,��i,����,���i,�`��,�̰�,�̧C,����(��),����,�W��"	
	};

	/*static CString szTitle[3] = {
	"O/I, High, Low, B.Qty, Bid, Ask, A.Qty, Vol, L.Qty,Last , Strike, Last, L.Qty,Vol,B.Qty, Bid, Ask, A.Q,High, Low,O/I ",
	"δƽ,���,���,����,����,����, ����,����,����, �ɼ�, ��ʹ��,�ɼ�,����,����,����,����,����,����,���,���,δƽ",
	"����,�̰�,�̧C,�R�i,�R�J,��X, ��i,�`��,���i,����,��ϻ�,����,���i,�`��, �R�i, �R�J,��X,��i,�̰�,�̧C,����"
	};*/

	static CString szTitleIV[3] = {
	"O/I,I/D, High, Low, Vol, Vega,Theta,Gamma,Delta,L.Qty, Last,Last IV, B.Qty, Bid,Bid IV,Ask IV, Ask, A.Qty, Strike,"
	" B.Qty, Bid,Bid IV, Ask IV,Ask, A.Q,  Last,Last IV, L.Qty,Delta,Gamma,Theta,Vega,  Vol, High, Low, O/I,I/D" ,
	"δƽ,����,���,���,����,Vega,Theta,Gamma,Delta,����,�ɼ�,�ɼ۲���, ����,����,���벨��, ��������, ����, ����,��ʹ��,"
	" ����, ����,���벨��, ��������,����,����,�ɼ�,�ɼ۲���,����,Delta,Gamma,Theta,Vega,����,���,���,δƽ,����" ,
	"����,�W��,�̰�,�̧C,�`��,Vega,Theta,Gamma,Delta,���i,����,�����i�T, �R�i,�R�J,�R�J�i�T, ��X�i�T, ��X, ��i,��ϻ�,"
	" �R�i, �R�J,�R�J�i�T, ��X�i�T,��X,��i,����,�����i�T,���i,Delta,Gamma,Theta,Vega,�`��,�̰�,�̧C,����,�W��" 
	};
	//P.touchȥ�� ֮�󻻰���
	static CString szTitlePB[3] = {
	"Margin,Prob.ITM,Vega,Theta,Gamma,Delta, Last,Last IV, Strike,Last,Last IV,Delta,Gamma,Theta,Vega,Prob.ITM,Margin" ,
	"����(��),Prob.ITM,Vega,Theta,Gamma,Delta,�ɼ�,�ɼ۲���, ��ʹ��,�ɼ�,�ɼ۲���,Delta,Gamma,Theta,Vega,Prob.ITM,����(��)" ,
	"����(��),Prob.ITM,Vega,Theta,Gamma,Delta,����,�����i�T, ��ϻ�,����,�����i�T,Delta,Gamma,Theta,Vega,Prob.ITM,����(��)" 
	};

	if(m_bIVMode == 0 || m_bIVMode==4)
	{
		memcpy( (BYTE*)lptstrCopy+pos, szTitle[m_iLangType], strlen(szTitle[m_iLangType]) ); 
		pos += strlen(szTitle[m_iLangType]);
	}
	else if( m_bIVMode==1 || m_bIVMode==3 )
	{
		memcpy( (BYTE*)lptstrCopy+pos, szTitleIV[m_iLangType], strlen(szTitleIV[m_iLangType]) ); 
		pos += strlen(szTitleIV[m_iLangType]);
	}
	else if( m_bIVMode==2 )
	{
		memcpy( (BYTE*)lptstrCopy+pos, szTitlePB[m_iLangType], strlen(szTitlePB[m_iLangType]) ); 
		pos += strlen(szTitlePB[m_iLangType]);
	}
	else if(m_bIVMode == 5)
	{
		memcpy( (BYTE*)lptstrCopy+pos, szTitleMG[m_iLangType], strlen(szTitleMG[m_iLangType]) ); 
		pos += strlen(szTitleMG[m_iLangType]);
	}

	memcpy( (BYTE*)lptstrCopy+pos, (const void*)LPCTSTR(szrf), 2 ); 
	pos += 2;
	fwrite(lptstrCopy,pos,1,f);
	pos = 0;
	

	for(int i = 0; i < m_nDataTotal; i++)
	{
		GetExportToExcelDataOneLine(i,lptstrCopy,pos);		

		fwrite(lptstrCopy,pos,1,f);
		pos = 0;
	}

	fclose(f);	
	delete[] lptstrCopy;
	
	DWORD dwt2 = GetTickCount();
	TRACE("ExportToExcel function:%d\n",dwt2-dwt1);

	
	return S_OK;
}

BYTE CTTOptions::GetExportToExcelDataOneLine(int nItem,BYTE* pData,long& pos)
{
	if(m_bIVMode == 0 || m_bIVMode==4 || m_bIVMode==5)
	{
		GetExportToExcelData(nItem,0,pData,pos);
		if( m_bIVMode==5 )
			GetExportToExcelData(nItem,21,pData,pos);
		GetExportToExcelData(nItem,1,pData,pos);
		GetExportToExcelData(nItem,2,pData,pos);
		GetExportToExcelData(nItem,3,pData,pos);
		GetExportToExcelData(nItem,4,pData,pos);
		GetExportToExcelData(nItem,5,pData,pos);
		GetExportToExcelData(nItem,6,pData,pos);
		GetExportToExcelData(nItem,7,pData,pos);
		GetExportToExcelData(nItem,8,pData,pos);
		GetExportToExcelData(nItem,9,pData,pos);
		GetExportToExcelData(nItem,10,pData,pos);
		GetExportToExcelData(nItem,11,pData,pos);
		GetExportToExcelData(nItem,12,pData,pos);
		GetExportToExcelData(nItem,13,pData,pos);
		GetExportToExcelData(nItem,14,pData,pos);
		GetExportToExcelData(nItem,15,pData,pos);
		GetExportToExcelData(nItem,16,pData,pos);
		GetExportToExcelData(nItem,17,pData,pos);
		GetExportToExcelData(nItem,18,pData,pos);
		GetExportToExcelData(nItem,19,pData,pos);
		if( m_bIVMode==5 )
			GetExportToExcelData(nItem,24,pData,pos);
		GetExportToExcelData(nItem,20,pData,pos);
	}
	else if( m_bIVMode==1 || m_bIVMode==3 )
	{
		GetExportToExcelData(nItem,0,pData,pos);
		GetExportToExcelData(nItem,1,pData,pos);
		GetExportToExcelData(nItem,2,pData,pos);
		GetExportToExcelData(nItem,3,pData,pos);
	
		//Vega,Theta,Gamma,Delta
		GetExportToExcelData(nItem,1+100,pData,pos);
		GetExportToExcelData(nItem,2+100,pData,pos);
		GetExportToExcelData(nItem,3+100,pData,pos);
		GetExportToExcelData(nItem,4+100,pData,pos);

		GetExportToExcelData(nItem,4,pData,pos);	
		GetExportToExcelData(nItem,5,pData,pos);
		//�ɼ۲���
		GetExportToExcelData(nItem,5+100,pData,pos);

		GetExportToExcelData(nItem,6,pData,pos);
		GetExportToExcelData(nItem,7,pData,pos);
		//���벨��, ��������
		GetExportToExcelData(nItem,7+100,pData,pos);
		GetExportToExcelData(nItem,8+100,pData,pos);

		GetExportToExcelData(nItem,8,pData,pos);
		GetExportToExcelData(nItem,9,pData,pos);
		GetExportToExcelData(nItem,10,pData,pos);  //strike
		GetExportToExcelData(nItem,11,pData,pos);
		GetExportToExcelData(nItem,12,pData,pos);
		//���벨��, ��������
		GetExportToExcelData(nItem,12+100,pData,pos);
		GetExportToExcelData(nItem,13+100,pData,pos);

		GetExportToExcelData(nItem,13,pData,pos);
		GetExportToExcelData(nItem,14,pData,pos);
		GetExportToExcelData(nItem,15,pData,pos);
		//�ɼ۲���
		GetExportToExcelData(nItem,15+100,pData,pos);

		GetExportToExcelData(nItem,16,pData,pos);

		//Delta,Gamma,Theta,Vega
		GetExportToExcelData(nItem,16+100,pData,pos);
		GetExportToExcelData(nItem,17+100,pData,pos);
		GetExportToExcelData(nItem,18+100,pData,pos);
		GetExportToExcelData(nItem,19+100,pData,pos);

		GetExportToExcelData(nItem,17,pData,pos);
		GetExportToExcelData(nItem,18,pData,pos);
		GetExportToExcelData(nItem,19,pData,pos);
		GetExportToExcelData(nItem,20,pData,pos);
	}
	else if( m_bIVMode==2 )
	{
		GetExportToExcelData(nItem,21,pData,pos);
		GetExportToExcelData(nItem,22,pData,pos);
	
		//Vega,Theta,Gamma,Delta
		GetExportToExcelData(nItem,1+100,pData,pos);
		GetExportToExcelData(nItem,2+100,pData,pos);
		GetExportToExcelData(nItem,3+100,pData,pos);
		GetExportToExcelData(nItem,4+100,pData,pos);
	
		GetExportToExcelData(nItem,5,pData,pos);
		//�ɼ۲���
		GetExportToExcelData(nItem,5+100,pData,pos);

		GetExportToExcelData(nItem,10,pData,pos);  //strike
		
		GetExportToExcelData(nItem,15,pData,pos);
		//�ɼ۲���
		GetExportToExcelData(nItem,15+100,pData,pos);

		

		//Delta,Gamma,Theta,Vega
		GetExportToExcelData(nItem,16+100,pData,pos);
		GetExportToExcelData(nItem,17+100,pData,pos);
		GetExportToExcelData(nItem,18+100,pData,pos);
		GetExportToExcelData(nItem,19+100,pData,pos);

		
		GetExportToExcelData(nItem,23,pData,pos);
		GetExportToExcelData(nItem,24,pData,pos);
	}
	
	return 0;
}

BYTE CTTOptions::GetExportToExcelData(int nItem,int nSubItem,BYTE* pData,long& pos)
{

	CString szrf = "\r\n";
	CString strComma = ",";
	if( m_pList1->m_bIVMode==5 )
		m_pList1->m_bIVMode = -1;
	char* pDest = m_pList1->GetReflectItemText(m_pList1->m_buf+nItem,nSubItem);
	if( m_pList1->m_bIVMode==-1 )
		m_pList1->m_bIVMode = 5;
	
	
	char ch1= '(';
	char ch2= ')';

	if (nSubItem == 0 || nSubItem == 20 ||nSubItem == 105 || nSubItem == 115 || nSubItem == 107 || nSubItem == 108 || nSubItem == 112 ||nSubItem == 113) //IV��������Ҫ���´���
	{
		memcpy( (BYTE*)pData+pos, (const void*)pDest, strlen(pDest) ); 

		if( nSubItem == 0 || nSubItem == 20 )
		{
			CString str = pDest;
			str = str.Mid(0,str.Find(ch1));
			str.TrimRight();
			char *p = str.GetBuffer(str.GetLength());
			memcpy((BYTE*)pData+pos,p,str.GetLength());
			pos += str.GetLength();
			str.ReleaseBuffer();
			memcpy( (BYTE*)pData+pos, (const void*)LPCTSTR(strComma), 1 ); 
			pos += 1;
		}
		
		char* p1 = strchr(pDest,ch1);
		char* p2 = strchr(pDest,ch2);

		if (p2 > p1 && p1 > 0)
		{
			memcpy((BYTE*)pData+pos,p1+1,p2-p1-1);
			pos += p2-p1-1;
		}
	}
	else
	{
		memcpy( (BYTE*)pData+pos, (const void*)pDest, strlen(pDest) ); 
		pos += strlen(pDest);
	}

	if( (m_bIVMode!=2&&nSubItem!=20) || (m_bIVMode==2&&nSubItem!=24) )  //�������һ��
	{
		memcpy( (BYTE*)pData+pos, (const void*)LPCTSTR(strComma), 1 ); 
		pos += 1;
	}
	else
	{
		memcpy( (BYTE*)pData+pos, (const void*)LPCTSTR(szrf), 2 ); 
		pos += 2;
	}


	ASSERT( pos < MEMSIZE );
	return 0;
}

void CTTOptions::NotifyItemChanged()
{
	//֪ͨTTmainFrm
	CComQIPtr<ITTObject, &IID_ITTObject> pObj(m_pMainFrm);					
	if(pObj != NULL)
	{	
		char buff[20];
		memset(buff,0,sizeof(buff));

		memcpy(buff,"A",1);
		memcpy(buff+1,m_szItemCode,8);

		VARIANT var;
		var.vt = VT_BYREF|VT_UI1;
		var.pbVal = (BYTE*)buff;
		pObj->PutByID(TTPID_ItemCodeWillChg, &var);
	}
}

void CTTOptions::Split(CString source, CStringArray& dest, CString division)
{
    dest.RemoveAll();
    int pos = 0;
    int pre_pos = 0;
    while( -1 != pos ){
        pre_pos = pos;
        pos = source.Find(division,pos+1);
		if( pos==-1 )
			break;
		if( pre_pos==0 )
			dest.Add(source.Mid(pre_pos,(pos-pre_pos)));
		else
			dest.Add(source.Mid(pre_pos+1,(pos-pre_pos-1)));
    }
	if( pos==-1 )
		dest.Add(source.Mid(pre_pos+1,source.GetLength()-pre_pos));
}

void CTTOptions::GetMarginTxt()
{
	int i,j,k,month=-1,pos=-1;
	long MarTime = m_lTransdate;
	if( IsIndex() )
		MarTime = m_lExpiryTime;
	for( i=0;i<MAX_OPTIONS_COUNT;i++ )
	{
		if(m_arrMargin[i].GetSize()>0 && memcmp(m_arrMargin[i][0].m_szfcode,m_szOptCode,5)==0 )
		{
			for( j=0;j<5;j++ )
			{
				if( m_arrMargin[i][0].m_lTransdate[j]==MarTime )
				{
					month = j;
					break;
				}
			}
			pos = i;
			break;
		}
	}

	if( pos==-1||month==-1 )
		return;

	char *pDest;
	for( i=0;i<m_nDataTotal;i++ )
	{
		for( j=0;j<m_arrMargin[pos].GetSize();j++ )
		{
			if( m_arrMargin[pos][j].m_fStrike==m_pDataBuf[i].m_fStrike )
				break;
		}
		m_pDataBuf[i].m_fCalls_Margin = m_arrMargin[pos][j].m_iCall_Margin[month];
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+i, 21 ) ;
		sprintf(pDest,"%d",m_arrMargin[pos][j].m_iCall_Margin[month]);
		if( m_arrMargin[pos][j].m_iCall_Margin[month]==0 )
			sprintf(pDest,"");
		m_pDataBuf[i].m_fPuts_Margin = m_arrMargin[pos][j].m_iPut_Margin[month];
		pDest = m_pList1->GetReflectItemText( m_pList1->m_buf+i, 24 ) ;
		sprintf(pDest,"%d",m_arrMargin[pos][j].m_iPut_Margin[month]);
		if( m_arrMargin[pos][j].m_iPut_Margin[month]==0 )
			sprintf(pDest,"");
	}
}

void CTTOptions::GetCashOrFuturesCode( char* itemcode, long ldate, char* returncode )
{

	BOOL bIndex = FALSE;
	if( memcmp(itemcode,"HSI    ",7)==0 
		|| memcmp(itemcode,"HSCEI  ",7)==0 
		|| memcmp(itemcode,"MHI    ",7)==0 
		|| memcmp(itemcode,"MCH    ",7)==0 )
		bIndex = TRUE;

	BOOL bFind = FALSE;

	if( m_OccList.GetSize()==0 )
		return;
	g_txtoccS txt;
	
	for(int i = 0; i< m_OccList.GetSize(); i++)
	{
		memcpy(&txt,&m_OccList[i],sizeof(txt));
		
		if(memcmp(txt.itemcode,itemcode,8) == 0)
		{
			bFind = TRUE;
			break;					
		}
		
	}				

	if(!bIndex)
	{
		memcpy(returncode,txt.cashitemcode,8);
		return ;
	}
	else
	{
		char title[6] = {0};
		memcpy(title,txt.fcode,6);

		
		ldate = ldate/100;
		int nMM = ldate%100;
		int nYY = (ldate/100)%100;
		
		TCHAR szBuf[9];
		TCHAR szXBuf[9];
		szXBuf[8] = 0;
		char szMonthCode[] = "FGHJKMNQUVXZ";
		int	nCodeLen = strlen(title);
		if (nCodeLen > G_GENCODELEN - 3 || nMM < 1 || nMM > 12 || nYY < 0)
			return ;
		if (nYY > 99)
			nYY = 0;
		sprintf( szBuf, "%s%c%02d%*s", _strupr(title), szMonthCode[nMM - 1], nYY, G_GENCODELEN - 3 - nCodeLen, " " );
		
		char ch = 'X';
		sprintf( szXBuf, "%c%s%c%02d%*s", ch,_strupr(title), szMonthCode[nMM - 1], nYY, G_GENCODELEN - 3 - nCodeLen, " " );
		ItemToCash itc;
		memcpy(itc.itemcode,itemcode,8);
		itc.ldate = ldate;
		memcpy(itc.cashcode,szXBuf,8);
		m_pwndCls->m_arrITC.Add(itc);
		SendTeleHisCash(szXBuf);
		
		memcpy(returncode,szBuf,G_GENCODELEN);
		return ;
	}
}

void CTTOptions::GetDvdInfo()
{
	SYSTEMTIME SysTime;
	GetSystemTime(&SysTime);
	long lToday = SysTime.wYear*10000 + SysTime.wMonth*100 + SysTime.wDay;
	GetExpiryTime();

	m_dPaiXi_1 = 0.0;
	m_dPaiXi_2 = 0.0;
	m_ParaList.RemoveAll();
	int iTemp1=0,iTemp2=0;
	long tempDate1 = 0;
	long tempDate2 = 0;
	int nID = m_GroupFile.FindItem(m_szItemCode);
	if( nID!=-1 )
	{
		m_ParaList.Copy(m_GroupFile.m_pParaList[nID]);

		for( int i=0;i<m_ParaList.GetSize();i++ )
		{
			if( m_ParaList[i].method==1 )
			{
				if(m_ParaList[i].ToDate>lToday && m_ParaList[i].ToDate<m_lExpiryTime )
				{	
					if( m_dPaiXi_1==0 )
					{
						m_dPaiXi_1 = m_ParaList[i].param1;
						DateDiff(m_ParaList[i].ToDate,lToday,iTemp1);
						iTemp1 = iTemp1/double(m_lExpiryDays)*CONST_STEP;
						tempDate1 = m_ParaList[i].ToDate;
					}
					else if( tempDate1==m_ParaList[i].ToDate )
						m_dPaiXi_1 += m_ParaList[i].param1;
					else if( tempDate2==m_ParaList[i].ToDate )
						m_dPaiXi_2 += m_ParaList[i].param1;
					else if( tempDate1 < m_ParaList[i].ToDate )
					{
						m_dPaiXi_2 = m_ParaList[i].param1; 
						DateDiff(m_ParaList[i].ToDate,lToday,iTemp2);
						iTemp2 = iTemp2/double(m_lExpiryDays)*CONST_STEP;
						tempDate2 = m_ParaList[i].ToDate;
					}
				}
			}
		}

		m_dPaiXi_1 += iTemp1*100;
		m_dPaiXi_2 += iTemp2*100;

	}
	
}

void CTTOptions::ReadRclFile()
{
	char szPath[MAX_PATH];
	sprintf(szPath,"%sbin\\hkstock.rcl",m_szRootPath);
	m_GroupFile.ReadFile(szPath);
}

void CTTOptions::ReadMarginFile()
{
	char fbuff[MAX_PATH];
	sprintf( fbuff, "%sdata\\CLMCurr.csv", m_szRootPath );

	CStdioFile file;
	BOOL ret = file.Open(fbuff,CFile::modeRead);
	if( !ret )
	{
		return;
	}

	Margin mar;
	CStringArray arrstr;
	CString diliv = ",";
	int i,j, k=-1, nLine=0;
	for( i=0;i<MAX_OPTIONS_COUNT;i++ )
		m_arrMargin[i].RemoveAll();
	CString strfile;
	int pos1,pos2;
	while(file.ReadString(strfile))
	{
		pos1 = strfile.Find('[');
		pos2 = strfile.Find(']');
		if( pos1!=-1 && pos2!=-1  )
		{
			strfile = strfile.Mid(pos1+1,pos2-pos1-1);
			if( strfile.GetLength()>5 )
				continue;
			memset(&mar,0,sizeof(mar));
			nLine = 0;
			k++;
			memcpy(mar.m_szfcode,(LPSTR)(LPCSTR)strfile,strfile.GetLength());
			continue;
		}
		if( k!=-1 )
		{
			nLine++;
			if( nLine==1 )
			{
				Split(strfile,arrstr,diliv);
			//	if( arrstr.GetSize()>7 )
			//		continue;
				for( j=1;j<arrstr.GetSize();j++ )
				{
					if( j%2==0 )
					{
						arrstr[j] = arrstr[j].Right(arrstr[j].GetLength()-1);
						arrstr[j] = "20"+arrstr[j];
						mar.m_lTransdate[(j-1)/2] = atoi(arrstr[j]);
					}
				}
			}
			else
			{
				Split(strfile,arrstr,diliv);
				if( /*arrstr.GetSize()>7 || */arrstr.GetSize()==0 )
					continue;
				
				mar.m_fStrike = atof(arrstr[0]);
				
				for( j=1;j<arrstr.GetSize();j++ )
				{
					if( j%2!=0 )
					{
						if( arrstr[j]=="-" )
							mar.m_iCall_Margin[(j-1)/2] = 0;
						else
							mar.m_iCall_Margin[(j-1)/2] = atoi(arrstr[j]);
					}
					else
					{
						if( arrstr[j]=="-" )
							mar.m_iPut_Margin[(j-1)/2] = 0;
						else
							mar.m_iPut_Margin[(j-1)/2] = atoi(arrstr[j]);
					}
				}
					
			}
			m_arrMargin[k].Add(mar);
		}
	}
	file.Close();
	
}

void CTTOptions::ReadHKStockOccFile()
{
	//CTTOptionsItemDlg dlg(m_iLangType);

	char fbuff[MAX_PATH];
	sprintf( fbuff, "%sdata\\hkstock2.occ", m_szRootPath );
	HANDLE hFile = CreateFile(fbuff,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
		OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		return ;
	}
	g_txtoccheadS txthead;
	g_txtoccS      txt;
	DWORD dwTm;

	m_OccList.RemoveAll();
		
	if(ReadFile(hFile,&txthead,sizeof(g_txtoccheadS),&dwTm,NULL) !=0 &&
		txthead.id == G_TXTOCCFILEID&&txthead.reserved == 0x1A)
	{
		for(int i = 0; i< txthead.numitem; i++)
		{
			if(!ReadFile(hFile,&txt,sizeof(g_txtoccS),&dwTm,NULL))
			{
				CloseHandle(hFile);
				return ;
			}
			
			TCHAR szItemCode[8];
			memcpy(szItemCode,txt.itemcode,8);
			
			if( memcmp(szItemCode,m_szItemCode,8)==0 )
			{
				memset(m_szOptCode,0,sizeof(m_szOptCode));
				memcpy(m_szOptCode,txt.optcode,5);
			//	break;
			}
			m_OccList.Add(txt);
		//	char log[100];
		//	sprintf(log,"itemcode=%s,fcode=%s,cashcode=%s,optcode=%s",txt.itemcode,txt.fcode,txt.cashitemcode,txt.optcode);
		//	WriteLogFile(log);
		}				
	}
	CloseHandle(hFile);
}

void CTTOptions::OnSelectItemCode()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 

	if(m_pGrpMng == NULL)
		return ;
	CComQIPtr< ITTGroupsMng,&IID_ITTGroupsMng> pGrp(m_pGrpMng);
	if(pGrp == NULL)
		return ;

	CTTOptionsItemDlg dlg(m_iLangType);
	// ben  2017.07.18 
	if( m_bSelectWin==0 )
		dlg.m_hwndParent = m_pbtnItemCode->m_hWnd;
	else if( m_bSelectWin==1 )
		dlg.m_hwndParent = m_pwndCls->m_hWnd;

	char fbuff[MAX_PATH];
	sprintf( fbuff, "%sdata\\hkstock2.occ", m_szRootPath );
	HANDLE hFile = CreateFile(fbuff,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
		OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		//Beep(0x300,100);
		MessageBeep(MB_OK);
		if(m_iLangType == 2)
			::MessageBox(NULL,_T("���} HKStock2.occ ����."),_T("���~!"),MB_OK);
		else if(m_iLangType == 1)
			::MessageBox(NULL,_T("�� HKStock2.occ ʧ��."),_T("����!"),MB_OK);
		else
		::MessageBox(NULL,_T("Open HKStock2.occ failed."),_T("Error!"),MB_OK);
		return ;
	}
	g_txtoccheadS txthead;
	g_txtoccS      txt;
	DWORD dwTm;
		char sz[100];
	if(ReadFile(hFile,&txthead,sizeof(g_txtoccheadS),&dwTm,NULL) !=0 &&
		txthead.id == G_TXTOCCFILEID&&txthead.reserved == 0x1A)
	{
		for(int i = 0; i< txthead.numitem; i++)
		{
			if(!ReadFile(hFile,&txt,sizeof(g_txtoccS),&dwTm,NULL))
			{
				CloseHandle(hFile);
				return ;
			}
			int nIndex = dlg.AddItemString((LPCTSTR)txt.itemcode);
			if(nIndex == -1)
			{
				CloseHandle(hFile);
				return ;
			}
			TCHAR szItemCode[8];
			memcpy(szItemCode,txt.itemcode,8);
			long lID;
			pGrp-> FindItem('A',(BYTE*)szItemCode,&lID);
			TCHAR szName[30];
			if( m_iLangType==0 )
				pGrp->GetItemPara(lID,ItemID_Lang1Descrip,(BYTE*)szName,30);
			else
			if( m_iLangType==1 )
				pGrp->GetItemPara(lID,ItemID_Lang3Descrip,(BYTE*)szName,30);
			else
			if( m_iLangType==2 )
				pGrp->GetItemPara(lID,ItemID_Lang2Descrip,(BYTE*)szName,30);

			dlg.AddName(nIndex,szName);
			dlg.AddFutText(nIndex,(LPCTSTR)txt.fcode);
			dlg.AddCashCode(nIndex,(LPCTSTR)txt.cashitemcode);
			dlg.AddOptCode(nIndex,(LPCTSTR)txt.optcode);
		}//end of for				
	}//end of if	
	
	CloseHandle(hFile);
	if(dlg.DoModal() == S_OK)
	{
		if(memcmp(m_szItemCode,dlg.m_szText[dlg.m_nSel],8))
		{
			//andy add 2003.10.16  �ȶϿ�ԭ�ȵ�����,����DO��DS
			SendEndFrame();
			//andy add 2003.10.16
			memset(m_szItemCode,0,sizeof(m_szItemCode));
			memcpy(m_szItemCode,dlg.m_szText[dlg.m_nSel],8);

			memset(m_szFuturesTitle,0,sizeof(m_szFuturesTitle));
			memcpy(m_szFuturesTitle,dlg.m_szFutText[dlg.m_nSel],6);

			memset(m_szOptCode,0,sizeof(m_szOptCode));
			memcpy(m_szOptCode,dlg.m_szOptCode[dlg.m_nSel],5);

			memset(m_szItemCashCode,0,sizeof(m_szItemCashCode));
			memcpy(m_szItemCashCode,dlg.m_szCashCode[dlg.m_nSel],8);

			//memset(m_szVHSICode,0,sizeof(m_szVHSICode));
			//memcpy(m_szVHSICode,dlg.m_szVHSICode[dlg.m_nSel],8);

			MakeFutCode(m_szFuturesCode,m_szFuturesTitle,
				m_lTransdate % 100, (m_lTransdate/100)%100);
			TCHAR szCode[9];
			memcpy(szCode,m_szItemCode,8);
			szCode[8] = 0;
			ResetFrmTitle() ;
			lstrcpy(m_szItemName,dlg.m_szName[dlg.m_nSel]);

/*
			::SetWindowText( m_pbtnItemCode->m_hWnd,szCode);
			::SetWindowText( m_pstaItemName->m_hWnd,m_szItemName);
*/
			GetExpiryTime();
			UpdateTitle() ;

//			::SetWindowText( m_pedtCash->m_hWnd,_T(""));
			m_pedtCash->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
//			::SetWindowText( m_pedtFutures->m_hWnd,_T(""));
			m_pedtFutures->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
			m_pedtVHSI->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
			ClearData(); //ResetTable();  andy modify 20090507
			SaveValue() ;

			sprintf(m_szEAS,"");
			if( memcmp(m_szItemCode,"HSI    ",7)==0  || memcmp(m_szItemCode,"MHI    ",7)==0 )
			{
				sprintf(m_szEAS,"%d",m_iEAS1);
			}
			else if( memcmp(m_szItemCode,"HSCEI  ",7)==0 || memcmp(m_szItemCode,"MCH    ",7)==0 )
			{
				sprintf(m_szEAS,"%d",m_iEAS2);
			}
			::PostMessage(m_hWnd,CM_SETWINDOWTEXT,3,0);

			GetDvdInfo();   //ben add 2018.5.15
			//SaveValueColor();//add 2014.9.25 Keeping
			
				//m_lstMonths.RemoveAll();
				//m_bClick_SelMonth = FALSE;
				m_pbtnOptMonth->ShowWindow(SW_HIDE);
				m_pstaExpiryDate->ShowWindow(SW_HIDE);
			
			memset(m_pList1->m_buf_simple,0,sizeof(ItemOptionsText)*MACRO_SmpItems);	
			
			SendMonthRequestFrame();

			SendRequestFrame();
			
			NotifyItemChanged(); //andy add 2009.06.11

			if( m_pwndCls!=NULL && m_pwndCls->IsWindowVisible() )
			{
				m_pwndCls->m_nIxStrike = -1;
				m_pwndCls->m_nIxStrike2 = -1;
				m_pwndCls->m_nIxStrike3 = -1;
				m_pwndCls->m_nIxStrike4 = -1;
				m_pwndCls->m_nIxStrike5 = -1;
				m_pwndCls->m_nIxStrike6 = -1;
				m_pwndCls->ClearFlag();
				m_pwndCls->m_bItemCodeChange = TRUE;
				if( m_pwndCls->m_bMode!=1 )
					m_pwndCls->SwitchCtrl();
				if( m_pwndCls->m_nIndex==STGY_CUSTOM )
				{
					if( m_pwndCls->m_bHaveCrt_Spin_C )
						m_pwndCls->DestroySpin(m_pwndCls->m_pSpin_C,m_pwndCls->m_bHaveCrt_Spin_C);
				}
				if( m_pwndCls->m_bUseRecord )
				{
					m_pwndCls->m_bUseRecord = FALSE;
					if( m_pwndCls->m_bMode==0 )
					{
						m_pwndCls->CreateBtn();
						m_pwndCls->CreateSpin(&m_pwndCls->m_list,m_pwndCls->m_pSpin,2,
							2,m_pwndCls->m_bHaveCrt_Spin);
						if( m_pwndCls->m_nIndex==STGY_CUSTOM )
						{
							for( int j=0;j<5;j++ )
								m_pwndCls->CreateSpin(&m_pwndCls->m_list,m_pwndCls->m_pSpinEx[j],j+3,2,m_pwndCls->m_bHaveCrt_Spin);
						}
					}
				}
				for( int i=0;i<3;i++ )
				{
					m_pwndCls->m_bResetBF[i] = TRUE;
				}
				for( i=0;i<6;i++ )
				{
					m_pwndCls->m_bAlterPrice[i] = FALSE;
					m_pwndCls->m_bAlterPrice2[i] = FALSE;
				}

//				m_pwndCls->m_nRetn = 0;
				OnSelectStrategy();
			}
			/*else
			{
				if( m_pwndCls!=NULL )
				{
					for( int i=0;i<m_pwndCls->m_StgyList.GetSize();i++ )
					{
						long lTransdate = m_pwndCls->m_StgyList[i].m_lExpTime/100;
						SendUpdateRP(FALSE,m_pwndCls->m_StgyList[i].m_szCode,lTransdate);
					}
					delete m_pwndCls;
					m_pwndCls = NULL;
					m_bStgyMode = -1;
				}
			}*/

		}

	}//end if.					

}

void CTTOptions::OnSelectItemCode2(DOUBLE dbItem)
{   //ͨ��putbyidֱ�Ӹı�item

	BOOL bFind = FALSE;
	char szItemCode[9];
	char szItemName[31];
	memset(szItemCode,0,sizeof(szItemCode));
	memset(szItemName,0,sizeof(szItemName));

	memcpy(szItemCode,&dbItem,8);


	ATLTRACE("OnSelectItemCode2 : %s\r\n",szItemCode);

	char fbuff[MAX_PATH];
	sprintf( fbuff, "%sdata\\hkstock2.occ", m_szRootPath );
	HANDLE hFile = CreateFile(fbuff,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
		OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		//Beep(0x300,100);
		MessageBeep(MB_OK);
//		if(m_iLangType == 2)
//			::MessageBox(NULL,_T("���} HKStock.occ ����."),_T("���~!"),MB_OK);
//		else if(m_iLangType == 1)
//			::MessageBox(NULL,_T("�� HKStock.occ ʧ��."),_T("����!"),MB_OK);
//		else
//		::MessageBox(NULL,_T("Open HKStock.occ failed."),_T("Error!"),MB_OK);
		return ;
	}
	g_txtoccheadS txthead;
	g_txtoccS      txt;
	DWORD dwTm;
		
	if(ReadFile(hFile,&txthead,sizeof(g_txtoccheadS),&dwTm,NULL) !=0 &&
		txthead.id == G_TXTOCCFILEID&&txthead.reserved == 0x1A)
	{
		for(int i = 0; i< txthead.numitem; i++)
		{
			if(!ReadFile(hFile,&txt,sizeof(g_txtoccS),&dwTm,NULL))
			{
				CloseHandle(hFile);
				return ;
			}
			
			if(memcmp(txt.itemcode,szItemCode,8) == 0)
			{
				bFind = TRUE;
				
				if(m_pGrpMng == NULL)
					return ;				
				CComQIPtr< ITTGroupsMng,&IID_ITTGroupsMng> pGrp(m_pGrpMng);
				if(pGrp == NULL)
					return ;
				
				long lID;
				pGrp-> FindItem('A',(BYTE*)szItemCode,&lID);
				TCHAR szName[30];
				if( m_iLangType==0 )
					pGrp->GetItemPara(lID,ItemID_Lang1Descrip,(BYTE*)szItemName,30);
				else
				if( m_iLangType==1 )
					pGrp->GetItemPara(lID,ItemID_Lang3Descrip,(BYTE*)szItemName,30);
				else
				if( m_iLangType==2 )
					pGrp->GetItemPara(lID,ItemID_Lang2Descrip,(BYTE*)szItemName,30);

				break;					
			}

		}//end of for				
	}//end of if		
	CloseHandle(hFile);



	if(bFind == TRUE)
	{
			//andy add 2003.10.16  �ȶϿ�ԭ�ȵ�����,����DO��DS
			SendEndFrame(); 
			//andy add 2003.10.16
			memset(m_szItemCode,0,sizeof(m_szItemCode));
			memcpy(m_szItemCode,txt.itemcode,8);

			memset(m_szFuturesTitle,0,sizeof(m_szFuturesTitle));
			memcpy(m_szFuturesTitle,txt.fcode,6);

			memset(m_szOptCode,0,sizeof(m_szOptCode));
			memcpy(m_szOptCode,txt.optcode,5);

			memset(m_szItemCashCode,0,sizeof(m_szItemCashCode));
			memcpy(m_szItemCashCode,txt.cashitemcode,8);

			MakeFutCode(m_szFuturesCode,m_szFuturesTitle,
				m_lTransdate % 100, (m_lTransdate/100)%100);
			TCHAR szCode[9];
			memcpy(szCode,m_szItemCode,8);
			szCode[8] = 0;
			ResetFrmTitle() ;
			lstrcpy(m_szItemName,szItemName);
/*
			::SetWindowText( m_pbtnItemCode->m_hWnd,szCode);
			::SetWindowText( m_pstaItemName->m_hWnd,m_szItemName);
*/			GetExpiryTime();
			UpdateTitle() ;
			

//			::SetWindowText( m_pedtCash->m_hWnd,_T(""));
			m_pedtCash->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
//			::SetWindowText( m_pedtFutures->m_hWnd,_T(""));
			m_pedtFutures->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
			m_pedtVHSI->PostMessage(WM_SETTEXT, 0, (LPARAM)_T(""));
			ClearData(); //ResetTable();  andy modify 20090507
			SaveValue() ;

			sprintf(m_szEAS,"");
			if( memcmp(m_szItemCode,"HSI    ",7)==0  || memcmp(m_szItemCode,"MHI    ",7)==0 )
			{
				sprintf(m_szEAS,"%d",m_iEAS1);
			}
			else if( memcmp(m_szItemCode,"HSCEI  ",7)==0 || memcmp(m_szItemCode,"MCH    ",7)==0 )
			{
				sprintf(m_szEAS,"%d",m_iEAS2);
			}
			::PostMessage(m_hWnd,CM_SETWINDOWTEXT,3,0);

			GetDvdInfo();
			//SaveValueColor();//add 2014.9.25 Keeping
			
				//m_lstMonths.RemoveAll();
				//m_bClick_SelMonth = FALSE;
				m_pbtnOptMonth->ShowWindow(SW_HIDE);
				m_pstaExpiryDate->ShowWindow(SW_HIDE);

			memset(m_pList1->m_buf_simple,0,sizeof(ItemOptionsText)*MACRO_SmpItems);
			
			SendMonthRequestFrame();
			SendRequestFrame();


			if( m_pwndCls!=NULL && m_pwndCls->IsWindowVisible() )
			{
				m_pwndCls->m_nIxStrike = -1;
				m_pwndCls->m_nIxStrike2 = -1;
				m_pwndCls->m_nIxStrike3 = -1;
				m_pwndCls->m_nIxStrike4 = -1;
				m_pwndCls->m_nIxStrike5 = -1;
				m_pwndCls->m_nIxStrike6 = -1;
				m_pwndCls->ClearFlag();
				m_pwndCls->m_bItemCodeChange = TRUE;
				if( m_pwndCls->m_bMode!=1 )
					m_pwndCls->SwitchCtrl();

				if( m_pwndCls->m_nIndex==STGY_CUSTOM )
				{
					if( m_pwndCls->m_bHaveCrt_Spin_C )
						m_pwndCls->DestroySpin(m_pwndCls->m_pSpin_C,m_pwndCls->m_bHaveCrt_Spin_C);
				}
				if( m_pwndCls->m_bUseRecord )
				{
					m_pwndCls->m_bUseRecord = FALSE;
					if( m_pwndCls->m_bMode==0 )
					{
						m_pwndCls->CreateBtn();
						m_pwndCls->CreateSpin(&m_pwndCls->m_list,m_pwndCls->m_pSpin,2,
							2,m_pwndCls->m_bHaveCrt_Spin);
						if( m_pwndCls->m_nIndex==STGY_CUSTOM )
						{
							for( int j=0;j<5;j++ )
								m_pwndCls->CreateSpin(&m_pwndCls->m_list,m_pwndCls->m_pSpinEx[j],j+3,2,m_pwndCls->m_bHaveCrt_Spin);
						}
					}
				}
				for( int i=0;i<3;i++ )
				{
					m_pwndCls->m_bResetBF[i] = TRUE;	
				}
				for( i=0;i<6;i++ )
				{
					m_pwndCls->m_bAlterPrice[i] = FALSE;
					m_pwndCls->m_bAlterPrice2[i] = FALSE;
				}

//				m_pwndCls->m_nRetn = 0;
				OnSelectStrategy();
			}
			/*else
			{
				if( m_pwndCls!=NULL )
				{
					for( int i=0;i<m_pwndCls->m_StgyList.GetSize();i++ )
					{
						long lTransdate = m_pwndCls->m_StgyList[i].m_lExpTime/100;
						SendUpdateRP(FALSE,m_pwndCls->m_StgyList[i].m_szCode,lTransdate);
					}
					delete m_pwndCls;
					m_pwndCls = NULL;
					m_bStgyMode = -1;
				}
			}*/


	}//end if.					

}

void CTTOptions::OnSelectMonth()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState()) 

	if(m_lstMonths.GetCount() == 0)
	{
		m_bClick_SelMonth = TRUE;
		SendMonthRequestFrame();		

		return;
	}

	memset(m_pList1->m_buf_simple,0,sizeof(ItemOptionsText)*MACRO_SmpItems);

	CdlgMonth::AddItemCode(m_szItemCode);
	BOOL bHandled = FALSE;
	OnShowMonthDlg(0, 0, 0, bHandled);	
	
}

void CTTOptions::SendMonthRequestFrame()
{
	FrameLen    framelen;
	FrameHead	framehead;
	FrameID		frameid;
	unsigned short	wElemType;
//	memset(&framehead,NULL,sizeof(FrameHead));
//	memset(&frameid,NULL,sizeof(FrameID));


	framehead.wFrameType = 'DO';
	framelen = sizeof(FrameHead) + sizeof(FrameID) + sizeof(short);
	frameid.cbGroupCode = m_cbGroupCode;
	memcpy(frameid.szItemCode,m_szItemCode,G_GENCODELEN);
	frameid.lTransdate =m_lTransdate;
	wElemType = 'RD';
	CComPtr<IStream> pIStream;
	CreateStreamOnHGlobal(NULL,TRUE,&pIStream);
	LARGE_INTEGER largeint;
	largeint.QuadPart = 0;
	ULARGE_INTEGER ulargeint;
	ulargeint.QuadPart = framelen + sizeof(framelen); // sizeof(FrameHead) + sizeof(FrameID) + sizeof(short) +sizeof(FrameLen);
	pIStream->SetSize(ulargeint);
	pIStream->Seek(largeint,STREAM_SEEK_SET,NULL);
	pIStream->Write(&framelen,sizeof(FrameLen),NULL);
	pIStream->Write(&framehead,sizeof(FrameHead),NULL);
	pIStream->Write(&frameid,sizeof(FrameID),NULL);
	pIStream->Write(&wElemType,sizeof(short),NULL);

	SubmitRQ(pIStream);
}

HRESULT CTTOptions::Zoom(long nType)
{
	const static int _FontSize_Min = 70;
	const static int _FontSize_Max = 220;
	int nOldSize = m_nFontSize;
	if(nType == TT_BT_FZOOMOUT)
	{
		// check valid.
/*
		{
			CRect rect1, rect2 ;
			m_pList1->GetDlgItem(0)->GetWindowRect(rect2) ;
			m_pList1->GetWindowRect(rect1) ;
			if( rect1.Height()<rect2.Height()*3 )
				return 0;
		}
*/

		//m_nFontSize -= 20; �ϰ棬����Ϊ20
		m_nFontSize -= 5;   //�°棬����Ϊ5

	}
	if(nType == TT_BT_FZOOMIN )
	{
		// check valid.
		{
			CRect rect1, rect2 ;
			m_pList1->GetDlgItem(0)->GetWindowRect(rect2) ;
			m_pList1->GetWindowRect(rect1) ;
			if( rect1.Height()<rect2.Height()*3 )
				return 0;
		}

		//m_nFontSize += 20;
		m_nFontSize += 5;
	}
	if (m_nFontSize<_FontSize_Min) 
		m_nFontSize = _FontSize_Min;
	if (m_nFontSize>_FontSize_Max) 
		m_nFontSize = _FontSize_Max;
	if( nOldSize==m_nFontSize )
		return S_FALSE ;
	//SaveValue();
	//SaveValue();//add 2014.9.25 Keeping
	//SaveValueColor();//add 2014.9.25 Keeping
	SetAllFont(m_strFontName, m_nFontSize);
	return S_OK;	
}

HRESULT CTTOptions::SetAllFont(LPCTSTR fontname, short fontsize)  //������������
{

	// create new font.
	m_font.DeleteObject() ;
	m_font.CreatePointFont( fontsize, fontname ) ;

	// set font.
	m_pList1->EnsureVisible( 0, FALSE ) ; 	
	m_pList1->SetFont( &m_font ) ;
	m_pHeader->SetFont( &m_font ) ;

	if(m_bIVMode == 0)
		SetColsMinWidth() ;
	else if( m_bIVMode == 1 )
		SetColsMinWidthIVMode();
	else if( m_bIVMode == 2 )
		SetColsMinWidthPBMode();

	m_pList1->GetDlgItem(0)->SetRedraw( FALSE );//����ػ��־
	m_pList1->SetRedraw( FALSE );
	for( int i=0;1;i++ )
	{
		LV_COLUMN column ;
		column.mask = LVCF_WIDTH ;  
		BOOL ret = m_pList1->GetColumn( i, &column ) ;
		if( ret==FALSE )
			break;
		int width = column.cx ;
		if( width<m_nColDefWidth[i] )
			m_pList1->SetColumnWidth( i, m_nColDefWidth[i] ) ;
		else
		if( width>=m_nColDefWidth[i]  )//+15 )
			m_pList1->SetColumnWidth( i, m_nColDefWidth[i]+15 ) ;

	}
	
	m_pList1->GetDlgItem(0)->SetRedraw( TRUE );
	m_pList1->GetDlgItem(0)->RedrawWindow() ;
	m_pList1->SetRedraw( TRUE );
	ResizeHeaderCtrl();//���¼��� m_pHeader �Ŀ���
	OnLstHScr() ;
 
	CRect temprect ;
	m_pList1->GetDlgItem(0)->GetWindowRect(temprect) ;

	int hi = temprect.Height() ; //��1�еĸ�	
	m_pHeader->GetWindowRect(temprect) ;  //��ȡ��ͷλ�� 
	m_pwndBgn->ScreenToClient(temprect) ; //����Ϊ�ͻ�����
	int dt = hi - temprect.Height() ;
	temprect.bottom = temprect.top + hi + 4 ;
	m_pHeader->MoveWindow( temprect, FALSE ) ;

	CRect temprect1 ;
	m_pList1->GetWindowRect(temprect1) ;
	m_pwndBgn->ScreenToClient(temprect1) ;
	temprect1.top = temprect.bottom-2 ;
	m_pList1->MoveWindow( temprect1 ) ;

	Sleep(20) ;	// have a rest, assure header update after list.
	m_pHeader->RedrawWindow() ;

	AdjustSize();
	return S_OK;
}

HRESULT CTTOptions::AdjustSize()
{
	return S_OK;
}

void CTTOptions::SetColsMinWidth()
{
	if( m_pList1->m_hWnd==NULL )
		return ;

	CString szDefaults[MACRO_MaxSubItems] = {
		"123456789    ",	//O/I
		"12345 ",	//Vol
		"13660 ",	//High
		"13660 ",	//Low
		"13660 ",	//Last
		"13660",	//Last Q
		"13660",	//Bid Q
		"13660 ",	//Bid
		"13660 ",	//Ask
		"13660",	//Ask Q

		"1234567",	//Strike

		"13660",	//Bid Q
		"13660 ",	//Bid
		"13660 ",	//Ask
		"13660",	//Ask Q
		"13660",	//Last Q
		"13660 ",	//Last
		"13660 ",	//High
		"13660 ",	//Low
		"12345 ",	//Vol
		"123456789    "	//O/I

	};

	for(int i =0; i< MACRO_MaxSubItems ; i++)
	{
		if(i==1 || i==2 || i==18 || i==19) //high,low
			m_nColDefWidth[i] = m_pList1->GetStringWidth( szDefaults[i] ) + 6 ;
		else
			m_nColDefWidth[i] = m_pList1->GetStringWidth( szDefaults[i] ) + 5 ;	
	}
	/*
	CString szDefaults[MACRO_MaxSubItems] = {
		"12345  ",	//O/I
		"12345 ",	//Vol
		"  13660",	//High
		"  13660",	//Low
		"  13660",	//Last
		"  13660",	//Last Q
		"  13660",	//Bid Q
		"  13660",	//Bid
		"  13660",	//Ask
		"  13660",	//Ask Q

		"  13660 ",	//Strike

		"  13660",	//Bid Q
		"  13660",	//Bid
		"  13660",	//Ask
		"  13660",	//Ask Q
		"  13660",	//Last Q
		"  13660",	//Last
		"  13660",	//High
		"  13660",	//Low
		"12345 ",	//Vol
		"12345 "	//O/I

	};

	for(int i =0; i< MACRO_MaxSubItems ; i++)
		m_nColDefWidth[i] = m_pList1->GetStringWidth( szDefaults[i] )+6 ;
	*/
}

void CTTOptions::SetColsMinWidthIVMode()
{
	if( m_pList1->m_hWnd==NULL )
		return ;

	CString szDefaults[MACRO_MaxSubItems] = {
		"123456789    ",	//O/I
		"12345",	//Vega
		"13660  ",	//Theta
		"13660 ",	//Gamma
		"13660 ",	//Delta
		"13660 (12.5%)",	//Last (IV)
		"13660",	//Bid Q
		"13660 (12.5%)",	//Bid (IV)
		"13660 (12.5%)",	//Ask (IV)
		"13660",	//Ask Q

		"1234567",	//Strike

		"13660",	//Bid Q
		"13660 (12.5%)",	//Bid (IV)
		"13660 (12.5%)",	//Ask (IV)
		"13660",	//Ask Q
		"13660 (12.5%)",	//Last(IV) 
		"13660 ",	//Delta
		"13660 ",	//Gamma
		"13660  ",	//TheTa
		"12345",	//Vega
		"123456789    "	//O/I

	};

	for(int i =0; i< MACRO_MaxSubItems ; i++)
	{
		if(i==1 || i==2 || i==18 || i==19) //high,low
			m_nColDefWidth[i] = m_pList1->GetStringWidth( szDefaults[i] ) + 6 ;
		else
			m_nColDefWidth[i] = m_pList1->GetStringWidth( szDefaults[i] ) + 5 ;	
	}

}

void CTTOptions::SetColsMinWidthPBMode()
{
	if( m_pList1->m_hWnd==NULL )
		return ;

	//P.touch��ȥ�� ֮�󻻰���
	CString szDefaults[MACRO_PBMaxSubItems] = {
		"12345  ",
		"12345  ",	//Prob.ITM
		"12345 ",	//Vega
		"13660   ",	//Theta
		"13660  ",	//Gamma
		"13660 ",	//Delta
		"13660 (12.5%)",	//Last (IV)
		

		"1234567",	//Strike

		
		"13660 (12.5%)",	//Last(IV) 
		"13660 ",	//Delta
		"13660  ",	//Gamma
		"13660   ",	//TheTa
		"12345 ",	//Vega
		"12345  ",	//Prob.ITM
		"12345  "
	};

	for(int i =0; i< MACRO_PBMaxSubItems ; i++)
	{
		m_nColDefWidth[i] = m_pList1->GetStringWidth( szDefaults[i] ) + 5 ;	
	}

}

LRESULT CTTOptions::SetWindowTextEx(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	HWND hWnd = NULL;
	if( wParam == 0 && ::IsWindow(hWnd = m_pedtCash->GetSafeHwnd()))
	{
//		::PostMessage(hWnd, WM_SETTEXT, 0, (LPARAM)m_szCash);
		m_pedtCash->SetWindowText( m_szCash );
	}
	else if( wParam == 1 && ::IsWindow(hWnd = m_pedtFutures->GetSafeHwnd()))
	{
//		::PostMessage(hWnd, WM_SETTEXT, 0, (LPARAM)m_szFutures);
		m_pedtFutures->SetWindowText(m_szFutures);
	}
	else if( wParam == 2 && ::IsWindow(hWnd = m_pedtFutures->GetSafeHwnd()))
	{
//		::PostMessage(hWnd, WM_SETTEXT, 0, (LPARAM)m_szFutures);
		m_pedtVHSI->SetWindowText(m_szVHSI);
	}
	else if( wParam == 3 && ::IsWindow(hWnd = m_pedtFutures->GetSafeHwnd()))
	{
		m_pedtEAS->SetWindowText(m_szEAS);
	}
	return 0;
}

void CTTOptions::SendDFChlFrame(BOOL bConnect)
{
	FrameLen    framelen;
	FrameHead	framehead;
	DSFrameID		frameid;
	unsigned short	wElemType;
	
	framelen = sizeof(FrameHead) + sizeof(DSFrameID) + sizeof(ElementType) + sizeof(char);
	memset(&framehead, 0, sizeof(framehead));
	framehead.wFrameType = TT_DT_785;
	memset(&frameid,NULL,sizeof(DSFrameID)); 
	
	wElemType = 'RQ';
	
	CComPtr<IStream> pIStream;
	CreateStreamOnHGlobal(NULL,TRUE,&pIStream);
	ULARGE_INTEGER size;
	size.QuadPart = framelen + sizeof(framelen);
	pIStream->SetSize(size);
	SeekFromBegin(pIStream, 0);
	
	HRESULT hr = pIStream->Write(&framelen, sizeof(framelen), NULL);
	hr = pIStream->Write(&framehead, sizeof(framehead), NULL);
	hr = pIStream->Write(&frameid, sizeof(frameid), NULL);
	hr = pIStream->Write(&wElemType, sizeof(wElemType), NULL);
	unsigned char cbRT= (bConnect==TRUE) ?  'C' : 'D' ;
	hr = pIStream->Write(&cbRT, sizeof(cbRT), NULL);
	
	SubmitRQ(pIStream,'DF');
}

void CTTOptions::SendDFRequestFrame()
{
//	WriteLogFile("SendDFRequestFrame");
	// w2t���ȷ� 785ͨ��������Ϣ.
	SendDFChlFrame( TRUE ) ;
	
	FrameLen    framelen;
	FrameHead	framehead;
	DSFrameID		frameid;
	unsigned short	wElemType;
	
	framelen = sizeof(FrameHead) + sizeof(DSFrameID) + sizeof(ElementType) + sizeof(char);
	memset(&framehead, 0, sizeof(framehead));
	framehead.wFrameType = TT_DT_785;
	memset(&frameid,NULL,sizeof(DSFrameID)); 
	
	wElemType = 'RQ';
	
	CComPtr<IStream> pIStream;
	CreateStreamOnHGlobal(NULL,TRUE,&pIStream);
	ULARGE_INTEGER size;
	size.QuadPart = framelen + sizeof(framelen);
	pIStream->SetSize(size);
	SeekFromBegin(pIStream, 0);
	
	HRESULT hr = pIStream->Write(&framelen, sizeof(framelen), NULL);
	hr = pIStream->Write(&framehead, sizeof(framehead), NULL);
	hr = pIStream->Write(&frameid, sizeof(frameid), NULL);
	hr = pIStream->Write(&wElemType, sizeof(wElemType), NULL);
	unsigned char cbRT = 'H' ;
	hr = pIStream->Write(&cbRT, sizeof(cbRT), NULL);
	
	SubmitRQ(pIStream,'DF');
}

void CTTOptions::SendEndFrame()
{
	SendTeleUpdateRQ(FALSE);
	SendUpdateRQ(FALSE);
}

void CTTOptions::ResizeHeaderCtrl() //���¼��� m_pHeader �Ŀ���
{
	short iTotal = GetColumnsTotal( *m_pList1 ) ;
	
	LVCOLUMN col ;
	col.mask = LVCF_WIDTH ;

	int nWidth[3] = {0,0,0} ;
	int nIndex = 0 ;
	int nLastIndex = 0 ;

	memset( nWidth, 0, sizeof(nWidth) ) ;
	for( short i=0;i<iTotal;i++ )
	{
		if( m_bIVMode!=2 )
		{
			if( i==POS_STRIKE )
				nIndex = 1 ;
			else if( i==11 )
				nIndex = 2 ;
		}
		else
		{
			if( i>14 )
				break;

			if( i==7 )
				nIndex = 1 ;
			else if( i==8 )
				nIndex = 2 ;
		}

		m_pList1->GetColumn( i, &col ) ;
		nWidth[nIndex] += col.cx ;
		
	}
	nWidth[0]++;// ���� + 1 ʹ�����ܶ���

	for( i=0;i<3;i++ )
	{
		HDITEM item ;
		item.mask = HDI_WIDTH ;
		item.cxy = nWidth[i] ; 
		m_pHeader->SetItem( i, &item ) ;
	}

	

	m_pHeader->RedrawWindow() ;

}

void CTTOptions::OnLstHScr() //ʹ�ⲿ��ͷλ��  ���� ListCtrl��ͷ�仯
{
	CRect HeaderRect ;
	m_pHeader->GetWindowRect( HeaderRect ) ;
	m_pwndBgn->ScreenToClient( HeaderRect ) ;

	CRect temp ;
	m_pList1->GetHeaderCtrl()->GetWindowRect( temp ) ;
	m_pList1->ScreenToClient( temp ) ;
	HeaderRect.left = temp.left ;
	HeaderRect.right += temp.right ;
	m_pHeader->MoveWindow( HeaderRect ) ;
	
}

STDMETHODIMP CTTOptions::SaveValue()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	USES_CONVERSION;

	ULONG len = 0;

	// --- Add request by Hope
	IStorage* pCtrlStg = NULL;
	if(GetControlStg((IUnknown**)&pCtrlStg) != S_OK)
		return E_FAIL;
	// --- Add request by Hope

	CComPtr<IStream> pIStream;
	pCtrlStg->CreateStream(L"Value", STGM_CREATE | STGM_READWRITE | 
		STGM_SHARE_EXCLUSIVE, 0, 0, &pIStream);
	if( pIStream == NULL )
	{
		PutControlStg();
		return E_FAIL;
	}

	pIStream->Write(m_szItemCode, 8, &len);
	pIStream->Write(m_szFuturesTitle, 6, &len);
	pIStream->Write(&m_lTransdate, sizeof(long), &len);
	m_PTransdate = m_lTransdate;
	pIStream->Write(&m_nFontSize, sizeof(short), &len);
	pIStream->Write(&m_strFontName, 100, &len);

	// first save lst.
	if( m_pList1->m_hWnd!=NULL )
	{
		short iTotal = GetColumnsTotal( *m_pList1 ) ;
		LVCOLUMN col ;
		col.mask = LVCF_WIDTH ;
		for( short i=0;i<iTotal;i++ )
		{
			m_pList1->GetColumn( i, &col ) ;
			short cx = col.cx ;
			m_pLstHeadsInfo->m_pBuf[i].m_nWidth = cx ;
		}

	}

	short iTotal = (short)m_pLstHeadsInfo->m_nBufTotal ;
	pIStream->Write(&iTotal, 2, &len);
	for( short i=0;i<iTotal;i++ )
	{
		short cx ;
		cx = (short)m_pLstHeadsInfo->m_pBuf[i].m_nWidth ;
		pIStream->Write(&cx, 2, &len);
	}

	pIStream->Write(&m_bShowHighPrice, sizeof(long), &len);
	pIStream->Write(m_szItemCashCode, 8, &len);
	pIStream->Write(&m_bIVMode, sizeof(long), &len);
	pIStream->Write(&m_bSimple, sizeof(long), &len);
	//
	pIStream->Write(m_szOptCode, 5, &len);

	pIStream.Release();
/*
	int nMonths, k;
	POSITION pos;
	if(pCtrlStg->CreateStream(L"MonthList", STGM_CREATE \
		| STGM_WRITE | STGM_SHARE_EXCLUSIVE, 0, 0, &pIStream) != S_OK)
		goto RELEASESTG;
	nMonths = m_lstMonths.GetCount();
	pIStream->Write(&nMonths, sizeof(nMonths), NULL);
	pos = m_lstMonths.GetHeadPosition();
	for(k = 0; k < nMonths; k++)
	{
		LONG theMonth = m_lstMonths.GetNext(pos);
		pIStream->Write(&theMonth, sizeof(theMonth), NULL);
	}
	pIStream.Release();
*/
//RELEASESTG:
	// --- Add request by Hope
	PutControlStg();
	// --- Add request by Hope
	
	return S_OK;
}

STDMETHODIMP CTTOptions::GetControlStg(IUnknown **punk)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	VARIANT var;
	var.vt = VT_UNKNOWN;
	VARIANT *pVar = &var;
	
	CComQIPtr<ITTObject,&IID_ITTObject> pObj(m_pMainFrm);
	if(pObj == NULL)
		S_FALSE;
			
	var.vt = VT_I4;
	var.lVal = m_nControlID;

	if(pObj->GetByID(TTPID_ControlStorage, &pVar) != S_OK)
		return E_FAIL;

	*punk = pVar->punkVal;
	if(*punk != NULL)
	{
		return S_OK;
	}
	else
	{
		return E_FAIL;
	}

}

STDMETHODIMP CTTOptions::PutControlStg()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	VARIANT var;
	var.vt = VT_UNKNOWN;
	VARIANT *pVar = &var;
	
	CComQIPtr<ITTObject,&IID_ITTObject> pObj(m_pMainFrm);
	if(pObj == NULL)
		S_FALSE;
			
	// --------- Add --------------------
	var.vt = VT_I4;
	var.lVal = m_nControlID;
	// --------- Add --------------------

	pObj->PutByID(TTPID_ControlStorage, pVar);
	return S_OK;

}

STDMETHODIMP CTTOptions::PutPrivateStg()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	VARIANT var;
	var.vt = VT_UNKNOWN;
	VARIANT *pVar = &var;
	
	CComQIPtr<ITTObject,&IID_ITTObject> pObj(m_pMainFrm);
	if(pObj == NULL)
		S_FALSE;		

	// --------- Add --------------------
	var.vt = VT_I4;
	var.lVal = m_nControlID;
	// --------- Add --------------------

	pObj->PutByID(TTPID_PrivateStorage, pVar);
	return S_OK;

}

STDMETHODIMP CTTOptions::GetPrivateStg(IUnknown **punk)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here

	VARIANT var;
	var.vt = VT_UNKNOWN;
	VARIANT *pVar = &var;
	
	CComQIPtr<ITTObject,&IID_ITTObject> pObj(m_pMainFrm);
	if(pObj == NULL)
		S_FALSE;		

	var.vt = VT_I4;
	var.lVal = m_nControlID;

	if(pObj->GetByID(TTPID_PrivateStorage, &pVar) != S_OK)
		return E_FAIL;

	*punk = pVar->punkVal;

	if(*punk != NULL)
		return S_OK;
	else
		return E_FAIL;

}

STDMETHODIMP CTTOptions::LoadValue()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
//	if(m_pCtrlStg == NULL)
//		return 1;
	// --- Add request by Hope
	IStorage* pCtrlStg = NULL;
	if(GetControlStg((IUnknown**)&pCtrlStg) != S_OK)
		return E_FAIL;
	// --- Add request by Hope

	CComPtr<IStream> pIStream;
	ULONG len = 0;
	if(pCtrlStg->OpenStream(L"Value", 0, STGM_READWRITE | STGM_SHARE_EXCLUSIVE, 
		0, &pIStream) == S_OK)
	{	//m_bClick_SelMonth = TRUE;	
		pIStream->Read(m_szItemCode, 8, &len);
		pIStream->Read(m_szFuturesTitle, 6, &len);
		pIStream->Read(&m_lTransdate, sizeof(long), &len);
		if(m_bSystemdesktop)//2012.1.5 daniel Ϊϵͳ����ȡ��ǰ����
			m_lTransdate = CTime::GetCurrentTime().GetYear()*100 + CTime::GetCurrentTime().GetMonth();
	    m_PTransdate=m_lTransdate;//2011.12.29 daniel ��ȡ�·�
	
		sprintf(m_szText, "%2d/%4d",m_lTransdate%100,m_lTransdate/100);
		MakeFutCode(m_szFuturesCode,m_szFuturesTitle,
			m_lTransdate % 100, (m_lTransdate/100)%100);

		pIStream->Read(&m_nFontSize, sizeof(short), &len);
		pIStream->Read(m_strFontName, 100, &len);

		m_font.DeleteObject() ;
		m_font.CreatePointFont( m_nFontSize, m_strFontName ) ;

		short iTotal = 0 ;
		pIStream->Read(&iTotal, 2, &len);
		if( len==2 )
		{
			for( short i=0;i<iTotal && i<m_pLstHeadsInfo->m_nBufTotal;i++ )
			{
				short cx ;
				pIStream->Read(&cx, 2, &len);
				if (cx>200)cx=53;  //daniel 2013.8.16

				m_pLstHeadsInfo->m_pBuf[i].m_nWidth = cx ;	

//				ATLTRACE("LoadValue = %d %d\r\n", i,cx) ;
			}
		}

		pIStream->Read(&m_bShowHighPrice, sizeof(long), &len);		
		pIStream->Read(m_szItemCashCode, 8, &len);
		pIStream->Read(&m_bIVMode, sizeof(long), &len);
		pIStream->Read(&m_bSimple, sizeof(long), &len);
		pIStream->Read(m_szOptCode, 5, &len);
	}
	else
	{
		pCtrlStg->CreateStream(L"Value", STGM_CREATE | STGM_READWRITE |
			STGM_SHARE_EXCLUSIVE, 0, 0, &pIStream);
		
		pIStream->Write(m_szItemCode, 8, &len);
		pIStream->Write(m_szFuturesTitle, 6, &len);
		pIStream->Write(&m_lTransdate, sizeof(long), &len);
		pIStream->Write(&m_nFontSize, sizeof(short), &len);
		pIStream->Write(m_strFontName, 100, &len);

		// first save lst.
		if( m_pList1->m_hWnd!=NULL )
		{
			short iTotal = GetColumnsTotal( *m_pList1 ) ;
			LVCOLUMN col ;
			col.mask = LVCF_WIDTH ;
			for( short i=0;i<iTotal;i++ )
			{
				m_pList1->GetColumn( i, &col ) ;
				short cx = col.cx ;
				m_pLstHeadsInfo->m_pBuf[i].m_nWidth = cx ;

			}

		}

		short iTotal = (short)m_pLstHeadsInfo->m_nBufTotal ;
		pIStream->Write(&iTotal, 2, &len);
		for( short i=0;i<iTotal;i++ )
		{
			short cx ;
			cx = (short)m_pLstHeadsInfo->m_pBuf[i].m_nWidth ;
			pIStream->Write(&cx, 2, &len);
		}

		pIStream->Write(&m_bShowHighPrice, sizeof(long), &len);	
		pIStream->Write(m_szItemCashCode, 8, &len);
		pIStream->Write(&m_bIVMode, sizeof(long), &len);
		pIStream->Write(&m_bSimple, sizeof(long), &len);
		pIStream->Write(m_szOptCode, 5, &len);
	}
	pIStream.Release();
/*
	int nMonths, k;
	if(pCtrlStg->OpenStream(L"MonthList", NULL, STGM_READ | STGM_SHARE_EXCLUSIVE, \
			0, &pIStream) != S_OK)
		goto RELEASESTG;

	if(pIStream->Read(&nMonths, sizeof(nMonths), NULL) != S_OK)
		goto RELEASESTG;
	m_lstMonths.RemoveAll();
	for(k = 0; k < nMonths; k++)
	{
		LONG theMonth;
		if(pIStream->Read(&theMonth, sizeof(theMonth), NULL) != S_OK)
			break;
		m_lstMonths.AddTail(theMonth);
	}
*/
//RELEASESTG:
	// --- Add request by Hope
	PutControlStg();
	// --- Add request by Hope
	return S_OK;
}

void CTTOptions::ResetCtrls()
{
	UpdateTitle() ;
	ResetFrmTitle() ;
	ResetTable() ;
	SetAllFont( m_strFontName, m_nFontSize ) ;



	m_pLstHeadsInfo->CreateLstHead( *m_pList1 ) ;
	m_pList1->m_bShowHighPrice = m_bShowHighPrice;
	m_pList1->m_bIVMode = m_bIVMode;
//	m_pList1->m_bSimpleMode = m_bSimple;
	//SendRequestFrame();
	UpdateListHearTitle();
}

void CTTOptions::UpdateListHearTitle()
{

	SwitchListHearTitle();
	SetLang();
	SetAllFont( m_strFontName, m_nFontSize ) ;

	m_pList1->m_bShowHighPrice = m_bShowHighPrice;
	m_pList1->m_bIVMode = m_bIVMode;

/*	if(m_bIVMode>0)
		m_pbtnHighPrice->EnableWindow(FALSE);
	else
		m_pbtnHighPrice->EnableWindow(TRUE);
*/
}

void CTTOptions::SwitchListHearTitle()
{
	int i = 0;

	if(m_bIVMode == 0)
	{
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT ) ;  // LVCFMT_RIGHT no effect ???
		m_pLstHeadsInfo->m_pBuf[i++].Config( "High", "���", "�̰�", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Low", "���", "�̧C", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vol","����", "�`��", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "L.Q.","����", "���i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last", "�ɼ�", "����", 64/*80*/, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q.", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid", "����", "�R�J", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask",  "����", "��X", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q.", "����", "��i", 30, LVCFMT_RIGHT ) ;
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Strike",  "��ʹ��", "��ϻ�", 30, LVCFMT_RIGHT ) ;

		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid",  "����", "�R�J", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask","����", "��X", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q", "����", "��i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last","�ɼ�", "����", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "L.Q.","����", "���i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vol","����", "�`��", 64, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "High", "���", "�̰�", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Low", "���", "�̧C", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT  ) ;
	}
	else if(m_bIVMode == 1)
	{
		
		//andy modify 2003.11.05 ԭ����Ĭ���п���50��"�ɽ���"��80�� ��ʾ��ȫ
		//ben 2017.07.18  �ɼۼ��ϲ��� �п���Ϊ80
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT ) ;  // LVCFMT_RIGHT no effect ???
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vega","Vega", "Vega", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Theta", "Theta", "Theta", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Gamma", "Gamma", "Gamma", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Delta", "Delta", "Delta", 64/*80*/, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config("Last(IV)", "�ɼ�(����)", "����(IV)",/*40*/80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q.", "����", "�R�i", 30, LVCFMT_RIGHT ) ;

		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid(IV)", "����(����)", "�R�J(IV)", 80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask(IV)",  "����(����)", "��X(IV)", 80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q.", "����", "��i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Strike",  "��ʹ��", "��ϻ�", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid(IV)", "����(����)", "�R�J(IV)", 80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask(IV)",  "����(����)", "��X(IV)", 80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q", "����", "��i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last(IV)","�ɼ�(����)", "����(IV)", /*40*/80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Delta","Delta", "Delta", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Gamma", "Gamma", "Gamma", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Theta", "Theta", "Theta", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vega","Vega", "Vega", 64, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT  ) ;
	}
	else if(m_bIVMode == 2)
	{
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Margin", "����(��)", "����(��)", 70, LVCFMT_RIGHT ) ;  
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Prob.ITM", "Prob.ITM", "Prob.ITM", 64, LVCFMT_RIGHT ) ;  
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vega","Vega", "Vega", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Theta", "Theta", "Theta", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Gamma", "Gamma", "Gamma", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Delta", "Delta", "Delta", 64/*80*/, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config("Last(IV)", "�ɼ�(����)", "����(IV)",/*40*/80, LVCFMT_RIGHT ) ;
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Strike",  "��ʹ��", "��ϻ�", 30, LVCFMT_RIGHT ) ;

		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last(IV)","�ɼ�(����)", "����(IV)", /*40*/80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Delta","Delta", "Delta", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Gamma", "Gamma", "Gamma", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Theta", "Theta", "Theta", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vega","Vega", "Vega", 64, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Prob.ITM", "Prob.ITM", "Prob.ITM", 64, LVCFMT_RIGHT ) ; 
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Margin", "����(��)", "����(��)", 70, LVCFMT_RIGHT ) ; 
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
	}
	else if( m_bIVMode==3 )
	{
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 0, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vega","Vega", "Vega", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Theta", "Theta", "Theta", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Gamma", "Gamma", "Gamma", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Delta", "Delta", "Delta", 64/*80*/, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config("Last(IV)", "�ɼ�(����)", "����(IV)",/*40*/80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q.", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid(IV)", "����(����)", "�R�J(IV)", 80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask(IV)",  "����(����)", "��X(IV)", 80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q.", "����", "��i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Strike",  "��ʹ��", "��ϻ�", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid(IV)", "����(����)", "�R�J(IV)", 80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask(IV)",  "����(����)", "��X(IV)", 80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q", "����", "��i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last(IV)","�ɼ�(����)", "����(IV)", /*40*/80, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Delta","Delta", "Delta", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Gamma", "Gamma", "Gamma", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Theta", "Theta", "Theta", 30, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vega","Vega", "Vega", 64, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 0, LVCFMT_RIGHT ) ;
		 
	}
	else if( m_bIVMode==4 )
	{
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT ) ;  // LVCFMT_RIGHT no effect ???
		m_pLstHeadsInfo->m_pBuf[i++].Config( "High", "���", "�̰�", 0, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Low", "���", "�̧C", 0, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vol","����", "�`��", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "L.Q.","����", "���i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last", "�ɼ�", "����", 64/*80*/, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q.", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid", "����", "�R�J", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask",  "����", "��X", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q.", "����", "��i", 30, LVCFMT_RIGHT ) ;
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Strike",  "��ʹ��", "��ϻ�", 30, LVCFMT_RIGHT ) ;
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid",  "����", "�R�J", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask","����", "��X", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q", "����", "��i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last","�ɼ�", "����", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "L.Q.","����", "���i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vol","����", "�`��", 64, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "High", "���", "�̰�", 0, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Low", "���", "�̧C", 0, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT  ) ;
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
	}
	else if( m_bIVMode==5 )
	{
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Margin", "����(��)", "����(��)", 70, LVCFMT_RIGHT ) ;  // LVCFMT_RIGHT no effect ???
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "High", "���", "�̰�", 0, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Low", "���", "�̧C", 0, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vol","����", "�`��", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "L.Q.","����", "���i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last", "�ɼ�", "����", 64/*80*/, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q.", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid", "����", "�R�J", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask",  "����", "��X", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q.", "����", "��i", 30, LVCFMT_RIGHT ) ;
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Strike",  "��ʹ��", "��ϻ�", 30, LVCFMT_RIGHT ) ;
		
		m_pLstHeadsInfo->m_pBuf[i++].Config( "B.Q", "����", "�R�i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Bid",  "����", "�R�J", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Ask","����", "��X", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "A.Q", "����", "��i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Last","�ɼ�", "����", 40, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "L.Q.","����", "���i", 30, LVCFMT_RIGHT ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Vol","����", "�`��", 64, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "High", "���", "�̰�", 0, LVCFMT_RIGHT  ) ;
	//	m_pLstHeadsInfo->m_pBuf[i++].Config( "Low", "���", "�̧C", 0, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "Margin", "����(��)", "����(��)", 70, LVCFMT_RIGHT  ) ;
		m_pLstHeadsInfo->m_pBuf[i++].Config( "O/I(I/D)", "δƽ(����)", "����(�W��)", 80, LVCFMT_RIGHT  ) ;
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ; 
//		m_pLstHeadsInfo->m_pBuf[i++].Config( "", "", "", 0, LVCFMT_RIGHT ) ;
	}
}




void CTTOptions::ClearData()
{
	ResetTable() ;
	ResetView(); //johnny 20151030
	m_szCash[0] = 0 ;
	m_szFutures[0] = 0 ;
	::PostMessage(m_hWnd,CM_SETWINDOWTEXT,0,0);	// Cash SetWindowText
	::PostMessage(m_hWnd,CM_SETWINDOWTEXT,1,0);	// Furture SetWindowText.
}

