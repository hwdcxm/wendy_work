// Strategy.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "Strategy.h"
#include "listctrlOptions.h"
//#include "wndBgn.h"
#include "btnInList.h"
#include "MyEdit.h"
#include "MySpinCtrl.h"
#include "MyComBo.h"
#include "Target.h"
#include "Calendar.h"
#include "Diagonal.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStrategy dialog

const char* szDescription5 = "Sell Call";
const char* szDescription6 = "Buy Call";

const char* szDescription1 = "Buy Call";
const char* szDescription2 = "Buy Put";
const char* szDescription3 = "Sell Call";
const char* szDescription4 = "Sell Put";
char* szDescription7 = "Buy Stock";
char* szDescription8 = "Sell Stock";

const CString strAdd = " (OTM)";
const char* szTip = "The upper and lower strikes must both be equidistant from the middle strike ";

char* szType[3] = {"Type","����","����"};
char* szStgy[3] = {"Strategy","����","����"};
char* szCount[3] = {"Qty","����","�ƶq"};
char* szVol[3] = {"Vol(M)","�м���ֵ","�����`��"};
char* szSize[3] = {"Size","ÿ�ݹ���","�C���Ѽ�"};
char* szJine[3] = {"Multiplier","��Լ����","��w����"};
char* szRefresh[3] = {"Refresh","ˢ��","��s"};
char* szManual[3] = {"Manual","�ֶ�","���"};
char* szStrike[3] = {"Strike","��ʹ��","��ϻ�"};
char* szDescrip[3] = {"Description","˵��","����"};
char* szBidAsk[3] = {"Bid/Ask","����/����","�R�J/��X��"};
char* szPreMium[3] = {"PreMium.M","��Ȩ��.��","���v��.��"};
char* szPreMium1[3] = {"PreMium.D","��Ȩ��.��","���v��.��"};
char* szFlutPL[3] = {"P/L","ӯ��","����"};
char* szFlutPL_T[3] = {"P/L(Amt)","ӯ�����","�������B"};
char* szMaxGain[3] = {"Max Gain","���ӯ��","�̤j�էQ"};
char* szMaxLoss[3] = {"Max Loss","������","�̤j���l"};
char* szBreak[3] = {"Breakeven","��ͼ�","���M��"};
char* szMode0[3] = {"Stgy","����","����"};
char* szMode1[3] = {"PV","ʹֵ","�h��"};
char* szMode2[3] = {"AMP","����","�i�T"};
char* szMode3[3] = {"P&L","ӯ��","����"};
char* szYK[3] = {"P&L($)","ӯ��($)","����($)"};
char* szWindowText[15] = {"Strategy","����","����","PV","ʹֵ","�h��","Strategy","����","����","Strategy","����","����","Strategy","����","����"};
char* szIVBlank[3] = {"P&L(%)","ӯ��(%)","����(%)"};
char* szInfinity[3] = {"Infinity","����","�L��"};
char* szApply[3] = {"Apply", "����", "�M��"};
char* szCustom[3] = {"Custom","�Զ���","�۩w�q"};
char* szBlank[3] = {"Blank","��","�L"};
char* szPrice_M[3] = {"Pr.M","�м�","����"};
char* szPrice_D[3] = {"Pr.D","�ɼ�","����"};
char* szStgyPB[3] = {"POP","��ϻ���","�զX���v"};
char* szStgyVG[3] = {"ROI","ֵ����","�ȳղv"};
char* szStgyRI[3] = {"Exp-Re","Ԥ�ڻر�","�w���^��"};
char* szStgyROI[3] = {"ROI","�ر���","�^���v"};

char* szIVTxt[] = {"P/L(%)","Delta","Vega","Gamma","Theta","C-Bid(IV)","C-Ask(IV)","P-Bid(IV)","P-Ask(IV)","C-Last(IV)","P-Last(IV)"};

char* szUL[3] = {"Upper  /  Lower","����  |  ֧��","���O  /  ���"};
char* szIVDaily[3] = {"Daily(IV)","ÿ�ղ���","�C��i�T"};
char* szIVWeekly[3] = {"Weekly(IV)","һ�ܲ���","�C�P�i�T"};
char* szIVBiweekly[3] = {"Biweekly(IV)","���ܲ���","�G�P�i�T"};
char* szIVMonthly[3] = {"Monthly(IV)","һ�²���","�@��i�T"};
char* szIVBimonthly[3] = {"Bimonthly(IV)","���²���","�G��i�T"};
char* szIVTrimonthly[3] = {"Trimonthly(IV)","���²���","�T��i�T"};
char* szIVDailyR[3] = {"Daily(IV-R)","ÿ�ղ�����Χ","�C��i�T�S��"};
char* szIVWeeklyR[3] = {"Weekly(IV-R)","ÿ�ܲ�����Χ","�C�P�i�T�S��"};
char* szIVMonthlyR[3] = {"Monthly(IV-R)","ÿ�²�����Χ","�C��i�T�S��"};
char* szOptPrice[3] = {"Opt Price", "��ļ۸�", "�Ъ�����"};

char* szTT0[3] = {"Strategy Table At Calculate MaxGain/MaxLoss (BSM)","�������ӯ/������� (����ģ��BSM)","�����̤j��/���p��� (��Ĭ�ҫ�BSM)"};
char* szTT1[3] = {"(BSM)Stdev unit PB percentage Calc Theo IV","����ģ��(BSM)��׼�λ���ʷ���ٷֱȼ������۲���","��Ĭ�ҫ�(BSM)�зǮt�����v���t�ʤ���p��z�תi�T"};
char* szTT2[3] = {"(BSM)Simulate Greeks Table In Group","����ģ��(BSM)�������Greeksͳ�Ʊ�","��Ĭ�ҫ�(BSM)�p��զXGreeks�έp��"};
char* szTT3[3] = {"(BSM)Simulate Theo P&L Table of remaining days","����ģ��(BSM)ģ�ⲻͬ������������ӯ����","��Ĭ�ҫ�(BSM)�������P�|�l�ѼƲz�׬�����"};
char* szTT4[3] = {"Strategy Table of Order Book","�����µ���¼ͳ�Ʊ�","�����U��O���έp��"};

char* szTT0_1[3] = {"Strategy Table At Calculate MaxGain/MaxLoss (CRR)","�������ӯ/������� (����ʽ����ģ��CRR)","�����̤j��/���p��� (�G�����w���ҫ�CRR)"};
char* szTT1_1[3] = {"(CRR)Stdev unit PB percentage Calc Theo IV","����ʽ����ģ��(CRR)��׼�λ���ʷ���ٷֱȼ������۲���","�G�����w���ҫ�(CRR)�зǮt�����v���t�ʤ���p��z�תi�T"};
char* szTT2_1[3] = {"(CRR)Simulate Greeks Table In Group","����ʽ����ģ��(CRR)�������Greeksͳ�Ʊ�","�G�����w���ҫ�(CRR)�p��զXGreeks�έp��"};
char* szTT3_1[3] = {"(CRR)Simulate Theo P&L Table of remaining days","����ʽ����ģ��(CRR)ģ�ⲻͬ������������ӯ����","�G�����w���ҫ�(CRR)�������P�|�l�ѼƲz�׬�����"};

char* szStkTip1[3] = {"the current strikes are useless(Be ascending)",
					  "��ѡ��ʹ�۲����γɲ���(����С����)",
					  "�ҿ��ϻ�����Φ�����(�ݥѤp��j)"};

char* szStkTip2[3] = {"have no open price",
					  "ׯ��û�п���",
					  "���a�S���}��"};

char* szPriceTip[3] = {"please input a valid price",
					   "������һ����Ч�ļ۸�",
					   "�п�J�@�Ӧ��Ī�����"};

char* szGKTips[4] = {"Position Delta(ESP)",
					 "Position Vega($/1%Change)",
					 "Position Gamma",
					 "Position Theta($/day)"};
char* szDelTips[3] = {"Delete record?","ɾ��������¼?","�R�������O��"};

char* szstaEXP[3] = {"R.Days","��������","�|�l�Ѽ�"};
char* szstaBF[3]  = {"IV","����","�i�T"};

char* szOdrBook[3] = {"order book","�µ���¼","�U��O��"};
char* szbookDate[3] = {"Date","����","���"};
char* szbookTime[3] = {"Time","ʱ��","�ɶ�"};
char* szDirection[3] = {"Direction","����","��V"};
char* szItem[3] = {"Item","���","�Ъ�"};
char* szLastP[3] = {"Last","�ɼ�","����"};
char* szExpTime[3] = {"EXP","������","�����"};
char* szDelete[3] = {"Del","ɾ��","�R��"};
char* szPLTotal[3] = {" P&L total($): ", "ӯ���ܼ�($): ", "�����`�p($): "};

char*  szExpDate[]={"EXP","������","������"};
char*  szRemainDay[] = {"(Days Remaining):", "(��������):", "(���N�씵):"};
char*  szWord[] = {"d", "��", "��"};

HHOOK   g_hHook = 0;
CStrategy* g_pDlg = NULL; 

CArrayFloat arr_IVX, arr_IV, arr_Greeks[4];  //Y����

CStrategy::CStrategy(CWnd* pParent /*=NULL*/)
	: CDialog(CStrategy::IDD, pParent)
{
	m_iDbClickInx = -1;
	m_fTheoIV = 15.0;
	m_nIndex = 0;
	m_nIndexIV = 0;
	m_lShares = 1;
	m_nIxStrike = -1;
	m_nIxStrike2 = -1;
	m_nIxStrike3 = -1;
	m_nIxStrike4 = -1;
	m_nIxStrike5 = -1;
	m_nIxStrike6 = -1;
	m_nRetn = 0;
	m_iSeconds = -1;
	m_bMode = 0;
	m_bTempMode = 0;
	m_nRow = 0;
	m_iCheck[0] = 1;
	m_iCheck[1] = 0;
	m_iCheck[2] = 0;
	iSign = -1;
	iSign1 = -1; 
	iSign2 = -1;
	iSign3 = -1;
	iSign4 = -1;
	m_nPos = -1;
	m_nPrePos = -1;
	m_nCkCount = 2;   //Ĭ�ϵ�һ���ѹ�ѡ�����ϵ�����һ����Ŀ��2
    m_bReLoadList2Data = TRUE;
	m_bDrawing = FALSE;
	m_fStgyPB = 1.0;
//	m_fEliminate = 0.0;
	m_fStock_C = 1.2;
	m_fLimitScale = 0.0;
	m_cx_TgtLo = -1;
	m_cx_TgtUp = -1;
	m_btMouseGet = 0;
	m_btMouseRelease = 1;
	m_bSelectLo = FALSE;
	m_bSelectUp = FALSE;
	m_bItemCodeChange = FALSE;
	m_lCaldExpDate1 = -1;
	m_lCaldExpDate2 = -1;
	m_iCaldInx1 = -1;
	m_iCaldInx2 = -1;
	m_iExpDays = 0;
/*
	m_fScale = 0.0;
	m_nOrderCount = 1;
	for( int i=0;i<6;i++ )
	{
		m_nCustomCount[i] = 0;
		m_nCustomIx[i] = 6;//6������  ��ѡ��Ȩ
	}
	m_nCustomCount[1] = 1;
	m_nCustomIx[1] = 1; //�Զ����ʼԤ��һ�� long call
*/
	ClearFlag();

	m_bTarget = 0;
	m_nItem = -1;
	m_nSubItem = -1;
	m_bHaveCrt = FALSE;
	m_bHaveCrt_Spin = FALSE;
	m_bHaveCrt_Spin_C = FALSE;
	m_bCrtCombo = FALSE;
	m_bBtnDown[0] = FALSE;
	m_bBtnDown[1] = FALSE;
	m_bFillList = TRUE;
	m_bDbClick = FALSE;
	m_bWeekly = 0;


	m_bShowTip = FALSE;
	m_bPainted = TRUE;
	m_bOrder = FALSE;
	m_bUseRecord = FALSE;
	m_bTransColor = FALSE;
	m_fIVedit = 0.0;
	for( int i=0;i<3;i++ )
	{
		m_bResetBF[i] = TRUE;	
	}
	m_iOdr = -1;
	for( i=0;i<6;i++ )
	{
		m_fLPrice[i] = 0.0;
		m_fiSignPrice[i] = 0.0;
		m_bAlterPrice[i] = FALSE;
		m_bAlterPrice2[i] = FALSE;
		m_bPrice[i] = TRUE;
	}

	m_pBtn = new CbtnInList();
	m_pBtn->m_pStgy = this;
	m_editCrt = new CMyEdit();
	m_editCrt->m_pStgy = this;
	m_pSpin = new CMySpinCtrl();
	m_pSpin->m_pStgy = this;
	m_pSpin_C = new CMySpinCtrl();
	m_pSpin_C->m_pStgy = this;

	for( i=0;i<5;i++ )
	{
		m_pSpinEx[i] = new CMySpinCtrl();
		m_pSpinEx[i]->m_pStgy = this;
	}

	m_pCombo = new CMyComBo();
	m_pCombo->m_pStgy = this;

	m_hCursor = LoadCursor(NULL,IDC_ARROW);

	memset(&m_cald_calinfo1,0,sizeof(BSMCALINFO));
	memset(&m_cald_calinfo2,0,sizeof(BSMCALINFO));

	InitializeCriticalSection(&m_cs);
}

CStrategy::~CStrategy()
{
}

void CStrategy::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStrategy)
	DDX_Control(pDX, IDC_BTN_MODE, m_btnMode);
	DDX_Control(pDX, IDC_LIGHT, m_light);
	DDX_Control(pDX, IDC_EDIT_TT3, m_edit3);
	DDX_Control(pDX, IDC_EDIT_TT2, m_edit2);
	DDX_Control(pDX, IDC_LIST2, m_list2);
	DDX_Control(pDX, IDC_BTN_CK, m_btnJianc);
	DDX_Control(pDX, IDC_TAB1, m_tab1);
	DDX_Control(pDX, IDC_EDIT_TT, m_edit);
	DDX_Control(pDX, IDC_EDIT_IV3, m_editIV3);
	DDX_Control(pDX, IDC_EDIT_IV2, m_editIV2);
	DDX_Control(pDX, IDC_EDIT_IV1, m_editIV1);
	DDX_Control(pDX, IDC_BTN_SAVE, m_BtnSave);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_CHECK3, m_ck3);
	DDX_Control(pDX, IDC_CHECK2, m_ck2);
	DDX_Control(pDX, IDC_CHECK1, m_ck1);
	DDX_Control(pDX, IDC_SELBOX, m_SelBox);
	DDX_Control(pDX, IDC_BTN_R, m_BtnR);
	DDX_Control(pDX, IDC_BTN_L, m_BtnL);
	DDX_Control(pDX, IDC_DAY3, m_staDay3);
	DDX_Control(pDX, IDC_DAY2, m_staDay2);
	DDX_Control(pDX, IDC_DAY1, m_staDay1);
	DDX_Control(pDX, IDC_STAPRICE4, m_staPrice4);
	DDX_Control(pDX, IDC_STACOST4, m_staCost4);
	DDX_Control(pDX, IDC_STA4, m_CrlStatic4);
	DDX_Control(pDX, IDC_COMBO_STRIKE4, m_ComBoxStrike4);
	DDX_Control(pDX, IDC_STAPL4, m_staPL4);
	DDX_Control(pDX, IDC_STAPL3, m_staPL3);
	DDX_Control(pDX, IDC_STAPL2, m_staPL2);
	DDX_Control(pDX, IDC_STAPL1, m_staPL1);
	DDX_Control(pDX, IDC_REFRESH, m_btnRefresh);
	DDX_Control(pDX, IDC_CMBTIME, m_CMBTime);
	DDX_Control(pDX, IDC_STAPRICE3, m_staPrice3);
	DDX_Control(pDX, IDC_STAPRICE2, m_staPrice2);
	DDX_Control(pDX, IDC_STAPRICE1, m_staPrice1);
	DDX_Control(pDX, IDC_STACOST3, m_staCost3);
	DDX_Control(pDX, IDC_STACOST2, m_staCost2);
	DDX_Control(pDX, IDC_STACOST1, m_staCost1);
	DDX_Control(pDX, IDC_STASIZE, m_staSize);
	DDX_Control(pDX, IDC_IVDATA, m_CMBIVData);
	DDX_Control(pDX, IDC_COMBO_STRIKE3, m_ComBoxStrike3);
	DDX_Control(pDX, IDC_COMBO_STRIKE2, m_ComBoxStrike2);
	DDX_Control(pDX, IDC_STA3, m_CrlStatic3);
	DDX_Control(pDX, IDC_STA2, m_CrlStatic2);
	DDX_Control(pDX, IDC_STA1, m_CrlStatic1);
	DDX_Control(pDX, IDC_COMBO_STRIKE, m_ComBoxStrike);
	DDX_Control(pDX, IDC_FRAME, m_frame);
	DDX_Control(pDX, IDC_COMBO_TYPE, m_ComBoxType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStrategy, CDialog)
	//{{AFX_MSG_MAP(CStrategy)
	ON_WM_PAINT()
	ON_CBN_SELCHANGE(IDC_COMBO_TYPE, OnSelchangeComboType)
	ON_WM_CTLCOLOR()
	ON_CBN_SELCHANGE(IDC_COMBO_STRIKE, OnSelchangeComboStrike)
	ON_CBN_SELCHANGE(IDC_COMBO_STRIKE2, OnSelchangeComboStrike2)
	ON_CBN_SELCHANGE(IDC_COMBO_STRIKE3, OnSelchangeComboStrike3)
	ON_CBN_SELCHANGE(IDC_IVDATA, OnSelchangeIvdata)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_CBN_SELCHANGE(IDC_CMBTIME, OnSelchangeCmbtime)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BTN_MODE, OnBtnMode)
	ON_CBN_SELCHANGE(IDC_COMBO_STRIKE4, OnSelchangeComboStrike4)
	ON_WM_DESTROY()
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST1, OnCustomDraw)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST2, OnCustomDraw1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, OnDeltaposSpin1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN2, OnDeltaposSpin2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN3, OnDeltaposSpin3)
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_BTN_R, OnBtnR)
	ON_BN_CLICKED(IDC_BTN_L, OnBtnL)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_BN_CLICKED(IDC_CHECK2, OnCheck2)
	ON_BN_CLICKED(IDC_CHECK3, OnCheck3)
	ON_BN_CLICKED(IDC_BTN_SAVE, OnBtnSave)
	ON_COMMAND(IDC_PL, OnPl)
	ON_COMMAND(IDC_DE, OnDe)
	ON_COMMAND(IDC_VE, OnVe)
	ON_COMMAND(IDC_GA, OnGa)
	ON_COMMAND(IDC_TH, OnTh)
	ON_COMMAND(IDC_CB, OnCb)
	ON_COMMAND(IDC_CA, OnCa)
	ON_COMMAND(IDC_PB, OnPb)
	ON_COMMAND(IDC_PA, OnPa)
	ON_COMMAND(IDC_CL, OnCl)
	ON_COMMAND(IDC_PLA, OnPla)
	ON_WM_RBUTTONUP()
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN4, OnDeltaposSpin4)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN5, OnDeltaposSpin5)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN6, OnDeltaposSpin6)
	ON_NOTIFY(NM_CLICK, IDC_LIST1, OnClickList1)
	ON_WM_SHOWWINDOW()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, OnSelchangeTab1)
	ON_EN_SETFOCUS(IDC_EDIT_IV1, OnSetfocusEditIv1)
	ON_EN_SETFOCUS(IDC_EDIT_IV2, OnSetfocusEditIv2)
	ON_EN_SETFOCUS(IDC_EDIT_IV3, OnSetfocusEditIv3)
	ON_BN_CLICKED(IDC_BTN_CK, OnBtnCk)
	ON_NOTIFY(NM_CLICK, IDC_LIST2, OnClickList2)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST2, OnDblclkList2)
	ON_WM_MOVE()
	ON_EN_KILLFOCUS(IDC_EDIT_IV1, OnKillfocusEditIv1)
	ON_EN_KILLFOCUS(IDC_EDIT_IV2, OnKillfocusEditIv2)
	ON_EN_KILLFOCUS(IDC_EDIT_IV3, OnKillfocusEditIv3)
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_CLOSE()
	ON_COMMAND(ID_TARGET, OnTarget)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SETCURSOR()
	ON_NOTIFY(NM_RCLICK, IDC_LIST2, OnRclickList2)
	//}}AFX_MSG_MAP
	ON_MESSAGE( MACRO_MsgRedrawER, OnMyRedrawER ) 
	ON_MESSAGE( MACRO_MsgRedrawDiagonal, OnMyRedrawDiagonal ) 
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStrategy message handlers

LRESULT CALLBACK HookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if( nCode<0 ) 
	{
		return CallNextHookEx(g_hHook, nCode, wParam, lParam);
	}
	if( nCode==HC_ACTION&&lParam>0 )
	{
		return CallNextHookEx(g_hHook, nCode, wParam, lParam);
	}

	int nStart=-1,nEnd=-1;
	CString striv;
	CString szChar;
	switch( wParam )
	{
	case VK_NUMPAD0:
	case 48:
		szChar = "0";
		break;
	case VK_NUMPAD1:
	case 49:
		szChar = "1";
		break;
	case VK_NUMPAD2:
	case 50:
		szChar = "2";
		break;
	case VK_NUMPAD3:
	case 51:
		szChar = "3";
		break;
	case VK_NUMPAD4:
	case 52:
		szChar = "4";
		break;
	case VK_NUMPAD5:
	case 53:
		szChar = "5";
		break;
	case VK_NUMPAD6:
	case 54:
		szChar = "6";
		break;
	case VK_NUMPAD7:
	case 55:
		szChar = "7";
		break;
	case VK_NUMPAD8:
	case 56:
		szChar = "8";
		break;
	case VK_NUMPAD9:
	case 57:
		szChar = "9";
		break;
	case VK_DECIMAL:
	case 190:
		szChar = ".";
		break;
	}

	if( wParam==VK_BACK )
	{
		if( g_pDlg->GetDlgItem(IDC_EDIT_IV1)==g_pDlg->GetFocus() )
		{
			g_pDlg->m_editIV1.GetSel(nStart,nEnd);
			g_pDlg->m_editIV1.GetWindowText(striv);
			if( nStart!=nEnd )
				striv.Delete(nStart,nEnd-nStart);
			else if( nStart>0 )
				striv.Delete(nStart-1,1);
			
			g_pDlg->m_editIV1.SetWindowText(striv);
			if( nStart!=nEnd )
				g_pDlg->m_editIV1.SetSel(nStart,nStart);
			else if( nStart>0 )
				g_pDlg->m_editIV1.SetSel(nStart-1,nStart-1);
		}
		else if( g_pDlg->GetDlgItem(IDC_EDIT_IV2)==g_pDlg->GetFocus() )
		{
			g_pDlg->m_editIV2.GetSel(nStart,nEnd);
			g_pDlg->m_editIV2.GetWindowText(striv);
			if( nStart!=nEnd )
				striv.Delete(nStart,nEnd-nStart);
			else if( nStart>0 )
				striv.Delete(nStart-1,1);
			
			g_pDlg->m_editIV2.SetWindowText(striv);
			if( nStart!=nEnd )
				g_pDlg->m_editIV2.SetSel(nStart,nStart);
			else if( nStart>0 )
				g_pDlg->m_editIV2.SetSel(nStart-1,nStart-1);
		}
		else if( g_pDlg->GetDlgItem(IDC_EDIT_IV3)==g_pDlg->GetFocus() )
		{
			g_pDlg->m_editIV3.GetSel(nStart,nEnd);
			g_pDlg->m_editIV3.GetWindowText(striv);
			if( nStart!=nEnd )
				striv.Delete(nStart,nEnd-nStart);
			else if( nStart>0 )
				striv.Delete(nStart-1,1);
			
			g_pDlg->m_editIV3.SetWindowText(striv);
			if( nStart!=nEnd )
				g_pDlg->m_editIV3.SetSel(nStart,nStart);
			else if( nStart>0 )
				g_pDlg->m_editIV3.SetSel(nStart-1,nStart-1);
		}
		else if( g_pDlg->m_editCrt->GetSafeHwnd()==::GetFocus() )
		{
			g_pDlg->m_editCrt->GetSel(nStart,nEnd);
			g_pDlg->m_editCrt->GetWindowText(striv);
			if( nStart!=nEnd )
				striv.Delete(nStart,nEnd-nStart);
			else if( nStart>0 )
				striv.Delete(nStart-1,1);
			
			g_pDlg->m_editCrt->SetWindowText(striv);
			if( nStart!=nEnd )
				g_pDlg->m_editCrt->SetSel(nStart,nStart);
			else if( nStart>0 )
				g_pDlg->m_editCrt->SetSel(nStart-1,nStart-1);
		}
	}
	else if( (wParam>=VK_NUMPAD0&&wParam<=VK_NUMPAD9) || wParam==VK_DECIMAL || (wParam>=48&&wParam<=57) || wParam==190  )
	{
		if( g_pDlg->GetDlgItem(IDC_EDIT_IV1)==g_pDlg->GetFocus() )
		{
			g_pDlg->m_editIV1.GetSel(nStart,nEnd);
			g_pDlg->m_editIV1.GetWindowText(striv);
			if( wParam==VK_DECIMAL && striv.Find(".")!=-1 )
				return CallNextHookEx(g_hHook, nCode, wParam, lParam);
			if( nStart!=nEnd )
				striv.Delete(nStart,nEnd-nStart);
			striv.Insert(nStart,szChar);
			g_pDlg->m_editIV1.SetWindowText(striv);
			g_pDlg->m_editIV1.SetSel(nStart+1,nStart+1);
		}
		else if( g_pDlg->GetDlgItem(IDC_EDIT_IV2)==g_pDlg->GetFocus() )
		{
			g_pDlg->m_editIV2.GetSel(nStart,nEnd);
			g_pDlg->m_editIV2.GetWindowText(striv);
			if( wParam==VK_DECIMAL && striv.Find(".")!=-1 )
				return CallNextHookEx(g_hHook, nCode, wParam, lParam);
			if( nStart!=nEnd )
				striv.Delete(nStart,nEnd-nStart);
			striv.Insert(nStart,szChar);
			g_pDlg->m_editIV2.SetWindowText(striv);
			g_pDlg->m_editIV2.SetSel(nStart+1,nStart+1);
		}
		else if( g_pDlg->GetDlgItem(IDC_EDIT_IV3)==g_pDlg->GetFocus() )
		{
			g_pDlg->m_editIV3.GetSel(nStart,nEnd);
			g_pDlg->m_editIV3.GetWindowText(striv);
			if( wParam==VK_DECIMAL && striv.Find(".")!=-1 )
				return CallNextHookEx(g_hHook, nCode, wParam, lParam);
			if( nStart!=nEnd )
				striv.Delete(nStart,nEnd-nStart);
			striv.Insert(nStart,szChar);
			g_pDlg->m_editIV3.SetWindowText(striv);
			g_pDlg->m_editIV3.SetSel(nStart+1,nStart+1);
		}
		else if( g_pDlg->m_editCrt->GetSafeHwnd()==::GetFocus() )
		{
			g_pDlg->m_editCrt->GetSel(nStart,nEnd);
			g_pDlg->m_editCrt->GetWindowText(striv);
			if( wParam==VK_DECIMAL && striv.Find(".")!=-1 )
				return CallNextHookEx(g_hHook, nCode, wParam, lParam);
			if( nStart!=nEnd )
				striv.Delete(nStart,nEnd-nStart);
			striv.Insert(nStart,szChar);
			g_pDlg->m_editCrt->SetWindowText(striv);
			g_pDlg->m_editCrt->SetSel(nStart+1,nStart+1);
		}
	}

	if( g_pDlg->GetDlgItem(IDC_EDIT_IV1)==g_pDlg->GetFocus() 
		|| g_pDlg->GetDlgItem(IDC_EDIT_IV2)==g_pDlg->GetFocus()
		|| g_pDlg->GetDlgItem(IDC_EDIT_IV3)==g_pDlg->GetFocus() )
	{
		if( striv.Find(".")==0 || striv.Find(".")==striv.GetLength()-1 )
			return CallNextHookEx(g_hHook, nCode, wParam, lParam);
		
		g_pDlg->m_nRetn = g_pDlg->PrePaint();
		if( g_pDlg->m_nRetn==0 )
			return CallNextHookEx(g_hHook, nCode, wParam, lParam);
		g_pDlg->DrawIncomeLine();
	}
		
	
	return CallNextHookEx(g_hHook, nCode, wParam, lParam);
}

LRESULT CStrategy::OnMyRedrawDiagonal( WPARAM item, LPARAM subitem )
{
	m_fScale += 0.2;
	m_fLimitScale = m_fScale;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return 0;
	m_bPainted = TRUE;
	DrawIncomeLine();
}

LRESULT CStrategy::OnMyRedrawER( WPARAM item, LPARAM subitem )
{
	m_fScale += 0.2;
	m_fLimitScale = m_fScale;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return 0;
	m_bPainted = TRUE;
	DrawIncomeLine();

	return 0;
}

BOOL CStrategy::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_brush.CreateSolidBrush(RGB(255,255,255));
	m_brush1.CreateSolidBrush(RGB(247,141,147));

	m_ck1.SetCheck(1);

	m_ComBoxType.InsertString(0, "Long Butterfly");
	m_ComBoxType.InsertString(1, "Short Butterfly");
	m_ComBoxType.InsertString(2, "Long Straddle");
	m_ComBoxType.InsertString(3, "Short Straddle");
	m_ComBoxType.InsertString(4, "Long Strangle");
	m_ComBoxType.InsertString(5, "Short Strangle");
	m_ComBoxType.InsertString(6, "Iron Condor");
	m_ComBoxType.InsertString(7, "Long Call");
	m_ComBoxType.InsertString(8, "Long Put");
	m_ComBoxType.InsertString(9, "Short Call");
	m_ComBoxType.InsertString(10, "Short Put");
	m_ComBoxType.InsertString(11, "Bull Call Spread");
	m_ComBoxType.InsertString(12, "Bear Call Spread");
	m_ComBoxType.InsertString(13, "Bull Put Spread");
	m_ComBoxType.InsertString(14, "Bear Put Spread");
	m_ComBoxType.InsertString(15, "Covered Call");
	m_ComBoxType.InsertString(16, "Covered Put");
	m_ComBoxType.InsertString(17, "Calendar Spread");
	m_ComBoxType.InsertString(18, "Daigonal Spread");
	m_ComBoxType.InsertString(STGY_CUSTOM, szCustom[m_TTOptions->m_iLangType]);
	m_ComBoxType.SetCurSel(m_nIndex);

	CString strForm,strsz;
	m_editIV1.SetWindowText("0.0");	
	m_editIV2.SetWindowText("0.0");
	m_editIV3.SetWindowText("0.0");

	m_list.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);
	m_list2.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);
	InitGDI();

	GetDlgItem(IDC_EXP)->SetFont(&m_font1);
	GetDlgItem(IDC_BF)->SetFont(&m_font1);

	SwitchCtrl();
	m_iLangType = m_TTOptions->m_iLangType;
	SetLang();

	m_CMBTime.GetWindowRect(&m_rect1);
	m_btnRefresh.GetWindowRect(&m_rect2);
	GetDlgItem(IDC_BTN_MODE)->GetWindowRect(&m_rect3);
	m_BtnL.GetWindowRect(&m_rect4);
	m_BtnR.GetWindowRect(&m_rect5);
	m_frame.GetWindowRect(m_frmrect);
	GetWindowRect(m_WinRect);
	m_tab1.GetWindowRect(&m_TabRect);
	m_tab1.GetWindowRect(&m_TabClientRect);
	ScreenToClient(&m_frmrect);
	ScreenToClient(&m_rect1);
	ScreenToClient(&m_rect2);
	ScreenToClient(&m_rect3);
	ScreenToClient(&m_rect4);
	ScreenToClient(&m_rect5);

	ScreenToClient(&m_TabClientRect);

	m_list.GetWindowRect(&m_RectLst1);
	m_list2.GetWindowRect(&m_RectLst2);
	m_edit2.GetWindowRect(&m_RectEd2);
	m_edit3.GetWindowRect(&m_RectEd3);
	ScreenToClient(&m_RectLst1);
	ScreenToClient(&m_RectLst2);
	ScreenToClient(&m_RectEd2);
	ScreenToClient(&m_RectEd3);

	MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top);

	CRect rc;
	GetDlgItem(IDC_IVT1)->GetWindowRect(&rc);
	ScreenToClient(&rc);
	m_editIV1.MoveWindow(&rc);
	GetDlgItem(IDC_IVT2)->GetWindowRect(&rc);
	ScreenToClient(&rc);
	m_editIV2.MoveWindow(&rc);
	GetDlgItem(IDC_IVT3)->GetWindowRect(&rc);
	ScreenToClient(&rc);
	m_editIV3.MoveWindow(&rc);
	
	pdc = this->GetDC();
	MemDC.CreateCompatibleDC(pdc);
	MemBitmap.CreateCompatibleBitmap(pdc,m_frmrect.Width()-6,m_frmrect.Height()-12);
	CBitmap *pOldBit = MemDC.SelectObject(&MemBitmap);


	m_tab1.InsertItem(0,"Table");
	m_tab1.InsertItem(1,"Order");

	CreateBtn();
	CreateSpin(&m_list,m_pSpin,2,2,m_bHaveCrt_Spin);

	m_arrITC.RemoveAll();
	ReadStgyHistoryFile();
	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CStrategy::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
	}
	else
	{
		if( m_bMode==1 )
			m_nRetn = CalcPainValue();
		else 
		{
			
		}
		CDialog::OnPaint();
	}
	// Do not call CDialog::OnPaint() for painting messages
}

BOOL CStrategy::OnEraseBkgnd(CDC* pDC) 
{
//	return CDialog::OnEraseBkgnd( pDC );

	CRect frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);
	
	MemDC.FillSolidRect(0, 0, frmrect.Width(),frmrect.Height(), RGB(0,0,0));
	
	pdc->BitBlt(frmrect.left,frmrect.top,frmrect.Width(),frmrect.Height(),&MemDC,0,0,SRCCOPY);

	return TRUE;
}

void CStrategy::OnCustomDraw1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMLVCUSTOMDRAW lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;

	int i;
    switch(lplvcd->nmcd.dwDrawStage)
	{
	case CDDS_PREPAINT:
	    *pResult = CDRF_NOTIFYITEMDRAW;
	    break;
    case CDDS_ITEMPREPAINT: 
	    *pResult = CDRF_NOTIFYSUBITEMDRAW;
	    break;
	case  (CDDS_ITEMPREPAINT | CDDS_SUBITEM):
		{
			COLORREF clrNewTextColor, clrNewBkColor;
			clrNewTextColor = RGB(0,0,0);
			clrNewBkColor = RGB(255,255,255);
			int    nItem = static_cast<int>( lplvcd->nmcd.dwItemSpec );
			int    nSubItem = static_cast<int>( lplvcd->iSubItem );

			for( i=0;i<m_arrNum.GetSize()-1;i++ )
			{
				if( nItem>=m_arrNum[i].nItem && nItem<m_arrNum[i+1].nItem ) 
					break;
			}
			if( i%2==0 )
				clrNewBkColor = RGB(176,224,230);
			else if( i%2==1 )
				clrNewBkColor = RGB(240,230,140);
			
			lplvcd->clrTextBk = clrNewBkColor;

			int stgyix;
			if( m_StgyList[i].m_iCustomIx[6]==1 )
				stgyix = m_StgyList[i].m_iCustomIx[7];
			else
				stgyix = m_StgyList[i].m_fCapital;
		/*	if( stgyix==17 && m_StgyList[i].m_lExpTime==m_ExtList[i].cald.lMonth2 )
			{
				if( nSubItem==3||nSubItem==4||nSubItem==6||nSubItem==7||nSubItem==8||nSubItem==9 )
				{
					if( nItem==m_arrNum[i].nItem )
					{
						clrNewTextColor = RGB(119,136,153);
						lplvcd->clrText = clrNewTextColor;
					}
				}
				else
				{
					clrNewTextColor = RGB(0,0,0);
					lplvcd->clrText = clrNewTextColor;
				}
			}*/

			if( nSubItem==11 )
			{
				clrNewTextColor = RGB(255,0,0);
				lplvcd->clrText = clrNewTextColor;
			}
			else if( nSubItem==10 )
			{
				for( i=0;i<m_arrNum.GetSize();i++ )
				{
					if( nItem==m_arrNum[i].nItem )
					{
						if( m_arrNum[i].bPrice==FALSE )
							clrNewTextColor = RGB(255,0,255);
						
						break;
					}
				}

				lplvcd->clrText = clrNewTextColor;
			}
			
			
			
			
			*pResult = CDRF_DODEFAULT;
		}
		break;
	}
}

void CStrategy::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMLVCUSTOMDRAW lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;

	int i,j,k1,k2;
	int nCount;
    switch(lplvcd->nmcd.dwDrawStage)
	{
	case CDDS_PREPAINT:
	    *pResult = CDRF_NOTIFYITEMDRAW;
	    break;
    case CDDS_ITEMPREPAINT: 
	    *pResult = CDRF_NOTIFYSUBITEMDRAW;
	    break;
	case  (CDDS_ITEMPREPAINT | CDDS_SUBITEM):
		{
			COLORREF clrNewTextColor, clrNewBkColor;
			clrNewTextColor = RGB(0,0,0);
			int    nItem = static_cast<int>( lplvcd->nmcd.dwItemSpec );
			int    nSubItem = static_cast<int>( lplvcd->iSubItem );
			if( m_bMode==0 )
			{
				if( !m_bUseRecord )
				{
					if(nItem < (m_nRow+2) )
					{
						clrNewBkColor = RGB(240,230,140); 
						if( nItem==1 && nSubItem>=7 )
							clrNewBkColor = RGB(222,184,87); 
						if( nItem>=2 )
						{
							if( nSubItem==4||nSubItem==5 )
								clrNewBkColor = RGB(255,218,185); 
							if( m_nIndex==STGY_CUSTOM && (nSubItem==1||nSubItem==3) )
							{
								if( nSubItem==3 && m_nCustomIx[nItem-2]!=4 && m_nCustomIx[nItem-2]!=5 )
									clrNewBkColor = RGB(255,218,185); 
								else if( nSubItem==1 )
									clrNewBkColor = RGB(255,218,185); 
							}
							if( (m_nIndex==15||m_nIndex==16) && nItem==3&&nSubItem==3 )
								clrNewBkColor = RGB(255,218,185); 
						}
					}
					else
						clrNewBkColor = RGB(176,224,230); 
				}
				else
				{
					if( nItem==0 )
					{
						clrNewBkColor = RGB(255,0,0);
						clrNewTextColor = RGB(255,255,255);
					}
					else if( nItem==1 && nSubItem>=7 )
						clrNewBkColor = RGB(222,184,87); 
					else if(nItem < (m_nRow+2) )
					{
						clrNewBkColor = RGB(240,230,140);
						if( nItem==1&&nSubItem==7&&m_bTransColor )
							clrNewTextColor = RGB(255,0,255); 
						if( (nSubItem==4||nSubItem==7) && nItem>=2  )
						{
							if( m_bPrice[nItem-2]==FALSE )
							{
								clrNewTextColor = RGB(255,0,255); 
							}
						}
						
					}
					else
						clrNewBkColor = RGB(176,224,230); 

					if( (nItem==m_nRow+3||nItem==m_nRow+2) && nSubItem==5 )
						clrNewTextColor = RGB(255,0,0); 
					if( nItem==m_nRow+3 && (nSubItem==7||nSubItem==8) )
						clrNewTextColor = RGB(255,0,0); 
				}
			}
			else if( m_bMode==2 )
			{
				if(nItem <= 4 )
					clrNewBkColor = RGB(240,230,140);   
				else
					clrNewBkColor = RGB(176,224,230); 
			}
			else
			{
				if( nSubItem<1 )
					clrNewBkColor = RGB(240,230,140);
				else
					clrNewBkColor = RGB(176,224,230);
			}
			
			lplvcd->clrTextBk = clrNewBkColor;
			lplvcd->clrText = clrNewTextColor;
			
			*pResult = CDRF_DODEFAULT;
		}
		break;
	}
}

float CStrategy::linear_equation(BOOL bBuy,BOOL bCall,float fStrike,float fXData)
{
	float fCalc = 0.0;
	if( bBuy && bCall ) //buy call
	{
		if( fXData<=fStrike )
			;
		else 
			fCalc = fXData - fStrike;
	}
	else if( bBuy && !bCall ) //buy put
	{
		if( fXData<=fStrike )
			fCalc = fStrike - fXData;
		else
			;
	}
	else if( !bBuy && bCall ) //sell call
	{
		if( fXData<=fStrike )
			;
		else
			fCalc = fStrike - fXData;
	}
	else if( !bBuy && !bCall ) //sell put
	{
		if( fXData<=fStrike )
			fCalc = fXData - fStrike;
		else
			;
	}
	
	return fCalc;
}

void CStrategy::SwitchCtrl()
{
	CString str1,str2;
	m_ComBoxType.EnableWindow(TRUE);
	if( m_nIndex!=17 && m_nIndex!=18 )
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_SHOW);

	switch( m_nIndex )
	{
	case 0:
	case 1:
		m_ComBoxStrike.EnableWindow(TRUE);
		m_ComBoxStrike2.EnableWindow(TRUE);
		m_ComBoxStrike3.EnableWindow(TRUE);
		m_ComBoxStrike.ShowWindow(SW_SHOW);
		m_ComBoxStrike2.ShowWindow(SW_SHOW);
		m_ComBoxStrike3.ShowWindow(SW_SHOW);
		m_ComBoxStrike4.ShowWindow(SW_HIDE);
		m_btnJianc.ShowWindow(SW_SHOW);
		m_btnJianc.EnableWindow(TRUE);
		m_nRow = 3;
		break;
	case 2:
	case 3:
		m_ComBoxStrike.EnableWindow(TRUE);
		m_ComBoxStrike2.EnableWindow(FALSE);
		m_ComBoxStrike.ShowWindow(SW_SHOW);
		m_ComBoxStrike3.ShowWindow(SW_HIDE);
		m_ComBoxStrike4.ShowWindow(SW_HIDE);
		m_ComBoxStrike2.ShowWindow(SW_SHOW);
		m_btnJianc.ShowWindow(SW_HIDE);
		m_nRow = 2;
		break;
	case 4:
	case 5:
	case 11:
	case 12:
	case 13:
	case 14:
		m_ComBoxStrike.EnableWindow(TRUE);
		m_ComBoxStrike2.EnableWindow(TRUE);
		m_ComBoxStrike3.ShowWindow(SW_HIDE);
		m_ComBoxStrike4.ShowWindow(SW_HIDE);
		m_ComBoxStrike.ShowWindow(SW_SHOW);
		m_ComBoxStrike2.ShowWindow(SW_SHOW);
		m_btnJianc.ShowWindow(SW_HIDE);
		m_nRow = 2;
		break;
	case 6:
		m_ComBoxStrike.EnableWindow(TRUE);
		m_ComBoxStrike2.EnableWindow(TRUE);
		m_ComBoxStrike3.EnableWindow(TRUE);
		m_ComBoxStrike4.EnableWindow(TRUE);
		m_ComBoxStrike.ShowWindow(SW_SHOW);
		m_ComBoxStrike3.ShowWindow(SW_SHOW);
		m_ComBoxStrike4.ShowWindow(SW_SHOW);
		m_ComBoxStrike2.ShowWindow(SW_SHOW);
		m_btnJianc.ShowWindow(SW_SHOW);
		m_btnJianc.EnableWindow(TRUE);
		m_nRow = 4;
		break;
	case 7:
	case 8:
	case 9:
	case 10:
		m_ComBoxStrike.EnableWindow(TRUE);
		m_ComBoxStrike2.ShowWindow(SW_HIDE);
		m_ComBoxStrike3.ShowWindow(SW_HIDE);
		m_ComBoxStrike4.ShowWindow(SW_HIDE);
		m_ComBoxStrike.ShowWindow(SW_SHOW);
		m_btnJianc.ShowWindow(SW_HIDE);
		m_nRow = 1;
		break;
	case STGY_CUSTOM:
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		m_ComBoxStrike.ShowWindow(SW_HIDE);
		m_ComBoxStrike2.ShowWindow(SW_HIDE);
		m_ComBoxStrike3.ShowWindow(SW_HIDE);
		m_ComBoxStrike4.ShowWindow(SW_HIDE);
		m_btnJianc.ShowWindow(SW_HIDE);
		m_nRow = 6;
		break;
	case 15:
	case 16:
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		m_ComBoxStrike.ShowWindow(SW_HIDE);
		m_ComBoxStrike2.ShowWindow(SW_HIDE);
		m_ComBoxStrike3.ShowWindow(SW_HIDE);
		m_ComBoxStrike4.ShowWindow(SW_HIDE);
		m_btnJianc.ShowWindow(SW_HIDE);
		m_nRow = 2;
		break;
	case 17:
	case 18:
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		m_ComBoxStrike.ShowWindow(SW_HIDE);
		m_ComBoxStrike2.ShowWindow(SW_HIDE);
		m_ComBoxStrike3.ShowWindow(SW_HIDE);
		m_ComBoxStrike4.ShowWindow(SW_HIDE);
		m_btnJianc.ShowWindow(SW_SHOW);
		m_btnJianc.EnableWindow(TRUE);
		m_nRow = 2;
		break;
	}
	
}

void CStrategy::SetLang()
{
	m_ComBoxType.DeleteString(STGY_CUSTOM);
	m_ComBoxType.InsertString(STGY_CUSTOM,szCustom[m_TTOptions->m_iLangType]);
	m_ComBoxType.SetCurSel(m_nIndex);

	m_CMBTime.ResetContent();
	m_CMBTime.InsertString(0, szManual[m_TTOptions->m_iLangType]);
	m_CMBTime.InsertString(1, "5s");
	m_CMBTime.InsertString(2, "10s");
	m_CMBTime.InsertString(3, "15s");
	m_CMBTime.InsertString(4, "20s");
	m_CMBTime.InsertString(5, "30s");
	m_CMBTime.SetCurSel(0);

	m_CMBIVData.ResetContent();
	m_CMBIVData.InsertString(0, szIVBlank[m_TTOptions->m_iLangType]);
	m_CMBIVData.InsertString(1, "Delta");
	m_CMBIVData.InsertString(2, "Vega");
	m_CMBIVData.InsertString(3, "Gamma");
	m_CMBIVData.InsertString(4, "Theta");
	m_CMBIVData.InsertString(5, "C-Bid IV ");
	m_CMBIVData.InsertString(6, "C-Ask IV");
	m_CMBIVData.InsertString(7, "P-Bid IV");
	m_CMBIVData.InsertString(8, "P-Ask IV");
	m_CMBIVData.InsertString(9, "C-Last IV");
	m_CMBIVData.InsertString(10, "P-Last IV");
	m_CMBIVData.SetCurSel(m_nIndexIV);
	

	CString str;
	str = szWindowText[int(m_bMode)*3+m_TTOptions->m_iLangType];
	str +="(";
	str += m_TTOptions->m_szItemCode;
	str += ")";
	SetWindowText(str);

	if( m_bMode==0 )
	{
		CString strgy;
		m_ComBoxType.GetWindowText(strgy);
		if( IsIndex() )
			strgy += szTT0[m_TTOptions->m_iLangType];
		else
			strgy += szTT0_1[m_TTOptions->m_iLangType];
		m_edit.SetWindowText(strgy);
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode0[m_TTOptions->m_iLangType]);
	}
	else if( m_bMode==1 ) 
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode1[m_TTOptions->m_iLangType]);
	else if( m_bMode==2 ) 
	{
		if( IsIndex() )
			m_edit.SetWindowText(szTT1[m_TTOptions->m_iLangType]);
		else
			m_edit.SetWindowText(szTT1_1[m_TTOptions->m_iLangType]);
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode2[m_TTOptions->m_iLangType]);
	}
	else if( m_bMode==3 )
	{
		if( IsIndex() )
			m_edit.SetWindowText(szTT2[m_TTOptions->m_iLangType]);
		else
			m_edit.SetWindowText(szTT2_1[m_TTOptions->m_iLangType]);
		GetDlgItem(IDC_BTN_MODE)->SetWindowText("Greeks");
	}
	else if( m_bMode==4 )
	{
		if( IsIndex() )
			m_edit.SetWindowText(szTT3[m_TTOptions->m_iLangType]);
		else
			m_edit.SetWindowText(szTT3_1[m_TTOptions->m_iLangType]);
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode3[m_TTOptions->m_iLangType]);
	}

	GetDlgItem(IDC_STATIC1)->SetWindowText(szType[m_TTOptions->m_iLangType]);
	GetDlgItem(IDC_STATIC2)->SetWindowText(szStrike[m_TTOptions->m_iLangType]);
	m_btnRefresh.SetWindowText(szRefresh[m_TTOptions->m_iLangType]);

	GetDlgItem(IDC_EXP)->SetWindowText(szstaEXP[m_TTOptions->m_iLangType]);
	GetDlgItem(IDC_BF)->SetWindowText(szstaBF[m_TTOptions->m_iLangType]);
	m_btnJianc.SetWindowText(szApply[m_TTOptions->m_iLangType]);
	
	SetListMode();
	SelectType();
	//if( m_nIxStrike!=-1 && m_nIxStrike!=-2 )
	if( m_nRetn==1 )
		SufPaint();
	
}

BOOL CStrategy::GetTextGK(LPTSTR pszText, float fValue, BYTE cbDecimal)
{
	
	if(cbDecimal < 0 || pszText == NULL )
		return FALSE;
	if(fabs(fValue) < 0.0001)
	{
		cbDecimal = 6;
	}
	else if( fabs(fValue)>=1.0 )
	{
		cbDecimal = 2;
	}

	DWORD	hibyte = 0;
	if( m_nDay1==0 )
		fValue = 0.0;

	switch(cbDecimal)
	{
	case 0:
		_stprintf(pszText,_T("%.0f "),fValue);
		break;
	case 1:
		_stprintf(pszText,_T("%.1f "),fValue);
		break;
	case 2:
		_stprintf(pszText,_T("%.2f "),fValue);
		break;
	case 3:
		_stprintf(pszText,_T("%.3f "),fValue);    
		break;
	case 4:
		_stprintf(pszText,_T("%.4f "),fValue);
		break;
	case 6:
		_stprintf(pszText,_T("%.6f "),fValue);
		break;
	default:
		lstrcpy(pszText,_T(""));
		break;
	}
	return TRUE;
}

int CStrategy::GetPriceTxt(float fo,CString &strprice,int flag)  
{
	if( fo==0.0 )
	{
		strprice = "0";
		return -1;
	}

	CString str;
	str.Format("%.6f",fo);
	int pos = str.Find(".");
	str.TrimRight('0');
	pos = str.GetLength()-pos-1;
	if( pos>4 )
	{
		pos = m_TTOptions->m_cbDecimal;
		int i,strlen;
		for( i=2;i<=4;i++ )
		{
			BOOL bBrk = FALSE;
			switch(i)
			{
			case 2:
				str.Format("%.2f",fo);
				break;
			case 3:
				str.Format("%.3f",fo);
				break;
			case 4:
				str.Format("%.4f",fo);
				break;
			}
			strlen = str.GetLength();
			str.TrimRight('0');
			if(strlen!=str.GetLength())
			{
				pos = str.Find(".");
				pos = str.GetLength()-pos-1;
				bBrk = TRUE;
			}
			if( bBrk )
				break;
		}
	}

	if( flag==1 )
		pos = m_TTOptions->m_cbDecimal;
	
	switch( pos )
	{
	case 4:
		strprice.Format("%.4f",fo);
		break;
	case 3:
		strprice.Format("%.3f",fo);
		break;
	case 2:
		strprice.Format("%.2f",fo);
		break;
	case 1:
		strprice.Format("%.1f",fo);
		break;
	case 0:
		strprice.Format("%.0f",fo);
		break;
	}
	
	return pos;
}

void BIG52GBK(char *szBuf)
{
	if( !strcmp(szBuf,"") )
		return;

	int nStrLen = strlen(szBuf);
	wchar_t *pws = new wchar_t[nStrLen];

	int nReturn = MultiByteToWideChar(950,0,szBuf,nStrLen,pws,nStrLen+1);
	BOOL bValue = FALSE;
	nReturn = WideCharToMultiByte(936,0,pws,nReturn,szBuf,nStrLen+1,"?",&bValue);
	szBuf[nReturn] = 0;
	delete[] pws;
}

BOOL CStrategy::IsIndex_Ext(char *code)
{
	if( memcmp(code,"HSI    ",7)==0 
		|| memcmp(code,"HSCEI  ",7)==0 
		|| memcmp(code,"MHI    ",7)==0 
		|| memcmp(code,"MCH    ",7)==0 )
		return TRUE;

	return FALSE;
}

BOOL CStrategy::IsIndex()
{
	if( memcmp(m_TTOptions->m_szItemCode,"HSI    ",7)==0 
		|| memcmp(m_TTOptions->m_szItemCode,"HSCEI  ",7)==0 
		|| memcmp(m_TTOptions->m_szItemCode,"MHI    ",7)==0 
		|| memcmp(m_TTOptions->m_szItemCode,"MCH    ",7)==0 )
		return TRUE;

	return FALSE;
}

void CStrategy::SetListMode()
{	
	if( !m_bFillList )
		return;
	CString strCustom[7];
	strCustom[0] = "Sell Call";
	strCustom[1] = "Buy Call";
	strCustom[2] = "Sell Put";
	strCustom[3] = "Buy Put";
	strCustom[4] = "Sell Stock";
	strCustom[5] = "Buy Stock";
	strCustom[6] = "-- --";
	int nCount, i;
	CString str1, str2;
	CString strtemp;
	CString strgy;
	CString str;

	int iDate;
	CTime tm;
	CTime time = CTime::GetCurrentTime();;
	iDate = m_TTOptions->m_lExpiryDays-m_nDay1;
	CTimeSpan span( iDate,0,0,0 );
	iDate = m_TTOptions->m_lExpiryDays-m_nDay2;
	CTimeSpan span1( iDate,0,0,0 );
	iDate = m_TTOptions->m_lExpiryDays-m_nDay3;
	CTimeSpan span2( iDate,0,0,0 );

	switch( m_bMode )
	{
	case 0:
		m_list.ModifyStyle(0,LVS_NOCOLUMNHEADER);
		m_ComBoxType.GetWindowText(strgy);
		strgy += " ";
		if( IsIndex() )
			strgy += szTT0[m_TTOptions->m_iLangType];
		else
			strgy += szTT0_1[m_TTOptions->m_iLangType];
		m_edit.SetWindowText(strgy);
		nCount = m_list.GetHeaderCtrl()->GetItemCount();
		for( i=0;i<nCount;i++ )
			m_list.DeleteColumn(0);
		m_list.InsertColumn(0,"1234",LVCFMT_RIGHT,120);
		if( m_nIndex>=16 )
			m_list.InsertColumn(1,"1234",LVCFMT_CENTER,130);
		else
			m_list.InsertColumn(1,"1234",LVCFMT_CENTER,120);
		m_list.InsertColumn(2,"1234",LVCFMT_CENTER,50);
		m_list.InsertColumn(3,"1234",LVCFMT_CENTER,80);
		m_list.InsertColumn(4,"1234",LVCFMT_RIGHT,60);
		m_list.InsertColumn(5,"1234",LVCFMT_RIGHT,60);
		m_list.InsertColumn(6,"1234",LVCFMT_RIGHT,60);
		m_list.InsertColumn(7,"1234",LVCFMT_RIGHT,75);
		m_list.InsertColumn(8,"1234",LVCFMT_CENTER,55);
		m_list.InsertColumn(9,"1234",LVCFMT_CENTER,65);
		m_list.InsertColumn(10,"1234",LVCFMT_CENTER,65);
		m_list.InsertColumn(11,"1234",LVCFMT_CENTER,65);
		
		m_list.DeleteAllItems();
		
		m_list.InsertItem(0,szStgy[m_TTOptions->m_iLangType]);
		for( i=1;i<m_nRow+2;i++)
			m_list.InsertItem(m_nRow,"");
		
		m_list.InsertItem(m_nRow+2,"");
		m_list.InsertItem(m_nRow+3,"");
		m_list.InsertItem(m_nRow+4,"");
		if( m_nIndex!=6 && m_nIndex!=STGY_CUSTOM )
			m_list.InsertItem(m_nRow+5,"");
		if( (m_nIndex>=2 && m_nIndex<=5) || (m_nIndex>=7 && m_nIndex!=STGY_CUSTOM) )
			m_list.InsertItem(m_nRow+6,"");
		if( m_nIndex>=7 && m_nIndex<=10 )
			m_list.InsertItem(m_nRow+7,"");

		if( IsIndex() )
			m_list.SetItemText(m_nRow+4,3,szJine[m_TTOptions->m_iLangType]);
		else
			m_list.SetItemText(m_nRow+4,3,szSize[m_TTOptions->m_iLangType]);
		
		m_list.SetItemText(0,1,szDescrip[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,2,szCount[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,3,szStrike[m_TTOptions->m_iLangType]);
		//if( m_nIndex==15||m_nIndex==16 )
		{
			m_list.SetItemText(0,4,szPrice_M[m_TTOptions->m_iLangType]);
			m_list.SetItemText(0,5,szPrice_D[m_TTOptions->m_iLangType]);
		}
		/*else
		{
			m_list.SetItemText(0,4,szPreMium[m_TTOptions->m_iLangType]);
			m_list.SetItemText(0,5,szPreMium1[m_TTOptions->m_iLangType]);
		}*/
		m_list.SetItemText(0,6,szFlutPL[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,7,szFlutPL_T[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,8,"Delta");
		m_list.SetItemText(0,9,"Vega");
		m_list.SetItemText(0,10,"Gamma");
		m_list.SetItemText(0,11,"Theta");
		m_list.SetItemText(m_nRow+2,0,szBreak[m_TTOptions->m_iLangType]);
		m_list.SetItemText(m_nRow+3,0,szMaxGain[m_TTOptions->m_iLangType]);
		m_list.SetItemText(m_nRow+4,0,szMaxLoss[m_TTOptions->m_iLangType]);
		m_list.SetItemText(m_nRow+2,3,szStgyPB[m_TTOptions->m_iLangType]);
		m_list.SetItemText(m_nRow+3,3,szStgyRI[m_TTOptions->m_iLangType]);
		m_list.SetItemText(m_nRow+4,6,szStgyVG[m_TTOptions->m_iLangType]);
		m_list.SetItemText(m_nRow+2,6,szStgyROI[m_TTOptions->m_iLangType]);
		
		m_ComBoxType.GetLBText(m_nIndex,strtemp);
		m_list.SetItemText(1,0,strtemp);
		if( m_nIndex==17 )
			m_list.SetItemText(1,0,"Calendar");
		else if( m_nIndex==18 )
			m_list.SetItemText(1,0,"Diagonal");
		switch( m_nIndex )
		{
		case 0:
			m_list.SetItemText(2,1,szDescription1);
			m_list.SetItemText(3,1,szDescription5);
			m_list.SetItemText(4,1,szDescription1);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",-2*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(4,2,str);
			break;
		case 1:
			m_list.SetItemText(2,1,szDescription3);
			m_list.SetItemText(3,1,szDescription6);
			m_list.SetItemText(4,1,szDescription3);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",2*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(4,2,str);
			break;
		case 2:
			m_list.SetItemText(2,1,szDescription1);
			m_list.SetItemText(3,1,szDescription2);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 3:
			m_list.SetItemText(2,1,szDescription3);
			m_list.SetItemText(3,1,szDescription4);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 4:
			str1 = szDescription1;
			str1 += strAdd;
			str2 = szDescription2;
			str2 += strAdd;
			m_list.SetItemText(2,1,str1);
			m_list.SetItemText(3,1,str2);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 5:
			str1 = szDescription3;
			str1 += strAdd;
			str2 = szDescription4;
			str2 += strAdd;
			m_list.SetItemText(2,1,str1);
			m_list.SetItemText(3,1,str2);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 6:
			str1 = szDescription2;
			str1 += strAdd;
			str2 = szDescription4;
			str2 += strAdd;
			m_list.SetItemText(2,1,str1);
			m_list.SetItemText(3,1,str2);
			str1 = szDescription3;
			str1 += strAdd;
			str2 = szDescription1;
			str2 += strAdd;
			m_list.SetItemText(4,1,str1);
			m_list.SetItemText(5,1,str2);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(4,2,str);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(5,2,str);
			break;
		case 7:
			m_list.SetItemText(2,1,szDescription1);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			break;
		case 8:
			m_list.SetItemText(2,1,szDescription2);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			break;
		case 9:
			m_list.SetItemText(2,1,szDescription3);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(2,2,str);
			break;
		case 10:
			m_list.SetItemText(2,1,szDescription4);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(2,2,str);
			break;
		case 11:
			m_list.SetItemText(2,1,szDescription1);
			m_list.SetItemText(3,1,szDescription3);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 12:
			m_list.SetItemText(2,1,szDescription3);
			m_list.SetItemText(3,1,szDescription1);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 13:
			m_list.SetItemText(2,1,szDescription2);
			m_list.SetItemText(3,1,szDescription4);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 14:
			m_list.SetItemText(2,1,szDescription4);
			m_list.SetItemText(3,1,szDescription2);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 15:
			m_list.SetItemText(2,1,szDescription7);
			m_list.SetItemText(3,1,szDescription3);
			str.Format("%d",m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 16:
			m_list.SetItemText(2,1,szDescription8);
			m_list.SetItemText(3,1,szDescription4);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(2,2,str);
			str.Format("%d",-1*m_nOrderCount);
			m_list.SetItemText(3,2,str);
			break;
		case 17:
		case 18:
			if( m_cald.bDebit==0 )
			{
				str.Format("%d",-1*m_nOrderCount);
				m_list.SetItemText(2,2,str);
				str.Format("%d",m_nOrderCount);
				m_list.SetItemText(3,2,str);
			}
			else
			{
				str.Format("%d",m_nOrderCount);
				m_list.SetItemText(2,2,str);
				str.Format("%d",-1*m_nOrderCount);
				m_list.SetItemText(3,2,str);
			}
			break;
		case STGY_CUSTOM:
			for( i=0;i<6;i++ )
			{
				m_list.SetItemText(i+2,1,strCustom[m_nCustomIx[i]]);
				str.Format("%d",m_nCustomCount[i]);
				m_list.SetItemText(i+2,2,str);
			}
			break;
		}
		break;
	case 2:
		m_list.ModifyStyle(0,LVS_NOCOLUMNHEADER);
		if( IsIndex() )
			m_edit.SetWindowText(szTT1[m_TTOptions->m_iLangType]);
		else
			m_edit.SetWindowText(szTT1_1[m_TTOptions->m_iLangType]);
		nCount = m_list.GetHeaderCtrl()->GetItemCount();
		for( i=0;i<nCount;i++ )
			m_list.DeleteColumn(0);
		m_list.InsertColumn(1,"1234",LVCFMT_RIGHT,59);
		m_list.InsertColumn(2,"1234",LVCFMT_CENTER,136);
		m_list.InsertColumn(3,"1234",LVCFMT_CENTER,136);
		m_list.InsertColumn(4,"1234",LVCFMT_CENTER,136);
		m_list.InsertColumn(5,"1234",LVCFMT_CENTER,136);
		m_list.InsertColumn(6,"1234",LVCFMT_CENTER,136);
		m_list.InsertColumn(7,"1234",LVCFMT_CENTER,136);
		
		m_list.DeleteAllItems();
		m_list.InsertItem(0,"");
		m_list.InsertItem(1,"68%");
		m_list.InsertItem(2,"80%");
		m_list.InsertItem(3,"90%");
		m_list.InsertItem(4,"95%");
		m_list.InsertItem(5,"");
		m_list.InsertItem(6,"68%");
		m_list.InsertItem(7,"80%");
		m_list.InsertItem(8,"90%");
		m_list.InsertItem(9,"95%");
		m_list.SetItemText(0,1,szIVDaily[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,2,szIVWeekly[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,3,szIVBiweekly[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,4,szIVMonthly[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,5,szIVBimonthly[m_TTOptions->m_iLangType]);
		m_list.SetItemText(0,6,szIVTrimonthly[m_TTOptions->m_iLangType]);
		m_list.SetItemText(5,1,szUL[m_TTOptions->m_iLangType]);
		m_list.SetItemText(5,2,szUL[m_TTOptions->m_iLangType]);
		m_list.SetItemText(5,3,szUL[m_TTOptions->m_iLangType]);
		m_list.SetItemText(5,4,szUL[m_TTOptions->m_iLangType]);
		m_list.SetItemText(5,5,szUL[m_TTOptions->m_iLangType]);
		m_list.SetItemText(5,6,szUL[m_TTOptions->m_iLangType]);
		break;
	case 3:
		m_list.ModifyStyle(LVS_NOCOLUMNHEADER,0);
		if( IsIndex() )
			m_edit.SetWindowText(szTT2[m_TTOptions->m_iLangType]);
		else
			m_edit.SetWindowText(szTT2_1[m_TTOptions->m_iLangType]);
		nCount = m_list.GetHeaderCtrl()->GetItemCount();
		for( i=0;i<nCount;i++ )
			m_list.DeleteColumn(0);
		
		m_list.InsertColumn(0,szOptPrice[m_TTOptions->m_iLangType],LVCFMT_CENTER,80);
		m_list.InsertColumn(1,"Delta",LVCFMT_CENTER,120);
		m_list.InsertColumn(2,"Vega",LVCFMT_CENTER,120);
		m_list.InsertColumn(3,"Gamma",LVCFMT_CENTER,120);
		m_list.InsertColumn(4,"Theta",LVCFMT_CENTER,120);
		m_list.InsertColumn(5,"",LVCFMT_CENTER,255+40);

		m_list.DeleteAllItems();
		break;
	case 4:
		m_list.ModifyStyle(LVS_NOCOLUMNHEADER,0);
		if( IsIndex() )
			m_edit.SetWindowText(szTT3[m_TTOptions->m_iLangType]);
		else
			m_edit.SetWindowText(szTT3_1[m_TTOptions->m_iLangType]);
		nCount = m_list.GetHeaderCtrl()->GetItemCount();
		for( i=0;i<nCount;i++ )
			m_list.DeleteColumn(0);

		m_list.InsertColumn(0,"Price",LVCFMT_CENTER,160);

		tm = time+span;
		str = tm.Format("%m/%d/%Y");
		m_list.InsertColumn(1,str,LVCFMT_CENTER,180);

		tm = time+span1;
		str = tm.Format("%m/%d/%Y");
		m_list.InsertColumn(2,str,LVCFMT_CENTER,180);

		tm = time+span2;
		str = tm.Format("%m/%d/%Y");
		m_list.InsertColumn(3,str,LVCFMT_CENTER,180);
		m_list.InsertColumn(4,"",LVCFMT_CENTER,115+40);

		m_list.DeleteAllItems();
		break;
	}

	
}

int CStrategy::GetCustomPriceAndType(int iIx, int iSign,float &fPrice)
{
	switch( iIx )
	{
	case 0:
	case 1:
		if( iSign!=-1 )
			fPrice = m_arrItem[iSign].m_fCalls_Nominal;
		else
			fPrice = 0.0;
		return POS_CALL_LAST;
	case 2:
	case 3:
		if( iSign!=-1 )
			fPrice = m_arrItem[iSign].m_fPuts_Nominal;
		else
			fPrice = 0.0;
		return POS_PUT_LAST;
	case 4:
	case 5:
		fPrice = m_TTOptions->GetCorrStockPrice(FALSE);
		return -1;
	case 6:
		fPrice = 0.0;
		return -1;
	}
}

float  CStrategy::UnitPrice(float fPrice,int iSign, BOOL bCall)
{	
	if( bCall )
		return m_arrItem[iSign].m_fCalls_Nominal;
	else
		return m_arrItem[iSign].m_fPuts_Nominal;
	
}

double CStrategy::GetStockBF()
{
	double vBF,tCall,tPut;
	double iCall,iPut;
	int is,ie;
	int nPos = m_TTOptions->ClosestCashNum();
	is = nPos-4;
	ie = nPos+4;
	if( is<0 )
		is = 0;
	if( ie>m_TTOptions->m_nDataTotal )
		ie = m_TTOptions->m_nDataTotal;

	BSMCALINFO calinfo;
	iCall = 0;
	iPut = 0;
	tCall = 0.0;
	tPut = 0.0;
	for( int i=is;i<=ie;i++ )
	{
		if( m_TTOptions->m_pDataBuf[i].m_fCalls_Nominal==0.0 )
			;
		else
		{
			memset(&calinfo, 0, sizeof(BSMCALINFO));
			m_TTOptions->ModelPrice(TRUE,m_TTOptions->m_pDataBuf[i].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
			if(calinfo.impliedVolitility==0.0)
				;
			else
			{
				iCall += m_TTOptions->m_pDataBuf[i].m_fCalls_OI;
				tCall += calinfo.impliedVolitility*m_TTOptions->m_pDataBuf[i].m_fCalls_OI;
			}
		}

		if( m_TTOptions->m_pDataBuf[i].m_fPuts_Nominal==0.0 )
			;
		else
		{
			memset(&calinfo, 0, sizeof(BSMCALINFO));
			m_TTOptions->ModelPrice(FALSE,m_TTOptions->m_pDataBuf[i].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
			if(calinfo.impliedVolitility==0.0)
				;
			else
			{
				iPut += m_TTOptions->m_pDataBuf[i].m_fPuts_OI;;
				tPut += calinfo.impliedVolitility*m_TTOptions->m_pDataBuf[i].m_fPuts_OI;
			}
		}
	}

	

	vBF = 0.0;
	if( tCall==0.0 )
		vBF = tPut/iPut;
	else if( tPut==0.0 )
		vBF = tCall/iCall;
	else if( tCall>0 && tPut>0 )
		vBF = (tCall/iCall+tPut/iPut)/2.0;

	return vBF;
}

void CStrategy::InitGDI()
{
	LOGFONT nflog; 
	ZeroMemory(&nflog,sizeof(nflog)); 
	nflog.lfHeight=14; 
	nflog.lfCharSet=GB2312_CHARSET; 
	m_font1.CreateFontIndirect(&nflog); 

	ZeroMemory(&nflog,sizeof(nflog)); 
	nflog.lfHeight=12; 
	nflog.lfCharSet=GB2312_CHARSET;  
	m_font2.CreateFontIndirect(&nflog);

	m_font3.CreateFont(
			12,                 
			0,
			2700,
			2700,
			FW_EXTRALIGHT,                                     
			FALSE,                               
			FALSE,                             
			FALSE,               
			GB2312_CHARSET,          
			OUT_DEFAULT_PRECIS,    
			CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,         
			DEFAULT_PITCH,                 
			"@����"); 

	m_font5.CreateFont(
		12,                 
		0,
		2700,
		2700,
		FW_NORMAL,                                     
		FALSE,                               
		FALSE,                             
		FALSE,               
		GB2312_CHARSET,          
		OUT_DEFAULT_PRECIS,    
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,         
		DEFAULT_PITCH,                 
		"@����");  

	ZeroMemory(&nflog,sizeof(nflog)); 
	nflog.lfHeight=16; 
	nflog.lfWeight=FW_NORMAL; 
	nflog.lfCharSet=GB2312_CHARSET; 
	m_font4.CreateFontIndirect(&nflog);

	ZeroMemory(&nflog,sizeof(nflog)); 
	nflog.lfHeight=22; 
	nflog.lfWeight=FW_BOLD; 
	nflog.lfCharSet=GB2312_CHARSET; 
	m_font6.CreateFontIndirect(&nflog);

	m_bsh1.CreateSolidBrush(RGB(107,142,35));
	m_bsh2.CreateSolidBrush(RGB(160,82,45));
	m_bsh3.CreateSolidBrush(RGB(32,178,170));
	m_bsh4.CreateSolidBrush(RGB(247,141,147));
	m_bsh5.CreateSolidBrush(RGB(100,149,237));
}

/*void CStrategy::Fy_x(float &arrfo, CArrayFloat &arrPL, float x)
{
	int i;
	for( i=0;i<arrPL.GetSize();i++ )
	{
		if( i%2==0 )
		{
			if( i<arrPL.GetSize()-2 && x>=arrPL[i] && x<arrPL[i+2] )
			{
				
				arrfo = arrPL[i+1]+(x-arrPL[i])*(arrPL[i+3]-arrPL[i+1])/(arrPL[i+2]-arrPL[i]);
				break;
			}
			else if( i==arrPL.GetSize()-2  )
				arrfo = arrPL[arrPL.GetSize()-1];
		}
		
	}
}*/

void CStrategy::InitDays()
{
	SYSTEMTIME SysTime;
	GetSystemTime(&SysTime);
	long lToday = SysTime.wYear*10000 + SysTime.wMonth*100 + SysTime.wDay;
	int  lExpiryDays;
	m_TTOptions->DateDiff(m_lCaldExpDate1,lToday,lExpiryDays);
	if( m_lCaldExpDate1<lToday )
		m_TTOptions->DateDiff(m_lCaldExpDate2,lToday,lExpiryDays);
	m_nDay1 = m_TTOptions->m_lExpiryDays;
	if( (m_nIndex==17||m_nIndex==18) && m_lCaldExpDate1!=-1 )
		m_nDay1 = lExpiryDays;
	m_iExpDays = m_nDay1;
	m_nDay2 = 5;
	m_nDay3 = 3;
	if( m_nDay2>m_nDay1 )
	{
		m_nDay2 = 1;
		m_nDay3 = 1;
	}
	if( m_nDay1==0 )
	{
		m_nDay2 = 0;
		m_nDay3 = 0;
	}
	CString str;
	str.Format("%d",m_nDay1);
	m_staDay1.SetWindowText(str);
	str.Format("%d",m_nDay2);
	m_staDay2.SetWindowText(str);
	str.Format("%d",m_nDay3);
	m_staDay3.SetWindowText(str);
}

void CStrategy::FindStrikeIx(StgyHistoryFile stgyfile)
{
	int i,ix1=-1,ix2=-1,ix3=-1,ix4=-1,ix5=-1,ix6=-1;
	for( i=0;i<m_arrItem.GetSize();i++ )
	{
		if( stgyfile.m_fStrike[0]==m_arrItem[i].m_fStrike )
			ix1 = i;
		if( stgyfile.m_fStrike[1]==m_arrItem[i].m_fStrike )
			ix2 = i;
		if( stgyfile.m_fStrike[2]==m_arrItem[i].m_fStrike )
			ix3 = i;
		if( stgyfile.m_fStrike[3]==m_arrItem[i].m_fStrike )
			ix4 = i;
		if( stgyfile.m_fStrikeEx[0]==m_arrItem[i].m_fStrike )
			ix5 = i;
		if( stgyfile.m_fStrikeEx[1]==m_arrItem[i].m_fStrike )
			ix6 = i;
	}

	if( ix1!=-1 )
	{
		m_nIxStrike = ix1;
		if( m_nIndex<15 )
			m_ComBoxStrike.SetCurSel(ix1);
	}
	if( ix2!=-1 )
	{
		m_nIxStrike2 = ix2;
		if( m_nIndex<15 )
			m_ComBoxStrike2.SetCurSel(ix2);
	}
	if( ix3!=-1 )
	{
		m_nIxStrike3 = ix3;
		if( m_nIndex<15 )
			m_ComBoxStrike3.SetCurSel(ix3);
	}
	if( ix4!=-1 )
	{
		m_nIxStrike4 = ix4;
		if( m_nIndex<15 )
			m_ComBoxStrike4.SetCurSel(ix4);
	}
	if( ix5!=-1 )
	{
		m_nIxStrike5 = ix5;
	}
	if( ix6!=-1 )
	{
		m_nIxStrike6 = ix6;
	}
	
}

void CStrategy::ClearFlag()
{
	for( int i=0;i<6;i++ )
	{
		m_fLPrice[i] = 0.0;
	}
	m_fScale = 0.0;
	m_nOrderCount = 1;
	for( i=0;i<6;i++ )
	{
		m_nCustomCount[i] = 0;
		m_nCustomIx[i] = 6;//6������  ��ѡ��Ȩ
	}
	m_nCustomCount[0] = 1;
	m_nCustomIx[0] = 1; //�Զ����ʼԤ��һ�� long call

}

double CStrategy::Calc_ER_Target(CArrayFloat &arrPL,float fLow,float fUp)
{
	double ER = 0.0;
	double e = 2.718281;
	double prob1 = 0.0, prob2 = 0.0;
	double pl = 0.0,pu = 0.0,px1 = 0.0,px2 = 0.0;
	double YK = 0.0,IV = 0.0;
	double d = -3.0;
	int i = 0,total = 128*6,j;
	double interval = 1.0/128.0;
	CString str;
	m_editIV1.GetWindowText(str);
	IV = atof(str)/100.0;

	SYSTEMTIME SysTime;
	GetSystemTime(&SysTime);
	long lToday = SysTime.wYear*10000 + SysTime.wMonth*100 + SysTime.wDay;
	int  lExpiryDays = m_TTOptions->m_lExpiryDays;
	if( m_nIndex==17||m_nIndex==18 )
		m_TTOptions->DateDiff(m_lCaldExpDate1,lToday,lExpiryDays);

	IV = IV*sqrt(lExpiryDays/252.0);
	double fCash = m_TTOptions->GetCorrStockPrice(FALSE);
	float x1,x2,y1,y2;

	BSMCALINFO info;
	m_iOdr = 1;
	m_TTOptions->ModelPrice(TRUE,fLow,fCash,lExpiryDays,POS_CALL_LAST,info);
	prob1 = info.ITM;
	m_iOdr = 1;
	m_TTOptions->ModelPrice(TRUE,fUp,fCash,lExpiryDays,POS_CALL_LAST,info);
	prob2 = info.ITM;
	m_PP = prob1-prob2;
/*	char ch[50];
	sprintf(ch,"%.2f,%.2f,%.2f,%.2f",fLow,fUp,prob1*100,prob2*100);
	m_TTOptions->WriteLogFile(ch);*/

	for( i=0;i<=total-1;i++ )
	{
		d = -3.0;
		d += i*interval;
		pl = fCash*pow(pow(e,IV),d);
		d += interval;
		pu = fCash*pow(pow(e,IV),d);

		
		if(pl>=fLow&&pl<=fUp) 
			;
		else
			continue;
		
		BSMCALINFO calinfo;
		m_iOdr = 1;
		m_TTOptions->ModelPrice(TRUE,pl,fCash,lExpiryDays,POS_CALL_LAST,calinfo);
		prob1 = calinfo.ITM;
		m_iOdr = 1;
		m_TTOptions->ModelPrice(TRUE,pu,fCash,lExpiryDays,POS_CALL_LAST,calinfo);
		prob2 = calinfo.ITM;
		
		for( j=0;j<arrPL.GetSize()-3;j+=2 )
		{
			x1 = arrPL[j];
			y1 = arrPL[j+1];
			x2 = arrPL[j+2];
			y2 = arrPL[j+3];
			YK = 0.0;
			if( pl>=x1&&pl<=x2 )
			{
				YK = y1+(pl-x1)* (y2-y1)/(x2-x1);
				break;
			}
			else if( j==0&&pl<x1 )
			{
				YK = y1+(pl-x1)* (y2-y1)/(x2-x1);
				break;
			}
			else if( j==arrPL.GetSize()-3&&pl>x2 )
			{
				YK = y1+(pl-x1)* (y2-y1)/(x2-x1);
				break;
			}
		}
		
		ER += YK*(prob1-prob2);
	}

//	sprintf(ch,"%.0f",ER);
//	m_TTOptions->WriteLogFile(ch);
	return ER;
}

double CStrategy::CalcExpectReturn(CArrayFloat &arrPL)
{
	double Ex_Re = 0.0;
	double e = 2.718281;
	double prob1 = 0.0, prob2 = 0.0;
	double pl = 0.0,pu = 0.0,px1 = 0.0,px2 = 0.0;
	double YK = 0.0,IV = 0.0;
	double d = -3.0;
	int i = 0,total = 128*6,j;
	double interval = 1.0/128.0;
	CString str;
	m_editIV1.GetWindowText(str);
	IV = atof(str)/100.0;
	SYSTEMTIME SysTime;
	GetSystemTime(&SysTime);
	long lToday = SysTime.wYear*10000 + SysTime.wMonth*100 + SysTime.wDay;
	int  lExpiryDays = m_TTOptions->m_lExpiryDays;
	if( m_nIndex==17||m_nIndex==18 )
		m_TTOptions->DateDiff(m_lCaldExpDate1,lToday,lExpiryDays);

	IV = IV*sqrt(lExpiryDays/252.0);
	double fCash = m_TTOptions->GetCorrStockPrice(FALSE);
/*	pl = fCash*pow(pow(e,IV),-3);
	pu = fCash*pow(pow(e,IV), 3);
	BSMCALINFO calinfo;
	m_TTOptions->ModelPrice(TRUE,pl,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
	prob1 = calinfo.ITM;
	m_iOdr = 1;
	m_TTOptions->ModelPrice(TRUE,pu,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
	prob2 = calinfo.ITM;
	char ch[50];
	sprintf(ch,"%.2f,%.2f,%.2f,%.2f",pl,pu,prob1*100,prob2*100);
	m_TTOptions->WriteLogFile(ch);*/
	float x1,x2,y1,y2;

	for( i=0;i<=total-1;i++ )
	{
		d = -3.0;
		d += i*interval;
		pl = fCash*pow(pow(e,IV),d);
		d += interval;
		pu = fCash*pow(pow(e,IV),d);

		BSMCALINFO calinfo;
		m_iOdr = 1;
		m_TTOptions->ModelPrice(TRUE,pl,fCash,lExpiryDays,POS_CALL_LAST,calinfo);
		prob1 = calinfo.ITM;
		m_iOdr = 1;
		m_TTOptions->ModelPrice(TRUE,pu,fCash,lExpiryDays,POS_CALL_LAST,calinfo);
		prob2 = calinfo.ITM;
		// prob = prob1-prob2;

		for( j=0;j<arrPL.GetSize()-3;j+=2 )
		{
			x1 = arrPL[j];
			y1 = arrPL[j+1];
			x2 = arrPL[j+2];
			y2 = arrPL[j+3];
			YK = 0.0;
			if( pl>=x1&&pl<=x2 )
			{
				YK = y1+(pl-x1)* (y2-y1)/(x2-x1);
				break;
			}
			else if( j==0&&pl<x1 )
			{
				YK = y1+(pl-x1)* (y2-y1)/(x2-x1);
				break;
			}
			else if( j==arrPL.GetSize()-3&&pl>x2 )
			{
				YK = y1+(pl-x1)* (y2-y1)/(x2-x1);
				break;
			}
		}

		Ex_Re += YK*(prob1-prob2);
	}

	return Ex_Re;
}

int CStrategy::CalcPainValue()
{
	m_bDrawing = TRUE;
	//char sz[100];
	//sprintf(sz,"DataSize: %d, ClosestNum: %d",m_TTOptions->m_nDataTotal,m_nPos);
//	m_TTOptions->WriteLogFile("Start Paint PainValue");
	int nCount;
	int MaxPainPos = 0;
	CArrayValue arrValue, arr_yV;
	arrValue.RemoveAll();
	nCount = m_TTOptions->m_nDataTotal;
	if( nCount<=0 )
		return 0;

	for( int i=1;i<nCount;i++ )
	{
		PainValue pv;
		memset(&pv,0,sizeof(pv));
		pv.m_fStrike = m_TTOptions->m_pDataBuf[i].m_fStrike;
		for( int j=0;j<nCount;j++ )
		{
			float strike = m_TTOptions->m_pDataBuf[j].m_fStrike;
			float OICall = m_TTOptions->m_pDataBuf[j].m_fCalls_OI;
			float OIPut  = m_TTOptions->m_pDataBuf[j].m_fPuts_OI;
			if( pv.m_fStrike==strike )
				;
			else if( pv.m_fStrike<strike )
			{
				pv.m_dValue += (strike-pv.m_fStrike)*OIPut;
				pv.m_dPV    += (strike-pv.m_fStrike)*OIPut;
			}
			else if( pv.m_fStrike>strike )
			{
				pv.m_dValue += (pv.m_fStrike-strike)*OICall;
				pv.m_dCV    += (pv.m_fStrike-strike)*OICall;
			}
		}
		if( pv.m_dValue>0.001 )
			arrValue.Add(pv);
	}

	if( arrValue.GetSize()==0 )
		return 0;

	double MaxPainValue = arrValue[0].m_dValue;
	for( i=1;i<arrValue.GetSize();i++ )
	{
		if( arrValue[i].m_dValue<MaxPainValue )
		{
			MaxPainValue = arrValue[i].m_dValue;
			MaxPainPos = i;
		}
	}

	CPaintDC dc(this);
	dc.SetBkMode(TRANSPARENT);
	
	CString tips1[3] = {"Total Pain","ͳ��ʹֵ","�yӋʹֵ"};
	CString tips2[3] = {"Put Pain","Putʹֵ","Putʹֵ"};
	CString tips3[3] = {"Call Pain","Callʹֵ","Callʹֵ"};
	//��������ϵ
	int ox, oy, dex, dey;
	CRect frmrect;
	m_frame.GetWindowRect(frmrect);
	ScreenToClient(frmrect);
	ox = frmrect.left+60;
	oy = frmrect.bottom-50;
	dex = frmrect.right-frmrect.left-140;
	dey = frmrect.bottom-frmrect.top-80;
	CPoint oxy(ox, oy);
	CPen pen2(PS_SOLID,1,RGB(0,0,0)),*oldpen1; 
	CPen pen1(PS_SOLID,1,RGB(105,105,105));
	oldpen1=dc.SelectObject(&pen1); 
	dc.MoveTo(oxy);
	dc.LineTo(oxy.x+dex,oxy.y);  
	dc.MoveTo(oxy);
	dc.LineTo(oxy.x,oxy.y-dey);  
	CFont *fontold; 
	fontold = dc.SelectObject(&m_font2); 
	char *szx[3] = {"Strike","��ʹ��","��ʹ�r"};
	char *szy[3] = {"PV","ʹֵ","ʹֵ"};
	dc.TextOut(oxy.x+dex+5, oxy.y, szx[m_TTOptions->m_iLangType]); 
	dc.TextOut(oxy.x-25, oxy.y-dey-15, szy[m_TTOptions->m_iLangType]);
	dc.SelectObject(&m_bsh1);
	CSize cSize;
	cSize = dc.GetTextExtent(tips1[m_TTOptions->m_iLangType]);
	int x1 = frmrect.right-cSize.cx-20;
	int y1 = frmrect.bottom-frmrect.Height()/2-30;
	int x2 = x1+15;
	int y2 = y1+15;
	dc.Rectangle(x1,y1,x2,y2);
	dc.TextOut(x1+18,y1,tips1[m_TTOptions->m_iLangType]);
	dc.SelectObject(&m_bsh2);
	y1 = frmrect.bottom-frmrect.Height()/2;
	x2 = x1+15;
	y2 = y1+15;
	dc.Rectangle(x1,y1,x2,y2);
	dc.TextOut(x1+18,y1,tips2[m_TTOptions->m_iLangType]);
	dc.SelectObject(&m_bsh3);
	y1 = frmrect.bottom-frmrect.Height()/2+30;
	x2 = x1+15;
	y2 = y1+15;
	dc.Rectangle(x1,y1,x2,y2);
	dc.TextOut(x1+18,y1,tips3[m_TTOptions->m_iLangType]);
	CString headline,strTxt;
	CString str[3] = {"MaxPain Strike:","��ʹ��ʹ��:","��ʹ��ʹ�r:"};
	char szBuf[30] = {0};
	strcpy(szBuf,m_TTOptions->m_szItemName);
	if( m_TTOptions->m_iLangType==2 )
		BIG52GBK(szBuf);
	headline = szBuf;
	headline.Replace(" ","");
	headline += m_TTOptions->m_szText;
	headline +=" ";
	headline += str[m_TTOptions->m_iLangType];
	CString szStrike;
	GetPriceTxt(arrValue[MaxPainPos].m_fStrike,szStrike);
	strTxt = headline+szStrike;

	 
	fontold = dc.SelectObject(&m_font4);

	cSize = dc.GetTextExtent(strTxt);
	dc.TextOut(frmrect.left+frmrect.Width()/2-cSize.cx/2,cSize.cy/2+5,headline);
	int itemp = frmrect.Width()/2-cSize.cx/2;
	cSize = dc.GetTextExtent(headline);
	dc.SetTextColor(RGB(255,0,0));
	dc.TextOut(frmrect.left+itemp+cSize.cx,cSize.cy/2+5,szStrike);

	
	fontold = dc.SelectObject(&m_font5);
	dc.SetTextColor(RGB(0,0,0));
	

	CStringArray arr_x,arr_y;
	CString s;
	int nXTotal;
	cSize = dc.GetTextExtent("10000");
	int interval = cSize.cy+5;
	nXTotal = dex/interval;
	int iStart,iEnd;
	iStart = MaxPainPos-nXTotal/2;
	if( iStart<0 )
		iStart = 0;
	iEnd = MaxPainPos+nXTotal-nXTotal/2;
	for( i=iStart;i<iEnd;i++ )
	{
		if( i>(arrValue.GetSize()-1) )
			break;

		GetPriceTxt(arrValue[i].m_fStrike,s);
		arr_x.Add(s);
		arr_yV.Add(arrValue[i]);
	}
	for( i=0;i<arr_x.GetSize();i++ )
	{
		//cSize = dc.GetTextExtent(arr_x[i]);
		dc.MoveTo(ox+i*interval,oy);
		dc.LineTo(ox+i*interval,oy+3);
		dc.TextOut(ox+i*interval+interval/2+cSize.cy/2,oy+4,arr_x[i]);
	}
	dc.MoveTo(ox+i*interval,oy);
	dc.LineTo(ox+i*interval,oy+3);//Ҫ�໭һ��


	
	fontold = dc.SelectObject(&m_font2);
	//������x�����꣬��y���꣬���㾫��
	double Ymin = 0.0;
    double Ymax = arr_yV[0].m_dValue;
	CString szUnit;
	double dea;
	for(i=1;i<arr_yV.GetSize();i++)
	{
		if( arr_yV[i].m_dValue>Ymax )
			Ymax = arr_yV[i].m_dValue;
	}

	if( Ymax>1000000000 )
	{
		szUnit = "B";
		Ymax = Ymax/1000000000;
	}
	else if( Ymax>1000000 )
	{
		szUnit = "M";
		Ymax = Ymax/1000000;
	}
	else if( Ymax>1000 )
	{
		szUnit = "K";
		Ymax = Ymax/1000;
	}
	//���־���
	if( (int)Ymax<=10 )
	{
		dea = Ymax/12;
		if( dea<0.2 )
			dea = 0.2;
		else if( dea<0.5 )
			dea = 0.5;
		else if( dea<1 )
			dea = 1;
		
		Ymax = (int(Ymax/dea)+1)*dea;
	}
	else if( (int)Ymax<=100 )
	{
		dea = Ymax/120;
		if( dea<0.2 )
			dea = 2;
		else if( dea<0.5 )
			dea = 5;
		else if( dea<1 )
			dea = 10;
		
		Ymax = (int(Ymax/dea)+1)*dea;
	}
	else if( (int)Ymax<=1000 )
	{
		dea = Ymax/1200;
		if( dea<0.1 )
			dea = 10;
		else if( dea<0.2 )
			dea = 20;
		else if( dea<0.5 )
			dea = 50;
		else if( dea<1 )
			dea = 100;
		
		Ymax = (int(Ymax/dea)+1)*dea;
	}
	
	double m_Phymax = Ymax;
	if( szUnit=="K" )
		m_Phymax = Ymax*1000;
	if( szUnit=="M" )
		m_Phymax = Ymax*1000000;
	if( szUnit=="B" )
		m_Phymax = Ymax*1000000000;

	for( double d=Ymin; d<(Ymax+dea*0.1); d = d+dea )
	{
	
		CString szCoo;
		
		if( dea<1 )
			szCoo.Format("%.1lf%s", d, szUnit);
		else
			szCoo.Format("%.0lf%s", d, szUnit);
			
		arr_y.Add(szCoo);
	}
	int tempDey;
	int nYval = (dey-5)/(arr_y.GetSize()-1);
	tempDey = nYval*(arr_y.GetSize()-1);
	arr_y[0] = "0";// mark
	for( i=0;i<arr_y.GetSize();i++ )
	{
		cSize = dc.GetTextExtent(arr_y[i]);
		if( i==0 )
		{
			dc.MoveTo(ox-5,oy);
			dc.LineTo(ox,oy);
		}
		else
		{
			dc.MoveTo(ox-5,oy-i*nYval);
			dc.LineTo(ox+nXTotal*interval,oy-i*nYval);
		}
		dc.TextOut(ox-7-cSize.cx,oy-i*nYval-cSize.cy/2,arr_y[i]);
	}

	//����ͼ
	for( i=0;i<arr_x.GetSize();i++ )
	{
		//��һ��
		dc.SelectObject(&m_bsh1);
		x1 = ox+i*interval+(interval/6);
		y1 = oy-arr_yV[i].m_dValue/m_Phymax*tempDey;
		x2 = ox+i*interval+(5*interval/6);
		y2 = oy;
		dc.Rectangle(x1,y1,x2,y2);
		//�ڶ���
		bool b = arr_yV[i].m_dPV>arr_yV[i].m_dCV? true:false;
		double dv = arr_yV[i].m_dPV>arr_yV[i].m_dCV? arr_yV[i].m_dPV:arr_yV[i].m_dCV;
		if( b )
			dc.SelectObject(&m_bsh2);
		else
			dc.SelectObject(&m_bsh3);
		y1 = oy-dv/m_Phymax*tempDey;
		dc.Rectangle(x1,y1,x2,y2);
		//������
		dv = arr_yV[i].m_dPV<arr_yV[i].m_dCV? arr_yV[i].m_dPV:arr_yV[i].m_dCV;
		if( b )
			dc.SelectObject(&m_bsh3);
		else
			dc.SelectObject(&m_bsh2);

		y1 = oy-dv/m_Phymax*tempDey;
		dc.Rectangle(x1,y1,x2,y2);
	}

	m_bDrawing = FALSE;
//	m_TTOptions->WriteLogFile("Painted PainValue");
	return 1;
}

void CStrategy::Trans_Y_axis(CArrayFloat &floarr,CStringArray &strarr)
{
	if( floarr.GetSize()<2 )
		return;

	int i,j;
	i = floarr.GetSize()-1;
	j = floarr.GetSize()-2;
	if( (floarr[i]-floarr[j])<1000000 )
		return;

	if( strarr.GetSize()!=floarr.GetSize() )
		return;

	for( i=0;i<floarr.GetSize();i++ )
	{
		CString str;
		str.Format("%.0f",floarr[i]/1000000);
		str += " M";
		strarr[i] = str;
	}
}

int CStrategy::CalcPrecis(float &iYmax, float &iYmin, float &dea)
{
	float f = (iYmax-iYmin)/6.0;
	int um;
	
	if( f<20 )
		dea = 20;
	else if( f<50 )
		dea = 50;
	else if( f<100 )
		dea = 100;
	else if( f<200 )
		dea = 200;
	else if( f<400 )
		dea = 400;
	else if( f<600 )
		dea = 600;
	else if( f<800 )
		dea = 800;
	else if( f<1000 )
		dea = 1000;
	else if( f<2000 )
		dea = 2000;
	else if( f<3000 )
		dea = 3000;
	else if( f<4000 )
		dea = 4000;
	else if( f<5000 )
		dea = 5000;
	else if( f<6000 )
		dea = 6000;
	else if( f<7000 )
		dea = 7000;
	else if( f<8000 )
		dea = 8000;
	else if( f<10000 )
		dea = 10000;
	else if( f<20000 )
		dea = 20000;
	else if( f<30000 )
		dea = 30000;
	else if( f<40000 )
		dea = 40000;
	else if( f<50000 )
		dea = 50000;
	else if( f<60000 )
		dea = 60000;
	else if( f<70000 )
		dea = 70000;
	else if( f<80000 )
		dea = 80000;
	else if( f<100000 )
		dea = 100000;
	else if( f<200000 )
		dea = 200000;
	else if( f<300000 )
		dea = 300000;
	else if( f<400000 )
		dea = 400000;
	else if( f<500000 )
		dea = 500000;
	else if( f<600000 )
		dea = 600000;
	else if( f<700000 )
		dea = 700000;
	else if( f<800000 )
		dea = 800000;
	else 
	{
		for( um=1;;um++ )
		{
			if( f<(um*1000000) )
			{
				dea = um*1000000;
				iYmax = (int(iYmax/dea)+1)*dea;
				iYmin = (int(iYmin/dea)-1)*dea;
				return 1;
			}
		}
	}
	

	iYmax = (int(iYmax/dea)+1)*dea;
	iYmin = (int(iYmin/dea)-1)*dea;

	return 1;
}

void CStrategy::SortStrikeIx()
{
	int farr[6];
	int i,j,itemp;
	float ftemp;
	farr[0] = iSign1;
	farr[1] = iSign2;
	farr[2] = iSign3;
	farr[3] = iSign4;
	farr[4] = iSign5;
	farr[5] = iSign6;
	for( i=0;i<6;i++ )
		m_iSort[i] = i;

	for( i=0;i<6;i++ )
	{
		for( j=0;j<5-i;j++ )
		{
			if( farr[j]>farr[j+1] )
			{
				itemp = m_iSort[j];
				m_iSort[j] = m_iSort[j+1];
				m_iSort[j+1] = itemp;
				ftemp = farr[j];
				farr[j] = farr[j+1];
				farr[j+1] = ftemp;
			}
		}
	}
	iSign1 = farr[0];
	iSign2 = farr[1];
	iSign3 = farr[2];
	iSign4 = farr[3];
	iSign5 = farr[4];
	iSign6 = farr[5];

	m_arrInt.RemoveAll();
	for( i=0;i<6;i++ )
	{
		if( farr[i]!=-1 )
			m_arrInt.Add(farr[i]);
	}
}

void  CStrategy::GetCustomBreak( CArrayFloat &arrflo )
{
	int i;
	float x1,x2,y1,y2,brk;
	m_arrBrkValue.RemoveAll();
	for( i=0;i<arrflo.GetSize()-3;i=i+2 )
	{
		x1 = arrflo[i];
		y1 = arrflo[i+1];
		x2 = arrflo[i+2];
		y2 = arrflo[i+3];
		if( i==0 )
		{
			if( y1>y2 )// �۸����0ʱΪ���ӯ��
				Gain = y1+(0.0-x1)* (y2-y1)/(x2-x1);
			if( y1<y2 )
				Loss = y1+(0.0-x1)* (y2-y1)/(x2-x1);
		}
		if( i==arrflo.GetSize()-4 )
		{
			if( y1<y2 )
				Gain = 1.0;
			if( y1>y2 )
				Loss = 1.0;
		}
		if( y1*y2<0 )
		{
			//f(x) = y1+(x-x1)* (y2-y1)/(x2-x1)
			//f(x)=0 ---- x = (x1-x2)*y1/(y2-y1)+x1
			if( y2!=y1 )
			{
				brk = (x1-x2)*y1/(y2-y1)+x1;
				m_arrBrkValue.Add(brk);
			}
		}
	}
}

float CStrategy::GetExpectReturn()
{
	float fValue;
	return fValue;
}

float CStrategy::Get_Fx_y(CArrayFloat &arrPL,float xValue)
{
	int i;
	float x1,x2,y1,y2,fy;
	for( i=0;i<arrPL.GetSize()-3;i=i+2 )
	{
		x1 = arrPL[i];
		y1 = arrPL[i+1];
		x2 = arrPL[i+2];
		y2 = arrPL[i+3];
		if( xValue>=x1&&xValue<=x2 )
		{
			fy = y1+(xValue-x1)* (y2-y1)/(x2-x1);
			return fy;
		}
	}
}

float CStrategy::GetCustomStgy(float fValue)
{
	int i,j;
	float fCalc = 0.0;
	float fstrike = 0.0;

	int nSize = m_arrInt.GetSize();
	for( i=0;i<nSize;i++ )
	{
		fstrike = m_arrItem[m_arrInt[i]].m_fStrike;
		if( fValue<=fstrike )
		{
			for( j=0;j<i;j++ )
			{
				if( m_nCustomIx[m_iSort[6-nSize+j]]==0 || m_nCustomIx[m_iSort[6-nSize+j]]==1 )
				{
					fCalc -= m_nCustomCount[m_iSort[6-nSize+j]]*m_arrItem[m_arrInt[j]].m_fStrike;
					fCalc += m_nCustomCount[m_iSort[6-nSize+j]]*fValue;
				}
			}
			for( j=i;j<nSize;j++ )
			{
				if( m_nCustomIx[m_iSort[6-nSize+j]]==2 || m_nCustomIx[m_iSort[6-nSize+j]]==3 )
				{
					fCalc += m_nCustomCount[m_iSort[6-nSize+j]]*m_arrItem[m_arrInt[j]].m_fStrike;
					fCalc -= m_nCustomCount[m_iSort[6-nSize+j]]*fValue;
				}
			}
			fCalc += principal;
			break;
		}
	}
	fstrike = m_arrItem[m_arrInt[nSize-1]].m_fStrike;
	if( fValue>fstrike )
	{
		for( j=0;j<nSize;j++ )
		{
			if( m_nCustomIx[m_iSort[6-nSize+j]]==0 || m_nCustomIx[m_iSort[6-nSize+j]]==1 )
			{
				fCalc -= m_nCustomCount[m_iSort[6-nSize+j]]*m_arrItem[m_arrInt[j]].m_fStrike;
				fCalc += m_nCustomCount[m_iSort[6-nSize+j]]*fValue;
			}
		}
		fCalc += principal;
	}

	fCalc *= m_lShares;
	
	BOOL boo = FALSE;
	for( i=0;i<6;i++ )
	{
		if( m_nCustomIx[i]<=3 )
		{
			boo = TRUE;
			break;
		}
	}
	if( boo )
		fCalc += CalcStock(fValue);
	return fCalc;
}

void CStrategy::SelectType()
{
	if( m_nRetn==0 )
		return;

	int i;
	CString str;

	if( m_nIndex==4||m_nIndex==5 )
	{
		//strangle
		m_ComBoxStrike2.ResetContent();
		for( i=0;i<m_nPos;i++ )
		{
			CString str;
			GetPriceTxt(m_arrItem[i].m_fStrike,str);
			
			m_ComBoxStrike2.InsertString(i, str);
		}
		m_ComBoxStrike.ResetContent();
		for( i=m_nPos;i<m_arrItem.GetSize();i++ )
		{
			CString str;
			GetPriceTxt(m_arrItem[i].m_fStrike,str);
			
			m_ComBoxStrike.InsertString(i-m_nPos, str);
		}
	}
	else if( m_nIndex==6 )
	{
		//Iron Condor
		m_ComBoxStrike.ResetContent();
		m_ComBoxStrike2.ResetContent();
		m_ComBoxStrike3.ResetContent();
		m_ComBoxStrike4.ResetContent();
		for( i=0;i<m_nPos;i++ )
		{
			CString str;
			GetPriceTxt(m_arrItem[i].m_fStrike,str);
			
			m_ComBoxStrike.InsertString(i, str);
			m_ComBoxStrike2.InsertString(i, str);
		}
		for( i=m_nPos;i<m_arrItem.GetSize();i++ )
		{
			CString str;
			GetPriceTxt(m_arrItem[i].m_fStrike,str);
			
		
			m_ComBoxStrike3.InsertString(i-m_nPos, str);
			m_ComBoxStrike4.InsertString(i-m_nPos, str);
		}
	}
	else if( m_nIndex>=11 && m_nIndex<15 )
	{
		m_ComBoxStrike.ResetContent();
		m_ComBoxStrike2.ResetContent();
		for( i=0;i<m_arrItem.GetSize();i++ )
		{
			CString str;
			GetPriceTxt(m_arrItem[i].m_fStrike,str);
			
			if( i!=m_arrItem.GetSize()-1 )
				m_ComBoxStrike.InsertString(i, str);
			if( i!=0 )
				m_ComBoxStrike2.InsertString(i-1, str);
		}
	}
	else if( m_nIndex<15 )
	{
		//straddle and butterfly
		m_ComBoxStrike.ResetContent();
		m_ComBoxStrike2.ResetContent();
		m_ComBoxStrike3.ResetContent();
		for( i=0;i<m_arrItem.GetSize();i++ )
		{
			CString str;
			GetPriceTxt(m_arrItem[i].m_fStrike,str);
			
			m_ComBoxStrike.InsertString(i, str);
			m_ComBoxStrike2.InsertString(i, str);
			m_ComBoxStrike3.InsertString(i, str);
		}
	}

	
	switch( m_nIndex )
	{
	case 0:
	case 1:
		if( m_nIxStrike==-1 )
		{
			m_nIxStrike = m_nPos-1;
		}
		if( m_nIxStrike2==-1 )
		{
			m_nIxStrike2 = m_nPos;
		}
		if( m_nIxStrike3==-1 )
		{
			m_nIxStrike3 = m_nPos+1;
		}
		if( m_nIxStrike>-1 )
		{
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
			m_ComBoxStrike3.SetCurSel(m_nIxStrike3);
		}
		break;
	case 2:
	case 3:
		if( m_nIxStrike==-1 )
		{
			m_nIxStrike = m_nPos;
		}
		if( m_nIxStrike>-1 )
		{
			m_nIxStrike2 = m_nIxStrike;
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
		}
		break;
	case 4:
	case 5:
		if( m_nIxStrike==-1 )
		{
			m_nIxStrike = 0;
		}
		if( m_nIxStrike2==-1 )
		{
			m_nIxStrike2 = m_nPos-1;
		}
		if( m_nIxStrike>-1 )
		{
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
		}
		break;
	case 6:
		if( m_nIxStrike==-1 )
		{
			m_nIxStrike = m_nPos-2;
		}
		if( m_nIxStrike2==-1 )
		{
			m_nIxStrike2 = m_nPos-1;
		}
		if( m_nIxStrike3==-1 )
		{
			m_nIxStrike3 = 0;
		}
		if( m_nIxStrike4==-1 )
		{
			m_nIxStrike4 = 1;
		}
		if( m_nIxStrike>-1 )
		{
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
			m_ComBoxStrike3.SetCurSel(m_nIxStrike3);
			m_ComBoxStrike4.SetCurSel(m_nIxStrike4);
		}
		break;
	case 7:
	case 8:
	case 9:
	case 10:
		if( m_nIxStrike==-1 )
		{	
			m_nIxStrike = m_nPos;
		}
		if( m_nIxStrike>-1 )
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
		break;
	case 11:
	case 12:
	case 13:
	case 14:
		if( m_nIxStrike==-1 )
		{
			m_nIxStrike = m_nPos-1;
		}
		if( m_nIxStrike2==-1 )
		{
			m_nIxStrike2 = m_nPos-1;
		}
		if( m_nIxStrike>-1 )
		{
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
		}
		break;
	}
	if( m_nIxStrike>-1 )
	{
		m_nIx1 = m_nIxStrike;
		m_nIx2 = m_nIxStrike2;
		m_nIx3 = m_nIxStrike3;
		m_nIx4 = m_nIxStrike4;
	}
	

	if( m_bUseRecord )
	{
		if( m_nIndex<15 )
		{
			m_ComBoxStrike.ResetContent();
			m_ComBoxStrike2.ResetContent();
			m_ComBoxStrike3.ResetContent();
			m_ComBoxStrike4.ResetContent();
			for( i=0;i<m_arrItem.GetSize();i++ )
			{
				CString str;
				GetPriceTxt(m_arrItem[i].m_fStrike,str);
				
				m_ComBoxStrike.InsertString(i, str);
				m_ComBoxStrike2.InsertString(i, str);
				m_ComBoxStrike3.InsertString(i, str);
				m_ComBoxStrike4.InsertString(i, str);
			}
		}
		FindStrikeIx(m_TTOptions->m_StgyFile);
	}
	if( m_nIndex==15||m_nIndex==16 )
	{
		m_ComBoxStrike.ResetContent();
		m_ComBoxStrike2.ResetContent();
		m_ComBoxStrike3.ResetContent();
		m_ComBoxStrike4.ResetContent();
		if( m_nIxStrike2==-1 )
		{
			m_nIxStrike2 = m_nPos;
			if( m_nIndex==16 )
				m_nIxStrike2 = m_nPos-1;
		}
		GetPriceTxt(m_arrItem[m_nIxStrike2].m_fStrike,str);
		m_list.SetItemText(3,3,str);
	}
	else if( m_nIndex==STGY_CUSTOM )
	{
		m_ComBoxStrike.ResetContent();
		m_ComBoxStrike2.ResetContent();
		m_ComBoxStrike3.ResetContent();
		m_ComBoxStrike4.ResetContent();

		int IxS[6];
		IxS[0] = m_nIxStrike;
		IxS[1] = m_nIxStrike2;
		IxS[2] = m_nIxStrike3;
		IxS[3] = m_nIxStrike4;
		IxS[4] = m_nIxStrike5;
		IxS[5] = m_nIxStrike6;

		for( i=0;i<6;i++ )
		{
			if( m_nCustomIx[i]>=4 ) 
			{
				str = "";
				IxS[i] = -1;
			}
			else
			{
				if( IxS[i]==-1 )
					IxS[i] = m_nPos;
			}
			if( IxS[i]!=-1 )
				GetPriceTxt(m_arrItem[IxS[i]].m_fStrike,str);

			if( m_bMode==0 )
				m_list.SetItemText(i+2,3,str);
		}
		m_nIxStrike = IxS[0];
		m_nIxStrike2 = IxS[1];
		m_nIxStrike3 = IxS[2];
		m_nIxStrike4 = IxS[3];
		m_nIxStrike5 = IxS[4];
		m_nIxStrike6 = IxS[5];

	}
	
}

void CStrategy::SufPaint()
{
	CString strMonth1, strMonth2;
	CString strSta;
	CString strForm,strsz;
	BOOL btemp = TRUE;
	BSMCALINFO calinfo;
	int i,j,k,temp,n;
	float fSubPL = 0.0;
	float fDiff[6];
	for( i=0;i<6;i++ )
		fDiff[i] = 0.0;
	float fPrice;
	float fCapital=0.0;

	CString strSize;
	strSize.Format("%d", m_lShares/m_nOrderCount);
	if( m_bMode==0 )
		m_list.SetItemText(m_nRow+4,4,strSize);

	
	float fCash = m_TTOptions->GetCorrStockPrice();

	SYSTEMTIME SysTime;
	GetSystemTime(&SysTime);
	long lToday = SysTime.wYear*10000 + SysTime.wMonth*100 + SysTime.wDay;
	int lDay1=0,lDay2=0;
	char cc[100] = {0};

	if( m_bMode==0 )
	{
		switch( m_nIndex )
		{
		case 0:
		case 1:
			n = 3;
			m_ComBoxStrike.GetLBText(m_nIxStrike,strSta);
			m_list.SetItemText(2,3,strSta);
			m_ComBoxStrike2.GetLBText(m_nIxStrike2,strSta);
			m_list.SetItemText(3,3,strSta);
			m_ComBoxStrike3.GetLBText(m_nIxStrike3,strSta);
			m_list.SetItemText(4,3,strSta);
			fPrice = m_fiSignPrice[0];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[0] = FALSE;
				m_iOdr = 4;
				fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(2,4,strSta);
			if( m_bAlterPrice2[0]==FALSE && m_bAlterPrice[0]==FALSE )
			{
				m_list.SetItemText(2,5,strSta);
				m_fLPrice[0] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[0],strSta,1);
				m_list.SetItemText(2,5,strSta);
			}
			if( m_fLPrice[0]!=0.0 )
			{
				if( m_nIndex==0 )
					fDiff[0] = fPrice-m_fLPrice[0];
				else
					fDiff[0] = m_fLPrice[0]-fPrice;

				fDiff[0] *= m_nOrderCount;
				fSubPL += fDiff[0];
			}
			
			fPrice = m_fiSignPrice[1];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[1] = FALSE;
				m_iOdr = 4;
				fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike2].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(3,4,strSta);
			if( m_bAlterPrice2[1]==FALSE && m_bAlterPrice[1]==FALSE )
			{
				m_list.SetItemText(3,5,strSta);
				m_fLPrice[1] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[1],strSta,1);
				m_list.SetItemText(3,5,strSta);
			}
			if( m_fLPrice[1]!=0.0 )
			{
				if( m_nIndex==0 )
					fDiff[1] = m_fLPrice[1]-fPrice;
				else
					fDiff[1] = fPrice-m_fLPrice[1];

				fDiff[1] *= 2*m_nOrderCount;
				fSubPL += fDiff[1];
			}
			
			fPrice = m_fiSignPrice[2];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[2] = FALSE;
				m_iOdr = 4;
				fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike3].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(4,4,strSta);
			if( m_bAlterPrice2[2]==FALSE && m_bAlterPrice[2]==FALSE )
			{
				m_list.SetItemText(4,5,strSta);
				m_fLPrice[2] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[2],strSta,1);
				m_list.SetItemText(4,5,strSta);
			}
			if( m_fLPrice[2]!=0.0 )
			{
				if( m_nIndex==0 )
					fDiff[2] = fPrice-m_fLPrice[2];
				else
					fDiff[2] = m_fLPrice[2]-fPrice;

				fDiff[2] *= m_nOrderCount;
				fSubPL += fDiff[2];
			}
			break;
		case 2:
		case 3:
		case 4:
		case 5:
		case 11:
		case 12:
		case 13:
		case 14:
			n = 2;
			m_ComBoxStrike.GetLBText(m_nIxStrike,strSta);
			m_list.SetItemText(2,3,strSta);
			m_ComBoxStrike2.GetLBText(m_nIxStrike2,strSta);
			m_list.SetItemText(3,3,strSta);
			fPrice = m_fiSignPrice[0];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[0] = FALSE;
				m_iOdr = 4;
				if( m_nIndex==13||m_nIndex==14 )
					fPrice = m_TTOptions->ModelPrice(FALSE,m_arrItem[m_nIxStrike].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
				else
					fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(2,4,strSta);
			if( m_bAlterPrice2[0]==FALSE&& m_bAlterPrice[0]==FALSE )
			{
				m_list.SetItemText(2,5,strSta);
				m_fLPrice[0] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[0],strSta,1);
				m_list.SetItemText(2,5,strSta);
			}
			if( m_fLPrice[0]!=0.0 )
			{
				if( m_nIndex==2 || m_nIndex==4 || m_nIndex==11 || m_nIndex==13 )
					fDiff[0] = fPrice-m_fLPrice[0];
				else
					fDiff[0] = m_fLPrice[0]-fPrice;

				fDiff[0] *= m_nOrderCount;
				fSubPL += fDiff[0];
			}
			
			fPrice = m_fiSignPrice[1];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[1] = FALSE;
				m_iOdr = 4;
				if( m_nIndex==11||m_nIndex==12 )
					fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike2].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
				else
					fPrice = m_TTOptions->ModelPrice(FALSE,m_arrItem[m_nIxStrike2].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(3,4,strSta);
			if( m_bAlterPrice2[1]==FALSE && m_bAlterPrice[1]==FALSE)
			{
				m_list.SetItemText(3,5,strSta);
				m_fLPrice[1] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[1],strSta,1);
				m_list.SetItemText(3,5,strSta);
			}
			if( m_fLPrice[1]!=0.0 )
			{
				if( m_nIndex==2 || m_nIndex==4 || m_nIndex==12 || m_nIndex==14 )
					fDiff[1] = fPrice-m_fLPrice[1];
				else
					fDiff[1] = m_fLPrice[1]-fPrice;

				fDiff[1] *= m_nOrderCount;
				fSubPL += fDiff[1];
			}
			break;
		case 6:
			n = 4;
			m_ComBoxStrike.GetLBText(m_nIxStrike,strSta);
			m_list.SetItemText(2,3,strSta);
			m_ComBoxStrike2.GetLBText(m_nIxStrike2,strSta);
			m_list.SetItemText(3,3,strSta);
			m_ComBoxStrike3.GetLBText(m_nIxStrike3,strSta);
			m_list.SetItemText(4,3,strSta);
			m_ComBoxStrike4.GetLBText(m_nIxStrike4,strSta);
			m_list.SetItemText(5,3,strSta);
			fPrice = m_fiSignPrice[0];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[0] = FALSE;
				m_iOdr = 4;
				fPrice = m_TTOptions->ModelPrice(FALSE,m_arrItem[m_nIxStrike].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(2,4,strSta);
			if( m_bAlterPrice2[0]==FALSE && m_bAlterPrice[0]==FALSE)
			{
				m_list.SetItemText(2,5,strSta);
				m_fLPrice[0] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[0],strSta,1);
				m_list.SetItemText(2,5,strSta);
			}
			if( m_fLPrice[0]!=0.0 )
			{
				fDiff[0] = fPrice-m_fLPrice[0];

				fDiff[0] *= m_nOrderCount;
				fSubPL += fDiff[0];
			}
			
			fPrice = m_fiSignPrice[1];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[1] = FALSE;
				m_iOdr = 4;
				fPrice = m_TTOptions->ModelPrice(FALSE,m_arrItem[m_nIxStrike2].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(3,4,strSta);
			if( m_bAlterPrice2[1]==FALSE&& m_bAlterPrice[1]==FALSE )
			{
				m_list.SetItemText(3,5,strSta);
				m_fLPrice[1] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[1],strSta,1);
				m_list.SetItemText(3,5,strSta);
			}
			if( m_fLPrice[1]!=0.0 )
			{
				fDiff[1] = m_fLPrice[1]-fPrice;

				fDiff[1] *= m_nOrderCount;
				fSubPL += fDiff[1];
			}
			
			fPrice = m_fiSignPrice[2];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[2] = FALSE;
				m_iOdr = 4;
				fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike3].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(4,4,strSta);
			if( m_bAlterPrice2[2]==FALSE && m_bAlterPrice[2]==FALSE)
			{
				m_list.SetItemText(4,5,strSta);
				m_fLPrice[2] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[2],strSta,1);
				m_list.SetItemText(4,5,strSta);
			}
			if( m_fLPrice[2]!=0.0 )
			{
				fDiff[2] = m_fLPrice[2]-fPrice;
				fDiff[2] *= m_nOrderCount;
				fSubPL += fDiff[2];
			}
			
			fPrice = m_fiSignPrice[3];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[3] = FALSE;
				m_iOdr = 4;
				fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike4].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(5,4,strSta);
			if( m_bAlterPrice2[3]==FALSE && m_bAlterPrice[3]==FALSE)
			{
				m_list.SetItemText(5,5,strSta);
				m_fLPrice[3] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[3],strSta,1);
				m_list.SetItemText(5,5,strSta);
			}
			if( m_fLPrice[3]!=0.0 )
			{
				fDiff[3] = fPrice-m_fLPrice[3];
				fDiff[3] *= m_nOrderCount;
				fSubPL += fDiff[3];
			}
			break;
		case 7:
		case 8:
		case 9:
		case 10:
			n = 1;
			m_ComBoxStrike.GetLBText(m_nIxStrike,strSta);
			m_list.SetItemText(2,3,strSta);
			fPrice = m_fiSignPrice[0];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[0] = FALSE;
				m_iOdr = 4;
				if( m_nIndex==7||m_nIndex==9 )
					fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
				else
					fPrice = m_TTOptions->ModelPrice(FALSE,m_arrItem[m_nIxStrike].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(2,4,strSta);
			if( m_bAlterPrice2[0]==FALSE&& m_bAlterPrice[0]==FALSE )
			{
				m_list.SetItemText(2,5,strSta);
				m_fLPrice[0] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[0],strSta,1);
				m_list.SetItemText(2,5,strSta);
			}
			if( m_fLPrice[0]!=0.0 )
			{
				if( m_nIndex<=8 )
					fDiff[0] = fPrice-m_fLPrice[0];
				else
					fDiff[0] = m_fLPrice[0]-fPrice;

				fDiff[0] *= m_nOrderCount;
				fSubPL += fDiff[0];
			}
			break;
		case 15:
		case 16:
			n=2;
			if( m_nIndex==16 )
			{
				CString strtxt = "Sell Stock";
				strtxt.Format("%s(%.1f)",strtxt,m_fStock_C);
				m_list.SetItemText(2,1,strtxt);
			}

			fPrice = m_fiSignPrice[0];
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(2,4,strSta);
			if( m_bAlterPrice2[0]==FALSE && m_bAlterPrice[0]==FALSE)
			{
				m_list.SetItemText(2,5,strSta);
				m_fLPrice[0] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[0],strSta,1);
				m_list.SetItemText(2,5,strSta);
			}
			if( m_fLPrice[0]!=0.0 )
			{
				if( m_nIndex==15 )
					fDiff[0] = fPrice-m_fLPrice[0];
				else
					fDiff[0] = m_fLPrice[0]-fPrice;

				fDiff[0] *= m_nOrderCount;
				fSubPL += fDiff[0];
			}
			
			fPrice = m_fiSignPrice[1];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[1] = FALSE;
				m_iOdr = 4;
				if( m_nIndex==15 )
					fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[m_nIxStrike2].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
				else
					fPrice = m_TTOptions->ModelPrice(FALSE,m_arrItem[m_nIxStrike2].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(3,4,strSta);
			if( m_bAlterPrice2[1]==FALSE && m_bAlterPrice[1]==FALSE)
			{
				m_list.SetItemText(3,5,strSta);
				m_fLPrice[1] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[1],strSta,1);
				m_list.SetItemText(3,5,strSta);
			}
			if( m_fLPrice[1]!=0.0 )
			{
				fDiff[1] = m_fLPrice[1]-fPrice;
				fDiff[1] *= m_nOrderCount;
				fSubPL += fDiff[1];
			}
			break;
		case 17: 
		case 18:
			n = 2;
			m_TTOptions->DateDiff(m_lCaldExpDate1,lToday,lDay1);
			m_TTOptions->DateDiff(m_lCaldExpDate2,lToday,lDay2);
		/*	fPrice = m_fiSignPrice[0];
			GetPriceTxt(fPrice,strSta,1);
			m_list.SetItemText(2,4,strSta);
			fPrice = m_fiSignPrice[1];
			GetPriceTxt(fPrice,strSta,1);
			m_list.SetItemText(3,4,strSta);*/

			fPrice = m_fiSignPrice[0];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[0] = FALSE;
				m_iOdr = 4;
				if( m_cald.bCall==1 )
					fPrice = m_TTOptions->ModelPrice(FALSE,m_cald.fStrike,fCash,lDay1,POS_PUT_LAST,calinfo);
				else
					fPrice = m_TTOptions->ModelPrice(TRUE,m_cald.fStrike,fCash,lDay1,POS_CALL_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(2,4,strSta);
			if( m_bAlterPrice2[0]==FALSE&& m_bAlterPrice[0]==FALSE )
			{
				m_list.SetItemText(2,5,strSta);
				m_fLPrice[0] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[0],strSta,1);
				m_list.SetItemText(2,5,strSta);
			}
		//	if( m_fLPrice[0]!=0.0 )
			{
				if( m_cald.bDebit==0 )
					fDiff[0] = m_fLPrice[0]-fPrice;
				else
					fDiff[0] = fPrice-m_fLPrice[0];

				fDiff[0] *= m_nOrderCount;
				fSubPL += fDiff[0];
			}

			
			fPrice = m_fiSignPrice[1];
			if( m_bUseRecord && fPrice==0.0 )
			{
				m_bPrice[1] = FALSE;
				m_iOdr = 4;
				if( m_cald.bCall==1 )
					fPrice = m_TTOptions->ModelPrice(FALSE,m_fStrike2_Spread,fCash,lDay2,POS_PUT_LAST,calinfo);
				else
					fPrice = m_TTOptions->ModelPrice(TRUE,m_fStrike2_Spread,fCash,lDay2,POS_CALL_LAST,calinfo);
			}
			GetPriceTxt(fPrice,strSta,1);
			fPrice = atof(strSta);
			m_list.SetItemText(3,4,strSta);
			if( m_bAlterPrice2[1]==FALSE && m_bAlterPrice[1]==FALSE)
			{
				m_list.SetItemText(3,5,strSta);
				m_fLPrice[1] = fPrice;
			}
			else 
			{
				GetPriceTxt(m_fLPrice[1],strSta,1);
				m_list.SetItemText(3,5,strSta);
			}
		//	if( m_fLPrice[1]!=0.0 )
			{
				if( m_cald.bDebit==0 )
					fDiff[1] = fPrice-m_fLPrice[1];
				else
					fDiff[1] = m_fLPrice[1]-fPrice;

				fDiff[1] *= m_nOrderCount;
				fSubPL += fDiff[1];
			}

			if( m_cald.bDebit==0 && m_cald.bCall==0 )
			{
				strMonth1.Format("Sell Call %s",GetMonthString(m_cald.lMonth1));
				strMonth2.Format("Buy Call %s",GetMonthString(m_cald.lMonth2));
			}
			else if( m_cald.bDebit==0 && m_cald.bCall==1 )
			{
				strMonth1.Format("Sell Put %s",GetMonthString(m_cald.lMonth1));
				strMonth2.Format("Buy Put %s",GetMonthString(m_cald.lMonth2));
			}
			else if( m_cald.bDebit==1 && m_cald.bCall==0 )
			{
				strMonth1.Format("Buy Call %s",GetMonthString(m_cald.lMonth1));
				strMonth2.Format("Sell Call %s",GetMonthString(m_cald.lMonth2));
			}
			else if( m_cald.bDebit==1 && m_cald.bCall==1 )
			{
				strMonth1.Format("Buy Put %s",GetMonthString(m_cald.lMonth1));
				strMonth2.Format("Sell Put %s",GetMonthString(m_cald.lMonth2));
			}
			m_list.SetItemText(2,1,strMonth1);
			m_list.SetItemText(3,1,strMonth2);
			fPrice = m_cald.fStrike;
			GetPriceTxt(fPrice,strSta,1);
			m_list.SetItemText(2,3,strSta);
			fPrice = m_fStrike2_Spread;
			GetPriceTxt(fPrice,strSta,1);
			m_list.SetItemText(3,3,strSta);
			break;
		case STGY_CUSTOM:
			n = 6;
			for( i=0;i<6;i++ )
			{
				if( m_nCustomIx[i]==4 )
				{
					CString strtxt = "Sell Stock";
					strtxt.Format("%s(%.1f)",strtxt,m_fStock_C);
					m_list.SetItemText(2+i,1,strtxt);	
				}

				fPrice = m_fiSignPrice[i];
				if( m_bUseRecord && fPrice==0.0 )
				{
					int nIx[6];
					nIx[0] = m_nIxStrike;
					nIx[1] = m_nIxStrike2;
					nIx[2] = m_nIxStrike3;
					nIx[3] = m_nIxStrike4;
					nIx[4] = m_nIxStrike5;
					nIx[5] = m_nIxStrike6;
					m_bPrice[i] = FALSE;
					m_iOdr = 4;
					if( m_nCustomIx[i]==0||m_nCustomIx[i]==1 )
						fPrice = m_TTOptions->ModelPrice(TRUE,m_arrItem[nIx[i]].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
					else if( m_nCustomIx[i]==2||m_nCustomIx[i]==3 )
						fPrice = m_TTOptions->ModelPrice(FALSE,m_arrItem[nIx[i]].m_fStrike,fCash,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
				}
				GetPriceTxt(fPrice,strSta,1);
				fPrice = atof(strSta);
				if( m_nCustomIx[i]==6 )
					strSta = "";
				m_list.SetItemText(i+2,4,strSta);
				if( (m_bAlterPrice2[i]==FALSE && m_bAlterPrice[i]==FALSE) || strSta=="" )
				{
					m_list.SetItemText(i+2,5,strSta);
					m_fLPrice[i] = fPrice;
				}
				else 
				{
					GetPriceTxt(m_fLPrice[i],strSta,1);
					m_list.SetItemText(i+2,5,strSta);
				}
				
				if( m_nCustomIx[i]==1 || m_nCustomIx[i]==3 || m_nCustomIx[i]==5 )
					fDiff[i] = fPrice-m_fLPrice[i];
				else
					fDiff[i] = m_fLPrice[i]-fPrice;

				fDiff[i] *= abs(m_nCustomCount[i]);
				fSubPL += fDiff[i];
			}
			break;
		}
	}
	
	if(  m_bMode==0 )
	{
		for( i=0;i<n;i++ )
		{
			if( IsIndex() )
				strSta.Format("%.0f",fDiff[i]);
			else
				GetPriceTxt(fDiff[i],strSta,1);
			if( m_nIndex==STGY_CUSTOM && m_nCustomIx[i]==6 )
				strSta = "";
			m_list.SetItemText(i+2,6,strSta);

			strSta.Format("$ %.0f",fDiff[i]*m_lShares/m_nOrderCount);
			if( m_nIndex==STGY_CUSTOM )
			{
				strSta.Format("$ %.0f",fDiff[i]*m_lShares);
				if( m_nCustomIx[i]==6 )
					strSta = "";
			}
			m_list.SetItemText(i+2,7,strSta);
		}
		if( m_bUseRecord )
		{
			if( !m_TTOptions->HaveFutures(m_TTOptions->m_szItemCode,m_TTOptions->m_lExpiryTime) )
			{
				for( i=0;i<n;i++ )
				{
					if( m_bPrice[i]==FALSE )
					{
						m_list.SetItemText(i+2,4,"");
						m_list.SetItemText(i+2,6,"");
						m_list.SetItemText(i+2,7,"");
					}
				}
			}
		}

		strSta.Format("$ %.0f",fSubPL*m_lShares/m_nOrderCount);
		m_list.SetItemText(1,7,strSta);
		if( m_bUseRecord )
		{
			if( !m_TTOptions->HaveFutures(m_TTOptions->m_szItemCode,m_TTOptions->m_lExpiryTime) )
			{
				for( int i=0;i<n;i++ )
				{
					if( m_bPrice[i]==FALSE )
					{
						m_list.SetItemText(1,7,"");
						break;
					}
				}
			}
		}
	}
	
	fCash = m_TTOptions->GetCorrStockPrice(FALSE);
	int iCallMar=0,iPutMar=0,iCallMar2=0;
	BOOL bBreak = FALSE;
	if( m_bMode==0&&m_nRetn==1  )
	{
		int z,i,j;
		int optIx[6];
		int nCont[6];
		memset(&nCont, 0, sizeof(int)*6);
		memset(&optIx, -1, sizeof(int)*6);
		switch( m_nIndex )
		{
		case 0:
			iCallMar = m_arrItem[iSign2].m_fCalls_Margin;
			if( iCallMar==0 )
				fCapital = 0.0;
			else
				fCapital = 2*iCallMar*m_nOrderCount+(m_fLPrice[0]+m_fLPrice[2])*m_lShares;
			break;
		case 1:
			iCallMar = m_arrItem[iSign1].m_fCalls_Margin;
			iCallMar2 = m_arrItem[iSign3].m_fCalls_Margin;
			if( iCallMar==0 || iCallMar2==0 )
				fCapital = 0.0;
			else
			{
				fCapital = iCallMar*m_nOrderCount+m_fLPrice[1]*m_lShares;
				fCapital += iCallMar2*m_nOrderCount;
			}
			break;
		case 2:
		case 4:
		case 7:
		case 8:
			fCapital = -1*principal*m_lShares;
			break;
		case 3:
			iCallMar = m_arrItem[iSign].m_fCalls_Margin;
			iPutMar = m_arrItem[iSign].m_fPuts_Margin;
			if( iCallMar==0 || iPutMar==0 )
				fCapital = 0.0;
			else
			{
				fCapital = iCallMar*m_nOrderCount;
				fCapital += iPutMar*m_nOrderCount;
			}
			break;
		case 5:
			iCallMar = m_arrItem[iSign2].m_fCalls_Margin;
			iPutMar = m_arrItem[iSign1].m_fPuts_Margin;
			if( iCallMar==0 || iPutMar==0 )
				fCapital = 0.0;
			else
			{
				fCapital = iCallMar*m_nOrderCount;
				fCapital += iPutMar*m_nOrderCount;
			}
			break;
		case 6:
			iPutMar = m_arrItem[iSign2].m_fPuts_Margin;
			iCallMar = m_arrItem[iSign3].m_fCalls_Margin;
			if( iCallMar==0 || iPutMar==0 )
				fCapital = 0.0;
			else
			{
				fCapital = iPutMar*m_nOrderCount+(m_fLPrice[0]+m_fLPrice[3])*m_lShares;
				fCapital += iCallMar*m_nOrderCount;
			}
			break;
		case 9:
			iCallMar = m_arrItem[iSign].m_fCalls_Margin;
			if( iCallMar==0 )
				fCapital = 0.0;
			else
			{
				fCapital = iCallMar*m_nOrderCount;
			}
			break;
		case 10:
			iPutMar = m_arrItem[iSign].m_fPuts_Margin;
			if( iPutMar==0 )
				fCapital = 0.0;
			else
				fCapital = iPutMar*m_nOrderCount;
			break;
		case 11:
			iCallMar = m_arrItem[iSign2].m_fCalls_Margin;
			if( iCallMar==0 )
				fCapital = 0.0;
			else
				fCapital = iCallMar*m_nOrderCount+m_fLPrice[0]*m_lShares;
			break;
		case 12:
			iCallMar = m_arrItem[iSign1].m_fCalls_Margin;
			if( iCallMar==0 )
				fCapital = 0.0;
			else
				fCapital = iCallMar*m_nOrderCount+m_fLPrice[1]*m_lShares;
			break;
		case 13:
			iPutMar = m_arrItem[iSign2].m_fPuts_Margin;
			if( iPutMar==0 )
				fCapital = 0.0;
			else
				fCapital = iPutMar*m_nOrderCount+m_fLPrice[0]*m_lShares;
			break;
		case 14:
			iPutMar = m_arrItem[iSign1].m_fPuts_Margin;
			if( iPutMar==0 )
				fCapital = 0.0;
			else
				fCapital = iPutMar*m_nOrderCount+m_fLPrice[1]*m_lShares;
			break;
		case 15:
			iCallMar = m_arrItem[iSign].m_fCalls_Margin;
			if( iCallMar==0 )
				fCapital = 0.0;
			else
				fCapital = iCallMar*m_nOrderCount+fCash*m_lShares;
			break;
		case 16:
			iPutMar = m_arrItem[iSign].m_fPuts_Margin;
			if( iPutMar==0 )
				fCapital = 0.0;
			else
				fCapital = iPutMar*m_nOrderCount+fCash*m_lShares*m_fStock_C;
			break;
		case 17:
		case 18:
			if( m_cald.bDebit==0 )
			{
				GetMargin(m_cald.fStrike,m_cald.lMonth1,iCallMar,iPutMar);
				if( m_cald.bCall==0 )
					fCapital = iCallMar*m_nOrderCount;
				else
					fCapital = iPutMar*m_nOrderCount;
				if( fCapital!=0.0 )
					fCapital += m_fLPrice[1]*m_lShares;
			}
			else
			{
				GetMargin(m_fStrike2_Spread,m_cald.lMonth2,iCallMar,iPutMar);
				if( m_cald.bCall==0 )
					fCapital = iCallMar*m_nOrderCount;
				else
					fCapital = iPutMar*m_nOrderCount;
				if( fCapital!=0.0 )
					fCapital += m_fLPrice[0]*m_lShares;
			}
			break;
		case STGY_CUSTOM:
			for( i=0;i<6;i++ )
			{
				switch( i )
				{
				case 0:
					j = m_nIxStrike;
					break;
				case 1:
					j = m_nIxStrike2;
					break;
				case 2:
					j = m_nIxStrike3;
					break;
				case 3:
					j = m_nIxStrike4;
					break;
				case 4:
					j = m_nIxStrike5;
					break;
				case 5:
					j = m_nIxStrike6;
					break;
				}
				switch(m_nCustomIx[i])
				{
				case 0:
					iCallMar = m_arrItem[j].m_fCalls_Margin;
					if( iCallMar==0 )
						bBreak = TRUE;
					else
						fCapital -= iCallMar*m_nCustomCount[i];
					break;
				case 1:
					fCapital += m_fLPrice[1]*m_nCustomCount[i]*m_lShares;
					break;
				case 2:
					iPutMar = m_arrItem[j].m_fPuts_Margin;
					if( iPutMar==0 )
						bBreak = TRUE;
					else
						fCapital -= m_arrItem[j].m_fPuts_Margin*m_nCustomCount[i];
					break;
				case 3:
					fCapital += m_fLPrice[3]*m_nCustomCount[i]*m_lShares;
					break;
				case 4:
					fCapital -= fCash*m_nCustomCount[i]*m_lShares*m_fStock_C;
					break;
				case 5:
					fCapital += fCash*m_nCustomCount[i]*m_lShares;
					break;
				}
			}
			if( bBreak )
				fCapital = 0.0;
	
			break;
		}
//goto AdjustWidth;
		switch(m_nIndex)
		{
		case 0:
		case 1:
			optIx[0] = 1;
			optIx[1] = 1;
			optIx[2] = 1;
			nCont[0] = pow(-1,m_nIndex)*m_nOrderCount;
			nCont[1] = -2*pow(-1,m_nIndex)*m_nOrderCount;
			nCont[2] = pow(-1,m_nIndex)*m_nOrderCount;
			break;
		case 2:
		case 3:
		case 4:
		case 5:
			optIx[0] = 1;
			optIx[1] = 0;
			nCont[0] = pow(-1,m_nIndex)*m_nOrderCount;
			nCont[1] = pow(-1,m_nIndex)*m_nOrderCount;
			break;
		case 6:
			optIx[0] = 0;
			optIx[1] = 0;
			optIx[2] = 1;
			optIx[3] = 1;
			nCont[0] = pow(-1,m_nIndex)*m_nOrderCount;
			nCont[1] = -1*pow(-1,m_nIndex)*m_nOrderCount;
			nCont[2] = -1*pow(-1,m_nIndex)*m_nOrderCount;
			nCont[3] = pow(-1,m_nIndex)*m_nOrderCount;
			break;
		case 7:
			optIx[0] = 1;
			nCont[0] = m_nOrderCount;
			break;
		case 8:
			optIx[0] = 0;
			nCont[0] = m_nOrderCount;
			break;
		case 9:
			optIx[0] = 1;
			nCont[0] = -1*m_nOrderCount;
			break;
		case 10:
			optIx[0] = 0;
			nCont[0] = -1*m_nOrderCount;
			break;
		case 11:
		case 12:
			optIx[0] = 1;
			optIx[1] = 1;
			nCont[0] = -1*pow(-1,m_nIndex)*m_nOrderCount;
			nCont[1] = pow(-1,m_nIndex)*m_nOrderCount;
			break;
		case 13:
		case 14:
			optIx[0] = 0;
			optIx[1] = 0;
			nCont[0] = -1*pow(-1,m_nIndex)*m_nOrderCount;
			nCont[1] = pow(-1,m_nIndex)*m_nOrderCount;
			break;
		case 15:
		case 16:
			optIx[0] = 2;// 2 ������Ʊ
			nCont[0] = -1*pow(-1,m_nIndex)*m_nOrderCount;
			optIx[1] = 16-m_nIndex;
			nCont[1] = -1*m_nOrderCount;
			break;
		case STGY_CUSTOM:
			for( z=0;z<6;z++ )
			{
				if( m_nCustomIx[z]<=1 )
					optIx[z] = 1;
				else if( m_nCustomIx[z]<=3 )
					optIx[z] = 0;
				else if( m_nCustomIx[z]<=5 )
					optIx[z] = 2;

				nCont[z] = m_nCustomCount[z];
			}
		case 17:
		case 18:
			optIx[0] = abs(m_cald.bCall-1);
			optIx[1] = abs(m_cald.bCall-1);
			if( m_cald.bDebit==0 )
			{
				nCont[0] = -1*m_nOrderCount;
				nCont[1] = m_nOrderCount;
			}
			else
			{
				nCont[0] = m_nOrderCount;
				nCont[1] = -1*m_nOrderCount;
			}
			break;
		}

		BOOL bNet = FALSE;
		double delta=0.0,vega=0.0,gamma=0.0,theta=0.0;
		int cbd[3];
		char sz[10];
		memset(&cbd,0,sizeof(int)*3);
		for( z=0;z<6;z++ )
		{
			float fStrike;
			int iAddr;
			BSMCALINFO calinfo;
			int itemp = 0;
			memset(&calinfo,0,sizeof(BSMCALINFO));
			if( nCont[z]!=0 )
			{
				bNet = TRUE;
				CString str;
				if( optIx[z]==2 )
					calinfo.delta = 1;
				else
				{
					if( optIx[z]==1 )
						iAddr = POS_CALL_LAST;
					else
						iAddr = POS_PUT_LAST;
					str = m_list.GetItemText(2+z,3);
					fStrike = atof(str);
					if( m_nIndex==17 || m_nIndex==18 )
					{
						if( z==0 )
						{
							memcpy(&calinfo,&m_cald_calinfo1,sizeof(BSMCALINFO));
						}
						else if(z==1)
						{
							memcpy(&calinfo,&m_cald_calinfo2,sizeof(BSMCALINFO));
						}
					}
					else
						m_TTOptions->ModelPrice(optIx[z],fStrike,0,m_TTOptions->m_lExpiryDays,iAddr,calinfo);
				}
				calinfo.delta *= nCont[z];
				if( optIx[z]==2 )
					sprintf(sz,"%.2f",calinfo.delta);
				else
					m_TTOptions->GetTextEx(sz,calinfo.delta,2);
				m_list.SetItemText(2+z,8,sz);
				delta += atof(sz);

				char cc[50];

				calinfo.vega *= nCont[z];
				m_TTOptions->GetTextVega(sz,calinfo.vega,2);
				m_list.SetItemText(2+z,9,sz);
				vega += atof(sz);
				strSta = sz;
				itemp = strSta.GetLength()-strSta.Find('.')-2;
				if( itemp>=cbd[0] )
					cbd[0] = itemp;

				calinfo.gamma *= nCont[z];
				m_TTOptions->GetTextEx(sz,calinfo.gamma,4);
				m_list.SetItemText(2+z,10,sz);
				gamma += atof(sz);
				strSta = sz;
				itemp = strSta.GetLength()-strSta.Find('.')-2;
				if( itemp>=cbd[1] )
					cbd[1] = itemp;

				calinfo.theta *= nCont[z];
				m_TTOptions->GetTextVega(sz,calinfo.theta,2);
				m_list.SetItemText(2+z,11,sz);
				theta += atof(sz);
				strSta = sz;
				itemp = strSta.GetLength()-strSta.Find('.')-2;
				if( itemp>=cbd[2] )
					cbd[2] = itemp;
			}
		}
		if( bNet )
		{
			sprintf(sz,"%.2f",delta);
			m_list.SetItemText(1,8,sz);

			if( cbd[0]==2 )
				sprintf(sz,"%.2f",vega);
			else
				sprintf(sz,"%.4f",vega);
			m_list.SetItemText(1,9,sz);

			if( cbd[1]==2 )
				sprintf(sz,"%.2f",gamma);
			else
				sprintf(sz,"%.4f",gamma);
			m_list.SetItemText(1,10,sz);

			if( cbd[2]==2 )
				sprintf(sz,"%.2f",theta);
			else
				sprintf(sz,"%.4f",theta);
			m_list.SetItemText(1,11,sz);
		}
	}
//goto AdjustWidth;
	if( m_bMode==4 )
	{
		SetListMode();
		CString str;
		for( i=0;i<m_arrPL[1].GetSize();i++ )
		{
			if( i%2==0 )
			{
				GetPriceTxt(m_arrPL[1][i],str);
				
				m_list.InsertItem(i/2,str);
			}
		}
		
		for( k=1;k<4;k++ )
		{
			for( i=0;i<m_arrPL[k].GetSize();i++ )
			{
				if( i%2!=0 )
				{
					str.Format("%.0f",m_arrPL[k][i]);
					m_list.SetItemText(i/2,k,str);
				}
			}
		}
	}

	

	//����
	if( m_bMode==2 )
	{
		fCash = m_TTOptions->GetCorrStockPrice();
		double  sdtemp;
		double sd1 = sqrt(252); //һ��
		double sd2 = sqrt(52);  //һ��
		double sd3 = sqrt(12);  //һ��
		double sd4 = fCash*m_TTOptions->m_fBF; 

		double sd5 = sqrt(26);  //����
		double sd6 = sqrt(6);   //����
		double sd7 = sqrt(4);   //����
		double sd[6] = {sd1,sd2,sd5,sd3,sd6,sd7};
		sdtemp = m_TTOptions->m_fBF*100;
		strsz = m_TTOptions->m_szItemCode;
		strsz.Remove(' ');
		strsz.MakeLower();
		if( strsz=="hsi"||strsz=="mhi" )
		{
			sd4 = fCash*m_TTOptions->m_fBF/100.0;
			sdtemp = m_TTOptions->m_fBF;
		}
		
		strForm.Format("IV: %.1f",sdtemp);
		m_list.SetItemText(0, 0,strForm);   //IVֵ
		
		// 68% *1, 80% *1.28, 90% *1.64, 95% *1.96
		CString str1,str2;
		for( int i=0;i<6;i++ )
		{
			double bval = sd4*1/sd[i];              
			strForm.Format("%.0f",bval);
			if(!IsIndex())
				strForm.Format("%.2f",bval);
			m_list.SetItemText(1, i+1,strForm); 
			GetPriceTxt(fCash-bval,str1,1);
			GetPriceTxt(fCash+bval,str2,1);
			strForm.Format("%s  |  %s",str2,str1);
			m_list.SetItemText(6,i+1,strForm);

			bval = sd4*1.28/sd[i];              
			strForm.Format("%.0f",bval);
			if(!IsIndex())
				strForm.Format("%.2f",bval);
			m_list.SetItemText(2, i+1,strForm); 
			GetPriceTxt(fCash-bval,str1,1);
			GetPriceTxt(fCash+bval,str2,1);
			strForm.Format("%s  |  %s",str2,str1);
			m_list.SetItemText(7,i+1,strForm);

			bval = sd4*1.64/sd[i];              
			strForm.Format("%.0f",bval);
			if(!IsIndex())
				strForm.Format("%.2f",bval);
			m_list.SetItemText(3, i+1,strForm); 
			GetPriceTxt(fCash-bval,str1,1);
			GetPriceTxt(fCash+bval,str2,1);
			strForm.Format("%s  |  %s",str2,str1);
			m_list.SetItemText(8,i+1,strForm);

			bval = sd4*1.96/sd[i];              
			strForm.Format("%.0f",bval);
			if(!IsIndex())
				strForm.Format("%.2f",bval);
			m_list.SetItemText(4, i+1,strForm); 
			GetPriceTxt(fCash-bval,str1,1);
			GetPriceTxt(fCash+bval,str2,1);
			strForm.Format("%s  |  %s",str2,str1);
			m_list.SetItemText(9,i+1,strForm);
		}
	}
	
	if( m_bMode==0 )
	{
		CString strup;
		float flo = 0.0;
		//ӯ��
		if( Gain==1.0 )
			strForm = szInfinity[m_TTOptions->m_iLangType];
		else
		{
			flo = float(Gain/m_lShares*m_nOrderCount);
			GetPriceTxt(flo,strup);
			strForm.Format("%s ($ %.0f)",strup,Gain);
		}
		m_list.SetItemText(m_nRow+3, 1,strForm);
		
		//����
		if( Loss==1.0 )
			strForm = szInfinity[m_TTOptions->m_iLangType];
		else
		{
			flo = float(Loss/m_lShares*m_nOrderCount);
			GetPriceTxt(flo,strup);
			strForm.Format("%s ($ %.0f)",strup,Loss);
		}
		m_list.SetItemText(m_nRow+4, 1,strForm);
		

		//��ͼ�
		if( m_arrBrkValue.GetSize()==1 )
			GetPriceTxt(m_arrBrkValue[0],strForm,1);
		else if( m_arrBrkValue.GetSize()>=2 )
		{
			CString str;
			GetPriceTxt(m_arrBrkValue[0],str,1);
			strForm = str;
			for( i=1;i<m_arrBrkValue.GetSize();i++ )
			{
				strForm += "/";
				GetPriceTxt(m_arrBrkValue[i],str,1);
				strForm += str;
			}
		}
		else if( m_arrBrkValue.GetSize()==0 )
			strForm = "--/--";
		m_list.SetItemText(m_nRow+2,1,strForm);
		
		//��ϻ���
		strForm.Format("%.1f",m_fStgyPB*100);
		strForm += "%";
		if( m_nIndex==STGY_CUSTOM || (strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex()) )
			strForm = "-- --";
		m_list.SetItemText(m_nRow+2,4,strForm);
		if( m_bUseRecord )
		{
			strForm = "";
			if( m_bYte==1 )
			{
				strForm.Format("%.1f",m_fHStgyPB*100);
				strForm += "%";
			}
			if( m_nIndex==STGY_CUSTOM || (strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex()) )
				strForm = "";
			m_list.SetItemText(m_nRow+2,5,strForm);
		}

		//Ԥ�ڻر��ͻر��� --ֵ����
		
		float d;
		CString strH;
		SYSTEMTIME SysTime;
		GetSystemTime(&SysTime);
		long lToday = SysTime.wYear*10000 + SysTime.wMonth*100 + SysTime.wDay;
		int  lExpiryDays = m_TTOptions->m_lExpiryDays;
		if( m_nIndex==17 || m_nIndex==18 )
			m_TTOptions->DateDiff(m_lCaldExpDate1,lToday,lExpiryDays);

		if( lExpiryDays==0 || (strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex()) )
			strForm = "-- --";
		else
		{
			if( m_arrPL[0].GetSize()!=0 )
				d = CalcExpectReturn(m_arrPL[0]);
			strForm.Format("%.0f",d);
		}
		m_ExpValueS = d;
		m_list.SetItemText(m_nRow+3,4,strForm);
		if( m_bUseRecord )
		{
			strForm = "";
			if( m_ExpValue!=0.0 )
				strForm.Format("%.0f",m_ExpValue);
			m_list.SetItemText(m_nRow+3,5,strForm);
		}

		m_fCapitalS = fCapital;
		if( m_bUseRecord && m_ExpValue!=0.0 )
			fCapital = m_fCapital;
		if( lExpiryDays==0 || (strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex()) )
			strForm = "-- --";
		else
		{
			if( fCapital==0.0 )
				strForm = "-- --";
			else
			{
				if( fabs(d/fCapital)<0.0001 )
				{
					if( d/fCapital<0.0 )
						strForm = "< -0.01";
					else
						strForm = "< 0.01";
				}
				else
					strForm.Format("%.2f",d/fCapital*100);

				strForm += "%";
			}
		}
		m_list.SetItemText(m_nRow+2,7,strForm);
		if( m_bUseRecord && m_ExpValue!=0.0 )
		{
			if( fCapital==0.0 )
				strForm = "-- --";
			else
			{
				if( fabs(m_ExpValue/fCapital)<0.0001 )
				{
					if( m_ExpValue/fCapital<0.0 )
						strForm = "< -0.01";
					else
						strForm = "< 0.01";
				}
				else
					strForm.Format("%.2f",m_ExpValue/fCapital*100);	

				strForm += "%";
			}
			m_list.SetItemText(m_nRow+3,7,strForm);
		}

		if( lExpiryDays==0 || (strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex()) || fCapital==0.0 )
			strForm = "-- --";
		else
		{
			if( m_bUseRecord )
				d = (pow(1.0+d/fCapital,365.0/m_InvestDays)-1)*100;
			else
				d = (pow(1.0+d/fCapital,365.0/lExpiryDays)-1)*100;
			
			if( fabs(d)>100 )
			{
				if( d>1000.0 )
					strForm = "> 1000";
				else
					strForm.Format("%.0f",d);
			}
			else
			{
				if( fabs(d)<0.01 )
				{
					if( d<0.0 )
						strForm = "< -0.01";
					else
						strForm = "< 0.01";
				}
				else
					strForm.Format("%.2f",d);
			}
			strForm += "%";
		}
		m_list.SetItemText(m_nRow+2,8,strForm);
		if( m_bUseRecord && m_ExpValue!=0.0 )
		{
			if( fCapital==0.0 )
				strForm = "-- --";
			else
			{
				d = (pow(1.0+m_ExpValue/fCapital,365.0/m_InvestDays)-1)*100;
				if( fabs(d)>100 )
				{
					if( d>1000.0 )
						strForm = "> 1000";
					else
						strForm.Format("%.0f",d);
				}
				else
				{
					if( fabs(d)<0.01 )
					{
						if( d<0.0 )
							strForm = "< -0.01";
						else
							strForm = "< 0.01";
					}
					else
						strForm.Format("%.2f",d);
				}
				strForm += "%";
				m_list.SetItemText(m_nRow+3,8,strForm);
			}
		}
		
		if( Gain==1.0 || Loss==1.0 || Loss==0.0 )
		{
			strForm = "-- --";
			m_list.SetItemText(m_nRow+4,7,strForm);
		}
		else
		{
			if( Gain>fabs(Loss) )
				strForm.Format("%.1f : 1",Gain/fabs(Loss));
			else
				strForm.Format("1 : %.1f",1.0/(Gain/fabs(Loss)));
			m_list.SetItemText(m_nRow+4,7,strForm);
		}
	}

	if( IsIndex()&&strcmp(m_TTOptions->m_szFutures,"")==0 )
		btemp = FALSE;
	if( m_bMode==3 && btemp )
	{
		
		SetListMode();
		CString str;
		char ch[10] = {0};
		for( i=0;i<arr_IVX.GetSize();i++ )
		{
			GetPriceTxt(arr_IVX[i],str);
			m_list.InsertItem(i, str);

			for( j=0;j<4;j++ )
			{
				GetTextGK(ch,arr_Greeks[j][i],4);
				str = ch;
				m_list.SetItemText(i,j+1,str);
			}
		}
	}
AdjustWidth:
	if( m_bMode==0 )
	{
		AdjustColumnWidth();
		if( !m_bUseRecord )
		{
			CRect  EditRect;
			m_list.GetSubItemRect(2, 2, LVIR_LABEL, EditRect);
			EditRect.SetRect(EditRect.right-16, EditRect.top-1, EditRect.right-1, EditRect.bottom);
			m_pSpin->MoveWindow(&EditRect);
			CRect  BtnRect;
			m_list.GetSubItemRect(2, 0, LVIR_LABEL, BtnRect);
			BtnRect.SetRect(BtnRect.right-55, BtnRect.top+1, BtnRect.right-5, BtnRect.bottom-1);
			m_pBtn->MoveWindow(&BtnRect);
			if( m_nIndex==STGY_CUSTOM )
			{
				for( int z=0;z<5;z++ )
				{
					m_list.GetSubItemRect(z+3, 2, LVIR_LABEL, EditRect);
					EditRect.SetRect(EditRect.right-16, EditRect.top-1, EditRect.right-1, EditRect.bottom);
					m_pSpinEx[z]->MoveWindow(&EditRect);
				}
			}
			m_list.Invalidate();
		}
		
		if( m_nIndex==16 )
		{
			CRect  EditRect;
			m_list.GetSubItemRect(2, 1, LVIR_LABEL, EditRect);
			EditRect.SetRect(EditRect.right-16, EditRect.top-1, EditRect.right-1, EditRect.bottom);
			m_pSpin_C->MoveWindow(&EditRect);
			m_list.Invalidate();
		}
		else if( m_nIndex==STGY_CUSTOM )
		{
			for( int z=0;z<5;z++ )
			{
				if( m_nCustomIx[z]==4 && m_bHaveCrt_Spin_C )
				{
					CRect  EditRect;
					m_list.GetSubItemRect(2+z, 1, LVIR_LABEL, EditRect);
					EditRect.SetRect(EditRect.right-16, EditRect.top-1, EditRect.right-1, EditRect.bottom);
					m_pSpin_C->MoveWindow(&EditRect);
					m_list.Invalidate();
					break;
				}
			}	
		}
	}

	if( m_bOrder && m_bReLoadList2Data )
		LoadData();

	if( m_bOrder )
	{
		//m_list2.EnableWindow();
		if( m_iDbClickInx!=-1 )
		{
			m_list2.EnableWindow();
			m_list2.SetItemState(m_iDbClickInx, LVIS_SELECTED,LVIS_SELECTED);
			m_list2.SetFocus();
			m_iDbClickInx = -1;
			UpdateYK();
		}
	}
	
}

int CStrategy::PrePaint()
{
	int i, is,ie;
	m_arrBrkValue.RemoveAll();
	m_arrBrkPB.RemoveAll();
	for( i=0;i<5;i++ )
		m_arrPL[i].RemoveAll();

	m_TTOptions->GetItemShares();
	m_lShares = m_TTOptions->m_lShares;
	m_lShares *= m_nOrderCount; //֮����ʾҪ����
	
	m_arrItem.RemoveAll();
	m_nPos = -1;
	
	EnterCriticalSection(&m_cs);
	for( i=0; i<m_TTOptions->m_nDataTotal; i++ )
		m_arrItem.Add(m_TTOptions->m_pDataBuf[i]);
	LeaveCriticalSection( &m_cs );
	
	
	if( m_arrItem.GetSize==0 )
		return 0;
	
	float fCash = m_TTOptions->GetCorrStockPrice(FALSE,1);
	
	for( i=0;i<m_arrItem.GetSize();i++ )
	{
		if( m_arrItem[i].m_fStrike>fCash )
		{
			m_nPos = i;
			break;
		}
	}
	if( m_nPos==-1 )
		return 0;
	
	BOOL b1 = FALSE;
	BOOL b2 = FALSE;
	if( m_nIxStrike==-1&&m_nIxStrike2==-1&&m_nIxStrike3==-1&&m_nIxStrike4==-1&&m_nIxStrike5==-1&&m_nIxStrike6==-1 )
		b1 = TRUE;
	if( m_nIxStrike==-2&&m_nIxStrike2==-2&&m_nIxStrike3==-2&&m_nIxStrike4==-2&&m_nIxStrike5==-2&&m_nIxStrike6==-2 )
		b2 = TRUE;

	if( b1 || b2 )
		m_nPrePos = m_nPos;
	else
		m_nPos = m_nPrePos;


	char sz[100];
	sprintf(sz,"DataSize: %d, ClosestNum: %d",m_TTOptions->m_nDataTotal,m_nPos);
//	m_TTOptions->WriteLogFile(sz);

	if( m_nPos>=m_TTOptions->m_nDataTotal )
		return 0;

	if( (m_nIndex==17||m_nIndex==18) && m_bItemCodeChange )
	{
	/*	m_cald.fStrike = m_arrItem[m_nPos].m_fStrike;
		m_fStrike2_Spread = m_cald.fStrike;
		if( m_nIndex==18 )
		{
			m_cald.fStrike = m_arrItem[m_nPos+1].m_fStrike;
			m_fStrike2_Spread = m_arrItem[m_nPos-1].m_fStrike;
		}*/

		m_cald.fStrike = m_arrItem[m_nPos].m_fStrike;
		POSITION pos = m_TTOptions->m_lstMonths.GetHeadPosition();
		m_cald.lMonth1 = m_TTOptions->m_lstMonths.GetNext(pos);
		m_cald.lMonth2 = m_TTOptions->m_lstMonths.GetNext(pos);
		m_fStrike2_Spread = m_cald.fStrike;
		
		if( m_nIndex==18 )
		{
			m_cald.fStrike = m_arrItem[m_nPos+1].m_fStrike;
			m_fStrike2_Spread = m_arrItem[m_nPos-1].m_fStrike;
		}
		CalendarRequest();
	//	m_bItemCodeChange = FALSE;
	}
	return 1;
	
}

void CStrategy::GetBrkProb()
{
	if( m_nIndex==STGY_CUSTOM || (strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex()) )
		return;

	int nBrk[10],i,j;
	float fBrkPB[10],fZero,fOne;
	fZero = 0.0;
	fOne = 1.0;  //0��1��
	BYTE bCall,bPut;
	bCall = 0;
	bPut = 0;
	m_fStgyPB = 1.0;
	memset(nBrk,0,2*sizeof(int));
	memset(fBrkPB,0,2*sizeof(float));
	m_arrBrkPB.RemoveAll();
	for( i=0;i<m_arrItem.GetSize();i++ )
	{
		for( j=0;j<m_arrBrkValue.GetSize();j++ )
		{
			if( m_arrItem[i].m_fStrike>m_arrBrkValue[j] && nBrk[j]==0 )
				nBrk[j] = i;
			if( i==m_arrItem.GetSize()-1 && nBrk[j]==0 )
				nBrk[j] = i;
		}
	}

	

	float chf1,chf2,fDiffStk;
	long iExpDay;
	BSMCALINFO calinfo;
	iExpDay = m_nDay1;
	char cc[100];

	if( m_arrBrkValue.GetSize()>=2 )
	{
		fDiffStk = m_arrItem[nBrk[0]].m_fStrike-m_arrItem[nBrk[0]-1].m_fStrike;
	//	m_TTOptions->CalcIVData(nBrk[0]-1,m_TTOptions->m_pDataBuf[nBrk[0]-1],POS_PUT_LAST);
	//	m_TTOptions->CalcIVData(nBrk[0],m_TTOptions->m_pDataBuf[nBrk[0]],POS_PUT_LAST);
	//	chf1 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]-1].m_szPuts_ITM);
	//	chf2 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]].m_szPuts_ITM);
		m_TTOptions->ModelPrice(FALSE,m_arrItem[nBrk[0]-1].m_fStrike,0,iExpDay,POS_PUT_LAST,calinfo,2);
		chf1 = 1.0 - calinfo.ITM;
		m_TTOptions->ModelPrice(FALSE,m_arrItem[nBrk[0]].m_fStrike,0,iExpDay,POS_PUT_LAST,calinfo,2);
		chf2 = 1.0 - calinfo.ITM;
		fBrkPB[0] = (m_arrBrkValue[0]-m_arrItem[nBrk[0]-1].m_fStrike)/fDiffStk*(chf2-chf1)+chf1;
		m_arrBrkPB.Add(fBrkPB[0]);
		m_arrBrkPB.Add(fZero);
		
		fDiffStk = m_arrItem[nBrk[1]].m_fStrike-m_arrItem[nBrk[1]-1].m_fStrike;
	//	m_TTOptions->CalcIVData(nBrk[1]-1,m_TTOptions->m_pDataBuf[nBrk[1]-1],POS_CALL_LAST);
	//	m_TTOptions->CalcIVData(nBrk[1],m_TTOptions->m_pDataBuf[nBrk[1]],POS_CALL_LAST);
	//	chf1 = atof(m_TTOptions->m_pList1->m_buf[nBrk[1]-1].m_szCalls_ITM);
	//	chf2 = atof(m_TTOptions->m_pList1->m_buf[nBrk[1]].m_szCalls_ITM);
		m_TTOptions->ModelPrice(TRUE,m_arrItem[nBrk[1]-1].m_fStrike,0,iExpDay,POS_CALL_LAST,calinfo,2);
		chf1 = calinfo.ITM;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[nBrk[1]].m_fStrike,0,iExpDay,POS_CALL_LAST,calinfo,2);
		chf2 = calinfo.ITM;
		fBrkPB[1] = (m_arrItem[nBrk[1]].m_fStrike-m_arrBrkValue[1])/fDiffStk*(chf1-chf2)+chf2;
		m_arrBrkPB.Add(fBrkPB[1]);
		m_arrBrkPB.Add(fOne);

		switch( m_nIndex )
		{
		case 0:
		case 1:
			fDiffStk = m_arrItem[nBrk[0]].m_fStrike-m_arrItem[nBrk[0]-1].m_fStrike;
		//	m_TTOptions->CalcIVData(nBrk[0]-1,m_TTOptions->m_pDataBuf[nBrk[0]-1],POS_CALL_LAST);
		//	m_TTOptions->CalcIVData(nBrk[0],m_TTOptions->m_pDataBuf[nBrk[0]],POS_CALL_LAST);
		//	chf1 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]-1].m_szCalls_ITM);
		//	chf2 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]].m_szCalls_ITM);
			m_TTOptions->ModelPrice(TRUE,m_arrItem[nBrk[0]-1].m_fStrike,0,iExpDay,POS_CALL_LAST,calinfo);
			chf1 = calinfo.ITM;
			m_TTOptions->ModelPrice(TRUE,m_arrItem[nBrk[0]].m_fStrike,0,iExpDay,POS_CALL_LAST,calinfo);
			chf2 = calinfo.ITM;
			fBrkPB[0] = (m_arrItem[nBrk[0]].m_fStrike-m_arrBrkValue[0])/fDiffStk*(chf1-chf2)+chf2;
			fBrkPB[0] = 1-fBrkPB[0];
			m_arrBrkPB[0] = fBrkPB[0];
			if( m_nIndex==0 )
				m_fStgyPB = 1-fBrkPB[0]-fBrkPB[1];
			else if( m_nIndex==1 )
				m_fStgyPB = fBrkPB[0]+fBrkPB[1];
			break;
		case 3:
		case 5:
		case 6:
			m_fStgyPB = 1-fBrkPB[0]-fBrkPB[1];
			break;
		case 2:
		case 4:
			m_fStgyPB = fBrkPB[0]+fBrkPB[1];
			break;
		case 17:
		case 18:
			/*if(m_cald.bDebit==0)
				m_fStgyPB = 1-fBrkPB[0]-fBrkPB[1];
			else
				m_fStgyPB = fBrkPB[0]+fBrkPB[1];*/
			if( m_arrPL[0][1]>0 )
				m_fStgyPB = fBrkPB[0]+fBrkPB[1];
			else
				m_fStgyPB = 1-fBrkPB[0]-fBrkPB[1];
			break;
		}
	}
	else if( m_arrBrkValue.GetSize()==1 )
	{
		switch( m_nIndex )
		{
		case 0:
		case 1:
		case 6:
		case 7:
		case 9:
		case 11:
		case 12:
		case 15:
		case 17:
		case 18:
			fDiffStk = m_arrItem[nBrk[0]].m_fStrike-m_arrItem[nBrk[0]-1].m_fStrike;
		//	m_TTOptions->CalcIVData(nBrk[0]-1,m_TTOptions->m_pDataBuf[nBrk[0]-1],POS_CALL_LAST);
		//	m_TTOptions->CalcIVData(nBrk[0],m_TTOptions->m_pDataBuf[nBrk[0]],POS_CALL_LAST);
		//	chf1 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]-1].m_szCalls_ITM);
		//	chf2 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]].m_szCalls_ITM);
			m_TTOptions->ModelPrice(TRUE,m_arrItem[nBrk[0]-1].m_fStrike,0,iExpDay,POS_CALL_LAST,calinfo,2);
			chf1 = calinfo.ITM;
			m_TTOptions->ModelPrice(TRUE,m_arrItem[nBrk[0]].m_fStrike,0,iExpDay,POS_CALL_LAST,calinfo,2);
			chf2 = calinfo.ITM;
			fBrkPB[0] = (m_arrItem[nBrk[0]].m_fStrike-m_arrBrkValue[0])/fDiffStk*(chf1-chf2)+chf2;

			fDiffStk = m_arrItem[nBrk[0]].m_fStrike-m_arrItem[nBrk[0]-1].m_fStrike;
		//	m_TTOptions->CalcIVData(nBrk[0]-1,m_TTOptions->m_pDataBuf[nBrk[0]-1],POS_PUT_LAST);
		//	m_TTOptions->CalcIVData(nBrk[0],m_TTOptions->m_pDataBuf[nBrk[0]],POS_PUT_LAST);
		//	chf1 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]-1].m_szPuts_ITM);
		//	chf2 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]].m_szPuts_ITM);
			m_TTOptions->ModelPrice(FALSE,m_arrItem[nBrk[0]-1].m_fStrike,0,iExpDay,POS_PUT_LAST,calinfo,2);
			chf1 = 1.0 - calinfo.ITM;
			m_TTOptions->ModelPrice(FALSE,m_arrItem[nBrk[0]].m_fStrike,0,iExpDay,POS_PUT_LAST,calinfo,2);
			chf2 = 1.0 - calinfo.ITM;
			fBrkPB[1] = (m_arrBrkValue[0]-m_arrItem[nBrk[0]-1].m_fStrike)/fDiffStk*(chf2-chf1)+chf1;

			if( m_nIndex==6 )
			{
				if( (iSign2-iSign1)>(iSign4-iSign3) )
				{
					fBrkPB[0] = 1-fBrkPB[0];
					m_arrBrkPB.Add(fBrkPB[0]);
					m_arrBrkPB.Add(fZero);
				}
				else if( (iSign2-iSign1)<(iSign4-iSign3) )
				{
					fBrkPB[0] = 1-fBrkPB[1];
					m_arrBrkPB.Add(fBrkPB[0]);
					m_arrBrkPB.Add(fOne);
				}
			}

			if( m_nIndex==9 || m_nIndex==12)
			{
				fBrkPB[0] = 1-fBrkPB[0];
				m_arrBrkPB.Add(fBrkPB[0]);
				m_arrBrkPB.Add(fZero);
			}
			else if( (m_nIndex==0 && 2*iSign2<iSign1+iSign3)
					||(m_nIndex==1 && 2*iSign2>iSign1+iSign3) ) 
			{
				fBrkPB[0] = 1-fBrkPB[0];
				m_arrBrkPB.Add(fBrkPB[0]);
				m_arrBrkPB.Add(fZero);
			}
			else if( m_nIndex==17 || m_nIndex==18 )
			{
				if( m_arrPL[0][1]<0 )
				{
					m_arrBrkPB.Add(fBrkPB[0]);
					m_arrBrkPB.Add(fOne);
				}
				else
				{
					fBrkPB[0] = 1-fBrkPB[0];
					m_arrBrkPB.Add(fBrkPB[0]);
					m_arrBrkPB.Add(fZero);
				}
			}
			else
			{
				m_arrBrkPB.Add(fBrkPB[0]);
				m_arrBrkPB.Add(fOne);
			}
			break;
		case 8:
		case 10:
		case 13:
		case 14:
		case 16:
			fDiffStk = m_arrItem[nBrk[0]].m_fStrike-m_arrItem[nBrk[0]-1].m_fStrike;
		//	m_TTOptions->CalcIVData(nBrk[0]-1,m_TTOptions->m_pDataBuf[nBrk[0]-1],POS_PUT_LAST);
		//	m_TTOptions->CalcIVData(nBrk[0],m_TTOptions->m_pDataBuf[nBrk[0]],POS_PUT_LAST);
		//	chf1 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]-1].m_szPuts_ITM);
		//	chf2 = atof(m_TTOptions->m_pList1->m_buf[nBrk[0]].m_szPuts_ITM);
			m_TTOptions->ModelPrice(FALSE,m_arrItem[nBrk[0]-1].m_fStrike,0,iExpDay,POS_PUT_LAST,calinfo);
			chf1 = 1.0 - calinfo.ITM;
			m_TTOptions->ModelPrice(FALSE,m_arrItem[nBrk[0]].m_fStrike,0,iExpDay,POS_PUT_LAST,calinfo);
			chf2 = 1.0 - calinfo.ITM;
			fBrkPB[0] = (m_arrBrkValue[0]-m_arrItem[nBrk[0]-1].m_fStrike)/fDiffStk*(chf2-chf1)+chf1;
			if( m_nIndex==10 || m_nIndex==13)
			{
				fBrkPB[0] = 1-fBrkPB[0];
				m_arrBrkPB.Add(fBrkPB[0]);
				m_arrBrkPB.Add(fOne);
			}
			else
			{
				m_arrBrkPB.Add(fBrkPB[0]);
				m_arrBrkPB.Add(fZero);
			}
			break;
		}
		m_fStgyPB = fBrkPB[0];
	}
}

CStringArray arr_x,arr_y,arr_xp,arr_yp;
CArrayFloat  arr_fx,arr_fy;
CString szValue;
BOOL bDraw;
BOOL bBreak1, bBreak2;
CStringArray arr_strIV;

float CStrategy::CalcStock(float fValue)
{
	int i;
	float fCalc = 0.0;

	for( i=0;i<6;i++ )
	{
		if( m_nCustomIx[i]==4 )
			fCalc += (m_fLPrice[i] - fValue)*abs(m_nCustomCount[i]);
		else if( m_nCustomIx[i]==5 )
			fCalc += (fValue - m_fLPrice[i])*abs(m_nCustomCount[i]);
	}

	fCalc *= m_lShares;
	return fCalc;
}

void CStrategy::GetCaldInx()
{
	int i;
	CCDArray tempCD;
	tempCD.RemoveAll();
	EnterCriticalSection(&m_cs);
	tempCD.Copy(m_TTOptions->m_arrCD);
	LeaveCriticalSection( &m_cs );
	for( i=0;i<tempCD.GetSize();i++ )
	{
		if( memcmp(tempCD[i].szCode,m_TTOptions->m_szItemCode,8)==0 && tempCD[i].lDate==m_cald.lMonth2 )
		{
			m_iCaldInx2 = i;
			break;
		}
	}
	
	for( i=0;i<tempCD.GetSize();i++ )
	{
		if( memcmp(tempCD[i].szCode,m_TTOptions->m_szItemCode,8)==0 && tempCD[i].lDate==m_cald.lMonth1 )
		{
			m_iCaldInx1 = i;
			break;
		}
	}
	
	m_nIxStrike = m_iCaldInx1;
	m_nIxStrike2 = m_iCaldInx2;  
	
}

//Calendar Spread����
/*
			if( f_Strike<=m_cald.fStrike )
			{
				if( m_cald.bDebit==0 && m_cald.bCall==0 )
				{
					temp1 = ( m_fLPrice[0]-m_fLPrice[1]+f )*m_lShares;
					  //Buy Call
				}
				else if( m_cald.bDebit==0 && m_cald.bCall==1 )
				{
					temp1 = ( m_fLPrice[0]-m_fLPrice[1]+f-(m_cald.fStrike-f_Strike) )*m_lShares;
					  //Buy Put
				}
				else if( m_cald.bDebit==1 && m_cald.bCall==0 )
				{
					temp1 = ( m_fLPrice[1]-m_fLPrice[0]-f )*m_lShares;
					   //Sell  Call
				}
				else if( m_cald.bDebit==1 && m_cald.bCall==1 )
				{
					temp1 = ( m_fLPrice[1]-m_fLPrice[0]-(f-(m_cald.fStrike-f_Strike)) )*m_lShares;
					  //Sell Put
				}
			}
			else
			{
				if( m_cald.bDebit==0 && m_cald.bCall==0 )
				{
					temp1 = ( m_fLPrice[0]-m_fLPrice[1]+f-(f_Strike-m_cald.fStrike) )*m_lShares;
					 //Buy Call
				}
				else if( m_cald.bDebit==0 && m_cald.bCall==1 )
				{
					temp1 = ( m_fLPrice[0]-m_fLPrice[1]+f )*m_lShares;
					  //Buy Put
				}
				else if( m_cald.bDebit==1 && m_cald.bCall==0 )
				{
					temp1 = ( m_fLPrice[1]-m_fLPrice[0]-(f-(f_Strike-m_cald.fStrike)) )*m_lShares;
					 //Sell Call
				}
				else if( m_cald.bDebit==1 && m_cald.bCall==1 )
				{
					temp1 = ( m_fLPrice[1]-m_fLPrice[0]-f )*m_lShares;
					  //Sell Put
				}
				
			}
			*/

int CStrategy::DrawIncomeLine()
{
	
//	CPaintDC dc(this);
	m_bDrawing = TRUE;

	BOOL TOF1,TOF2; int PON;//����Calendar��Diagonal   TRUE or FALSE   +1 or -1

	static int NonMarketNum = 0;
	
	CString headline[3] = {"P&L","ӯ��ֵ","ӯֵ̝"};
	CRect frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);
	
	MemDC.FillSolidRect(0, 0, frmrect.Width()-4,frmrect.Height()-12, RGB(255,255,255));
	
	MemDC.SetBkMode(TRANSPARENT);

	int ox, oy, dex, dey;
	ox = 45;
	if( IsIndex() )
		ox = 60;
	oy = frmrect.Height()-50;
	dex = frmrect.Width()-100;
	if( IsIndex() )
		dex = frmrect.Width()-110;
	if( m_nIndexIV>0 && m_nIndexIV<5 )
		dex -= 10;
	if( IsIndex() && m_nIndexIV==3 )
		dex -= 18;
	if( !IsIndex() && (m_nIndexIV!=3||m_nIndexIV!=0) )
		dex += 5;
	
	dey = frmrect.Height()-75;
	CPoint oxy(ox, oy);

	CSize cSize, cSize0;
	
//	CFont *oldfont = NULL;
	
	/*oldfont =*/ MemDC.SelectObject(&m_font1);

	cSize = MemDC.GetTextExtent(headline[m_TTOptions->m_iLangType]);

	if(IsIndex())
		MemDC.TextOut(20, frmrect.Height()-dey-cSize.cy-55,headline[m_TTOptions->m_iLangType]);
	else
		MemDC.TextOut(5, frmrect.Height()-dey-cSize.cy-55,headline[m_TTOptions->m_iLangType]);

	SYSTEMTIME SysTime;
	GetSystemTime(&SysTime);
	long lToday = SysTime.wYear*10000 + SysTime.wMonth*100 + SysTime.wDay;
	int  lExpiryDays;
	m_TTOptions->DateDiff(m_TTOptions->m_lExpiryTime,lToday,lExpiryDays);
	if( m_nIndex==17 || m_nIndex==18 )
	{
		m_TTOptions->DateDiff(m_lCaldExpDate1,lToday,lExpiryDays);
	}
	
	CString strExp,strSgn;
	int iLang = m_TTOptions->m_iLangType;
	char szBuf[30] = {0};
	strcpy(szBuf,m_TTOptions->m_szItemName);
	if( m_TTOptions->m_iLangType==2 )
		BIG52GBK(szBuf);

	strExp.Format("%s%s%s%s%d(%d%s)", szBuf,m_TTOptions->m_szText,szExpDate[iLang],szRemainDay[iLang],m_TTOptions->m_lExpiryTime,lExpiryDays,szWord[iLang]);
	if( m_nIndex==17 || m_nIndex==18 )
		strExp.Format("%s%d/%d%s%s%d(%d%s)", szBuf,m_lCaldExpDate1/100%100,m_lCaldExpDate1/10000,szExpDate[iLang],szRemainDay[iLang],m_lCaldExpDate1,lExpiryDays,szWord[iLang]);
	cSize = MemDC.GetTextExtent(strExp);
	//MemDC.SelectObject(oldfont);
	//oldfont = 
	MemDC.SelectObject(&m_font1);
	if( m_bTarget==0 )
		MemDC.TextOut(frmrect.Width()/2-cSize.cx/2, cSize.cy/2-2,strExp);
	else
	{
		CSize tempsize;
		tempsize = MemDC.GetTextExtent(headline[m_TTOptions->m_iLangType]);
		if( IsIndex() )
			MemDC.TextOut(30+tempsize.cx,cSize.cy/2-2,strExp);
		else
			MemDC.TextOut(10+tempsize.cx,cSize.cy/2-2,strExp);
	}
	
	CPen *oldpen = NULL;
	CPen pen1(PS_SOLID,1,RGB(211,211,211));  //��ɫ
	CPen pen2(PS_SOLID,1,RGB(0,0,0));//��ɫ
	CPen pen2_2(PS_SOLID,4,RGB(0,0,0));
	CPen pen3(PS_SOLID,2,RGB(255,0,0));//��ɫ
	CPen pen4(PS_SOLID,1,RGB(0,139,0));//��ɫ

	CPen pen11(PS_SOLID,2,RGB(0,255,127));
	CPen pen12(PS_SOLID,2,RGB(30,144,255));
	CPen pen13(PS_SOLID,2,RGB(0,130,0));
	CPen pen14(PS_SOLID,2,RGB(148,0,211));
	CPen penEx1(PS_SOLID,1,RGB(100,149,237));
	CPen penEx2(PS_SOLID,1,RGB(247,141,147));

	CPen pen5(PS_SOLID,1,RGB(47,79,79));//�ּ���ɫ
	CPen pen6(PS_SOLID,1,RGB(238,118,0));//��ɫ
	CPen pen7(PS_DOT,1,RGB(46,139,87));//��
	CPen pen8(PS_SOLID,1,RGB(105,105,105)); 
	CPen pen9(PS_SOLID,1,RGB(47,79,79)); 
	CPen pen10(PS_DOT,1,RGB(85,26,139)); 

	CPen pen15(PS_SOLID,1,RGB(205,92,92));
	CPen pen16(PS_DASH,1,RGB(119,136,153));

	for( int w=0;w<2;w++ )
	{
		if( m_bBtnDown[w] )
		{
			MemDC.SelectObject(&penEx1);
			MemDC.SelectObject(&m_bsh5);
		}
		else
		{
			MemDC.SelectObject(&penEx2);
			MemDC.SelectObject(&m_bsh4);
		}
		MemDC.Ellipse(frmrect.Width()-80+w*(24+10),frmrect.Height()-40,frmrect.Width()-56+w*(24+10),frmrect.Height()-16);
	}
	MemDC.SelectObject(&m_font6);
	strSgn = "-";
	CSize sze = MemDC.GetTextExtent(strSgn);
	if( m_bBtnDown[0] )
		MemDC.SetTextColor(RGB(255,255,255));
	else
		MemDC.SetTextColor(RGB(0,0,0));
	MemDC.TextOut(frmrect.Width()-56-12-sze.cx/2,frmrect.Height()-16-12-sze.cy/2,strSgn);
	strSgn = "+";
	sze = MemDC.GetTextExtent(strSgn);
	if( m_bBtnDown[1] )
		MemDC.SetTextColor(RGB(255,255,255));
	else
		MemDC.SetTextColor(RGB(0,0,0));
	MemDC.TextOut(frmrect.Width()-22-12-sze.cx/2,frmrect.Height()-16-12-sze.cy/2,strSgn);

	MemDC.SetTextColor(RGB(0,0,0));
	oldpen = MemDC.SelectObject(&pen8);
	//X��Y��
	MemDC.MoveTo(oxy);
	MemDC.LineTo(oxy.x+dex,oxy.y);  
	MemDC.LineTo(oxy.x+dex,oxy.y-dey);  
	MemDC.LineTo(oxy.x,oxy.y-dey); 
	MemDC.LineTo(oxy.x,oxy.y);  
	
	if( m_bPainted )
	{
		arr_x.RemoveAll();
		arr_y.RemoveAll();
		arr_xp.RemoveAll();
		arr_yp.RemoveAll();
		arr_fx.RemoveAll();
		arr_fy.RemoveAll();
	}
	
	float dea = 0.0;
	float fExtre = 0.0;
	int intervalX = dex/11;     //X��11���� ���
	int intervalY; //= dey/6;     //Y��6���� ���  ��������ٶ���������Ŀ
	int is, ie, i, j, k,d;
	
	float fCash = m_TTOptions->GetCorrStockPrice(FALSE,1);
	float fCorr = m_TTOptions->GetCorrStockPrice(FALSE);
	float fFarPrice = 0.0;//Զ�µ��ڻ���
	float fSpread = 0.0;  //ָ����ȨԶ���·ݵ��ڻ��۲�
	if( IsIndex()&&(m_nIndex==17|| m_nIndex==18) )
	{
		fCorr = GetMonthPrice(m_lCaldExpDate1);
		fFarPrice = GetMonthPrice(m_lCaldExpDate2);
		fSpread = fFarPrice-fCorr;
	}

	BOOL bCall;
	float f = 0.0, fIV = 0.0,fdivi = 0.0,f1 = 0.0,f2 = 0.0;
	float f_Strike = 0.0;
	int indexIV;
	float fTran = 0.0, ftempPL = 0.0;
	float ftempPL1 = 0.0;
	float temp1 = 0.0, temp2=0.0;
	float iYmax = 0.0, iYmin = 0.0;
	float price = 0.0;
	int   iExpDay;
	int   irow;
	int   iPMs[6];//  1 or -1  short:-1  long:1
				  //  �����е���Ȩ�������1��Ҫ�������ķ���
	int   inAddr[6];  //POS_CALL_LAST or POS_PUT_LAST
	int   CPPos;
	int   IxS;

	CLPArray arrLP1;
	CLPArray arrLP2;
	
	memset(&iPMs, 0, 6*sizeof(int));
	memset(&inAddr, 0, 6*sizeof(int));
	CString strForm;
//	m_fEliminate = 0.0;
	char cc[100] = {0};

	if( m_bPainted )
	{
		char sz[100];
		sprintf(sz,"StgyIx: %d, UseRecord: %d",m_nIndex,m_bUseRecord);
//		m_TTOptions->WriteLogFile(sz);
		bDraw = TRUE;
		bBreak1 = FALSE;
		bBreak2 = FALSE;
	switch( m_nIndex )
	{
	case 0:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike2;
		iSign3 = m_nIxStrike3;
		if( m_nIxStrike>m_nIxStrike3 )
		{
			iSign1 = m_nIxStrike3;
			iSign3 = m_nIxStrike;
		}
		iSign = (iSign1+iSign3+1)/2;
		
		if( iSign1<0 || iSign2<0 || iSign3<0 )
		{
			ReleaseDC(&MemDC);
			m_bDrawing = FALSE;
			return 0;
		}
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign1].m_fCalls_Ask,iSign1,TRUE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign2].m_fCalls_Bid,iSign2,TRUE);
		if( !m_bAlterPrice[2] )
			m_fiSignPrice[2] = UnitPrice(m_arrItem[iSign3].m_fCalls_Ask,iSign3,TRUE);
		//principal = 2*m_fiSignPrice[1]-m_fiSignPrice[0]-m_fiSignPrice[2];
		//fExtre = (m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
//			m_fEliminate = m_fLPrice[1]*2;
			principal = 2*m_fLPrice[1]-m_fLPrice[0]-m_fLPrice[2];
			fExtre = (m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		}

		fIV = 0.0;
		fdivi = 0.0;
		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV = calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility*2;
			fdivi += 2;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign3].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		
		iYmax = fExtre;
		iYmin = principal*m_lShares;
		
		//�����������ӳ���
		temp1 = principal*m_lShares;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		
		temp1 = principal*m_lShares;
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( principal<0 && fExtre>=0 )
		{
			temp1 = m_arrItem[iSign1].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			bBreak1 = TRUE;
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		

		if( (2*m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike-m_arrItem[iSign3].m_fStrike+principal)<0 && fExtre>=0 )
		{
			temp1 = 2*m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			bBreak2 = TRUE;
			m_arrBrkValue.Add(temp1);
		}
		
		m_arrPL[0].Add(m_arrItem[iSign3].m_fStrike);
		temp1 = (2*m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike-m_arrItem[iSign3].m_fStrike+principal)*m_lShares;
		m_arrPL[0].Add(temp1);
		
		//temp1 = principal*m_lShares;
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);

		Gain = fExtre;
		Loss = m_arrPL[0][1]<temp1?m_arrPL[0][1]:temp1;
		if( Gain<0 || Loss>0 )
			bDraw = FALSE;


		iYmin = Loss;

		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<3;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = 1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_ASK;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (price-m_fiSignPrice[0])*m_lShares;
						//if( m_bUseRecord )
							f = (price-m_fLPrice[0])*m_lShares;
						break;
					case 1:
						iPMs[j] = -1*2;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_BID;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (m_fiSignPrice[1]-price)*m_lShares*2;
						//if( m_bUseRecord )
							f = (m_fLPrice[1]-price)*m_lShares*2;
						break;
					case 2:
						iPMs[j] = 1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_ASK;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign3].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (price-m_fiSignPrice[2])*m_lShares;
						//if( m_bUseRecord )
							f = (price-m_fLPrice[2])*m_lShares;
						break;
					}
			//		char log[50];
					
					temp1 += f;
			//		sprintf(log,"Market = %.2f,Price = %.2f,temp = %.2f",f_Strike,price,temp1);
			//		if(k==1)
			//			m_TTOptions->WriteLogFile(log);

				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea; 
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}
		break;
	case 1:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike2;
		iSign3 = m_nIxStrike3;
		if( m_nIxStrike>m_nIxStrike3 )
		{
			iSign1 = m_nIxStrike3;
			iSign3 = m_nIxStrike;
		}
		iSign = (iSign1+iSign3+1)/2;

		if( iSign1<0 || iSign2<0 || iSign3<0 )
		{
			ReleaseDC(&MemDC);
			m_bDrawing = FALSE;
			return 0;
		}
	
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign1].m_fCalls_Bid,iSign1,TRUE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign2].m_fCalls_Ask,iSign2,TRUE);
		if( !m_bAlterPrice[2] )
			m_fiSignPrice[2] = UnitPrice(m_arrItem[iSign3].m_fCalls_Bid,iSign3,TRUE);
		//principal = -2*m_fiSignPrice[1]+m_fiSignPrice[0]+m_fiSignPrice[2];
		//fExtre = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		//if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
//			m_fEliminate = m_fLPrice[0]+m_fLPrice[2];
			principal = -2*m_fLPrice[1]+m_fLPrice[0]+m_fLPrice[2];
			fExtre = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV = calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility*2;
			fdivi += 2;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign3].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = fExtre;
		iYmax = principal*m_lShares;;
		
		
		
		//�����������ӳ���
		
		temp1 = principal*m_lShares;
		
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		temp1 = principal*m_lShares;
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( principal>0 && fExtre<=0 )
		{
			temp1 = m_arrItem[iSign1].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			bBreak1 = TRUE;
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( (m_arrItem[iSign1].m_fStrike+m_arrItem[iSign3].m_fStrike-2*m_arrItem[iSign2].m_fStrike+principal)>0 && fExtre<=0 )
		{
			temp1 = 2*m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike-principal;
			
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			bBreak2 = TRUE;
			m_arrBrkValue.Add(temp1);
		}
		
		m_arrPL[0].Add(m_arrItem[iSign3].m_fStrike);
		temp1 = (m_arrItem[iSign1].m_fStrike+m_arrItem[iSign3].m_fStrike-2*m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		m_arrPL[0].Add(temp1);
		
		//temp1 = principal*m_lShares;
		
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);

		Loss = fExtre;
		Gain = m_arrPL[0][1]>temp1?m_arrPL[0][1]:temp1;
		if( Gain<0 || Loss>0 )
			bDraw = FALSE;

		iYmax = Gain;

		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<3;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = -1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_BID;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (m_fiSignPrice[0]-price)*m_lShares;
						//if( m_bUseRecord )
							f = (m_fLPrice[0]-price)*m_lShares;
						break;
					case 1:
						iPMs[j] = 1*2;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_ASK;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (price-m_fiSignPrice[1])*m_lShares*2;
						//if( m_bUseRecord )
							f = (price-m_fLPrice[1])*m_lShares*2;
						break;
					case 2:
						iPMs[j] = -1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_BID;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign3].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (m_fiSignPrice[2]-price)*m_lShares;
						//if( m_bUseRecord )
							f = (m_fLPrice[2]-price)*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}

		CalcPrecis(iYmax,iYmin,dea);
		
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}
		
		//�ּ�P&L
		if( fCash<=m_arrItem[iSign1].m_fStrike || fCash>=m_arrItem[iSign3].m_fStrike )
			ftempPL = principal*m_lShares;
		else if( fCash>m_arrItem[iSign1].m_fStrike && fCash<m_arrItem[iSign2].m_fStrike )
			ftempPL = (m_arrItem[iSign1].m_fStrike-fCash+principal)*m_lShares;
		else if( fCash>m_arrItem[iSign2].m_fStrike && fCash<m_arrItem[iSign3].m_fStrike )
			ftempPL = (fCash-m_arrItem[iSign3].m_fStrike+principal)*m_lShares;
		break;
		
	case 17:
	case 18:
		arrLP1.RemoveAll();
		arrLP2.RemoveAll();
		if( m_iCaldInx1==-1||m_iCaldInx2==-1 )
			GetCaldInx();
		if( m_iCaldInx1==-1||m_iCaldInx2==-1 )
		{
			ReleaseDC(&MemDC);
			m_bDrawing = FALSE;
			m_nRetn = 0;
			return 0;
		}
		if( IsIndex()&&(fCorr==0.0 || fFarPrice==0.0) )
		{
			NonMarketNum++;
			if( NonMarketNum>=3 )
			{
				ReleaseDC(&MemDC);
				m_bDrawing = FALSE;
			//	NonMarketNum = 0;
				return 0;
			}
			ReleaseDC(&MemDC);
			m_bDrawing = FALSE;
			m_nRetn = 0;
			return 0;
		}
		NonMarketNum = 0;
		EnterCriticalSection(&m_cs);
		arrLP1.Copy(m_TTOptions->m_arrLP[m_iCaldInx1]);
		arrLP2.Copy(m_TTOptions->m_arrLP[m_iCaldInx2]);
		LeaveCriticalSection( &m_cs );

		if( !m_bAlterPrice[0] )
		{
			for( i=0;i<arrLP1.GetSize();i++ )
			{
				if( arrLP1[i].fStrike==m_cald.fStrike )
				{
					if( m_cald.bCall==0 )
						m_fiSignPrice[0] = arrLP1[i].fCall;
					else
						m_fiSignPrice[0] = arrLP1[i].fPut;
					break;
				}
			}
		}
	
		if( !m_bAlterPrice[1] )
		{
			for( i=0;i<arrLP2.GetSize();i++ )
			{
				if( arrLP2[i].fStrike==m_fStrike2_Spread )
				{
					if( m_cald.bCall==0 )
						m_fiSignPrice[1] = arrLP2[i].fCall;
					else
						m_fiSignPrice[1] = arrLP2[i].fPut;
					break;
				}
			} 
		}
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}

		for( i=0;i<m_arrItem.GetSize();i++ )
		{
			if( m_arrItem[i].m_fStrike==m_cald.fStrike )
				iSign1 = i;
			if( m_arrItem[i].m_fStrike==m_fStrike2_Spread )
				iSign2 = i;
		}
		
		if( m_cald.bDebit==0 )
			principal = m_fLPrice[0]-m_fLPrice[1];
		else
			principal = m_fLPrice[1]-m_fLPrice[0];
		fExtre = principal*m_lShares;
		szValue.Format("%.0f", fExtre);
		fIV = 0.0;
		fdivi = 0.0;
		{
			BYTE bPos = 0;
			if( m_cald.bCall==0 )
				m_TTOptions->ModelPrice(TRUE,m_cald.fStrike,0,lExpiryDays,POS_CALL_LAST,calinfo,bPos);
			else
				m_TTOptions->ModelPrice(FALSE,m_cald.fStrike,0,lExpiryDays,POS_PUT_LAST,calinfo,bPos);
		}
		memcpy(&m_cald_calinfo1,&calinfo,sizeof(BSMCALINFO));
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}

		{
			m_TTOptions->DateDiff(m_lCaldExpDate2,m_lCaldExpDate1,iExpDay);
			if( m_cald.bCall==0 )
				m_TTOptions->ModelPrice(TRUE,m_fStrike2_Spread,0,lExpiryDays+iExpDay,POS_CALL_LAST,calinfo,1);
			else
				m_TTOptions->ModelPrice(FALSE,m_fStrike2_Spread,0,lExpiryDays+iExpDay,POS_PUT_LAST,calinfo,1);
		}
		memcpy(&m_cald_calinfo2,&calinfo,sizeof(BSMCALINFO));
		if( m_cald_calinfo2.impliedVolitility<0.0001 )
			memcpy(&m_cald_calinfo2,&m_cald_calinfo1,sizeof(BSMCALINFO));

		iSign = (iSign1+iSign2+1)/2;
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike);
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);

		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran )
		{
			m_fScale += 0.2;
			dea = fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}

		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = 0;
		iYmax = 0;
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
		if( m_cald.bDebit==0 && m_cald.bCall==0 )
		{
			TOF1 = FALSE;TOF2 = TRUE;PON = 1;
		}
		else if( m_cald.bDebit==0 && m_cald.bCall==1 )
		{
			TOF1 = FALSE;TOF2 = FALSE;PON = 1;
		}
		else if( m_cald.bDebit==1 && m_cald.bCall==0 )
		{
			TOF1 = TRUE;TOF2 = TRUE;PON = -1;
		}
		else if( m_cald.bDebit==1 && m_cald.bCall==1 )
		{
			TOF1 = TRUE;TOF2 = FALSE;PON = -1;
		}

		for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
		{	
			float tempskt = f_Strike;
			if( f_Strike>m_cald.fStrike&&(f_Strike-0.2*dea)<m_cald.fStrike )
			{
				f_Strike = m_cald.fStrike;
			}
			else if( f_Strike>m_fStrike2_Spread&&(f_Strike-0.2*dea)<m_fStrike2_Spread )
			{
				f_Strike = m_fStrike2_Spread;
			}
			temp1 = 0.0; 
			m_arrPL[0].Add(f_Strike);
			m_iOdr = -1;  //û��ȥ����������ͬʣ������
		//	if( m_cald.bCall==0 )
		//		f = ModelPrice_Clad(TRUE,m_fStrike2_Spread,f_Strike+fSpread,iExpDay,1);
		//	else
				f = ModelPrice_Clad(TOF2,m_fStrike2_Spread,f_Strike+fSpread,iExpDay,1);

			temp1 = linear_equation(TOF1,TOF2,m_cald.fStrike,f_Strike);
			temp1 = (temp1+principal+PON*f)*m_lShares;

			if(iExpDay!=0)
			{
				m_arrPL[0].Add(temp1);
				if( temp1>iYmax )
					iYmax = temp1;
				if( temp1<iYmin )
					iYmin = temp1;
			}
			f_Strike = tempskt;
			f_Strike += 0.2*dea;
		}
		GetCustomBreak(m_arrPL[0]);

///////////////////////////////////////////////����Diagonal Spread��͵㣬�������
		{
			CArrayFloat arrTempPL;
			for( int i=1;i<m_arrItem.GetSize();i++ )
			{	
				f_Strike = m_arrItem[i].m_fStrike;
				temp1 = 0.0; 
				arrTempPL.Add(f_Strike);
				m_iOdr = -1;  //û��ȥ����������ͬʣ������
				//	if( m_cald.bCall==0 )
				//		f = ModelPrice_Clad(TRUE,m_fStrike2_Spread,f_Strike+fSpread,iExpDay,1);
				//	else
						f = ModelPrice_Clad(TOF2,m_fStrike2_Spread,f_Strike+fSpread,iExpDay,1);
				
				temp1 = linear_equation(TOF1,TOF2,m_cald.fStrike,f_Strike);
				temp1 = (temp1+principal+PON*f)*m_lShares;
				
				arrTempPL.Add(temp1);
			}
			int BrkNum = m_arrBrkValue.GetSize();
			GetCustomBreak(arrTempPL);
			if( BrkNum!=m_arrBrkValue.GetSize() )
			{
				ReleaseDC(&MemDC);
				PostMessage(MACRO_MsgRedrawDiagonal);
				m_bDrawing = FALSE;
				return 1;
			}
		}

///////////////////////////////////////////////

		for( k=1;k<4;k++ )
		{
			m_iOdr = k;
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{		
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					f = 0.0;
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = m_cald.bDebit==0?-1:1;
						inAddr[j] = m_cald.bCall==0?POS_CALL_LAST:POS_PUT_LAST;
						price = ModelPrice_Clad(m_cald.bCall==0?TRUE:FALSE,m_cald.fStrike,f_Strike,iExpDay,0);
						if( m_cald.bDebit==0 )
							f = (m_fLPrice[0]-price)*m_lShares;
						else
							f = (price-m_fLPrice[0])*m_lShares;
						break;
					case 1:
						iPMs[j] = m_cald.bDebit==0?1:-1;
						inAddr[j] = m_cald.bCall==0?POS_CALL_LAST:POS_PUT_LAST;
						m_TTOptions->DateDiff(m_lCaldExpDate2,m_lCaldExpDate1,lExpiryDays);	
						price = ModelPrice_Clad(m_cald.bCall==0?TRUE:FALSE,m_fStrike2_Spread,f_Strike+fSpread,lExpiryDays+iExpDay,1);
						if( m_cald.bDebit==0 )
							f = (price-m_fLPrice[1])*m_lShares;
						else
							f = (m_fLPrice[1]-price)*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}

		Gain = iYmax;
		Loss = iYmin;
		m_TTOptions->DateDiff(m_lCaldExpDate2,m_lCaldExpDate1,iExpDay);
		f = ModelPrice_Clad(TOF2,m_fStrike2_Spread,m_arrItem[1].m_fStrike+fSpread,iExpDay,1);
		temp1 = linear_equation(TOF1,TOF2,m_cald.fStrike,m_arrItem[1].m_fStrike);
		temp1 = (temp1+principal+PON*f)*m_lShares;
		if( temp1>Gain )
			Gain = temp1;
		else if( temp1<Loss )
			Loss = temp1;
		
		f = ModelPrice_Clad(TOF2,m_fStrike2_Spread,m_arrItem[m_arrItem.GetSize()-1].m_fStrike+fSpread,iExpDay,1);
		temp1 = linear_equation(TOF1,TOF2,m_cald.fStrike,m_arrItem[m_arrItem.GetSize()-1].m_fStrike);
		temp1 = (temp1+principal+PON*f)*m_lShares;
		if( temp1>Gain )
			Gain = temp1;
		else if( temp1<Loss )
			Loss = temp1;
		
		if( (iYmax<0 || iYmin>0) || (iYmax==0.0&&iYmin==0.0))
				bDraw = FALSE;

		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		//m_staPL2.SetWindowText(szValue);
		//m_staPL1.SetWindowText(szInfinity[m_TTOptions->m_iLangType]);
		
		  //�ּ�P&L
	//	if( fCash<m_arrItem[iSign].m_fStrike )
	//		ftempPL = (m_arrItem[iSign].m_fStrike-fCash+principal)*m_lShares;
	//	else if( fCash>m_arrItem[iSign].m_fStrike)
	//		ftempPL = (fCash-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		break;

	case 2:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike;
		iSign = m_nIxStrike;
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign].m_fCalls_Ask,iSign,TRUE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign].m_fPuts_Ask,iSign,FALSE);
		
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = 0-m_fLPrice[0]-m_fLPrice[1];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}

		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(m_arrItem[iSign].m_fStrike-fCash);
		if( f<fabs(principal) )
			f = fabs(principal);
		dea = (int(f/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran )
		{
			m_fScale += 0.2;
			dea = fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = fExtre;
		iYmax = (m_arrItem[iSign].m_fStrike-arr_fx[0]+principal)*m_lShares;
		
		//�����������ӳ���
		
		temp1 = (m_arrItem[iSign].m_fStrike-arr_fx[1]+principal)*m_lShares;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		temp1 = (arr_fx[arr_fx.GetSize()-1]-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		

		if( temp1>iYmax )
			iYmax = temp1;
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);


		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
		
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = 1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_ASK;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (price-m_fiSignPrice[0])*m_lShares;
						//if( m_bUseRecord )
							f = (price-m_fLPrice[0])*m_lShares;
						break;
					case 1:
						iPMs[j] = 1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_ASK;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (price-m_fiSignPrice[1])*m_lShares;
						//if( m_bUseRecord )
							f = (price-m_fLPrice[1])*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = fExtre;
		Gain = 1.0;
		if( Loss>0 )
			bDraw = FALSE;
		//m_staPL2.SetWindowText(szValue);
		//m_staPL1.SetWindowText(szInfinity[m_TTOptions->m_iLangType]);
		
		  //�ּ�P&L
		if( fCash<m_arrItem[iSign].m_fStrike )
			ftempPL = (m_arrItem[iSign].m_fStrike-fCash+principal)*m_lShares;
		else if( fCash>m_arrItem[iSign].m_fStrike)
			ftempPL = (fCash-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		break;
			
	case 3:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike;
		iSign = m_nIxStrike;
		
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign].m_fCalls_Bid,iSign,TRUE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign].m_fPuts_Bid,iSign,FALSE);
		//principal = m_fiSignPrice[0]+m_fiSignPrice[1];
		//fExtre = principal*m_lShares;
		//if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = m_fLPrice[0]+m_fLPrice[1];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(m_arrItem[iSign].m_fStrike-fCash);
		if( f<fabs(principal) )
			f = fabs(principal);
		dea = (int(f/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran )
		{
			m_fScale += 0.2;
			dea = fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmax = fExtre;
		iYmin = (arr_fx[0]-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		
		//�����������ӳ���
		
		temp1 = (arr_fx[1]-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		
		
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		m_arrPL[0].Add(m_arrItem[iSign].m_fStrike);
		temp1 = fExtre;
		m_arrPL[0].Add(temp1);
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = (m_arrItem[iSign].m_fStrike-arr_fx[arr_fx.GetSize()-1]+principal)*m_lShares;

		if( temp1<iYmin )
			iYmin = temp1;
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);

		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = -1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_BID;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (m_fiSignPrice[0]-price)*m_lShares;
						//if( m_bUseRecord )
							f = (m_fLPrice[0]-price)*m_lShares;
						break;
					case 1:
						iPMs[j] = -1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_BID;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (m_fiSignPrice[1]-price)*m_lShares;
						//if( m_bUseRecord )
							f = (m_fLPrice[1]-price)*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Gain = fExtre;
		Loss = 1.0;
		if( Gain<0  )
			bDraw = FALSE;
		//m_staPL1.SetWindowText(szValue);
		//m_staPL2.SetWindowText(szInfinity[m_TTOptions->m_iLangType]);
		//�ּ�P&L
		if( fCash<m_arrItem[iSign].m_fStrike )
			ftempPL = (fCash-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		else if( fCash>m_arrItem[iSign].m_fStrike)
			ftempPL = (m_arrItem[iSign].m_fStrike-fCash+principal)*m_lShares;
		break;
			
	case 4:
		iSign2 = m_nIxStrike+m_nPos;
		iSign1 = m_nIxStrike2;
		if( m_bUseRecord )
		{
			iSign2 = m_nIxStrike;
		}
		iSign = iSign1+(iSign2-iSign1+1)/2;
		
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign2].m_fCalls_Ask,iSign2,TRUE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign1].m_fPuts_Ask,iSign1,FALSE);
		//principal = 0-m_fiSignPrice[0]-m_fiSignPrice[1];	
		//fExtre = principal*m_lShares;
		//if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = 0-m_fLPrice[1]-m_fLPrice[0];	
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = 0-principal+m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = fExtre;
		iYmax = (m_arrItem[iSign1].m_fStrike-arr_fx[0]+principal)*m_lShares;
		
		
		
		//�����������ӳ���
		
		temp1 = (m_arrItem[iSign1].m_fStrike-arr_fx[1]+principal)*m_lShares;
		
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		if( fExtre<=0 )
		{
			temp1 = m_arrItem[iSign1].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( fExtre<=0 )
		{
			temp1 = m_arrItem[iSign2].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = (arr_fx[arr_fx.GetSize()-1]-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;

		if( temp1>iYmax )
			iYmax = temp1;
		
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);


		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = 1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_ASK;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (price-m_fiSignPrice[0])*m_lShares;
						//if( m_bUseRecord )
							f = (price-m_fLPrice[0])*m_lShares;
						break;
					case 1:
						iPMs[j] = 1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_ASK;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
						//f = (price-m_fiSignPrice[1])*m_lShares;
						//if( m_bUseRecord )
							f = (price-m_fLPrice[1])*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = fExtre;
		Gain = 1.0;
		if( Loss>0 )
			bDraw = FALSE;
		//m_staPL2.SetWindowText(szValue);
		//m_staPL1.SetWindowText(szInfinity[m_TTOptions->m_iLangType]);
		//�ּ�P&L
		if( fCash>=m_arrItem[iSign1].m_fStrike && fCash<=m_arrItem[iSign2].m_fStrike )
			ftempPL = principal*m_lShares;
		else if( fCash<m_arrItem[iSign1].m_fStrike )
			ftempPL = (m_arrItem[iSign1].m_fStrike-fCash+principal)*m_lShares;
		else if( fCash>m_arrItem[iSign2].m_fStrike)
			ftempPL = (fCash-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		break;
		
	case 5:
		iSign2 = m_nIxStrike+m_nPos;
		iSign1 = m_nIxStrike2;
		if( m_bUseRecord )
			iSign2 = m_nIxStrike;
		iSign = iSign1+(iSign2-iSign1+1)/2;
	
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign2].m_fCalls_Bid,iSign2,TRUE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign1].m_fPuts_Bid,iSign1,FALSE);
	//	principal = m_fiSignPrice[0]+m_fiSignPrice[1];	
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = m_fLPrice[1]+m_fLPrice[0];	
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
			
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = principal+m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmax = fExtre;
		iYmin = (arr_fx[0]-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		
		
		//�����������ӳ���
		temp1 = (arr_fx[1]-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		
		
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		if( fExtre>=0 )
		{
			temp1 = m_arrItem[iSign1].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( fExtre>=0 )
		{
			temp1 = m_arrItem[iSign2].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = (m_arrItem[iSign2].m_fStrike-arr_fx[arr_fx.GetSize()-1]+principal)*m_lShares;
		

		if( temp1<iYmin )
			iYmin = temp1;
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);

		
		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0;
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = -1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_BID;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (m_fiSignPrice[0]-price)*m_lShares;
					//	if( m_bUseRecord )
							f = (m_fLPrice[0]-price)*m_lShares;
						break;
					case 1:
						iPMs[j] = -1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_BID;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (m_fiSignPrice[1]-price)*m_lShares;
					//	if( m_bUseRecord )
							f = (m_fLPrice[1]-price)*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Gain = fExtre;
		Loss = 1.0;
		if( Gain<0 )
			bDraw = FALSE;
		//m_staPL1.SetWindowText(szValue);
		//m_staPL2.SetWindowText(szInfinity[m_TTOptions->m_iLangType]);
		//�ּ�P&L
		if( fCash>=m_arrItem[iSign1].m_fStrike && fCash<=m_arrItem[iSign2].m_fStrike )
			ftempPL = principal*m_lShares;
		else if( fCash<m_arrItem[iSign1].m_fStrike )
			ftempPL = (fCash-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		else if( fCash>m_arrItem[iSign2].m_fStrike)
			ftempPL = (m_arrItem[iSign2].m_fStrike-fCash+principal)*m_lShares;
		break;
	case 15:
	case 16:
		iSign = m_nIxStrike2;
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = m_TTOptions->GetCorrStockPrice(FALSE);
		if( !m_bAlterPrice[1] )
		{
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign].m_fCalls_Bid,iSign,TRUE);
			if( m_nIndex==16 )
				m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign].m_fPuts_Bid,iSign,FALSE);
		}
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = m_fLPrice[1];
			fExtre = (m_arrItem[iSign].m_fStrike-m_fLPrice[0]+principal)*m_lShares;
			if( m_nIndex==16 )
				fExtre = (m_fLPrice[0]-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		if( m_nIndex==15 )
			m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		else
			m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		fIV = calinfo.impliedVolitility;
		m_fIVedit = fIV/1.0;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(m_arrItem[iSign].m_fStrike-fCash);
		if( f<fabs(principal) )
			f = fabs(principal);
		dea = (int(f/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran )
		{
			m_fScale += 0.2;
			dea = fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
				
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmax = fExtre;
		iYmin = (arr_fx[1]-m_fLPrice[0]+principal)*m_lShares;
		if( m_nIndex==16 )
			iYmin = (m_fLPrice[0]-arr_fx[arr_fx.GetSize()-1]+principal)*m_lShares;
		
		
		//�����������ӳ���
		
		temp1 = iYmin;
		if( m_nIndex==16 )
			temp1 = iYmax;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);

		m_arrPL[4].Add(arr_fx[2]);
		if( m_nIndex==15 )
			temp1 = (arr_fx[2]-m_fLPrice[0])*m_lShares;
		else
			temp1 = (m_fLPrice[0]-arr_fx[2])*m_lShares;
		m_arrPL[4].Add(temp1);
		
		if( m_nIndex==15 )
		{
			if( iYmax>0 && iYmin<0 )
			{
				temp1 = m_fLPrice[0]-principal;
				m_arrPL[0].Add(temp1);
				m_arrPL[0].Add(temp2);
				m_arrBrkValue.Add(temp1);
			}
			
			m_arrPL[0].Add(m_arrItem[iSign].m_fStrike);
			m_arrPL[0].Add(iYmax);
		}
		else
		{
			m_arrPL[0].Add(m_arrItem[iSign].m_fStrike);
			m_arrPL[0].Add(iYmax);

			if( iYmax>0 && iYmin<0 )
			{
				temp1 = m_fLPrice[0]+principal;
				m_arrPL[0].Add(temp1);
				m_arrPL[0].Add(temp2);
				m_arrBrkValue.Add(temp1);
			}
		}

		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		if( m_nIndex==15 )
			m_arrPL[0].Add(iYmax);
		else
			m_arrPL[0].Add(iYmin);

		m_arrPL[4].Add(arr_fx[arr_fx.GetSize()-2]);
		if( m_nIndex==15 )
			temp1 = (arr_fx[arr_fx.GetSize()-2]-m_fLPrice[0])*m_lShares;
		else
			temp1 = (m_fLPrice[0]-arr_fx[arr_fx.GetSize()-2])*m_lShares;
		m_arrPL[4].Add(temp1);

		if( iYmax<m_arrPL[4][1] )
			iYmax = m_arrPL[4][1];
		if( iYmax<m_arrPL[4][3] )
			iYmax = m_arrPL[4][3];
		if( iYmin>m_arrPL[4][1] )
			iYmin = m_arrPL[4][1];
		if( iYmin>m_arrPL[4][3] )
			iYmin = m_arrPL[4][3];

		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0;
				m_arrPL[k].Add(f_Strike);
				
				m_iOdr = k;
				iPMs[0] = -1;
				if( m_nIndex==15 )
				{
					inAddr[0] = POS_CALL_LAST;
					price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[0],calinfo);
					f = (f_Strike-m_fLPrice[0]+m_fLPrice[1]-price)*m_lShares;
				}
				else
				{
					inAddr[0] = POS_PUT_LAST;
					price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[0],calinfo);
					f = (m_fLPrice[0]-f_Strike+m_fLPrice[1]-price)*m_lShares;
				}
						
				temp1 += f;
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		if( m_nIndex==15 )
			Loss = (m_fLPrice[1]-m_fLPrice[0])*m_lShares;
		else
			Loss = 1.0;
		Gain = fExtre;
		if( Gain<0 )
			bDraw = FALSE;
		break;
	case STGY_CUSTOM:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike2;
		iSign3 = m_nIxStrike3;
		iSign4 = m_nIxStrike4;
		iSign5 = m_nIxStrike5;
		iSign6 = m_nIxStrike6;
		SortStrikeIx();
		if( m_arrInt.GetSize()==0 )
			m_arrInt.Add(m_nPos);
		iSign = (m_arrInt[0]+m_arrInt[m_arrInt.GetSize()-1]+1)/2;
		
		for( i=0;i<m_arrInt.GetSize();i++ )
		{
			IxS = m_iSort[6-m_arrInt.GetSize()+i];
			if( !m_bAlterPrice[IxS] )
				GetCustomPriceAndType(m_nCustomIx[IxS],m_arrInt[i],m_fiSignPrice[IxS]);
		}
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && (m_nCustomIx[i]==4 || m_nCustomIx[i]==5) )
				GetCustomPriceAndType(m_nCustomIx[i],i,m_fiSignPrice[i]); //ȡһ�ι�Ʊ�۸�

			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = 0.0;
			for( i=0;i<m_arrInt.GetSize();i++ )
			{
				IxS = m_iSort[6-m_arrInt.GetSize()+i];
				if( m_nCustomIx[IxS]<=3 )
				{
					principal += (-1*m_fLPrice[IxS]*m_nCustomCount[IxS]);
//					if( m_nCustomIx[IxS]==0 || m_nCustomIx[IxS]==2 )
//						m_fEliminate += -1*m_fLPrice[IxS]*m_nCustomCount[IxS];
				}
			}
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
		for( i=0;i<m_arrInt.GetSize();i++ )
		{
			IxS = m_iSort[6-m_arrInt.GetSize()+i];
			CPPos = GetCustomPriceAndType(m_nCustomIx[IxS],0,ftempPL1);
			if( CPPos==-1 )
				continue;
			if( CPPos>10 )
				bCall = FALSE;
			else
				bCall = TRUE;
			m_TTOptions->ModelPrice(bCall,m_arrItem[m_arrInt[i]].m_fStrike,0,m_TTOptions->m_lExpiryDays,CPPos,calinfo);
			if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
			{
				fIV += calinfo.impliedVolitility*abs(m_nCustomCount[IxS]);
				fdivi += abs(m_nCustomCount[IxS]);
			}
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}

		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		//f = fabs(principal)+m_arrItem[iSign].m_fStrike-m_arrItem[m_arrInt[0]].m_fStrike;
		//dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea = 2*fTran;
		dea += m_fScale*fTran;
		for( j=0;;j++ )
		{
			arr_x.RemoveAll();
			arr_fx.RemoveAll();
			arr_xp.RemoveAll();
			m_arrPL[0].RemoveAll();
			m_arrPL[4].RemoveAll();
			m_arrBrkValue.RemoveAll();
			bDraw = TRUE;
			for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
			{
				CString str;
				GetPriceTxt(f,str);
				
				
				arr_x.Add(str);
				arr_fx.Add(f);
				
				str.Format("%.1f", (f-fCash)/fCash*100);
				if( f>fCash )
					str.Format("+%.1f", (f-fCash)/fCash*100);
				str += "%";
				arr_xp.Add(str);
			}
			
			temp1 = GetCustomStgy(arr_fx[1]);
			m_arrPL[0].Add(arr_fx[1]);
			m_arrPL[0].Add(temp1);
			iYmax = temp1;
			iYmin = temp1;

			BOOL boo = FALSE;
			for( d=0;d<6;d++ )
			{
				if( m_nCustomIx[d]==4 || m_nCustomIx[d]==5 )
				{
					boo = TRUE;
					break;
				}
			}

			if( boo )
			{
				temp1 = CalcStock(arr_fx[2]);
				m_arrPL[4].Add(arr_fx[2]);
				m_arrPL[4].Add(temp1);
			}
			
			for( i=0;i<m_arrInt.GetSize();i++ )
			{
				temp1 = GetCustomStgy(m_arrItem[m_arrInt[i]].m_fStrike);
				m_arrPL[0].Add(m_arrItem[m_arrInt[i]].m_fStrike);
				m_arrPL[0].Add(temp1);
				if( temp1>iYmax )
					iYmax = temp1;
				if( temp1<iYmin )
					iYmin = temp1;
			}
			
			temp1 = GetCustomStgy(arr_fx[arr_fx.GetSize()-1]);
			m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
			m_arrPL[0].Add(temp1);
			if( temp1>iYmax )
				iYmax = temp1;
			if( temp1<iYmin )
				iYmin = temp1;

			if( boo )
			{
				m_arrPL[4].Add(arr_fx[arr_fx.GetSize()-2]);
				temp1 = CalcStock(arr_fx[arr_fx.GetSize()-2]);
				m_arrPL[4].Add(temp1);
			}
			
			Gain = 0.0;
			Loss = 0.0;
			GetCustomBreak(m_arrPL[0]);
			if( Gain!=1.0 && Gain<iYmax )
				Gain = iYmax;
			if( Loss!=1.0 && Loss>iYmin )
				Loss = iYmin;
			if( (iYmax<0 || iYmin>0) || (iYmax==0.0&&iYmin==0.0))
				bDraw = FALSE;

			if( boo )
			{
				if( iYmax<m_arrPL[4][1] )
					iYmax = m_arrPL[4][1];
				if( iYmax<m_arrPL[4][3] )
					iYmax = m_arrPL[4][3];
				if( iYmin>m_arrPL[4][1] )
					iYmin = m_arrPL[4][1];
				if( iYmin>m_arrPL[4][3] )
					iYmin = m_arrPL[4][3];
			}

			if( j==1 )
				break;	
			for( i=0;i<6;i++ )
			{
				if( m_nCustomIx[i]!=6 )
					break;
			}
			if( i==6 )
				break;

			if( m_arrBrkValue.GetSize()!=0 )
				f = fabs(m_arrBrkValue[0]-m_arrItem[iSign].m_fStrike)>fabs(fCash-m_arrItem[iSign].m_fStrike)?fabs(m_arrBrkValue[0]-m_arrItem[iSign].m_fStrike):fabs(fCash-m_arrItem[iSign].m_fStrike);
			else
				f = fabs(fCash-m_arrItem[iSign].m_fStrike);

			if( f>dea )
				dea = (int(fabs(f)/fTran)/3+1)*fTran;
			else if( f<dea )
				dea = fTran;
			dea += m_fScale*fTran;
			if( dea<fTran || m_arrItem[m_arrInt[0]].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
			{
				m_fScale += 0.2;
				dea += 0.2*fTran;
			}
			else if( dea>5.1*fTran && m_fScale!=0.0 )
			{
				m_fScale -= 0.2;
				dea -= 0.2*fTran; 
			}

			if( dea==fTran*(2+m_fScale) )
				break;
		}
		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0;
				m_arrPL[k].Add(f_Strike);
				float fsktp;
				int nSize = m_arrInt.GetSize();
				int inx;
				for( j=0;j<nSize;j++ )
				{
					inx = m_iSort[6-nSize+j];
					m_iOdr = k;
					fsktp = m_arrItem[m_arrInt[j]].m_fStrike;

					iPMs[inx] = m_nCustomCount[inx];
					inAddr[inx] = GetCustomPriceAndType(m_nCustomIx[inx],0,ftempPL1);//POS_PUT_LAST;//POS_PUT_ASK;
					if( inAddr[inx]>10 )
						bCall = FALSE;
					else
						bCall = TRUE;
					price = m_TTOptions->ModelPrice(bCall,fsktp,f_Strike,iExpDay,inAddr[j],calinfo);
					{
						if( m_nCustomIx[inx]==1 || m_nCustomIx[inx]==3 )
							f = abs(iPMs[inx])*(price-m_fLPrice[inx])*m_lShares;
						else
							f = abs(iPMs[inx])*(m_fLPrice[inx]-price)*m_lShares;
					}
					
					temp1 += f;
				}
				BOOL boo = FALSE;
				for( d=0;d<6;d++ )
				{
					if( m_nCustomIx[d]<=3 )
					{
						boo = TRUE;
						break;
					}
				}
				if( boo )
				{
					for( j=0;j<6;j++ )
					{
						f = 0.0;
						if( m_nCustomIx[j]==4 || m_nCustomIx[j]==5 )
							f = (f_Strike-m_fLPrice[j])*m_nCustomCount[j]*m_lShares;
						temp1 += f;
					}
				}
				
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}
		break;
	case 6:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike2;
		iSign3 = m_nIxStrike3+m_nPos;
		iSign4 = m_nIxStrike4+m_nPos;
		if( m_bUseRecord )
		{
			iSign3 = m_nIxStrike3;
			iSign4 = m_nIxStrike4;
		}
		iSign = (iSign1+iSign4+1)/2;
			
		if( !m_bAlterPrice[0])
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign1].m_fPuts_Ask,iSign1,FALSE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign2].m_fPuts_Bid,iSign2,FALSE);
		if( !m_bAlterPrice[2] )
			m_fiSignPrice[2] = UnitPrice(m_arrItem[iSign3].m_fCalls_Bid,iSign3,TRUE);
		if( !m_bAlterPrice[3] )
			m_fiSignPrice[3] = UnitPrice(m_arrItem[iSign4].m_fCalls_Ask,iSign4,TRUE);
	//	principal = m_fiSignPrice[1]+m_fiSignPrice[2]-m_fiSignPrice[0]-m_fiSignPrice[3];
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
//			m_fEliminate = m_fLPrice[1]+m_fLPrice[2];
			principal = m_fLPrice[1]+m_fLPrice[2]-m_fLPrice[0]-m_fLPrice[3];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign3].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign4].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(principal)+m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		iYmax = fExtre;
		iYmin = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		
		
		//�����������ӳ���
		
		temp1 = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		temp1 = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign2].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			bBreak1 = TRUE;
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign3].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( (m_arrItem[iSign3].m_fStrike-m_arrItem[iSign4].m_fStrike+principal)<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign3].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			bBreak2 = TRUE;
			m_arrBrkValue.Add(temp1);
		}
		
		m_arrPL[0].Add(m_arrItem[iSign4].m_fStrike);
		temp1 = (m_arrItem[iSign3].m_fStrike-m_arrItem[iSign4].m_fStrike+principal)*m_lShares;
		
		m_arrPL[0].Add(temp1);
		
		//temp1 = (m_arrItem[iSign3].m_fStrike-m_arrItem[iSign4].m_fStrike+principal)*m_lShares;
		
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);

		Gain = fExtre;
		Loss = m_arrPL[0][1]<temp1?m_arrPL[0][1]:temp1;
		if( Gain<0 || Loss>0 )
			bDraw = FALSE;

		iYmin = Loss;


		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
		
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0;
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<4;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = 1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_ASK;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (price-m_fiSignPrice[0])*m_lShares;
					//	if( m_bUseRecord )
							f = (price-m_fLPrice[0])*m_lShares;
						break;
					case 1:
						iPMs[j] = -1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_BID;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (m_fiSignPrice[1]-price)*m_lShares;
					//	if( m_bUseRecord )
							f = (m_fLPrice[1]-price)*m_lShares;
						break;
					case 2:
						iPMs[j] = -1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_BID;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign3].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (m_fiSignPrice[2]-price)*m_lShares;
					//	if( m_bUseRecord )
							f = (m_fLPrice[2]-price)*m_lShares;
						break;
					case 3:
						iPMs[j] = 1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_ASK;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign4].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (price-m_fiSignPrice[3])*m_lShares;
					//	if( m_bUseRecord )
							f = (price-m_fLPrice[3])*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}
		
		
		//m_staPL1.SetWindowText(szValue);
		//szValue.Format("%.0f", m_arrPL[0][1]);
		//m_staPL2.SetWindowText(szValue);
		//m_staPL1.GetWindowText(szValue);
		//�ּ�P&L
		if( fCash<=m_arrItem[iSign1].m_fStrike || fCash>=m_arrItem[iSign4].m_fStrike )
			ftempPL = temp1;
		else if( fCash>m_arrItem[iSign1].m_fStrike && fCash<m_arrItem[iSign2].m_fStrike )
			ftempPL = (fCash-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		else if( fCash>m_arrItem[iSign3].m_fStrike && fCash<m_arrItem[iSign4].m_fStrike )
			ftempPL = (m_arrItem[iSign3].m_fStrike-fCash+principal)*m_lShares;
		else if( fCash>=m_arrItem[iSign2].m_fStrike && fCash<=m_arrItem[iSign3].m_fStrike )
			ftempPL = principal*m_lShares;

		break;
	case 7:
		iSign = m_nIxStrike;
		
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign].m_fCalls_Ask,iSign,TRUE);
	//	principal = 0-m_fiSignPrice[0];
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = 0-m_fLPrice[0];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		fIV = calinfo.impliedVolitility;
		m_fIVedit = fIV/1.0;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(m_arrItem[iSign].m_fStrike-fCash);
		if( f<fabs(principal) )
			f = fabs(principal);
		dea = (int(f/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran )
		{
			m_fScale += 0.2;
			dea = fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = fExtre;
		iYmax = (arr_fx[arr_fx.GetSize()-1]-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		
		
		//�����������ӳ���
		
		temp1 = fExtre;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( fExtre<0 )
		{
			temp1 = m_arrItem[iSign].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(iYmax);


		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//			f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0;
				m_arrPL[k].Add(f_Strike);
				
				m_iOdr = k;
				iPMs[0] = 1;
				inAddr[0] = POS_CALL_LAST;//POS_CALL_ASK;
				price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[0],calinfo);
			//	f = (price-m_fiSignPrice[0])*m_lShares;
			//	if( m_bUseRecord )
					f = (price-m_fLPrice[0])*m_lShares;
						
				temp1 += f;

	//			char log[50];
	//			sprintf(log,"price=%.4f,f=%.4f,temp1=%.4f",price,f/m_lShares,temp1);
	//			m_TTOptions->WriteLogFile(log);
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = fExtre;
		Gain = 1.0;
		if( Loss>0 )
			bDraw = FALSE;
		break;
	case 8:
		iSign = m_nIxStrike;
		
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign].m_fPuts_Ask,iSign,FALSE);
	//	principal = 0-m_fiSignPrice[0];
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = 0-m_fLPrice[0];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		fIV = calinfo.impliedVolitility;
		m_fIVedit = fIV/1.0;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(m_arrItem[iSign].m_fStrike-fCash);
		if( f<fabs(principal) )
			f = fabs(principal);
		dea = (int(f/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran )
		{
			m_fScale += 0.2;
			dea = fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = fExtre;
		iYmax = (m_arrItem[iSign].m_fStrike-arr_fx[1]+principal)*m_lShares;
		
		
		//�����������ӳ���
		
		temp1 = iYmax;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		if( fExtre<0 )
		{
			temp1 = m_arrItem[iSign].m_fStrike+principal;
			
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}

		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(fExtre);

		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{		
				temp1 = 0.0;
				m_arrPL[k].Add(f_Strike);
				
				m_iOdr = k;
				iPMs[0] = 1;
				inAddr[0] = POS_PUT_LAST;//POS_PUT_ASK;
				price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[0],calinfo);
			//	f = (price-m_fiSignPrice[0])*m_lShares;
			//	if( m_bUseRecord )
					f = (price-m_fLPrice[0])*m_lShares;
						
				temp1 += f;
				
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = fExtre;
		Gain = (m_arrItem[m_nIxStrike].m_fStrike-m_fLPrice[0])*m_lShares;
		if( Loss>0 )
			bDraw = FALSE;
		break;
	case 9:
		iSign = m_nIxStrike;

		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign].m_fCalls_Bid,iSign,TRUE);
	//	principal = m_fiSignPrice[0];
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = m_fLPrice[0];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		fIV = calinfo.impliedVolitility;
		m_fIVedit = fIV/1.0;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(m_arrItem[iSign].m_fStrike-fCash);
		if( f<fabs(principal) )
			f = fabs(principal);
		dea = (int(f/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran )
		{
			m_fScale += 0.2;
			dea = fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmax = fExtre;
		iYmin = (m_arrItem[iSign].m_fStrike-arr_fx[arr_fx.GetSize()-1]+principal)*m_lShares;
		
		
		//�����������ӳ���
		
		temp1 = fExtre;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( fExtre>0 )
		{
			temp1 = m_arrItem[iSign].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(iYmin);

		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{		
				temp1 = 0.0;
				m_arrPL[k].Add(f_Strike);
				
				m_iOdr = k;
				iPMs[0] = -1;
				inAddr[0] = POS_CALL_LAST;//POS_CALL_BID;
				price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[0],calinfo);
			//	f = (m_fiSignPrice[0]-price)*m_lShares;
			//	if( m_bUseRecord )
					f = (m_fLPrice[0]-price)*m_lShares;
						
				temp1 += f;
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = 1.0;
		Gain = fExtre;
		if( Gain<0 )
			bDraw = FALSE;
		break;
	case 10:
		iSign = m_nIxStrike;
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign].m_fPuts_Bid,iSign,FALSE);
	//	principal = m_fiSignPrice[0];
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
			principal = m_fLPrice[0];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		fIV = calinfo.impliedVolitility;
		m_fIVedit = fIV/1.0;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = fabs(m_arrItem[iSign].m_fStrike-fCash);
		if( f<fabs(principal) )
			f = fabs(principal);
		dea = (int(f/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran )
		{
			m_fScale += 0.2;
			dea = fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmax = fExtre;
		iYmin = (arr_fx[1]-m_arrItem[iSign].m_fStrike+principal)*m_lShares;
		
		
		//�����������ӳ���
		
		temp1 = iYmin;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);
		
		if( fExtre>0 )
		{
			temp1 = m_arrItem[iSign].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}

		temp1 = fExtre;
		m_arrPL[0].Add(m_arrItem[iSign].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(fExtre);

		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{		
				temp1 = 0.0;
				m_arrPL[k].Add(f_Strike);
				
				m_iOdr = k;
				iPMs[0] = -1;
				inAddr[0] = POS_PUT_LAST;//POS_PUT_BID;
				price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign].m_fStrike,f_Strike,iExpDay,inAddr[0],calinfo);
			//	f = (m_fiSignPrice[0]-price)*m_lShares;
			//	if( m_bUseRecord )
					f = (m_fLPrice[0]-price)*m_lShares;
						
				temp1 += f;
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = (m_fLPrice[0]-m_arrItem[m_nIxStrike].m_fStrike)*m_lShares;
		Gain = fExtre;
		if( Gain<0 )
			bDraw = FALSE;
		break;
	case 11:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike2+1;
		if( m_bUseRecord )
			iSign2 = m_nIxStrike2;
		iSign = iSign1+(iSign2-iSign1+1)/2;
		
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign1].m_fCalls_Ask,iSign1,TRUE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign2].m_fCalls_Bid,iSign2,TRUE);
	//	principal = 0-m_fiSignPrice[0]+m_fiSignPrice[1];	
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
//			m_fEliminate = m_fLPrice[1];
			principal = 0-m_fLPrice[0]+m_fLPrice[1];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = 0-principal+m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = fExtre;
		iYmax = (m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		
		
		
		//�����������ӳ���
		
		temp1 = iYmin;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);

		temp1 = iYmin;
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign1].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = iYmax;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		temp1 = iYmax;
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);
		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = 1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_ASK;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (price-m_fiSignPrice[0])*m_lShares;
					//	if( m_bUseRecord )
							f = (price-m_fLPrice[0])*m_lShares;
					
						break;
					case 1:
						iPMs[j] = -1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_BID;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (m_fiSignPrice[1]-price)*m_lShares;
					//	if( m_bUseRecord )
							f = (m_fLPrice[1]-price)*m_lShares;
					
						break;
					}

					temp1 += f;
//					char log[50];
//					sprintf(log,"price=%.4f,f=%.4f,temp1=%.4f",price,f/m_lShares,temp1);
//					m_TTOptions->WriteLogFile(log);
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = fExtre;
		Gain = (m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		if( Loss>0 )
			bDraw = FALSE;

		break;
	case 12:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike2+1;
		if( m_bUseRecord )
			iSign2 = m_nIxStrike2;
		iSign = iSign1+(iSign2-iSign1+1)/2;
		
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign1].m_fCalls_Bid,iSign1,TRUE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign2].m_fCalls_Ask,iSign2,TRUE);
	//	principal = m_fiSignPrice[0]-m_fiSignPrice[1];	
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
//			m_fEliminate = m_fLPrice[0];
			principal = m_fLPrice[0]-m_fLPrice[1];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_CALL_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = 0-principal+m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		iYmax = fExtre;
		
		
		
		//�����������ӳ���
		
		temp1 = iYmax;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);

		temp1 = iYmax;
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign1].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = iYmin;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		temp1 = iYmin;
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);


		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{		
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = -1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_BID;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (m_fiSignPrice[0]-price)*m_lShares;
					//	if( m_bUseRecord )
							f = (m_fLPrice[0]-price)*m_lShares;
						break;
					case 1:
						iPMs[j] = 1;
						inAddr[j] = POS_CALL_LAST;//POS_CALL_ASK;
						price = m_TTOptions->ModelPrice(TRUE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (price-m_fiSignPrice[1])*m_lShares;
					//	if( m_bUseRecord )
							f = (price-m_fLPrice[1])*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		Gain = fExtre;
		if( Loss>0 )
			bDraw = FALSE;

		break;
	case 13:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike2+1;
		if( m_bUseRecord )
			iSign2 = m_nIxStrike2;
		
		iSign = iSign1+(iSign2-iSign1+1)/2;
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign1].m_fPuts_Ask,iSign1,FALSE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign2].m_fPuts_Bid,iSign2,FALSE);
	//	principal = 0-m_fiSignPrice[0]+m_fiSignPrice[1];	
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
//			m_fEliminate = m_fLPrice[1];
			principal = 0-m_fLPrice[0]+m_fLPrice[1];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = 0-principal+m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmin = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		iYmax = fExtre;
		
		
		
		//�����������ӳ���
		
		temp1 = iYmin;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);

		temp1 = iYmin;
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign2].m_fStrike-principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = iYmax;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		temp1 = iYmax;
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);

		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{		
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = 1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_ASK;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (price-m_fiSignPrice[0])*m_lShares;
					//	if( m_bUseRecord )
							f = (price-m_fLPrice[0])*m_lShares;
						break;
					case 1:
						iPMs[j] = -1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_BID;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (m_fiSignPrice[1]-price)*m_lShares;
					//	if( m_bUseRecord )
							f = (m_fLPrice[1]-price)*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Loss = (m_arrItem[iSign1].m_fStrike-m_arrItem[iSign2].m_fStrike+principal)*m_lShares;
		Gain = fExtre;
		if( Loss>0 )
			bDraw = FALSE;

		break;
	case 14:
		iSign1 = m_nIxStrike;
		iSign2 = m_nIxStrike2+1;
		if( m_bUseRecord )
			iSign2 = m_nIxStrike2;
		
		iSign = iSign1+(iSign2-iSign1+1)/2;
		
		if( !m_bAlterPrice[0] )
			m_fiSignPrice[0] = UnitPrice(m_arrItem[iSign1].m_fPuts_Bid,iSign1,FALSE);
		if( !m_bAlterPrice[1] )
			m_fiSignPrice[1] = UnitPrice(m_arrItem[iSign2].m_fPuts_Ask,iSign2,FALSE);
	//	principal = m_fiSignPrice[0]-m_fiSignPrice[1];	
	//	fExtre = principal*m_lShares;
	//	if( m_bUseRecord )
		for( i=0;i<6;i++ )
		{
			if( !m_bAlterPrice[i] && !m_bAlterPrice2[i] )
				m_fLPrice[i] = m_fiSignPrice[i];
		}
		{
//			m_fEliminate = m_fLPrice[0];
			principal = m_fLPrice[0]-m_fLPrice[1];
			fExtre = principal*m_lShares;
		}
		szValue.Format("%.0f", fExtre);

		fIV = 0.0;
		fdivi = 0.0;
//		BSMCALINFO calinfo;
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign2].m_fStrike,0,m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
		if( fabs(calinfo.impliedVolitility)>=0.0001 && fabs(calinfo.impliedVolitility+1.0)>=0.0001 )
		{
			fIV += calinfo.impliedVolitility;
			fdivi += 1;
		}
		if( fIV==0.0 )
			m_fIVedit = 0.0;
		else
			m_fIVedit = fIV/fdivi;
		strForm.Format("%.1f",m_fIVedit*100);
		if( m_bResetBF[0] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV1.SetWindowText(strForm);
			m_bResetBF[0] = FALSE;
		}
		if( m_bResetBF[1] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV2.SetWindowText(strForm);
			m_bResetBF[1] = FALSE;
		}
		if( m_bResetBF[2] )
		{
			if( m_nDay1==0 )
				strForm = "0.0";
			m_editIV3.SetWindowText(strForm);
			m_bResetBF[2] = FALSE;
		}
		
		fTran = m_arrItem[m_nPos].m_fStrike - m_arrItem[m_nPos-1].m_fStrike;
		f = /*0-principal+*/m_arrItem[iSign].m_fStrike-m_arrItem[iSign1].m_fStrike;
		if( f<fabs(fCash-m_arrItem[iSign].m_fStrike) )
			f = fabs(fCash-m_arrItem[iSign].m_fStrike);
		dea = (int(fabs(f)/fTran)/3+1)*fTran;
		dea += m_fScale*fTran;
		if( dea<fTran || m_arrItem[iSign1].m_fStrike<(m_arrItem[iSign].m_fStrike-4*dea) )
		{
			m_fScale += 0.2;
			dea += 0.2*fTran;
		}
		else if( dea>5.1*fTran && m_fScale!=0.0 )
		{
			m_fScale -= 0.2;
			dea -= 0.2*fTran; 
		}
		for( f=m_arrItem[iSign].m_fStrike-5*dea;f<=m_arrItem[iSign].m_fStrike+5*dea;f=f+dea )
		{
			CString str;
			GetPriceTxt(f,str);
			
			
			arr_x.Add(str);
			arr_fx.Add(f);

			str.Format("%.1f", (f-fCash)/fCash*100);
			if( f>fCash )
				str.Format("+%.1f", (f-fCash)/fCash*100);
			str += "%";
			arr_xp.Add(str);
		}
		
		iYmax = (m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		iYmin = fExtre;
		
		
		
		//�����������ӳ���
		
		temp1 = iYmax;
		m_arrPL[0].Add(arr_fx[1]);
		m_arrPL[0].Add(temp1);

		temp1 = iYmax;
		m_arrPL[0].Add(m_arrItem[iSign1].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		if( iYmin<=0 && iYmax>=0 )
		{
			temp1 = m_arrItem[iSign2].m_fStrike+principal;
			m_arrPL[0].Add(temp1);
			m_arrPL[0].Add(temp2);
			m_arrBrkValue.Add(temp1);
		}
		
		temp1 = iYmin;
		m_arrPL[0].Add(m_arrItem[iSign2].m_fStrike);
		m_arrPL[0].Add(temp1);
		
		temp1 = iYmin;
		m_arrPL[0].Add(arr_fx[arr_fx.GetSize()-1]);
		m_arrPL[0].Add(temp1);


		for( k=1;k<4;k++ )
		{
			switch(k)
			{
			case 1:
				iExpDay = m_nDay1;
				break;
			case 2:
				iExpDay = m_nDay2;
				break;
			case 3:
				iExpDay = m_nDay3;
				break;
			}
			
			BSMCALINFO calinfo;
			
		//	for( i=1;i<arr_fx.GetSize();i++ )
		//	{
		//		f_Strike = arr_fx[i];
			for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
			{		
				temp1 = 0.0; 
				m_arrPL[k].Add(f_Strike);
				for( j=0;j<2;j++ )
				{
					m_iOdr = k;
					switch(j)
					{
					case 0:
						iPMs[j] = -1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_BID;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign1].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (m_fiSignPrice[0]-price)*m_lShares;
					//	if( m_bUseRecord )
							f = (m_fLPrice[0]-price)*m_lShares;
						break;
					case 1:
						iPMs[j] = 1;
						inAddr[j] = POS_PUT_LAST;//POS_PUT_ASK;
						price = m_TTOptions->ModelPrice(FALSE,m_arrItem[iSign2].m_fStrike,f_Strike,iExpDay,inAddr[j],calinfo);
					//	f = (price-m_fiSignPrice[1])*m_lShares;
					//	if( m_bUseRecord )
							f = (price-m_fLPrice[1])*m_lShares;
						break;
					}
					temp1 += f;
				}
				if(iExpDay!=0)
				{
					m_arrPL[k].Add(temp1);
					if( temp1>iYmax )
						iYmax = temp1;
					if( temp1<iYmin )
						iYmin = temp1;
				}
				f_Strike += 0.2*dea;
			}
		}
		
		CalcPrecis(iYmax,iYmin,dea);
		for( f=iYmin;f<=iYmax;f=f+dea )
		{
			CString str;
			str.Format("%.0f", f);
			arr_y.Add(str);
			arr_fy.Add(f);

			str.Format("%.0f",f/fabs(principal*m_lShares)*100);
			if( f>0 )
				str.Format("+%.0f",f/fabs(principal*m_lShares)*100);
			str += "%";
			arr_yp.Add(str);
		}

		Gain = (m_arrItem[iSign2].m_fStrike-m_arrItem[iSign1].m_fStrike+principal)*m_lShares;
		Loss = fExtre;
		if( Loss>0 )
			bDraw = FALSE;

		break;
	default:
		ReleaseDC(&MemDC);
		m_bDrawing = FALSE;
		return 0;
		break;
	}

//	if( m_nIndex!=17 )
		GetBrkProb();
	}
	//�ر�������������
	if( m_nDay1==0 )
	{
		m_arrPL[1].RemoveAll();
		m_arrPL[1].Copy(m_arrPL[0]);
	}
	if( m_nDay2==0 )
	{
		m_arrPL[2].RemoveAll();
		m_arrPL[2].Copy(m_arrPL[0]);
	}
	if( m_nDay3==0 )
	{
		m_arrPL[3].RemoveAll();
		m_arrPL[3].Copy(m_arrPL[0]);
	}
	if( strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex() )	
	{
		m_arrPL[1].RemoveAll();
		m_arrPL[2].RemoveAll();
		m_arrPL[3].RemoveAll();
	}

	Trans_Y_axis(arr_fy,arr_y);
	
	int nCountX = arr_x.GetSize();
	int nCountY = arr_y.GetSize();
	intervalY = dey/(nCountY-1);
	int tempDex = (nCountX-1)*intervalX;
	int tempDey = (nCountY-1)*intervalY;
	int cx,cy;
	MemDC.SelectObject(oldpen);
	oldpen = MemDC.SelectObject(&pen2);
	//X����Y�������
	for( i=1;i<nCountX;i++ )
	{
		MemDC.MoveTo(ox+i*intervalX, oy);
		MemDC.LineTo(ox+i*intervalX, oy+8);
	}
	
	for( i=0;i<nCountY;i++ )
	{
		MemDC.MoveTo(ox,oy-i*intervalY);
		MemDC.LineTo(ox-6,oy-i*intervalY);
		if( m_nIndexIV==0 )
		{
			MemDC.MoveTo(ox+dex,oy-i*intervalY);
			MemDC.LineTo(ox+dex+6,oy-i*intervalY);
		}
	}

	
	MemDC.SelectObject(&m_font2);

	//MemDC.SetBkMode(TRANSPARENT);
	//X,Y����ֵ�����귽����
	
	for( i=0;i<nCountY;i++ )
	{
		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen1);
		cSize = MemDC.GetTextExtent(arr_y[i]);
		MemDC.TextOut(ox-cSize.cx-10,oy-i*intervalY-cSize.cy/2,arr_y[i]);
		if( m_nIndexIV==0 )
		{
			cSize = MemDC.GetTextExtent(arr_yp[i]);
			MemDC.TextOut(ox+dex+10,oy-i*intervalY-cSize.cy/2,arr_yp[i]);
		}
		if( i>0 )
		{
			if( arr_y[i]=="0" )
			{
				MemDC.SelectObject(oldpen);
				oldpen = MemDC.SelectObject(&pen2);
			}
			MemDC.MoveTo(oxy.x,oxy.y-i*intervalY);
			MemDC.LineTo(ox+dex,oxy.y-i*intervalY);
		}
	}
	MemDC.SelectObject(oldpen);
	oldpen = MemDC.SelectObject(&pen1);
	for( i=1;i<nCountX;i++ )
	{
		cSize = MemDC.GetTextExtent(arr_x[i]);
		MemDC.TextOut(ox+i*intervalX-cSize.cx/2,oy+11,arr_x[i]);
		cSize = MemDC.GetTextExtent(arr_xp[i]);
		MemDC.TextOut(ox+i*intervalX-cSize.cx/2,oy+25,arr_xp[i]);
		MemDC.MoveTo(ox+i*intervalX,oxy.y);
		MemDC.LineTo(ox+i*intervalX,oxy.y-dey);
	}
	
	//0��ˮƽ��
	MemDC.SelectObject(oldpen);
	oldpen = MemDC.SelectObject(&pen2);
	if( nCountY!=0 )
	{
		if( arr_fy[0]<=0 && arr_fy[nCountY-1]>=0)
		{
			cy = oy-(0-arr_fy[0])/(arr_fy[nCountY-1]-arr_fy[0])*tempDey;
			MemDC.MoveTo(ox, cy);
			MemDC.LineTo(ox+dex, cy);
		}
	}
	
	//����
	for( k=0;k<5;k++ )
	{
		if( k>0 && k<4 && m_iCheck[k-1]==0 )
			continue;
		switch(k)
		{
		case 0:
			MemDC.SelectObject(oldpen);
			oldpen = MemDC.SelectObject(&pen3);
			break;
		case 1:
			MemDC.SelectObject(oldpen);
			oldpen = MemDC.SelectObject(&pen6);
			break;
		case 2:
			MemDC.SelectObject(oldpen);
			oldpen = MemDC.SelectObject(&pen9);
			break;
		case 3:
			MemDC.SelectObject(oldpen);
			oldpen = MemDC.SelectObject(&pen7);
			break;
		case 4:
			MemDC.SelectObject(oldpen);
			oldpen = MemDC.SelectObject(&pen16);
			break;
		}
		for( i=0;i<m_arrPL[k].GetSize();i++ )
		{
			cx = ox+(m_arrPL[k][i]-arr_fx[0])/(arr_fx[nCountX-1]-arr_fx[0])*tempDex;
			i += 1;
			cy = oy-(m_arrPL[k][i]-arr_fy[0])/(arr_fy[nCountY-1]-arr_fy[0])*tempDey;
			if( i==1 )
				MemDC.MoveTo(cx,cy);
			else
				MemDC.LineTo(cx,cy);
		}
		
	}

	if( m_bTarget==1 )
	{
		int cx1,cx2,rng;
		if( m_bPainted )
		{
			if( m_bItemCodeChange )
			{
				InitTargetRange();
				m_bItemCodeChange = FALSE;
			}
			m_ER = Calc_ER_Target(m_arrPL[0],m_fTargetLo,m_fTargetUp);
		}
	//	if( (m_bSelectLo || m_bSelectUp) && ( m_point.x>=(ox+intervalX+frmrect.left) && m_point.x<=(ox+intervalX*(nCountX-1)+frmrect.left) ) )
		if(m_bSelectLo || m_bSelectUp)
		{	
			static BOOL tempbChange = FALSE;
			if(m_btMouseGet==1 && m_btMouseRelease==0 )
			{
				float xLen,x;
				if ( m_point.x<(ox+intervalX+frmrect.left) )
					x = arr_fx[1];
				else if( m_point.x>(ox+intervalX*(nCountX-1)+frmrect.left) )
					x = arr_fx[arr_fx.GetSize()-1];
				else
				{
					xLen = (m_point.x-frmrect.left-ox)/((float)tempDex);
					x = arr_fx[0]+xLen*(arr_fx[arr_fx.GetSize()-1]-arr_fx[0]);
				}
				float temp;
				if( m_bSelectLo )
				{
					if( x>m_fTargetUp )
					{
						temp = m_fTargetUp;
						m_fTargetUp = x;
						m_fTargetLo = temp;
					}
					else
						m_fTargetLo = x;
				}
				else if( m_bSelectUp )
				{
					if( x<m_fTargetLo )
					{
						temp = m_fTargetLo;
						m_fTargetLo = x;
						m_fTargetUp = temp;
					}
					else
						m_fTargetUp = x;
				}
				tempbChange = TRUE;
			}
			else if(m_btMouseGet==0 && m_btMouseRelease==1 && tempbChange )
			{
				m_ER = Calc_ER_Target(m_arrPL[0],m_fTargetLo,m_fTargetUp);
				tempbChange = FALSE;
			}
		}
		if( m_fTargetLo<arr_fx[1] || m_fTargetUp>arr_fx[nCountX-1] )
		{
			ReleaseDC(&MemDC);
			PostMessage(MACRO_MsgRedrawER);
			m_bDrawing = FALSE;
			return 1;
		}
		
		cx1 = ox+(m_fTargetLo-arr_fx[0])/(arr_fx[nCountX-1]-arr_fx[0])*tempDex;
		m_cx_TgtLo = frmrect.left+cx1;
		MemDC.SelectObject(&pen2);
		if( m_bSelectLo )
		{
			for( i=1;i<nCountY;i++ )
			{
				MemDC.FillSolidRect(cx1-4,oy-i*intervalY-4,8,8,RGB(0,0,0));
			}
		}
		MemDC.MoveTo(cx1,oy-dey);
		MemDC.LineTo(cx1,oy);
		cx2 = ox+(m_fTargetUp-arr_fx[0])/(arr_fx[nCountX-1]-arr_fx[0])*tempDex;
		m_cx_TgtUp = frmrect.left+cx2;
		if( m_bSelectUp )
		{
			for( i=1;i<nCountY;i++ )
			{
				MemDC.FillSolidRect(cx2-4,oy-i*intervalY-4,8,8,RGB(0,0,0));
			}
		}
		MemDC.MoveTo(cx2,oy-dey);
		MemDC.LineTo(cx2,oy);
		MemDC.SelectObject(&pen1);
		rng = dey/10;
		for(i=oy-dey;i<=oy;i+=rng)
		{
			MemDC.MoveTo(cx1,i);
			if( (oy-i)<(cx2-cx1) )
				MemDC.LineTo(cx1+oy-i,oy);
			else
				MemDC.LineTo(cx2,i+cx2-cx1);
		}
		for(i=cx1+rng;i<=cx2;i+=rng)
		{
			MemDC.MoveTo(i,oy-dey);
			if( (cx2-i)<dey )
				MemDC.LineTo(cx2,oy-dey+cx2-i);
			else
				MemDC.LineTo(i+dey,oy);
		}

		CSize tempsize1,tempsize2;
		tempsize1 = MemDC.GetTextExtent(headline[m_TTOptions->m_iLangType]);
		tempsize2 = MemDC.GetTextExtent(strExp);
		CString str,strLo,strUp;
		GetPriceTxt(m_fTargetLo,strLo,1);
		GetPriceTxt(m_fTargetUp,strUp,1);
		str.Format("R.=(%s,%s) E.R=%.0f P.P=%.1f",strLo,strUp,m_ER,m_PP*100);
		str+="%";
		MemDC.SelectObject(&m_font1);
		MemDC.SetTextColor(RGB(255,0,255));
		if( !m_bUseRecord )
		{
			if( IsIndex() )
				MemDC.TextOut(30+tempsize1.cx+tempsize2.cx+60,cSize.cy/2-2,str);
			else
				MemDC.TextOut(10+tempsize1.cx+tempsize2.cx+60,cSize.cy/2-2,str);
		}
		else
		{
			MemDC.SetTextColor(RGB(255,0,255));
			if( IsIndex() )
				MemDC.TextOut(30+tempsize1.cx+tempsize2.cx+60,-1,str);
			else
				MemDC.TextOut(10+tempsize1.cx+tempsize2.cx+60,-1,str);

			str.Format("R.=(%s,%s) E.R=%.0f P.P=%.1f",strLo,strUp,m_ExtRecord.d_ER,m_ExtRecord.f_PP*100);
			str+="%";
			MemDC.SetTextColor(RGB(255,0,0));
			if( IsIndex() )
				MemDC.TextOut(30+tempsize1.cx+tempsize2.cx+60,cSize.cy,str);
			else
				MemDC.TextOut(10+tempsize1.cx+tempsize2.cx+60,cSize.cy,str);
		}

		MemDC.SetTextColor(RGB(0,0,0));
	}

	//�ּ�P
	if( fCorr>=arr_fx[0]&&fCorr<=arr_fx[arr_fx.GetSize()-1] )
	{
		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen5);
		if( nCountX!=0 )
		{
			cx = ox+(fCorr-arr_fx[0])/(arr_fx[nCountX-1]-arr_fx[0])*tempDex;
			cy = oy-dey;
			CString szCash;
			GetPriceTxt(fCorr,szCash);
			cSize = MemDC.GetTextExtent(szCash);
			MemDC.MoveTo(cx, oy);
			MemDC.LineTo(cx, cy);
			MemDC.TextOut(cx+2,oy-cSize.cy-15,szCash);
		}
	}

	//��͵������
	char sz[100];
	
	float flo;
	if( !bDraw )
	{
//		
	}
	else if( bDraw )
	{
		
		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen10);
		CSize cSize1 = MemDC.GetTextExtent("10.0%");
		if( m_arrBrkValue.GetSize()!=0 )
		{
			flo = m_arrBrkValue[0];
			cx = ox+(flo-arr_fx[0])/(arr_fx[nCountX-1]-arr_fx[0])*tempDex;
			GetPriceTxt(flo,szValue);
			MemDC.MoveTo(cx, oy);
			MemDC.LineTo(cx, oy-dey);
			MemDC.TextOut(cx+2, oy-cSize.cy-2,szValue);
			
			if( m_nIndex!=STGY_CUSTOM && m_arrBrkPB.GetSize()>0 )
			{
				szValue.Format("%.1f",m_arrBrkPB[0]*100);
				szValue += "%";
				if( m_arrBrkPB[1]==0.0 )
				{
					MemDC.FillSolidRect(cx-cSize1.cx-6,oy-dey+5,cSize1.cx+4,2+cSize1.cy,RGB(100,149,237));
					MemDC.SetTextColor(RGB(255,255,255));
					MemDC.TextOut(cx-3-cSize1.cx, oy-dey+6,szValue);
				}
				else
				{
					MemDC.FillSolidRect(cx+2,oy-dey+5,cSize1.cx+4,2+cSize1.cy,RGB(100,149,237));
					MemDC.SetTextColor(RGB(255,255,255));
					MemDC.TextOut(cx+3, oy-dey+6,szValue);
				}
			}
		}

		if( m_arrBrkValue.GetSize()>1 )
		{
			for( i=1;i<m_arrBrkValue.GetSize();i++ )
			{
				flo = m_arrBrkValue[i];
				cx = ox+(flo-arr_fx[0])/(arr_fx[nCountX-1]-arr_fx[0])*tempDex;
				GetPriceTxt(flo,szValue);
				MemDC.MoveTo(cx, oy);
				MemDC.LineTo(cx, oy-dey);
				MemDC.SetTextColor(RGB(0,0,0));
				MemDC.TextOut(cx+2, oy-cSize.cy-2,szValue);
				
				if( m_nIndex!=STGY_CUSTOM && m_arrBrkPB.GetSize()>0 )
				{
					szValue.Format("%.1f",m_arrBrkPB[2*i]*100);
					szValue += "%";
					MemDC.FillSolidRect(cx+2,oy-dey+5,cSize1.cx+4,2+cSize1.cy,RGB(100,149,237));
					MemDC.SetTextColor(RGB(255,255,255));
					MemDC.TextOut(cx+3, oy-dey+6,szValue);
				}
			}
		}
		MemDC.SetTextColor(RGB(0,0,0));
	}
	MemDC.SelectObject(&m_font2);

	if( m_point.x>=(ox+intervalX+frmrect.left) && m_point.x<=(ox+intervalX*(nCountX-1)+frmrect.left) )
	{
		cSize0 = MemDC.GetTextExtent("09/11/2017 -10000");
		MemDC.FillSolidRect(ox+1,oy-dey+2,cSize0.cx+2,3+(cSize0.cy+2)*m_nCkCount,RGB(211,211,211));

		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen15);
		MemDC.MoveTo(m_point.x-frmrect.left,oy-dey);
		MemDC.LineTo(m_point.x-frmrect.left,oy);

		float arrfo;
		float x;
		float xLen = (m_point.x-frmrect.left-ox)/((float)tempDex);
		x = arr_fx[0]+xLen*(arr_fx[arr_fx.GetSize()-1]-arr_fx[0]);
		
		int iDate;
		CTime tm;
		CString str;
		CTime time = CTime::GetCurrentTime();
		
		arrfo = Get_Fx_y(m_arrPL[0],x);
		CTimeSpan span1( lExpiryDays-1,0,0,0 );
		tm = time+span1;
		str = tm.Format("%m/%d/%Y");
		str.Format("%s %.0f",str, arrfo);
		MemDC.SetTextColor(RGB(255,0,0));
		MemDC.TextOut(ox+2,oy-dey+5,str);
		
		if( m_ck1.GetCheck() && m_arrPL[1].GetSize()>0 )
		{
			arrfo = Get_Fx_y(m_arrPL[1],x);
			iDate = m_TTOptions->m_lExpiryDays-m_nDay1;
			CTimeSpan span( iDate,0,0,0 );
			tm = time+span;
			str = tm.Format("%m/%d/%Y");
			str.Format("%s %.0f",str, arrfo);
			MemDC.SetTextColor(RGB(238,118,0));
			MemDC.TextOut(ox+2,oy-dey+5+cSize0.cy+2,str);

			str.Format("%.0f",arrfo);
			CSize cs = MemDC.GetTextExtent(str);
			int cy = oy-(arrfo-arr_fy[0])/(arr_fy[nCountY-1]-arr_fy[0])*tempDey;
			MemDC.FillSolidRect(m_point.x-frmrect.left+4,cy-cSize0.cy-8,cs.cx+4,3+cSize0.cy,RGB(0,0,0));
			MemDC.SetTextColor(RGB(255,255,255));
			MemDC.TextOut(m_point.x-frmrect.left+6,cy-cSize0.cy-6,str);

			POINT point[5] = {{ox+dex+1,cy},{ox+dex+10,cy-cs.cy/2-1},{ox+dex+42,cy-cs.cy/2-1},{ox+dex+42,cy+cs.cy/2+1},{ox+dex+10,cy+cs.cy/2+1}};
			CRgn Rgn;
			Rgn.CreatePolygonRgn(point,5,WINDING);
			MemDC.FillRgn(&Rgn,&m_brush1);
			Rgn.DeleteObject();
			MemDC.SelectObject(&pen2);
			MemDC.MoveTo(point[0]);
			MemDC.LineTo(point[1]);
			MemDC.LineTo(point[2]);
			MemDC.LineTo(point[3]);
			MemDC.LineTo(point[4]);
			MemDC.LineTo(point[0]);
			MemDC.SetTextColor(RGB(0,0,0));
			str.Format("%.0f",arrfo/fabs(principal*m_lShares)*100);
			str += "%";
			MemDC.TextOut(ox+dex+12,cy-cs.cy/2,str);
			char cd[50];
			

			MemDC.SetBkMode(TRANSPARENT);
		}
		if( m_ck2.GetCheck()&& m_arrPL[2].GetSize()>0 )
		{
			arrfo = Get_Fx_y(m_arrPL[2],x);
			iDate = m_TTOptions->m_lExpiryDays-m_nDay2;
			CTimeSpan span( iDate,0,0,0 );
			tm = time+span;
			str = tm.Format("%m/%d/%Y");
			str.Format("%s %.0f",str, arrfo);
			MemDC.SetTextColor(RGB(47,79,79));
			if( !m_ck1.GetCheck() )
				MemDC.TextOut(ox+2,oy-dey+5+cSize0.cy+2,str);
			else
				MemDC.TextOut(ox+2,oy-dey+5+2*(cSize0.cy+2),str);
		}
		if( m_ck3.GetCheck()&& m_arrPL[3].GetSize()>0 )
		{
			arrfo = Get_Fx_y(m_arrPL[3],x);
			iDate = m_TTOptions->m_lExpiryDays-m_nDay3;
			CTimeSpan span( iDate,0,0,0 );
			tm = time+span;
			str = tm.Format("%m/%d/%Y");
			str.Format("%s %.0f",str, arrfo);
			MemDC.SetTextColor(RGB(46,139,87));
			if( !m_ck1.GetCheck()&&!m_ck2.GetCheck() )
				MemDC.TextOut(ox+2,oy-dey+5+cSize0.cy+2,str);
			else if( !m_ck1.GetCheck()||!m_ck2.GetCheck() )
				MemDC.TextOut(ox+2,oy-dey+5+2*(cSize0.cy+2),str);
			else if( m_ck1.GetCheck()&&m_ck2.GetCheck() )
				MemDC.TextOut(ox+2,oy-dey+5+3*(cSize0.cy+2),str);
		}
		CSize cSize1 = MemDC.GetTextExtent("100.0%");
		if( m_nIndex==STGY_CUSTOM )
		{
			BSMCALINFO calinfo;
			
			m_iOdr = 1;
			m_TTOptions->ModelPrice(FALSE,x,m_TTOptions->GetCorrStockPrice(FALSE),m_TTOptions->m_lExpiryDays,POS_PUT_LAST,calinfo);
			str.Format("%.1f",(1.0-calinfo.ITM)*100);
			str += "%";
			if( m_point.x<=(ox+cSize0.cx+2+frmrect.left) )
			{
				MemDC.FillSolidRect(m_point.x-frmrect.left-cSize1.cx-6,oy-dey+6+(cSize0.cy+2)*m_nCkCount,cSize1.cx+4,2+cSize1.cy,RGB(100,149,237));
				MemDC.SetTextColor(RGB(255,255,255));
				MemDC.TextOut(m_point.x-frmrect.left-3-cSize1.cx, oy-dey+6+(cSize0.cy+2)*m_nCkCount,str);
				str.Format("%.1f",calinfo.ITM*100);
				str += "%";
				MemDC.FillSolidRect(m_point.x-frmrect.left+3,oy-dey+6+(cSize0.cy+2)*m_nCkCount,cSize1.cx+4,2+cSize1.cy,RGB(100,149,237));
				MemDC.TextOut(m_point.x-frmrect.left+4, oy-dey+6+(cSize0.cy+2)*m_nCkCount,str);
			}
			else
			{
				MemDC.FillSolidRect(m_point.x-frmrect.left-cSize1.cx-6,oy-dey+5,cSize1.cx+4,2+cSize1.cy,RGB(100,149,237));
				MemDC.SetTextColor(RGB(255,255,255));
				MemDC.TextOut(m_point.x-frmrect.left-3-cSize1.cx, oy-dey+6,str);
				str.Format("%.1f",calinfo.ITM*100);
				str += "%";
				MemDC.FillSolidRect(m_point.x-frmrect.left+3,oy-dey+5,cSize1.cx+4,2+cSize1.cy,RGB(100,149,237));
				MemDC.TextOut(m_point.x-frmrect.left+4, oy-dey+6,str);
			}
		}

		int nDeci = GetPriceTxt(fCash,str);
		if( nDeci>=2 )
			str.Format("%.2f",x);
		else if( nDeci==1 )
			str.Format("%.1f",x);
		else if( nDeci==0 )
			str.Format("%.0f",x);
		MemDC.SetTextColor(RGB(47,79,79));
		if( m_point.x<=(ox+cSize0.cx+2+frmrect.left) )
		{
			if( m_nIndex==STGY_CUSTOM )
				MemDC.TextOut(m_point.x-frmrect.left+2,oy-dey+6+(cSize0.cy+2)*m_nCkCount+cSize1.cy+2,str);
			else
				MemDC.TextOut(m_point.x-frmrect.left+2,oy-dey+6+(cSize0.cy+2)*m_nCkCount,str);
		}
		else
		{
			if( m_nIndex==STGY_CUSTOM )
				MemDC.TextOut(m_point.x-frmrect.left+2,oy-dey+6+cSize1.cy+2,str);
			else
				MemDC.TextOut(m_point.x-frmrect.left+2,oy-dey+3,str);
		}

		MemDC.SetTextColor(RGB(0,0,0));
	}
	//IV Data
	MemDC.SelectObject(oldpen);
	oldpen = MemDC.SelectObject(&pen1);
	MemDC.MoveTo(ox+dex, oy);
	MemDC.LineTo(ox+dex, oy-dey);

	cSize = MemDC.GetTextExtent(szIVTxt[m_nIndexIV]);
	MemDC.TextOut(ox+dex-cSize.cx/2,frmrect.Height()-dey-cSize.cy-55,szIVTxt[m_nIndexIV]);
	
	//MemDC.SelectObject(oldfont);
	//oldfont = 
	MemDC.SelectObject(&m_font2);

	
	if( m_bPainted )
	{
		arr_IV.RemoveAll();
		arr_IVX.RemoveAll();
		
		for( i=0;i<4;i++ )
			arr_Greeks[i].RemoveAll();
	}
	arr_strIV.RemoveAll();
	float ftemp = 0;
	float fMax, fMin;
	CString strAmp;
	if( m_bPainted )
	{
	//	for( i=1;i<arr_fx.GetSize();i++ )
	//	{
	//		f_Strike = arr_fx[i];
		for( f_Strike=arr_fx[1];f_Strike<=arr_fx[arr_fx.GetSize()-1]; )
		{			
			arr_IVX.Add(f_Strike);
			for( j=0;j<5;j++ )  //���Greeks��4���� j=0ѭ���㵱ǰѡ���iv index�� 1��4��greeks      
			{
				f = 0.0;
				ftemp = 0.0;
				
				if( j==0 )
					indexIV = m_nIndexIV;
				else
					indexIV = j;
				
				for( k=0;k<6;k++ )  //ֻ����Greeks���õ����ѭ�� IVֻ��k=0��һ��  iPMs[k]��ֵ 1����-1 *����
				{
					if( indexIV>4 && k>0 )
						break;
					
					float fStkep;
					CString szText;
					if( iPMs[k]==0 )
						continue;
					
					if( k==0 )
					{
						if( m_nIndex==STGY_CUSTOM )
							fStkep = m_arrItem[m_nIxStrike].m_fStrike;
						else if( m_nIndex==15||m_nIndex==16 )
							fStkep = m_arrItem[m_nIxStrike2].m_fStrike;
						else
							m_ComBoxStrike.GetLBText(m_nIxStrike,szText);
					}
					else if( k==1 )
					{
						if( m_nIndex==STGY_CUSTOM )
							fStkep = m_arrItem[m_nIxStrike2].m_fStrike;
						else
							m_ComBoxStrike2.GetLBText(m_nIxStrike2,szText);
					}
					else if( k==2 )
					{
						if( m_nIndex==STGY_CUSTOM )
							fStkep = m_arrItem[m_nIxStrike3].m_fStrike;
						else
							m_ComBoxStrike3.GetLBText(m_nIxStrike3,szText);
					}
					else if( k==3 )
					{
						if( m_nIndex==STGY_CUSTOM )
							fStkep = m_arrItem[m_nIxStrike4].m_fStrike;
						else
							m_ComBoxStrike4.GetLBText(m_nIxStrike4,szText);
					}
					else if( k==4 )
					{
						fStkep = m_arrItem[m_nIxStrike5].m_fStrike;
					}
					else if( k==5 )
					{
						fStkep = m_arrItem[m_nIxStrike6].m_fStrike;
					}
					if( m_nIndex<15 )
						fStkep = atof(szText);
					if( m_nIndex==17||m_nIndex==18 )
					{
						if( k==0 )
							fStkep = m_cald.fStrike;
						else if( k==1 )
							fStkep = m_fStrike2_Spread;
					}
					
					BSMCALINFO calinfo;
					m_TTOptions->DateDiff(m_lCaldExpDate1,lToday,lExpiryDays);
					int tempday,nday1,nday2;
					nday1 = m_nDay1;
					nday2 = m_TTOptions->m_lExpiryDays;   //һ������õ�������
					m_TTOptions->DateDiff(m_lCaldExpDate2,m_lCaldExpDate1,tempday);
					BYTE bPos = 0;
					float fSprdStrike = f_Strike;  //�����·ݼ۲� :fSpread
					if( m_nIndex==17||m_nIndex==18 )
					{
						nday2 = lExpiryDays;       
						if( k==1  )   //��ڶ����·ݵ�ʱ������Ҫ���������µ�������
						{
							bPos = 1;
							nday1 += tempday;     //nday1:�ɵ�������   nDay2:�̶�����������
							nday2 += tempday;
							fSprdStrike += fSpread;
						}
					}
					memset(&calinfo, 0, sizeof(BSMCALINFO));
					switch( indexIV )
					{
					case 1:
					case 2:
					case 3:
					case 4:
						m_iOdr = 1;//�ɵ�ǰ�̶��ĵ�����ʣ��������Ϊ�ɵ�������������greeks
						if( inAddr[k]<10 )
							m_TTOptions->ModelPrice(TRUE,fStkep,fSprdStrike,nday1,inAddr[k],calinfo);
						else
							m_TTOptions->ModelPrice(FALSE,fStkep,fSprdStrike,nday1,inAddr[k],calinfo);
						break;
					case 9:
						m_TTOptions->ModelPrice(TRUE,f_Strike,0,nday2,POS_CALL_LAST,calinfo,bPos);
						break;
					case 10:
						m_TTOptions->ModelPrice(FALSE,f_Strike,0,nday2,POS_PUT_LAST,calinfo,bPos);
						break;
					case 5:
						m_TTOptions->ModelPrice(TRUE,f_Strike,0,nday2,POS_CALL_BID,calinfo,bPos);
						break;
					case 6:
						m_TTOptions->ModelPrice(TRUE,f_Strike,0,nday2,POS_CALL_ASK,calinfo,bPos);
						break;
					case 7:
						m_TTOptions->ModelPrice(FALSE,f_Strike,0,nday2,POS_PUT_BID,calinfo,bPos);
						break;
					case 8:
						m_TTOptions->ModelPrice(FALSE,f_Strike,0,nday2,POS_PUT_ASK,calinfo,bPos);
						break;
					}
					switch( indexIV )
					{
					case 1:
						ftemp = calinfo.delta*iPMs[k]*m_nOrderCount;
						break;
					case 2:
						ftemp = calinfo.vega*iPMs[k]*m_nOrderCount;
						break;
					case 3:
						ftemp = calinfo.gamma*iPMs[k]*m_nOrderCount;
						break;
					case 4:
						ftemp = calinfo.theta*iPMs[k]*m_nOrderCount;
						break;
					case 5:
					case 6:
					case 7:
					case 8:
					case 9:
					case 10:
						ftemp = calinfo.impliedVolitility*100;
						break;
					}
					f += ftemp ;
			}
			if( m_nIndex==15 && indexIV==1 )
				f += m_nOrderCount;
			if( m_nIndex==16 && indexIV==1 )
				f -= m_nOrderCount;
			if( m_nIndex==STGY_CUSTOM && indexIV==1 )
			{
				for( int z=0;z<6;z++ )
				{
					if( m_nCustomIx[z]==4||m_nCustomIx[z]==5 )
						f += m_nCustomCount[z];
				}
			}
			
			if( j==0 )
				arr_IV.Add(f);
			else
				arr_Greeks[j-1].Add(f);
		}
		f_Strike += 0.2*(arr_fx[2]-arr_fx[1]);
	}
	}
	if( strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex() )
	{
		for( int z=0;z<4;z++ )
			arr_Greeks[z].RemoveAll();
	}

	if( m_nIndexIV==0 )
	{
		pdc->BitBlt(frmrect.left+2, frmrect.top+10, frmrect.Width()-4,frmrect.Height()-12, &MemDC, 0, 0, SRCCOPY);
		if( m_bPainted && m_bFillList )
		{
			SufPaint();
		}
		m_bPainted = TRUE;
		m_bDrawing = FALSE;
		m_bFillList = TRUE;
		if( m_bItemCodeChange )
			m_bItemCodeChange = FALSE;
		return 1;
	}

	fMax = fMin = arr_IV[0];
	for( i=0;i<arr_IV.GetSize();i++ )
	{
		if( arr_IV[i]<fMin )
			fMin = arr_IV[i];
		if( arr_IV[i]>fMax )
			fMax = arr_IV[i];
	}
	int acc = 0;
	if( (fabs(fMax-fMin)/10)<0.000005 )
	{
		dea = 0.000002;
		acc = 6;
	}
	else if( (fabs(fMax-fMin)/10)<0.00001 )
	{
		dea = 0.000005;
		acc = 6;
	}
	else if( (fabs(fMax-fMin)/10)<0.00002 )
	{
		dea = 0.00002;
		acc = 5;
	}
	else if( (fabs(fMax-fMin)/10)<0.00005 )
	{
		dea = 0.00005;
		acc = 5;
	}
	else if( (fabs(fMax-fMin)/10)<0.0002 )
	{
		dea = 0.0002;
		acc = 4;
	}
	else if( (fabs(fMax-fMin)/10)<0.0005 )
	{
		dea = 0.0005;
		acc = 4;
	}
	else if( (fabs(fMax-fMin)/10)<0.002 )
	{
		dea = 0.002;
		acc = 3;
	}
	else if( (fabs(fMax-fMin)/10)<0.005 )
	{
		dea = 0.005;
		acc = 3;
	}
	else if( (fabs(fMax-fMin)/10)<0.02 )
	{
		dea = 0.02;
		acc = 2;
	}
	else if( (fabs(fMax-fMin)/10)<0.05 )
	{
		dea = 0.05;
		acc = 2;
	}
	else if( (fabs(fMax-fMin)/10)<0.2 )
	{
		dea = 0.2;
		acc = 1;
	}
	else if( (fabs(fMax-fMin)/10)<0.5 )
	{
		dea = 0.5;
		acc = 1;
	}
	else if( (fabs(fMax-fMin)/10)<1 )
		dea = 1;
	else if( (fabs(fMax-fMin)/10)<2 )
		dea = 2;
	else if( (fabs(fMax-fMin)/10)<5 )
		dea = 5;
	else if( (fabs(fMax-fMin)/10)<10 )
		dea = 10;
	else if( (fabs(fMax-fMin)/10)<15 )
		dea = 15;
	else if( (fabs(fMax-fMin)/10)<20 )
		dea = 20;
	else if( (fabs(fMax-fMin)/10)<30 )
		dea = 30;
	else if( (fabs(fMax-fMin)/10)<50 )
		dea = 50;
	else if( (fabs(fMax-fMin)/10)<100 )
		dea = 100;
	else if( (fabs(fMax-fMin)/10)<200 )
		dea = 200;
	else if( (fabs(fMax-fMin)/10)<300 )
		dea = 300;
	else if( (fabs(fMax-fMin)/10)<500 )
		dea = 500;
	else if( (fabs(fMax-fMin)/10)<1000 )
		dea = 1000;
	

	fMax = (int(fMax/dea)+1)*dea;
	fMin = (int(fMin/dea)-1)*dea;
	for( ftemp=fMin;ftemp<(fMax+0.1*dea);ftemp+=dea )
	{
		CString str;
		switch(acc)
		{
		case 0:
			str.Format("%.0f", ftemp);
			break;
		case 1:
			str.Format("%.1f", ftemp);
			break;
		case 2:
			str.Format("%.2f", ftemp);
			break;
		case 3:
			str.Format("%.3f", ftemp);
			break;
		case 4:
			str.Format("%.4f", ftemp);
			break;
		case 5:
			str.Format("%.5f", ftemp);
			break;
		case 6:
			str.Format("%.6f", ftemp);
			break;
		}
		arr_strIV.Add(str);
	}
	MemDC.SelectObject(oldpen);
	oldpen = MemDC.SelectObject(&pen2);
	MemDC.SetTextColor(RGB(0,0,0));
	int interval = dey/arr_strIV.GetSize();
	tempDey = (arr_strIV.GetSize()-1)*interval; 
	for( i=0;i<arr_strIV.GetSize();i++ )
	{
		MemDC.MoveTo(ox+dex, oy-i*interval);
		MemDC.LineTo(ox+dex+6, oy-i*interval);
		cSize = MemDC.GetTextExtent(arr_strIV[i]);
		MemDC.TextOut(ox+dex+10,oy-i*interval-cSize.cy/2, arr_strIV[i]);
	}
	
	switch( m_nIndexIV )
	{
	case 1:
		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen11);
		break;
	case 2:
		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen12);
		break;
	case 3:
		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen13);
		break;
	case 4:
		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen14);
		break;
	default:
		MemDC.SelectObject(oldpen);
		oldpen = MemDC.SelectObject(&pen4);
		break;
	}
	int nCount = arr_IV.GetSize();
	CString sdf;
	int numb1 = -1,numb2 = -1;
	for( i=0;i<arr_IV.GetSize();i++ )
	{
		if( arr_IV[i]!=0.0 )
		{
			numb1 = i;
			break;
		}
	}
	for( i=arr_IV.GetSize()-1;i>-1;i-- )
	{
		if( arr_IV[i]!=0.0 )
		{
			numb2 = i;
			break;
		}
	}
	
	for( i=numb1;i<=numb2;i++ )
	{
		cx = ox+(arr_IVX[i]-arr_fx[0])/(arr_fx[nCountX-1]-arr_fx[0])*tempDex;
		cy = oy-(arr_IV[i]-fMin)/(fMax-fMin)*tempDey;
		
		if( i==numb1 )
			MemDC.MoveTo(cx,cy);
		else
			MemDC.LineTo(cx,cy);
	}

	if( m_nIndexIV>0 && m_nIndexIV<5 )
	{ 
		MemDC.SelectObject(&m_font3);
		cSize = MemDC.GetTextExtent(szGKTips[m_nIndexIV-1]);
		MemDC.TextOut(frmrect.Width()-2,oy-dey/2-cSize.cx/2, szGKTips[m_nIndexIV-1]);
//		MemDC.SelectObject(oldfont);
	}

	pdc->BitBlt(frmrect.left+2, frmrect.top+10, frmrect.Width()-4,frmrect.Height()-12, &MemDC, 0, 0, SRCCOPY);
	
	if( m_bPainted && m_bFillList )
	{
		SufPaint();
	}
	m_bPainted = TRUE;
	m_bDrawing = FALSE;
	m_bFillList = TRUE;
	if( m_bItemCodeChange )
		m_bItemCodeChange = FALSE;
	return 1;
}

void CStrategy::OnSelchangeComboType() 
{
	int ix = m_ComBoxType.GetCurSel();
	if( ix!=m_nIndex )
	{
		m_nIxStrike = -1;
		m_nIxStrike2 = -1;
		m_nIxStrike3 = -1;
		m_nIxStrike4 = -1;
		m_nIxStrike5 = -1;
		m_nIxStrike6 = -1;

		if( m_bHaveCrt_Spin_C && ix!=16 )
			DestroySpin(m_pSpin_C,m_bHaveCrt_Spin_C);

		if( ix==16 && !m_bHaveCrt_Spin_C && m_bMode==0 )
				CreateSpin(&m_list,m_pSpin_C,2,1,m_bHaveCrt_Spin_C);

		if( ix==STGY_CUSTOM && m_bMode==0 )
		{
			m_nOrderCount = 1;
			for( int j=0;j<5;j++ )
				CreateSpin(&m_list,m_pSpinEx[j],j+3,2,m_bHaveCrt_Spin);

			if( m_bOrder )
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top+33);
			}
			else
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top+33);
			}
			m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top+33,m_RectLst2.Width(),m_RectLst2.Height());
			m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top+33,m_RectEd2.Width(),m_RectEd2.Height());
			m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top+33,m_RectEd3.Width(),m_RectEd3.Height());
			m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height()+33);
			m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height()+33);
			AdjustWindowH_Order();
		}
		if( m_nIndex==STGY_CUSTOM && m_bMode==0 )
		{
			for( int j=0;j<5;j++ )
				DestroySpin(m_pSpinEx[j],m_bHaveCrt_Spin);
			m_bHaveCrt_Spin = TRUE;//��Ϊ��һ��spin����

			if( m_bOrder )
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top);
			}
			else
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top);
			}
			m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top,m_RectEd2.Width(),m_RectEd2.Height());
			m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top,m_RectEd3.Width(),m_RectEd3.Height());
			m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top,m_RectLst2.Width(),m_RectLst2.Height());
			m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height());
			m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height());
			AdjustWindowH_Order();
		}

		ClearFlag();
		memset(&m_cald,0,sizeof(m_cald));

		m_nIndex = ix;
		SwitchCtrl();
		SetListMode();

		for( int i=0;i<3;i++ )
		{
			m_bResetBF[i] = TRUE;	
		}
		for( i=0;i<6;i++ )
		{
			m_bAlterPrice[i] = FALSE;
			m_bAlterPrice2[i] = FALSE;
		}

		m_nRetn = PrePaint();
		SelectType();
		if( m_nRetn==0 )
			return;

		if( ix==17 || ix==18 )
		{
			m_cald.fStrike = m_arrItem[m_nPos].m_fStrike;
			POSITION pos = m_TTOptions->m_lstMonths.GetHeadPosition();
			m_cald.lMonth1 = m_TTOptions->m_lstMonths.GetNext(pos);
			m_cald.lMonth2 = m_TTOptions->m_lstMonths.GetNext(pos);
			m_fStrike2_Spread = m_cald.fStrike;

			if( ix==18 )
			{
				m_cald.fStrike = m_arrItem[m_nPos+1].m_fStrike;
				m_fStrike2_Spread = m_arrItem[m_nPos-1].m_fStrike;
			}
			
			CalendarRequest();
			
		}

		InitDays();
		DrawIncomeLine();
	}
}

HBRUSH CStrategy::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if(nCtlColor ==CTLCOLOR_STATIC) 
	{
		pDC->SetBkMode(TRANSPARENT);
		return m_brush;
	}
	if( nCtlColor ==CTLCOLOR_EDIT )
	{
		if(pWnd->GetDlgCtrlID()==IDC_EDIT_TT || pWnd->GetDlgCtrlID()==IDC_EDIT_TT2) 
			pDC->SetBkColor(RGB(255,218,185));
		else if(pWnd->GetDlgCtrlID()==IDC_EDIT_TT3)
			pDC->SetBkColor(RGB(255,193,193));
	}
	// TODO: Change any attributes of the DC here
	if(nCtlColor ==CTLCOLOR_DLG) 
		return m_brush;
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}



void CStrategy::OnSelchangeComboStrike() 
{
	int i;
	int ix = m_ComBoxStrike.GetCurSel();
	CString str;
	float fstk,fstk1,fstk2,fstk3,fstk4;
	m_ComBoxStrike.GetLBText(ix, str);
	fstk = atof(str);
	m_ComBoxStrike.GetLBText(m_nIxStrike, str);
	fstk1 = atof(str);
	m_ComBoxStrike2.GetLBText(m_nIxStrike2, str);
	fstk2 = atof(str);
	if( ix!=m_nIx1 )
	{

		if( m_nIndex>=11 && fstk>=fstk2 )
		{
			for(i=0;i<m_ComBoxStrike2.GetCount();i++)
			{
				m_ComBoxStrike2.GetLBText(i, str);
				float f = atof(str);
				if( f==fstk+fstk2-fstk1 )
				{
					m_nIxStrike2 = i;
					break;
				}
			}
			if( i==m_ComBoxStrike2.GetCount() )
				m_nIxStrike2 = i-1;
		}

	
		

		m_bAlterPrice[0] = FALSE; 
		m_bAlterPrice2[0] = FALSE;
		m_nIx1 = ix;
		if( m_nIndex==0 || m_nIndex==1 || m_nIndex==6 )
		{
			return;
		}
		else
			m_nIxStrike = ix;

		for( int ii=0;ii<3;ii++ )
		{
			m_bResetBF[ii] = TRUE;	
		}

		SetListMode();

		m_nRetn = PrePaint();
		SelectType();
		if( m_nRetn==0 )
			return;
		
		DrawIncomeLine();
		
	}
}

void CStrategy::OnSelchangeComboStrike2() 
{
	int i;
	int ix = m_ComBoxStrike2.GetCurSel();
	CString str;
	float fstk,fstk1,fstk2,fstk3,fstk4;
	m_ComBoxStrike2.GetLBText(ix, str);
	fstk = atof(str);
	m_ComBoxStrike.GetLBText(m_nIxStrike, str);
	fstk1 = atof(str);
	m_ComBoxStrike2.GetLBText(m_nIxStrike2, str);
	fstk2 = atof(str);
	/*m_ComBoxStrike3.GetLBText(m_nIxStrike3, str);
	fstk3 = atof(str);
	m_ComBoxStrike4.GetLBText(m_nIxStrike4, str);
	fstk4 = atof(str);
	float flo = 0;
	int iRow = m_TTOptions->FindRow(fstk);*/
	if( ix!=m_nIx2 )
	{
	/*	switch( m_nIndex )
		{
		case 0:
		case 11:
			flo = m_TTOptions->m_pDataBuf[iRow].m_fCalls_Nominal;//m_fCalls_Bid;
			break;
		case 1:
		case 12:
			flo = m_TTOptions->m_pDataBuf[iRow].m_fCalls_Nominal;//m_fCalls_Ask;
			break;
		case 2:
		case 4:
		case 14:
			flo = m_TTOptions->m_pDataBuf[iRow].m_fPuts_Nominal;//m_fPuts_Ask;
			break;
		case 3:
		case 5:
		case 6:
		case 13:
			flo = m_TTOptions->m_pDataBuf[iRow].m_fPuts_Nominal;//m_fPuts_Bid;
			break;
		}*/
		
		if( m_nIndex>=11 && fstk<=fstk1 )
		{
			for(i=0;i<m_ComBoxStrike.GetCount();i++)
			{
				m_ComBoxStrike.GetLBText(i, str);
				float f = atof(str);
				if( f==fstk-(fstk2-fstk1) )
				{
					m_nIxStrike = i;
					break;
				}
			}
			if( i==m_ComBoxStrike.GetCount() )
				m_nIxStrike = 0;
		}
		
		/*
		if( flo==0 )
		{
			MessageBox(szStkTip2[m_TTOptions->m_iLangType], "Tips",MB_OK);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
			return ;
		}*/
		m_bAlterPrice[1] = FALSE;
		m_bAlterPrice2[1] = FALSE;
		m_nIx2 = ix;
		if( m_nIndex==0 || m_nIndex==1 || m_nIndex==6 )
		{
			
			return;
		}
		else
			m_nIxStrike2 = ix;

		for( int ii=0;ii<3;ii++ )
		{
			m_bResetBF[ii] = TRUE;	
		}

		SetListMode();

		m_nRetn = PrePaint();
		SelectType();
		if( m_nRetn==0 )
			return;
		DrawIncomeLine();
	}
}

void CStrategy::OnSelchangeComboStrike3() 
{
	int i;
	int ix = m_ComBoxStrike3.GetCurSel();
	/*CString str;
	float fstk,fstk1,fstk2,fstk3,fstk4;
	m_ComBoxStrike3.GetLBText(ix, str);
	fstk = atof(str);
	m_ComBoxStrike.GetLBText(m_nIxStrike, str);
	fstk1 = atof(str);
	m_ComBoxStrike2.GetLBText(m_nIxStrike2, str);
	fstk2 = atof(str);
	m_ComBoxStrike3.GetLBText(m_nIxStrike3, str);
	fstk3 = atof(str);
	m_ComBoxStrike4.GetLBText(m_nIxStrike4, str);
	fstk4 = atof(str);
	float flo = 0;
	int iRow = m_TTOptions->FindRow(fstk);*/
	if( ix!=m_nIx3 )
	{
		/*switch( m_nIndex )
		{
		case 0:
			flo = m_TTOptions->m_pDataBuf[iRow].m_fCalls_Nominal;//m_fCalls_Ask;
			break;
		case 1:
		case 6:
			flo = m_TTOptions->m_pDataBuf[iRow].m_fCalls_Nominal;//m_fCalls_Bid;
			break;
		}

		
		if( flo==0 )
		{
			MessageBox(szStkTip2[m_TTOptions->m_iLangType], "Tips",MB_OK);
			m_ComBoxStrike3.SetCurSel(m_nIxStrike3);
			return ;
		}*/
		m_bAlterPrice[2] = FALSE;
		m_bAlterPrice2[2] = FALSE;
		m_nIx3 = ix;
		if( m_nIndex==0 || m_nIndex==1 || m_nIndex==6 )
		{
			return;
		}
		else
			m_nIxStrike3 = ix;

		for( int ii=0;ii<3;ii++ )
		{
			m_bResetBF[ii] = TRUE;	
		}

		SetListMode();

		m_nRetn = PrePaint();
		SelectType();
		if( m_nRetn==0 )
			return;
		DrawIncomeLine();	
	}	
}

void CStrategy::OnSelchangeIvdata() 
{
	int ix = m_CMBIVData.GetCurSel();	
	if( ix!=m_nIndexIV )
	{
		m_nIndexIV = ix;

		m_nRetn = PrePaint();
		if( m_nRetn==0 )
			return;
		DrawIncomeLine();
	}
}

void CStrategy::OnRefresh() 
{	
	m_arrITC.RemoveAll();
	StgyHistoryList StgyList;
//	StgyFileExtList ExtList;
	StgyList.RemoveAll();
//	ExtList.RemoveAll();
	for( int i=0;i<m_StgyList.GetSize();i++ )
	{
		StgyHistoryFile file;
	//	StgyFileExt  ext;
		memset(&file,0,sizeof(file));
	//	memset(&ext,0,sizeof(ext));
		int stgyinx;
		if( m_StgyList[i].m_iCustomIx[6]==1 )
			stgyinx = m_StgyList[i].m_iCustomIx[7];
		else
			stgyinx = m_StgyList[i].m_fCapital;
		
		memcpy(&file,&m_StgyList[i],sizeof(file));
	//	memcpy(&ext,&m_ExtList[i],sizeof(ext));
		StgyList.Add(file);
	//	ExtList.Add(ext);
		if( stgyinx==17 || stgyinx==18 )
		{
			file.m_lExpTime = m_ExtList[i].cald.lMonth2;
			StgyList.Add(file);
		//	ExtList.Add(ext);
		}
	}
	for(i=0;i<StgyList.GetSize();i++ )
	{
		BOOL bSend = TRUE;
		for( int j=0;j<i;j++ )
		{
			if( strcmp(StgyList[j].m_szCode,StgyList[i].m_szCode)==0 )
			{
				if( !IsIndex_Ext(StgyList[j].m_szCode) || (IsIndex_Ext(StgyList[j].m_szCode)&&StgyList[j].m_lExpTime==StgyList[i].m_lExpTime) )
					bSend = FALSE;
			}
		}
		if( bSend )
		{
			char code[9] = {0};
			m_TTOptions->GetCashOrFuturesCode(StgyList[i].m_szCode,StgyList[i].m_lExpTime, code);
			ItemToCash itc;
			memcpy(itc.itemcode,StgyList[i].m_szCode,8);
			itc.ldate = StgyList[i].m_lExpTime;
			memcpy(itc.cashcode,code,8);
			m_arrITC.Add(itc);
			m_TTOptions->SendTeleHisCash(code);
		}
	}

	if( m_bOrder )
		UpdateYK();

	m_nRetn = PrePaint();
	SetListMode();
	SelectType();
	if( m_nRetn==0 )
		return;
	RECT frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);
	if( !m_bUseRecord )
	{
		for( int i=0;i<6;i++ )
		{
			m_bAlterPrice[i] = FALSE;
			m_bAlterPrice2[i] = FALSE;
		}
	}
	for( int j=0;j<3;j++ )
	{
		m_bResetBF[j] = TRUE;	
	}
//	m_bReLoadList2Data = TRUE;
	if( m_bMode!=1 )
	{
		DrawIncomeLine();
	}
	else
		InvalidateRect(&frmrect);
}

void CStrategy::OnSelchangeCmbtime() 
{
	int ix = m_CMBTime.GetCurSel();
	switch(ix)
	{
	case 0:
		m_iSeconds = -1;
		KillTimer(2333);
		break;
	case 1:
		m_iSeconds = 5;
		KillTimer(2333);
		SetTimer(2333, 5*1000, NULL);
		break;
	case 2:
		m_iSeconds = 10;
		KillTimer(2333);
		SetTimer(2333, 10*1000, NULL);
		break;
	case 3:
		m_iSeconds = 15;
		KillTimer(2333);
		SetTimer(2333, 15*1000, NULL);
		break;
	case 4:
		m_iSeconds = 20;
		KillTimer(2333);
		SetTimer(2333, 20*1000, NULL);
		break;
	case 5:
		m_iSeconds = 30;
		KillTimer(2333);
		SetTimer(2333, 30*1000, NULL);
		break;
	}
}

void CStrategy::OnTimer(UINT nIDEvent) 
{
	if( nIDEvent==1333 )
	{
		PrePaint();
		DrawIncomeLine();
		KillTimer(1333);
	}
	if( nIDEvent==3333 )
	{
		UpdateYK();
		KillTimer(3333);
	}
	if( nIDEvent==2333 )
	{
		m_arrITC.RemoveAll();
		StgyHistoryList StgyList;
	//	StgyFileExtList ExtList;
		StgyList.RemoveAll();
	//	ExtList.RemoveAll();
		for( int i=0;i<m_StgyList.GetSize();i++ )
		{
			StgyHistoryFile file;
		//	StgyFileExt  ext;
			memset(&file,0,sizeof(file));
	//		memset(&ext,0,sizeof(ext));
			int stgyinx;
			if( m_StgyList[i].m_iCustomIx[6]==1 )
				stgyinx = m_StgyList[i].m_iCustomIx[7];
			else
				stgyinx = m_StgyList[i].m_fCapital;
			
			memcpy(&file,&m_StgyList[i],sizeof(file));
		//	memcpy(&ext,&m_ExtList[i],sizeof(ext));
			StgyList.Add(file);
		//	ExtList.Add(ext);
			if( stgyinx==17 || stgyinx==18 )
			{
				file.m_lExpTime = m_ExtList[i].cald.lMonth2;
				StgyList.Add(file);
		//		ExtList.Add(ext);
			}
		}
		for(i=0;i<StgyList.GetSize();i++ )
		{
			BOOL bSend = TRUE;
			for( int j=0;j<i;j++ )
			{
				if( strcmp(StgyList[j].m_szCode,StgyList[i].m_szCode)==0 )
				{
					if( !IsIndex_Ext(StgyList[j].m_szCode) || (IsIndex_Ext(StgyList[j].m_szCode)&&StgyList[j].m_lExpTime==StgyList[i].m_lExpTime) )
						bSend = FALSE;
				}
			}
			if( bSend )
			{
				char code[9] = {0};
				m_TTOptions->GetCashOrFuturesCode(StgyList[i].m_szCode,StgyList[i].m_lExpTime, code);
				ItemToCash itc;
				memcpy(itc.itemcode,StgyList[i].m_szCode,8);
				itc.ldate = StgyList[i].m_lExpTime;
				memcpy(itc.cashcode,code,8);
				m_arrITC.Add(itc);
				m_TTOptions->SendTeleHisCash(code);
			}
		}

		if( m_bOrder )
			UpdateYK();
		
		m_nRetn = PrePaint();
		SetListMode();
		SelectType();
		
		if( m_nRetn==0 )
			return;
		RECT frmrect;
		m_frame.GetWindowRect(&frmrect);
		ScreenToClient(&frmrect);
		if( !m_bUseRecord )
		{
			for( int i=0;i<6;i++ )
			{
				m_bAlterPrice[i] = FALSE;
				m_bAlterPrice2[i] = FALSE;
			}
		}
		for( int j=0;j<3;j++ )
		{
			m_bResetBF[j] = TRUE;	
		}
		
		if( m_bMode!=1 )
			DrawIncomeLine();
		else
			InvalidateRect(&frmrect);
		
	}
	CDialog::OnTimer(nIDEvent);
}

void CStrategy::OnModeStgy()
{
	/*m_bOrder = FALSE;
	m_tab1.SetCurSel(0);
	MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top);
	m_ComBoxStrike.EnableWindow(TRUE);
	m_ComBoxStrike2.EnableWindow(TRUE);
	m_ComBoxStrike3.EnableWindow(TRUE);
	m_ComBoxStrike4.EnableWindow(TRUE);
	m_btnJianc.EnableWindow(TRUE);
	m_ComBoxType.EnableWindow(TRUE);*/

	if( m_nIndex==STGY_CUSTOM )
	{
		MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top+33);
		m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top+33,m_RectLst2.Width(),m_RectLst2.Height());
		m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top+33,m_RectEd2.Width(),m_RectEd2.Height());
		m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top+33,m_RectEd3.Width(),m_RectEd3.Height());
		m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height()+33);
		m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height()+33);
		AdjustWindowH_Order();
	}
	m_edit.ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode0[m_TTOptions->m_iLangType]);
		GetDlgItem(IDC_STATIC1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_SHOW);
		if( m_nIndex==6 )
			m_ComBoxStrike4.ShowWindow(SW_SHOW);
		if( m_nIndex==6 ||m_nIndex==0 ||m_nIndex==1 )
			m_ComBoxStrike3.ShowWindow(SW_SHOW);
		m_ComBoxStrike2.ShowWindow(SW_SHOW);
		m_ComBoxStrike.ShowWindow(SW_SHOW);
		m_ComBoxType.ShowWindow(SW_SHOW);
		m_list.ShowWindow(SW_SHOW);
		m_staDay1.ShowWindow(SW_SHOW);
		m_staDay2.ShowWindow(SW_SHOW);
		m_staDay3.ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SPIN1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SPIN2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SPIN3)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SPIN4)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SPIN5)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SPIN6)->ShowWindow(SW_SHOW);
		m_editIV1.ShowWindow(SW_SHOW);
		m_editIV2.ShowWindow(SW_SHOW);
		m_editIV3.ShowWindow(SW_SHOW);
		m_SelBox.ShowWindow(SW_SHOW);
		GetDlgItem(IDC_CHECK1)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_CHECK2)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_CHECK3)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EXP)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BF)->ShowWindow(SW_SHOW);
		m_tab1.ShowWindow(SW_SHOW);
		m_BtnL.ShowWindow(SW_SHOW);
		GetDlgItem(IDC_BTN_MODE)->ShowWindow(SW_SHOW);
		m_BtnR.ShowWindow(SW_SHOW);
		if( !m_bUseRecord )
			SwitchCtrl();
		if( !m_bUseRecord && m_bMode==0 )
		{
			if( !m_bHaveCrt_Spin )
			{
				CreateBtn();
				CreateSpin(&m_list,m_pSpin,2,2,m_bHaveCrt_Spin);
				if( m_nIndex==STGY_CUSTOM )
				{
					for( int j=0;j<5;j++ )
						CreateSpin(&m_list,m_pSpinEx[j],j+3,2,m_bHaveCrt_Spin);
				}
			}
		}
		{
			m_frame.MoveWindow(m_frmrect.left,m_frmrect.top,m_frmrect.Width(),m_frmrect.Height());
			m_CMBTime.MoveWindow(m_rect1.left,m_rect1.top,m_rect1.Width(),m_rect1.Height());
			m_btnRefresh.MoveWindow(m_rect2.left,m_rect2.top,m_rect2.Width(),m_rect2.Height());
		}
}

void CStrategy::OnModePain()
{
	m_bOrder = FALSE;
	m_tab1.SetCurSel(0);
	MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top);

	int nPreX;
	RECT frmrect,winrect;
	GetWindowRect(&winrect);
	ScreenToClient(&winrect);
	
		if( m_bHaveCrt_Spin )
		{
			DestroySpin(m_pSpin,m_bHaveCrt_Spin);
			m_pBtn->DestroyWindow();
			if( m_nIndex==STGY_CUSTOM )
			{
				for( int j=0;j<5;j++ )
					DestroySpin(m_pSpinEx[j],m_bHaveCrt_Spin);
			}
		}
		
		m_edit.ShowWindow(SW_HIDE);
		m_btnJianc.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode1[m_TTOptions->m_iLangType]);
		GetDlgItem(IDC_STATIC1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC6)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC7)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC8)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC9)->ShowWindow(SW_HIDE);
		m_staSize.ShowWindow(SW_HIDE);
		m_ComBoxStrike4.ShowWindow(SW_HIDE);
		m_ComBoxStrike3.ShowWindow(SW_HIDE);
		m_ComBoxStrike2.ShowWindow(SW_HIDE);
		m_CrlStatic4.ShowWindow(SW_HIDE);
		m_CrlStatic3.ShowWindow(SW_HIDE);
		m_CrlStatic2.ShowWindow(SW_HIDE);
		m_CrlStatic1.ShowWindow(SW_HIDE);
		m_ComBoxStrike.ShowWindow(SW_HIDE);
		m_ComBoxType.ShowWindow(SW_HIDE);
		m_SelBox.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_CHECK3)->ShowWindow(SW_HIDE);
		m_tab1.ShowWindow(SW_HIDE);
		m_BtnL.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BTN_MODE)->ShowWindow(SW_HIDE);
		m_BtnR.ShowWindow(SW_HIDE);
		m_frame.MoveWindow(winrect.left+10,m_frmrect.top,m_frmrect.right-winrect.left-10,m_frmrect.bottom-m_frmrect.top+155);

		nPreX = winrect.left+20;
		m_btnRefresh.MoveWindow(nPreX,winrect.bottom-10-m_rect2.Height(),m_rect2.Width(),m_rect2.Height());

		nPreX = nPreX + m_rect2.Width() + 10;
		m_CMBTime.MoveWindow(nPreX,winrect.bottom-10-m_rect1.Height(),m_rect1.Width(),m_rect1.Height());
		m_list.ShowWindow(SW_HIDE);
		m_staDay1.ShowWindow(SW_HIDE);
		m_staDay2.ShowWindow(SW_HIDE);
		m_staDay3.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SPIN1)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SPIN2)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SPIN3)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SPIN4)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SPIN5)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SPIN6)->ShowWindow(SW_HIDE);
		m_editIV1.ShowWindow(SW_HIDE);
		m_editIV2.ShowWindow(SW_HIDE);
		m_editIV3.ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EXP)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_BF)->ShowWindow(SW_HIDE);
	
}

void CStrategy::OnBtnLR()
{

	if( m_bMode==0 )
	{
		if( m_nIndex==16 )
		{
			CreateSpin(&m_list,m_pSpin_C,2,1,m_bHaveCrt_Spin_C);
		}
		else if( m_nIndex==STGY_CUSTOM )
		{
			for( int z=0;z<5;z++ )
			{
				if( m_nCustomIx[z]==4 && !m_bHaveCrt_Spin_C )
				{
					CreateSpin(&m_list,m_pSpin_C,2+z,1,m_bHaveCrt_Spin_C);
				}
			}	
		}
	}
	else
	{
		if( m_bHaveCrt_Spin_C )
			DestroySpin(m_pSpin_C,m_bHaveCrt_Spin_C);
	}

	if( m_bMode==0 )
	{
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode0[m_TTOptions->m_iLangType]);
		SetListMode();
		if( !m_bUseRecord )
		{
			CreateBtn();
			CreateSpin(&m_list,m_pSpin,2,2,m_bHaveCrt_Spin);
			if( m_nIndex==STGY_CUSTOM )
			{
				for( int j=0;j<5;j++ )
					CreateSpin(&m_list,m_pSpinEx[j],j+3,2,m_bHaveCrt_Spin);
			}
		}

		if( m_nIndex>=15 )
			SelectType();
		if( m_nIndex==STGY_CUSTOM )
		{
			if( m_bOrder )
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top+33);
			}
			else
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top+33);
			}
			m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top+33,m_RectLst2.Width(),m_RectLst2.Height());
			m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top+33,m_RectEd2.Width(),m_RectEd2.Height());
			m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top+33,m_RectEd3.Width(),m_RectEd3.Height());
			m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height()+33);
			m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height()+33);
			AdjustWindowH_Order();
		}
		else
		{
			if( m_bOrder )
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top);
			}
			else
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top);
			}
			m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top,m_RectEd2.Width(),m_RectEd2.Height());
			m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top,m_RectEd3.Width(),m_RectEd3.Height());
			m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top,m_RectLst2.Width(),m_RectLst2.Height());
			m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height());
			m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height());
			AdjustWindowH_Order();
		}
	}
	else if( m_bMode==2 )
	{

		if( m_bHaveCrt_Spin )
		{
			DestroySpin(m_pSpin,m_bHaveCrt_Spin);
			m_pBtn->DestroyWindow();
			if( m_nIndex==STGY_CUSTOM )
			{
				for( int j=0;j<5;j++ )
					DestroySpin(m_pSpinEx[j],m_bHaveCrt_Spin);
			}
		}
		
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode2[m_TTOptions->m_iLangType]);
		SetListMode();

		
		if( m_bOrder )
		{
			//if( m_nIndex==17 )
			//	MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top-16);
			//else
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top+16);
		}
		else
		{
			//if( m_nIndex==17 )
			//	MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top-16);
			//else
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top+16);
		}
		if( m_nIndex==STGY_CUSTOM&&m_bTempMode==0 )
		{
			m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top+16,m_RectEd2.Width(),m_RectEd2.Height());
			m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top+16,m_RectEd3.Width(),m_RectEd3.Height());
			m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top+16,m_RectLst2.Width(),m_RectLst2.Height());
		}
		else
		{
			m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top+16,m_RectLst2.Width(),m_RectLst2.Height());
			m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top+16,m_RectEd2.Width(),m_RectEd2.Height());
			m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top+16,m_RectEd3.Width(),m_RectEd3.Height());
		}
		m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height()+16);
		m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height()+16);
		AdjustWindowH_Order();
		
	}
	else if( m_bMode==3 )
	{
		if( m_bHaveCrt_Spin )
		{
			DestroySpin(m_pSpin,m_bHaveCrt_Spin);
			m_pBtn->DestroyWindow();
			if( m_nIndex==STGY_CUSTOM )
			{
				for( int j=0;j<5;j++ )
					DestroySpin(m_pSpinEx[j],m_bHaveCrt_Spin);
			}
		}
		
		GetDlgItem(IDC_BTN_MODE)->SetWindowText("Greeks");
		SetListMode();

		if( m_bOrder )
		{
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top);
		}
		else
		{
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top);
		}
		m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top,m_RectEd2.Width(),m_RectEd2.Height());
		m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top,m_RectEd3.Width(),m_RectEd3.Height());
		m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top,m_RectLst2.Width(),m_RectLst2.Height());
		m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height());
		m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height());
		AdjustWindowH_Order();
	}
	else if( m_bMode==4 )
	{
		if( m_bHaveCrt_Spin )
		{
			DestroySpin(m_pSpin,m_bHaveCrt_Spin);
			m_pBtn->DestroyWindow();
			if( m_nIndex==STGY_CUSTOM )
			{
				for( int j=0;j<5;j++ )
					DestroySpin(m_pSpinEx[j],m_bHaveCrt_Spin);
			}
		}
		
		GetDlgItem(IDC_BTN_MODE)->SetWindowText(szMode3[m_TTOptions->m_iLangType]);
		SetListMode();

		if( m_bOrder )
		{
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top);
		}
		else
		{
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top);
		}
		m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top,m_RectEd2.Width(),m_RectEd2.Height());
		m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top,m_RectEd3.Width(),m_RectEd3.Height());
		m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top,m_RectLst2.Width(),m_RectLst2.Height());
		m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height());
		m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height());
		AdjustWindowH_Order();
	}

	m_bFillList = FALSE;
	SetTimer(1333,200,NULL);
	SufPaint();
	
	/*m_nRetn = PrePaint();
	SelectType();
	if( m_nRetn==0 )
		return;
	if( m_bMode!=1 )
	{
		DrawIncomeLine();
	}*/
	
}

void CStrategy::OnBtnMode() 
{
	
}

void CStrategy::OnSelchangeComboStrike4() 
{
	int i;
	int ix = m_ComBoxStrike4.GetCurSel();
/*	CString str;
	float fstk,fstk1,fstk2,fstk3,fstk4;
	m_ComBoxStrike4.GetLBText(ix, str);
	fstk = atof(str);
	m_ComBoxStrike.GetLBText(m_nIxStrike, str);
	fstk1 = atof(str);
	m_ComBoxStrike2.GetLBText(m_nIxStrike2, str);
	fstk2 = atof(str);
	m_ComBoxStrike3.GetLBText(m_nIxStrike3, str);
	fstk3 = atof(str);
	m_ComBoxStrike4.GetLBText(m_nIxStrike4, str);
	fstk4 = atof(str);
	float flo = 0;
	int iRow = m_TTOptions->FindRow(fstk);*/
	if( ix!=m_nIx4 )
	{
	
		/*flo = m_TTOptions->m_pDataBuf[iRow].m_fCalls_Nominal;//m_fCalls_Ask;

		if( flo==0 )
		{
			MessageBox(szStkTip2[m_TTOptions->m_iLangType], "Tips",MB_OK);
			m_ComBoxStrike4.SetCurSel(m_nIxStrike4);
			return ;
		}*/

		m_bAlterPrice[3] = FALSE;
		m_bAlterPrice2[3] = FALSE;
		m_nIx4  = ix;
		return;
//��Ϊ���ĸ���ʹ��ֻ��IronCondor�У����Բ����жϷ���

	}
}

BOOL CStrategy::PreTranslateMessage(MSG* pMsg) 
{
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CStrategy::OnDestroy() 
{
	
	CDialog::OnDestroy();

	m_brush.DeleteObject();
	m_brush1.DeleteObject();
	ReleaseDC(&MemDC);
	ReleaseDC(pdc);
	MemBitmap.DeleteObject();
	m_font1.DeleteObject();
	m_font2.DeleteObject();
	m_font3.DeleteObject();
	m_font4.DeleteObject();
	m_font5.DeleteObject();
	m_font6.DeleteObject();
	m_bsh1.DeleteObject();
	m_bsh2.DeleteObject();
	m_bsh3.DeleteObject();
	m_bsh4.DeleteObject();
	m_bsh5.DeleteObject();
	if( m_pBtn!=NULL )
	{
		delete m_pBtn;
		m_pBtn = NULL;
	}
	if( m_editCrt!=NULL )
	{
		delete m_editCrt;
		m_editCrt = NULL;
	}
	if( m_pSpin!=NULL )
	{
		delete m_pSpin;
		m_pSpin = NULL;
	}
	if( m_pSpin_C!=NULL )
	{
		delete m_pSpin_C;
		m_pSpin_C = NULL;
	}
	for( int i=0;i<5;i++ )
	{
		if( m_pSpinEx[i]!=NULL )
		{
			delete m_pSpinEx[i];
			m_pSpinEx[i] = NULL;
		}
	}
	if( m_pCombo!=NULL )
	{
		delete m_pCombo;
		m_pCombo = NULL;
	}

	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}

	DeleteCriticalSection(&m_cs);
	
	for( i=0;i<m_StgyList.GetSize();i++ )
	{
		long lTransdate = m_StgyList[i].m_lExpTime/100;
		if( m_ExtList[i].b_weekly==1 )
			lTransdate = m_StgyList[i].m_lExpTime;
		m_TTOptions->SendUpdateRP(FALSE,m_StgyList[i].m_szCode,lTransdate);
		if( m_ExtList[i].cald.lMonth2!=0 )
		{
			long lm = m_ExtList[i].cald.lMonth2;
			if( m_ExtList[i].b_Mth2_Weekly==0 )
				lm = lm/100;
			m_TTOptions->SendUpdateRP(FALSE,m_StgyList[i].m_szCode,lm);
		}
	}
	delete m_TTOptions->m_pwndCls;
	m_TTOptions->m_pwndCls = NULL;
	m_TTOptions->m_bStgyMode = -1;

	if( g_pDlg!=NULL )
	{
		//delete g_pDlg;
		g_pDlg = NULL;
	}

}

void CStrategy::OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	CString str;
	if(pNMUpDown->iDelta<0)                    
    {
		if( m_nDay1==m_iExpDays )
		{
			*pResult = 0;
			return;
		}
		m_nDay1++;
		str.Format("%d",m_nDay1);
		m_staDay1.SetWindowText(str);

		if( m_iCheck[0]==0 )
		{
			*pResult = 0;
			return;
		}
		
		m_nRetn = PrePaint();
		//SelectType();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
    }
    else if(pNMUpDown->iDelta >0)    
    {
		if( m_nDay1==0 )
		{
			*pResult = 0;
			return;
		}
        m_nDay1--;
		str.Format("%d",m_nDay1);
		m_staDay1.SetWindowText(str);
		
		if( m_iCheck[0]==0 )
		{
			*pResult = 0;
			return;
		}
		
		m_nRetn = PrePaint();
		//SelectType();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
    }
	
	*pResult = 0;
}

void CStrategy::OnDeltaposSpin2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	CString str;
	if(pNMUpDown->iDelta<0)                    
    {
		if( m_nDay2==m_iExpDays )
		{
			*pResult = 0;
			return;
		}
		m_nDay2++;
		str.Format("%d",m_nDay2);
		m_staDay2.SetWindowText(str);

		if( m_iCheck[1]==0 )
		{
			*pResult = 0;
			return;
		}

		m_nRetn = PrePaint();
		//SelectType();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
    }
    else if(pNMUpDown->iDelta >0)    
    {
		if( m_nDay2==0 )
		{
			*pResult = 0;
			return;
		}
        m_nDay2--;
		str.Format("%d",m_nDay2);
		m_staDay2.SetWindowText(str);

		if( m_iCheck[1]==0 )
		{
			*pResult = 0;
			return;
		}

		m_nRetn = PrePaint();
		//SelectType();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
    }

	*pResult = 0;
}

void CStrategy::OnDeltaposSpin3(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	
	CString str;
	if(pNMUpDown->iDelta<0)                    
    {
		if( m_nDay3==m_iExpDays )
		{
			*pResult = 0;
			return;
		}
		m_nDay3++;
		str.Format("%d",m_nDay3);
		m_staDay3.SetWindowText(str);

		if( m_iCheck[2]==0 )
		{
			*pResult = 0;
			return;
		}

		m_nRetn = PrePaint();
		//SelectType();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
    }
    else if(pNMUpDown->iDelta >0)    
    {
		if( m_nDay3==0 )
		{
			*pResult = 0;
			return;
		}
        m_nDay3--;
		str.Format("%d",m_nDay3);
		m_staDay3.SetWindowText(str);

		if( m_iCheck[2]==0 )
		{
			*pResult = 0;
			return;
		}

		m_nRetn = PrePaint();
		//SelectType();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
    }

	*pResult = 0;
}

void CStrategy::OnMouseMove(UINT nFlags, CPoint point) 
{
	if( m_bMode==1 )
		return;
	CRect frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);	
	int nCount = m_arrPL[0].GetSize();
	CRect rct(frmrect.left,frmrect.top+35,frmrect.right,frmrect.bottom-40);
	if( rct.PtInRect(point) && m_nRetn==1 && nCount!=0 && m_bDrawing==FALSE )
	{
		if( (m_bSelectLo || m_bSelectUp) && m_btMouseGet==1 && m_btMouseRelease==0 )
		{
			m_hCursor = LoadCursor(NULL,IDC_CROSS);
		}
		else
			m_hCursor = LoadCursor(NULL,IDC_ARROW);
		m_point = point;
		m_bPainted = FALSE;
		DrawIncomeLine();
	}

	int x1 = frmrect.right-80+2+12;
	int y1 = frmrect.bottom-16-12+10;
	int x2 = frmrect.right-56+2+12+10;
	int y2 = frmrect.bottom-16-12+10;;
	int r = 12;
	if( (pow(point.x-x1,2)+pow(point.y-y1,2))<=r*r )
	{
		m_hCursor = LoadCursor( NULL , IDC_HAND ) ;
	}
	else if( (pow(point.x-x2,2)+pow(point.y-y2,2))<=r*r )
	{
		m_hCursor = LoadCursor( NULL , IDC_HAND ) ;
	}
	else if( !m_bSelectLo && !m_bSelectUp )
	{
		m_hCursor = LoadCursor( NULL , IDC_ARROW ) ;
	}
	
	CDialog::OnMouseMove(nFlags, point);
}

void CStrategy::OnBtnR() 
{
	switch( m_bMode )
	{
	case 0:
		m_bTempMode = 0;
		m_bMode = 2;
		break;
	case 2:
		m_bTempMode = 2;
		m_bMode = 3;
		break;
	case 3:
		m_bTempMode = 3;
		m_bMode = 4;
		break;
	case 4:
		m_bTempMode = 4;
		m_bMode = 0;
		break;
	}
	OnBtnLR();
}

void CStrategy::OnBtnL() 
{
	switch( m_bMode )
	{
	case 0:
		m_bTempMode = 0;
		m_bMode = 4;
		break;
	case 2:
		m_bTempMode = 2;
		m_bMode = 0;
		break;
	case 3:
		m_bTempMode = 3;
		m_bMode = 2;
		break;
	case 4:
		m_bTempMode = 4;
		m_bMode = 3;
	}
	OnBtnLR();
}

void CStrategy::OnCheck1() 
{	
	m_iCheck[0] = m_ck1.GetCheck();
	if( m_ck1.GetCheck() )
		m_nCkCount += 1;
	else
		m_nCkCount -= 1;
	m_nRetn = PrePaint();
	//SelectType();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnCheck2() 
{
	m_iCheck[1] = m_ck2.GetCheck();
	if( m_ck2.GetCheck() )
		m_nCkCount += 1;
	else
		m_nCkCount -= 1;
	m_nRetn = PrePaint();
	//SelectType();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnCheck3() 
{
	m_iCheck[2] = m_ck3.GetCheck();
	if( m_ck3.GetCheck() )
		m_nCkCount += 1;
	else
		m_nCkCount -= 1;
	m_nRetn = PrePaint();
	//SelectType();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnPl() 
{	
	m_nIndexIV = 0;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnDe() 
{
	m_nIndexIV = 1;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnVe() 
{
	m_nIndexIV = 2;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnGa() 
{
	m_nIndexIV = 3;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnTh() 
{
	m_nIndexIV = 4;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnBtnSave()
{}

void CStrategy::OnCb() 
{
	m_nIndexIV = 5;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnCa() 
{
	m_nIndexIV = 6;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnPb() 
{
	m_nIndexIV = 7;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnPa() 
{
	m_nIndexIV = 8;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnCl() 
{	
	m_nIndexIV = 9;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnPla() 
{
	m_nIndexIV = 10;
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	DrawIncomeLine();
}

void CStrategy::OnRButtonUp(UINT nFlags, CPoint point) 
{
//	if( m_nIndex==17 )
//		return;
	CRect frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);

	if( frmrect.PtInRect(point) && m_bMode!=1 )
	{
		CMenu   menu;   
		menu.LoadMenu(IDR_MENU1); 
		CMenu   *pContextMenu=menu.GetSubMenu(0); 
		CPoint point1;//����һ������ȷ�����λ�õ�λ��  
		GetCursorPos(&point1);//��ȡ��ǰ����λ�ã��Ա�ʹ�ò˵����Ը�����
		if( strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex() )
		{
			for( int i=1;i<=5;i++ )
				pContextMenu->EnableMenuItem(i, MF_DISABLED | MF_BYPOSITION );
		}
		if( m_bTarget==1 )
			pContextMenu->CheckMenuItem(ID_TARGET,MF_CHECKED|MF_BYCOMMAND);
		else
			pContextMenu->CheckMenuItem(ID_TARGET,MF_UNCHECKED|MF_BYCOMMAND);
		if( m_bUseRecord )
			pContextMenu->EnableMenuItem(ID_TARGET,MF_DISABLED|MF_GRAYED);
		pContextMenu->TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON,point1.x,point1.y,this);
	}

	CDialog::OnRButtonUp(nFlags, point);
}

void CStrategy::OnDeltaposSpin4(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	
	CString str;
	if(pNMUpDown->iDelta<0)                    
    {
		m_editIV1.GetWindowText(str);
		str.Format("%.1f",atof(str)+0.1);
		m_editIV1.SetWindowText(str);
		m_nRetn = PrePaint();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
	}
	else if(pNMUpDown->iDelta>0)                    
    {
		m_editIV1.GetWindowText(str);
		if( atof(str)==0.0 )
		{
			*pResult = 0;
			return;
		}
		str.Format("%.1f",atof(str)-0.1);
		m_editIV1.SetWindowText(str);
		m_nRetn = PrePaint();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
	}

	*pResult = 0;
}

void CStrategy::OnDeltaposSpin5(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	CString str;
	if(pNMUpDown->iDelta<0)                    
    {
		m_editIV2.GetWindowText(str);
		str.Format("%.1f",atof(str)+0.1);
		m_editIV2.SetWindowText(str);
		m_nRetn = PrePaint();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
	}
	else if(pNMUpDown->iDelta>0)                    
    {
		m_editIV2.GetWindowText(str);
		if( atof(str)==0.0 )
		{
			*pResult = 0;
			return;
		}
		str.Format("%.1f",atof(str)-0.1);
		m_editIV2.SetWindowText(str);
		m_nRetn = PrePaint();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
	}
	*pResult = 0;
}

void CStrategy::OnDeltaposSpin6(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	CString str;
	if(pNMUpDown->iDelta<0)                    
    {
		m_editIV3.GetWindowText(str);
		str.Format("%.1f",atof(str)+0.1);
		m_editIV3.SetWindowText(str);
		m_nRetn = PrePaint();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
	}
	else if(pNMUpDown->iDelta>0)                    
    {
		m_editIV3.GetWindowText(str);
		if( atof(str)==0.0 )
		{
			*pResult = 0;
			return;
		}
		str.Format("%.1f",atof(str)-0.1);
		m_editIV3.SetWindowText(str);
		m_nRetn = PrePaint();
		if( m_nRetn==0 )
		{
			*pResult = 0;
			return;
		}
		DrawIncomeLine();
	}
	*pResult = 0;
}

void CStrategy::InitTargetRange()
{
	double e = 2.718281;
	double prob1 = 0.0, prob2 = 0.0;
	double pl = 0.0,pu = 0.0,px1 = 0.0,px2 = 0.0;
	double YK = 0.0,IV = 0.0;
	double d = -3.0;
	int i = 0,total = 128*6,j;
	double interval = 1.0/128.0;
	CString str;
	m_editIV1.GetWindowText(str);
	IV = atof(str)/100.0;
	IV = IV*sqrt(m_TTOptions->m_lExpiryDays/252.0);
	double fCash = m_TTOptions->GetCorrStockPrice(FALSE);
	float x1,x2,y1,y2;
	
	total = 128*2;
	m_fTargetLo = fCash*pow(pow(e,IV),-1);
	m_fTargetUp = fCash*pow(pow(e,IV),1);
}

void CStrategy::UpdateYK()
{
	CCDArray tempCD;
	tempCD.RemoveAll();
	EnterCriticalSection(&m_cs);
	tempCD.Copy(m_TTOptions->m_arrCD);
	LeaveCriticalSection( &m_cs );

	CStringArray strArry;
	CString strForm;
	
	StgyHistoryFile stgyfile;
	StgyFileExt     extfile;
	int i;
	float fTotal = 0.0;

	for( i=0;i<m_StgyList.GetSize();i++ )
	{
		memset(&stgyfile,0,sizeof(stgyfile));
		memset(&extfile,0,sizeof(extfile));
		stgyfile = m_StgyList[i];
		memcpy(&extfile,&m_ExtList[i],sizeof(extfile));

		int nPos = -1;
		m_iYK = 0.0;
		for( int m=0;m<tempCD.GetSize();m++ )
		{
			CodeDate codedate;
			codedate = tempCD[m];
			if( memcmp(codedate.szCode,stgyfile.m_szCode,8)==0 &&
				( (extfile.b_weekly==0&&codedate.lDate==stgyfile.m_lExpTime/100)||(extfile.b_weekly==1&&codedate.lDate==stgyfile.m_lExpTime) ) )
			{
				nPos = m;
				break;
			}
		}
		
		if( nPos!=-1 )
		{
			BOOL bPrice = m_arrNum[i].bPrice;
			bPrice = PairString(stgyfile,extfile.cald,strArry,nPos,extfile.b_Mth2_Weekly);
			strForm.Format("%.0f",m_iYK);
			if( !m_TTOptions->HaveFutures(stgyfile.m_szCode,stgyfile.m_lExpTime) )
			{
				strForm = "";
				m_iYK = 0;
			}
			m_list2.SetItemText(m_arrNum[i].nItem,10,strForm);
			m_arrNum[i].bPrice = bPrice;
		}

		CString strYK;
		strYK = m_list2.GetItemText(m_arrNum[i].nItem,10);
		fTotal += atof(strYK);
	}

	strForm.Format("%.0f", fTotal);
	strForm = szPLTotal[m_TTOptions->m_iLangType] + strForm;
	m_edit3.SetWindowText(strForm);
}

float CStrategy::GetMonthPrice(long lDate)
{
	float fPrice = 0.0;
	char code[9] = {0};
	m_TTOptions->GetCashOrFuturesCode(m_TTOptions->m_szItemCode,lDate, code);

	CCashArray arrCash;
	arrCash.RemoveAll();
	EnterCriticalSection(&m_cs);
	arrCash.Copy(m_TTOptions->m_arrCash);
	LeaveCriticalSection( &m_cs );

	for( int k=0;k<arrCash.GetSize();k++ )
	{
		if( memcmp(arrCash[k].szCode,code,8)==0 )
		{	
			fPrice = arrCash[k].fCash;
			break;
		}
	}
	return fPrice;
}

void CStrategy::AdjustWindowH_Order()
{
	CRect winrect,lstrect;
	GetWindowRect(winrect);
	m_list2.GetWindowRect(lstrect);
	ScreenToClient(&lstrect);
	int heigh= GetSystemMetrics(SM_CYFULLSCREEN);
	if( winrect.Height()>heigh )
	{
		MoveWindow(winrect.left,winrect.top,winrect.Width(),heigh);
		m_list2.MoveWindow(lstrect.left,lstrect.top,lstrect.Width(),lstrect.Height()-winrect.Height()+heigh);
	}
}

void CStrategy::AdjustColumnWidth()
{
	int iDefColumnWidth[12] = {120,120,50,80,60,60,60,75,55,65,65,65};
	if( m_nIndex>=16 )
		iDefColumnWidth[1] = 130;

	int i,j,iLen,iLenOld,iTotalLen = 0;
	int temp = 120+120+50+80+60+60+60+75+55+65+65+65;
	for( i=0;i<12;i++ )
	{
		iLenOld = 0;
		for( j=0;j<m_nRow+5;j++ )
		{
			CString str = m_list.GetItemText(j,i);
			iLen = m_list.GetStringWidth(str);
			if( iLen>iLenOld )
			{
				iLenOld = iLen;
			}
		}
		if( iLenOld>0 )
		{
			iLenOld = iLenOld+12;
			if( m_nIndex>=16 && i==1 )
				iLenOld += 15;
			if( i==2 )
				iLenOld += 10;
			iDefColumnWidth[i] = iLenOld;
		}
		iTotalLen += iDefColumnWidth[i];
	}
	if( iTotalLen<temp )
	{
		int iRng = (temp-iTotalLen)/12;
		int iLast = (temp-iTotalLen)%12;
		for( i=0;i<12;i++ )
		{
			iDefColumnWidth[i] += iRng;
		}
		iDefColumnWidth[11] += iLast;
	}
	for( i=0;i<12;i++ )
	{
		m_list.SetColumnWidth(i,iDefColumnWidth[i]);
	}
}

void CStrategy::CreateBtn()
{
	CRect rect;
	m_pBtn->Create( "Save", WS_CHILD|WS_VISIBLE, rect, this, MACRO_Btn_Save_ID ) ;
	m_pBtn->SetFont(this->GetFont(),FALSE);
	m_pBtn->SetParent(&m_list);
	CRect  BtnRect;
	m_list.GetSubItemRect(2, 0, LVIR_LABEL, BtnRect);
	//BtnRect.SetRect(BtnRect.left+5/*0.15*BtnRect.Width()*/, BtnRect.top+1, BtnRect.left + 55/*0.65*BtnRect.Width()*/, BtnRect.bottom-1);
	BtnRect.SetRect(BtnRect.right-55, BtnRect.top+1, BtnRect.right-5, BtnRect.bottom-1);
	m_pBtn->MoveWindow(&BtnRect);
	m_pBtn->ShowWindow(SW_SHOW);
}

void CStrategy::CreateCombo(NM_LISTVIEW *list,CMyComBo *combo,int &Item,int &SubItem,BOOL &havecreat)
{
	Item = list->iItem;
	SubItem = list->iSubItem;

	if( m_nIndex==STGY_CUSTOM && m_nCustomIx[Item-2]==6 && SubItem==3 ) //�Զ��������û��ѡ����Ȩ������
		return;

	havecreat = TRUE;
    combo->Create(WS_CHILD | WS_VISIBLE |CBS_DROPDOWN |WS_VSCROLL, CRect(0, 0, 0, 0), this, IDC_COMBO_CREATEID);
    combo->SetFont(this->GetFont(), FALSE);
    combo->SetParent(&m_list);
    CRect  EditRect;
    m_list.GetSubItemRect(Item, SubItem, LVIR_LABEL, EditRect);
    EditRect.SetRect(EditRect.left + 1, EditRect.top + 1, EditRect.left + m_list.GetColumnWidth(SubItem) - 1, EditRect.bottom - 1);//+1��-1�����ñ༭�����ڵ�ס�б����е�������
    CString strItem = m_list.GetItemText(Item, SubItem);
    combo->SetWindowText(strItem);
    combo->MoveWindow(&EditRect);
    combo->ShowWindow(SW_SHOW);
}

void CStrategy::DestroyCombo( CListCtrl *list, CMyComBo *combo,BOOL &havecreat )
{
	if( m_ComboSubItem==1 && m_bMode!=1 )
	{
		CString strcount;
		CString strCustom[7];
		strCustom[0] = "Sell Call";
		strCustom[1] = "Buy Call";
		strCustom[2] = "Sell Put";
		strCustom[3] = "Buy Put";
		strCustom[4] = "Sell Stock";
		strCustom[5] = "Buy Stock";
		strCustom[6] = "-- --";
		list->SetItemText(m_ComboItem,m_ComboSubItem,strCustom[m_nCustomIx[m_ComboItem-2]]);
		//���һ������������
		if( m_nCustomIx[m_ComboItem-2]==0 || m_nCustomIx[m_ComboItem-2]==2 || m_nCustomIx[m_ComboItem-2]==4 )
			m_nCustomCount[m_ComboItem-2] = -1*abs(m_nCustomCount[m_ComboItem-2]);
		else
			m_nCustomCount[m_ComboItem-2] = abs(m_nCustomCount[m_ComboItem-2]);
	}
	havecreat = FALSE;
	combo->DestroyWindow();

	if( m_bMode==0 )
	{
		m_nRetn = PrePaint();
		if( m_nRetn==0 )
			return;
		SetListMode();
		SelectType();
		DrawIncomeLine();
	}
}

void CStrategy::CreateSpin( CListCtrl *list, CMySpinCtrl *creatspin, int Item, int SubItem, BOOL &havecreat )
{
	creatspin->Create(WS_BORDER|WS_CHILD|WS_VISIBLE|UDS_ALIGNRIGHT|UDS_ARROWKEYS|UDS_SETBUDDYINT,
			CRect(0,0,0,0),this,MACRO_Btn_Spin_ID);

	havecreat = TRUE;
	creatspin->SetFont(this->GetFont(), FALSE);
	creatspin->SetParent(&m_list);
	CRect  EditRect;
	m_list.GetSubItemRect(Item, SubItem, LVIR_LABEL, EditRect);
	EditRect.SetRect(EditRect.right-16, EditRect.top-1, EditRect.right-1, EditRect.bottom);
	creatspin->MoveWindow(&EditRect);
	creatspin->ShowWindow(SW_SHOW);
}

void CStrategy::DestroySpin( CMySpinCtrl *destoryspin, BOOL &havecreat )
{
	havecreat = FALSE;
	destoryspin->DestroyWindow();
}

void CStrategy::CreateEdt( NM_LISTVIEW  *pEditCtrl, CMyEdit *createdit, int &Item, int &SubItem, BOOL &havecreat)//������Ԫ��༭����
{
	Item = pEditCtrl->iItem;
	SubItem = pEditCtrl->iSubItem;

	if( m_nIndex==STGY_CUSTOM && m_nCustomIx[Item-2]==6 ) //�Զ��������û��ѡ����Ȩ������
		return;

	createdit->Create(ES_AUTOHSCROLL | WS_CHILD | ES_LEFT | ES_WANTRETURN,
		CRect(0, 0, 0, 0), this, IDC_EDIT_CREATEID);
	havecreat = TRUE;
	createdit->SetFont(this->GetFont(), FALSE);
	createdit->SetParent(&m_list);
	CRect  EditRect;
	m_list.GetSubItemRect(Item, SubItem, LVIR_LABEL, EditRect);
	EditRect.SetRect(EditRect.left+1, EditRect.top+1, EditRect.left + m_list.GetColumnWidth(SubItem)-1, EditRect.bottom-1);
	CString strItem = m_list.GetItemText(Item, SubItem);
//	m_szListTxt = strItem;
	createdit->SetWindowText(strItem);//����Ԫ���ַ���ʾ�ڱ༭����
	createdit->MoveWindow(&EditRect);//���༭��λ�÷�����Ӧ��Ԫ����
	createdit->ShowWindow(SW_SHOW);//��ʾ�༭���ڵ�Ԫ������
	createdit->SetFocus();//����Ϊ���� 
	createdit->SetSel(-1);//���ù�����ı������ֵ����
}

void CStrategy::DestroyEdit(CListCtrl *list,CMyEdit* destroyedit, int &Item, int &SubItem, BOOL &havecreat)
{
	CString meditdata = "";
	destroyedit->GetWindowText(meditdata);
	int iFind = meditdata.Find(".");
	if( iFind==0 )
		meditdata.Insert(0,"0");
	else if( iFind==meditdata.GetLength()-1 )
		meditdata.Insert(iFind+1,"0");

	if( meditdata==""||atof(meditdata)==0.0 )
	{
//		meditdata = m_szListTxt;
	}
	else
	{
		iFind = meditdata.Find(".");
		if( iFind!=-1 )
		{
			if( (meditdata.GetLength()-iFind-1)>m_TTOptions->m_cbDecimal && m_TTOptions->m_cbDecimal!=0 )
				meditdata = meditdata.Left(iFind+m_TTOptions->m_cbDecimal+1);
			else if( m_TTOptions->m_cbDecimal==0 )
				meditdata = meditdata.Left(iFind+m_TTOptions->m_cbDecimal);
		}
		float flo = atof(meditdata);
		GetPriceTxt(flo,meditdata,1);
	}

	for( int i=0;i<6;i++ )
	{
		if( Item==i+2 )
		{
			if( SubItem==5 )
			{
				m_fLPrice[i] = atof(meditdata);
				m_bAlterPrice2[i] = TRUE;
			}
			else if( SubItem==4 )
			{
				m_fiSignPrice[i] = atof(meditdata);
				m_bAlterPrice[i] = TRUE;
			}
			break;
		}
	}

	list->SetItemText(Item, SubItem, meditdata);//�����Ӧ��Ԫ���ַ�
	destroyedit->DestroyWindow();//���ٶ����д�����Ҫ�����٣���Ȼ�ᱨ��

	havecreat = FALSE;

	if( SubItem==4 )
		SufPaint();
	else if( SubItem==5 )
	{
		m_nRetn = PrePaint();
		if( m_nRetn==1 )
			DrawIncomeLine();
	}
}

void CStrategy::OnClickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW  *pEditCtrl = (NM_LISTVIEW *)pNMHDR;

	int i;

	int item = pEditCtrl->iItem;
	int subitem = pEditCtrl->iSubItem;
	if( m_bUseRecord )
	{
		*pResult = 0;
		return;
	}
	if( m_bMode==0 )
	{
		if (item==-1 || !(item>1&&item<m_nRow+2&&(subitem==4||subitem==5)))
		{
			if (m_bHaveCrt == TRUE)
			{
				DestroyEdit(&m_list, m_editCrt, m_nItem, m_nSubItem, m_bHaveCrt);
			}
		}
		else if( item>1&&item<m_nRow+2&&(subitem==4||subitem==5 ))
		{
			if (m_bHaveCrt == TRUE)
			{
				DestroyEdit(&m_list, m_editCrt, m_nItem, m_nSubItem, m_bHaveCrt);
				if( m_bHaveCrt==FALSE )
					CreateEdt(pEditCtrl,m_editCrt,m_nItem,m_nSubItem,m_bHaveCrt);
			}
			else
				CreateEdt(pEditCtrl,m_editCrt,m_nItem,m_nSubItem,m_bHaveCrt);
		}
		
		
	/*	if (item==-1 || !(item==2&&subitem==2))
		{
			if (m_bCrtCombo == TRUE)
			{
				DestroyCombo(&m_list, m_pCombo, m_bCrtCombo);
				m_pSpin->ShowWindow(SW_SHOW);
			}
		}
		else */if( (m_nIndex<STGY_CUSTOM&&item==2&&subitem==2) || (m_nIndex==STGY_CUSTOM&&item>1&&item<8&&subitem==2) )
		{
			if( m_nIndex==STGY_CUSTOM )
			{
				if( m_nCustomIx[item-2]==6 )
				{
					*pResult = 0;
					return;
				}
			}

			if (m_bCrtCombo == TRUE)
			{
				DestroyCombo(&m_list, m_pCombo, m_bCrtCombo);
				if( m_nIndex==STGY_CUSTOM&&item>2 )
					m_pSpinEx[item-3]->ShowWindow(SW_SHOW);
				else
					m_pSpin->ShowWindow(SW_SHOW);
				if( m_bCrtCombo==FALSE )
				{
					CreateCombo(pEditCtrl,m_pCombo,m_ComboItem,m_ComboSubItem,m_bCrtCombo);
					if( m_nIndex==STGY_CUSTOM&&item>2 )
						m_pSpinEx[item-3]->ShowWindow(SW_HIDE);
					else
						m_pSpin->ShowWindow(SW_HIDE);
				}
			}
			else
			{
				CreateCombo(pEditCtrl,m_pCombo,m_ComboItem,m_ComboSubItem,m_bCrtCombo);
				if( m_nIndex==STGY_CUSTOM&&item>2 )
					m_pSpinEx[item-3]->ShowWindow(SW_HIDE);
				else
					m_pSpin->ShowWindow(SW_HIDE);
			}
			
			if( !m_bCrtCombo )
			{
				*pResult = 0;
				return;
			}
			CString strShares[5];
			strShares[0] = "10";
			strShares[1] = "20";
			strShares[2] = "30";
			strShares[3] = "50";
			strShares[4] = "100";
			for( i=0;i<5;i++ )
					m_pCombo->AddString(strShares[i]);
			CRect rc;
			m_pCombo->GetDroppedControlRect(&rc);
			m_pCombo->GetParent()->ScreenToClient(&rc);
			rc.bottom += 120;
			m_pCombo->MoveWindow(&rc);
			m_pCombo->ShowDropDown();
		}
		

		if( m_nIndex==15||m_nIndex==16 )
		{
		/*	if (item==-1 || !(item==3&&subitem==3))
			{
				if (m_bCrtCombo == TRUE)
				{
					DestroyCombo(&m_list, m_pCombo, m_bCrtCombo);
				}
			}
			else */if(item==3&&subitem==3)
			{
				if (m_bCrtCombo == TRUE)
				{
					DestroyCombo(&m_list, m_pCombo, m_bCrtCombo);
					if( m_bCrtCombo==FALSE )
						CreateCombo(pEditCtrl,m_pCombo,m_ComboItem,m_ComboSubItem,m_bCrtCombo);
				}
				else
					CreateCombo(pEditCtrl,m_pCombo,m_ComboItem,m_ComboSubItem,m_bCrtCombo);

				if( !m_bCrtCombo )
				{
					*pResult = 0;
					return;
				}
				
				for( i=0;i<m_arrItem.GetSize();i++ )
				{
					CString str;
					GetPriceTxt(m_arrItem[i].m_fStrike,str);
					//if( m_arrItem[i].m_fStrike>m_fLPrice[0] )
					m_pCombo->AddString(str);
				}
				CRect rc;
				m_pCombo->GetDroppedControlRect(&rc);
				m_pCombo->GetParent()->ScreenToClient(&rc);
				rc.bottom += 120;
				m_pCombo->MoveWindow(&rc);
				m_pCombo->ShowDropDown();
			}
		}
		else if( m_nIndex==STGY_CUSTOM )
		{
			CString strCustom[7];
			strCustom[0] = "Sell Call";
			strCustom[1] = "Buy Call";
			strCustom[2] = "Sell Put";
			strCustom[3] = "Buy Put";
			strCustom[4] = "Sell Stock";
			strCustom[5] = "Buy Stock";
			strCustom[6] = "-- --";
		/*	if (item==-1 || !(item>1&&item<m_nRow+2&&(subitem==1||subitem==3)))
			{
				if (m_bCrtCombo == TRUE)
				{
					DestroyCombo(&m_list, m_pCombo, m_bCrtCombo);
				}
			}
			else */if( item>1&&item<m_nRow+2&&subitem==1)
			{
				if (m_bCrtCombo == TRUE)
				{
					DestroyCombo(&m_list, m_pCombo, m_bCrtCombo);
					if( m_bCrtCombo==FALSE )
						CreateCombo(pEditCtrl,m_pCombo,m_ComboItem,m_ComboSubItem,m_bCrtCombo);
				}
				else
					CreateCombo(pEditCtrl,m_pCombo,m_ComboItem,m_ComboSubItem,m_bCrtCombo);

				for( i=0;i<7;i++ )
					m_pCombo->AddString(strCustom[i]);
				CRect rc;
				m_pCombo->GetDroppedControlRect(&rc);
				m_pCombo->GetParent()->ScreenToClient(&rc);
				rc.bottom += 120;
				m_pCombo->MoveWindow(&rc);
				m_pCombo->ShowDropDown();
			}
			else if( item>1&&item<m_nRow+2&&subitem==3)
			{
				if (m_bCrtCombo == TRUE)
				{
					DestroyCombo(&m_list, m_pCombo, m_bCrtCombo);
					if( m_bCrtCombo==FALSE && m_nCustomIx[item-2]!=4 && m_nCustomIx[item-2]!=5 )
						CreateCombo(pEditCtrl,m_pCombo,m_ComboItem,m_ComboSubItem,m_bCrtCombo);
				}
				else
				{
					if( m_nCustomIx[item-2]!=4 && m_nCustomIx[item-2]!=5 )
						CreateCombo(pEditCtrl,m_pCombo,m_ComboItem,m_ComboSubItem,m_bCrtCombo);
				}

				if( !m_bCrtCombo )
				{
					*pResult = 0;
					return;
				}
				for( i=0;i<m_arrItem.GetSize();i++ )
				{
					CString str;
					GetPriceTxt(m_arrItem[i].m_fStrike,str);
					m_pCombo->AddString(str);
				}
				CRect rc;
				m_pCombo->GetDroppedControlRect(&rc);
				m_pCombo->GetParent()->ScreenToClient(&rc);
				rc.bottom += 120;
				m_pCombo->MoveWindow(&rc);
				m_pCombo->ShowDropDown();
			}
		}
	}
	

	*pResult = 0;
}

void CStrategy::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	if( bShow && m_TTOptions->m_bStgyMode==0 )
		SetTimer(1333,200,NULL);	
}

void CStrategy::ReadStgyHistoryFile()
{
	IUnknown* pITTobj = NULL;
	m_TTOptions->m_pSystemObj->QueryInterface( IID_ITTObject,(void * *)&pITTobj );
	CComQIPtr<ITTObject> pIObj( pITTobj );
	if( !pIObj )
		return;

	VARIANT var;
	var.vt = VT_UNKNOWN;
	VARIANT *pVar = &var;
	if(pIObj->GetByID(TTPID_UserName,&pVar) != S_OK)
		return;
	CString strUserName = CString( pVar->bstrVal );

	m_StgyList.RemoveAll();
	m_ExtList.RemoveAll();
	StgyHistoryFile stgyfile;
	StgyFileExt  fileext;

	char fbuff[MAX_PATH];
	sprintf( fbuff, "%susers\\%s\\strategy.dat", m_TTOptions->m_szRootPath,strUserName );
	HANDLE hFile = CreateFile(fbuff,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
		OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		return ;
	}
		
	char fileID[32] = {0};
	DWORD dwTm;
	int nCount;
	int i;
	if(ReadFile(hFile,fileID,32,&dwTm,NULL) !=0)		
	{
		if (memcmp(fileID,STGY_FILEID,strlen(STGY_FILEID))!=0 && memcmp(fileID,STGY_FILEID2,strlen(STGY_FILEID2))!=0)
		{
			CloseHandle(hFile);
			return ;
		}
	}
	if(ReadFile(hFile,&nCount,sizeof(int),&dwTm,NULL) !=0)
	{
		for( i=0;i<nCount;i++ )
		{
			memset(&stgyfile,0,sizeof(stgyfile));
			if(ReadFile(hFile,&stgyfile,sizeof(stgyfile),&dwTm,NULL) !=0)
			{
				m_StgyList.Add(stgyfile);
			}
			if (memcmp(fileID,STGY_FILEID2,strlen(STGY_FILEID2)) == 0)
			{
				if(ReadFile(hFile,&fileext,sizeof(fileext),&dwTm,NULL) !=0)
				{
					m_ExtList.Add(fileext);
				}
			}
		}
	}
	CloseHandle(hFile);

	nCount = m_StgyList.GetSize(); 
	if( nCount==0 )
		return;
	for( i=0;i<m_StgyList.GetSize();i++ )
	{
		int iExpDays;
		long lCurTime;
		CTime tm = CTime::GetCurrentTime();
		CString strForm = tm.Format("%Y%m%d");
		lCurTime = atoi(strForm);
		m_TTOptions->DateDiff(m_StgyList[i].m_lExpTime,lCurTime,iExpDays);

		int stgyix;
		if( m_StgyList[i].m_iCustomIx[6]==1 )
			stgyix = m_StgyList[i].m_iCustomIx[7];
		else
			stgyix = m_StgyList[i].m_fCapital;

		if( iExpDays<0 )
		{
			m_StgyList.RemoveAt(i);
			if (memcmp(fileID,STGY_FILEID2,strlen(STGY_FILEID2)) == 0)
				m_ExtList.RemoveAt(i);
			i = i-1;
			continue;
		}
	}

	if( m_ExtList.GetSize()==0 )
	{
		StgyFileExt fileext;
		memset(&fileext,0,sizeof(fileext));
		for( i=0;i<m_StgyList.GetSize();i++  )
			m_ExtList.Add(fileext);
	}

	if( i!=nCount )
		SaveStgyHistoryFile();

	long lTransdate;
	m_arrITC.RemoveAll();
	StgyHistoryList StgyList;
	StgyFileExtList ExtList;
	StgyList.RemoveAll();
	ExtList.RemoveAll();
	for( i=0;i<m_StgyList.GetSize();i++ )
	{
		///////////Calendar�汾֮ǰ  �Զ����˳������17��������Զ����˳��ĳ�STGY_CUSTOM

		///////////
		StgyHistoryFile file;
		StgyFileExt  ext;
		memset(&file,0,sizeof(file));
		memset(&ext,0,sizeof(ext));
		int stgyinx;
		if( m_StgyList[i].m_iCustomIx[6]==1 )
			stgyinx = m_StgyList[i].m_iCustomIx[7];
		else
			stgyinx = m_StgyList[i].m_fCapital;

		if( stgyinx>=17 && m_ExtList[i].cald.lMonth1==0 )
			m_StgyList[i].m_iCustomIx[7] = STGY_CUSTOM;

		memcpy(&file,&m_StgyList[i],sizeof(file));
		memcpy(&ext,&m_ExtList[i],sizeof(ext));
		StgyList.Add(file);
		ExtList.Add(ext);
		if( stgyinx==17 || stgyinx==18 )
		{
			file.m_lExpTime = m_ExtList[i].cald.lMonth2;
			StgyList.Add(file);
			ExtList.Add(ext);
		}
	}
	for( i=0;i<StgyList.GetSize();i++ )
	{
		BOOL bSend = TRUE;
		BOOL bSend2 = TRUE;
		for( int j=0;j<i;j++ )
		{
			if( strcmp(StgyList[j].m_szCode,StgyList[i].m_szCode)==0 )
			{
				if( StgyList[j].m_lExpTime==StgyList[i].m_lExpTime  && ExtList[j].b_weekly==ExtList[i].b_weekly)
					bSend = FALSE;
			}
			if( strcmp(StgyList[j].m_szCode,StgyList[i].m_szCode)==0 )
			{
				if( !IsIndex_Ext(StgyList[j].m_szCode) || (IsIndex_Ext(StgyList[j].m_szCode)&&StgyList[j].m_lExpTime==StgyList[i].m_lExpTime) )
					bSend2 = FALSE;
			}
		}
		if( bSend )
		{
			lTransdate = StgyList[i].m_lExpTime/100;
			if( ExtList[i].b_weekly==1 )
				lTransdate = StgyList[i].m_lExpTime;
			m_TTOptions->SendUpdateRP(TRUE,StgyList[i].m_szCode,lTransdate);
		}
		if( bSend2 )
		{
			char code[9] = {0};
			m_TTOptions->GetCashOrFuturesCode(StgyList[i].m_szCode,StgyList[i].m_lExpTime, code);
			ItemToCash itc;
			memcpy(itc.itemcode,StgyList[i].m_szCode,8);
			itc.ldate = StgyList[i].m_lExpTime;
			memcpy(itc.cashcode,code,8);
			m_arrITC.Add(itc);
			m_TTOptions->SendTeleHisCash(code);
		}
	}
}

void CStrategy::SaveStgyHistoryFile()
{
	IUnknown* pITTobj = NULL;
	m_TTOptions->m_pSystemObj->QueryInterface( IID_ITTObject,(void * *)&pITTobj );
	CComQIPtr<ITTObject> pIObj( pITTobj );
	if( !pIObj )
		return;

	VARIANT var;
	var.vt = VT_UNKNOWN;
	VARIANT *pVar = &var;
	if(pIObj->GetByID(TTPID_UserName,&pVar) != S_OK)
		return;
	CString strUserName = CString( pVar->bstrVal );

	CFile f;
	CFileException e;
	int i;

	char fbuff[MAX_PATH];
	sprintf( fbuff, "%susers\\%s\\strategy.dat", m_TTOptions->m_szRootPath,strUserName );

	if(!f.Open(fbuff, CFile::modeCreate | CFile::modeWrite, &e))
	{
		return ;
	}
	
	if( m_ExtList.GetSize()==0 )
	{
		StgyFileExt fileext;
		memset(&fileext,0,sizeof(fileext));
		for( i=0;i<m_StgyList.GetSize();i++  )
			m_ExtList.Add(fileext);
	}

	char sz[32] = {0};
	strcpy(sz,STGY_FILEID2);
	f.Write(sz,32);
	int nCount = m_StgyList.GetSize();
	StgyHistoryFile stgyfile;
	StgyFileExt  fileext;
	if( nCount==0 )
	{
		f.Close();
		return;
	}
	f.Write(&nCount,sizeof(int));
	for( i=0;i<nCount;i++ )
	{
		memset(&stgyfile,0,sizeof(stgyfile));
		stgyfile = m_StgyList[i];
		f.Write(&stgyfile,sizeof(stgyfile));
		memset(&fileext,0,sizeof(fileext));
		fileext = m_ExtList[i];
		f.Write(&fileext,sizeof(fileext));
	}
	f.Close();
}

#define MathE	2.7182818284590452354 
// ��Ȼ�����ĵ�

#define MathPI	3.14159
// PI

float CStrategy::ModelPrice_Clad(BOOL bCall,double dStrike, double dMaket, int iExpDay,BYTE bPos)
{
	double MOP;
	double F = dMaket;
	double sd = 0.127;
	CString str;
	if( bPos==0 )
	{
		switch( m_iOdr )
		{
		case 1:
			m_editIV1.GetWindowText(str);
			sd = atof(str)/100.0;
			break;
		case 2:
			m_editIV2.GetWindowText(str);
			sd = atof(str)/100.0;
			break;
		case 3:
			m_editIV3.GetWindowText(str);
			sd = atof(str)/100.0;
			break;
		}
	}
	else
	{
		sd = m_cald_calinfo2.impliedVolitility;
		if( m_iOdr==-1 )
		{
			if( m_ck1.GetCheck() )
			{
				m_editIV1.GetWindowText(str);
				sd += (atof(str)-m_fIVedit*100)/100.0;
			}
			else if( !m_ck1.GetCheck()&&m_ck2.GetCheck() )
			{
				m_editIV2.GetWindowText(str);
				sd += (atof(str)-m_fIVedit*100)/100.0;
			}
			else if( !m_ck1.GetCheck()&&!m_ck2.GetCheck()&&m_ck3.GetCheck )
			{
				m_editIV3.GetWindowText(str);
				sd += (atof(str)-m_fIVedit*100)/100.0;
			}
		}
		else
		{
			switch(m_iOdr)
			{
			case 1:
				m_editIV1.GetWindowText(str);
				sd += (atof(str)-m_fIVedit*100)/100.0;
				break;
			case 2:
				m_editIV2.GetWindowText(str);
				sd += (atof(str)-m_fIVedit*100)/100.0;
				break;
			case 3:
				m_editIV3.GetWindowText(str);
				sd += (atof(str)-m_fIVedit*100)/100.0;
				break;
			}
		}
	}
	
	double X = dStrike ;
	double r = m_TTOptions->m_fRiskInterest*0.01 ;
	double dT_t = iExpDay/365.0;
	double time_sqrt = sqrt(dT_t) ;
	
	if( (F*X*sd*time_sqrt)==0.0 )
	{
		return 0;
	}
	char cc[100] = {0};

	double d1 = ( log( F/X ) + (r+0.5*sd*sd)*dT_t ) /  ( sd*time_sqrt ) ;
	double d2 = d1 - sd*time_sqrt ;

	double N_d1  =  ( d1>0.0) ? CBM1976Wrapper::N(d1) : 1.0-CBM1976Wrapper::N(fabs(d1)) ;			// 
	double N_d2  =  ( d2>0.0) ? CBM1976Wrapper::N(d2) : 1.0-CBM1976Wrapper::N(fabs(d2)) ;			// 
	double Np_d1 =	pow( MathE, -0.5*d1*d1 ) / ( sqrt( 2.0*MathPI ) ) ;

	double MOP1 = ( F*N_d1 )- (pow( MathE, -1.0*r*dT_t )*X*N_d2 );
	double MOP2 = MOP1 + X*pow( MathE, -1.0*r*dT_t )-F;
	// BS���� ��֤�۸�.
	
	if( bCall==TRUE )
	{
		MOP = MOP1;
	}
	else
	{
		MOP = MOP2 ;	
	}

	return MOP;
}

//��������ʹ�۵����ۼ۸�
float CStrategy::ModelPrice_Stgy(BOOL bCall,StgyHistoryFile stgyfile,LastPrice lastp)
{
	if( strcmp(m_TTOptions->m_szFutures,"")==0&&IsIndex() )
	{
		//memset(&calinfo,0,sizeof(calinfo));
		return 0;
	}

	float fPrice,fCash;
	int i;
	CCashArray arrCash;
	arrCash.RemoveAll();
	EnterCriticalSection(&m_cs);
	arrCash.Copy(m_TTOptions->m_arrCash);
	LeaveCriticalSection( &m_cs );
	for( i=0;i<arrCash.GetSize();i++ )
	{
		if( memcmp(stgyfile.m_szCode,arrCash[i].szCode,8)==0 )
		{
			fCash = arrCash[i].fCash;
			break;
		}
	}
	
	BSMCALINFO calinfo;
	int nAddr;
	if( bCall )
		nAddr = POS_CALL_LAST;
	else
		nAddr = POS_PUT_LAST;

	m_iOdr = 4;

	int stgyix;
	if( stgyfile.m_iCustomIx[6]==1 )
		stgyix = stgyfile.m_iCustomIx[7];
	else
		stgyix = stgyfile.m_fCapital;
	int iExpDays;
	long lCurTime;
	CTime tm = CTime::GetCurrentTime();
	CString strForm = tm.Format("%Y%m%d");
	lCurTime = atoi(strForm);
	m_TTOptions->DateDiff(stgyfile.m_lExpTime,lCurTime,iExpDays);
//	if(stgyix==17)

	fPrice = m_TTOptions->ModelPrice(bCall, lastp.fStrike, fCash,iExpDays,nAddr,calinfo);

	return fPrice;
}

BOOL CStrategy::PairString(StgyHistoryFile stgyfile, Calend cald,CStringArray &arr, int nPos,BYTE bWeekly)
{
	CString strCustom[7];
	strCustom[0] = "Sell Call";
	strCustom[1] = "Buy Call";
	strCustom[2] = "Sell Put";
	strCustom[3] = "Buy Put";
	strCustom[4] = "Sell Stock";
	strCustom[5] = "Buy Stock";
	strCustom[6] = "-- --";

	int m;
	BOOL bPrice = TRUE;
	CLPArray arrLP[100];
	CCashArray arrCash;
	CCDArray tempCD;
	arrCash.RemoveAll();
	for( m=0;m<100;m++ )
		arrLP[m].RemoveAll();
	EnterCriticalSection(&m_cs);
	arrCash.Copy(m_TTOptions->m_arrCash);
	for( m=0;m<100;m++ )
		arrLP[m].Copy(m_TTOptions->m_arrLP[m]);
	LeaveCriticalSection( &m_cs );

	arr.RemoveAll();
	CString str;
	int i,j,k;
	float f1=0,f2=0,f3=0,f4=0;
	char sz[100] = {0};
	int stgyix;
	if( stgyfile.m_iCustomIx[6]==1 )
		stgyix = stgyfile.m_iCustomIx[7];
	else
		stgyix = stgyfile.m_fCapital;

	switch(stgyix)
	{
	case 17:
	case 18:
		if( cald.bDebit==0 )
		{
			if( cald.bCall==0 )
				arr.Add(strCustom[0]);
			else
				arr.Add(strCustom[2]);
			str.Format("%d",-1*stgyfile.m_nCount);
			arr.Add(str);

			if( cald.bCall==0 )
				arr.Add(strCustom[1]);
			else
				arr.Add(strCustom[3]);
			str.Format("%d",stgyfile.m_nCount);
			arr.Add(str);
		}
		else
		{
			if( cald.bCall==0 )
				arr.Add(strCustom[1]);
			else
				arr.Add(strCustom[3]);
			str.Format("%d",stgyfile.m_nCount);
			arr.Add(str);

			if( cald.bCall==0 )
				arr.Add(strCustom[0]);
			else
				arr.Add(strCustom[2]);
			str.Format("%d",-1*stgyfile.m_nCount);
			arr.Add(str);
		}

		if( nPos==-1 )
			break;
		
		for( j=0;j<arrLP[nPos].GetSize();j++ )
		{
			LastPrice lastp = arrLP[nPos][j];
			if( stgyfile.m_fStrike[0]==lastp.fStrike )
			{
				if( cald.bCall==0 )
				{
					if( lastp.fCall==0.0 )
					{
						bPrice = FALSE;
						lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
						CString str;
						GetPriceTxt(lastp.fCall,str,1);
						lastp.fCall = atof(str);
					}
					if( cald.bDebit==0 )
						f1 = stgyfile.m_fPrice[0]-lastp.fCall;
					else
						f1 = lastp.fCall-stgyfile.m_fPrice[0];
				}
				else
				{
					if( lastp.fPut==0.0 )
					{
						bPrice = FALSE;
						lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
						CString str;
						GetPriceTxt(lastp.fPut,str,1);
						lastp.fPut = atof(str);
					}
					if( cald.bDebit==0 )
						f1 = stgyfile.m_fPrice[0]-lastp.fPut;
					else
						f1 = lastp.fPut-stgyfile.m_fPrice[0];
				}
				break;
			}
		}
		nPos = -1;
		tempCD.RemoveAll();
		EnterCriticalSection(&m_cs);
		tempCD.Copy(m_TTOptions->m_arrCD);
		LeaveCriticalSection( &m_cs );
		for( m=0;m<tempCD.GetSize();m++ )
		{
			CodeDate codedate;
			codedate = tempCD[m];
			long lm = cald.lMonth2;
			if( bWeekly==0 )
				lm = lm/100;
			if( memcmp(codedate.szCode,stgyfile.m_szCode,8)==0 && codedate.lDate==lm )
			{
				nPos = m;
				break;
			}
		}
		if( nPos==-1 )
		{
			m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
			break;
		}

		for( j=0;j<arrLP[nPos].GetSize();j++ )
		{
			LastPrice lastp = arrLP[nPos][j];
			if( stgyfile.m_fStrike[1]==lastp.fStrike )
			{
				if( cald.bCall==0 )
				{
					if( lastp.fCall==0.0 )
					{
						bPrice = FALSE;
						stgyfile.m_lExpTime = cald.lMonth2;
						lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
						CString str;
						GetPriceTxt(lastp.fCall,str,1);
						lastp.fCall = atof(str);
					}
					if( cald.bDebit==0 )
						f2 = lastp.fCall-stgyfile.m_fPrice[1];
					else
						f2 = stgyfile.m_fPrice[1]-lastp.fCall;
				}
				else
				{
					if( lastp.fPut==0.0 )
					{
						bPrice = FALSE;
						stgyfile.m_lExpTime = cald.lMonth2;
						lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
						CString str;
						GetPriceTxt(lastp.fPut,str,1);
						lastp.fPut = atof(str);
					}
					if( cald.bDebit==0 )
						f2 = lastp.fPut-stgyfile.m_fPrice[1];
					else
						f2 = stgyfile.m_fPrice[1]-lastp.fPut;
				}
				break;
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 15:
		str = "Buy Stock";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( j=0;j<arrLP[nPos].GetSize();j++ )
		{
			LastPrice lastp = arrLP[nPos][j];
			if( stgyfile.m_fStrike[1]==lastp.fStrike )
			{
				if( lastp.fCall==0.0 )
				{
					bPrice = FALSE;
					lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
				}
				f1 = stgyfile.m_fPrice[1]-lastp.fCall;
				for( i=0;i<arrCash.GetSize();i++ )
				{
					char code[9] = {0};
					for( k=0;k<m_arrITC.GetSize();k++ )
					{
						if( memcmp(stgyfile.m_szCode,m_arrITC[k].itemcode,8)==0&&stgyfile.m_lExpTime==m_arrITC[k].ldate )
						{
							memcpy(code,m_arrITC[k].cashcode,8);
							break;
						}
					}
					if( memcmp(code,arrCash[i].szCode,8)==0 )
					{
						f2 = arrCash[i].fCash-stgyfile.m_fPrice[0];
						break;
					}
				}
				break;
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 16:
		str = "Sell Stock";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Put";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( j=0;j<arrLP[nPos].GetSize();j++ )
		{
			LastPrice lastp = arrLP[nPos][j];
			if( stgyfile.m_fStrike[1]==lastp.fStrike )
			{
				if( lastp.fPut==0.0 )
				{
					bPrice = FALSE;
					lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
				}
				f1 = stgyfile.m_fPrice[1]-lastp.fPut;
				for( i=0;i<arrCash.GetSize();i++ )
				{
					char code[9] = {0};
					for( k=0;k<m_arrITC.GetSize();k++ )
					{
						if( memcmp(stgyfile.m_szCode,m_arrITC[k].itemcode,8)==0&&stgyfile.m_lExpTime==m_arrITC[k].ldate )
						{
							memcpy(code,m_arrITC[k].cashcode,8);
							break;
						}
					}
					if( memcmp(code,arrCash[i].szCode,8)==0 )
					{
						f2 = stgyfile.m_fPrice[0]-arrCash[i].fCash;
						break;
					}
				}
				break;
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case STGY_CUSTOM:
		for( i=0;i<6;i++ )
		{
			if( stgyfile.m_iCustomIx[i]==6 )
				continue;
			arr.Add(strCustom[stgyfile.m_iCustomIx[i]]);
			str.Format("%d",stgyfile.m_iCustomCount[i]);
			arr.Add(str);
		}
		if( nPos==-1 )
			break;
		for( i=0;i<6;i++ )
		{
			if( stgyfile.m_iCustomIx[i]==6 )
				continue;
			if( stgyfile.m_iCustomIx[i]==4||stgyfile.m_iCustomIx[i]==5 )
			{
				for( j=0;j<arrCash.GetSize();j++ )
				{
					char code[9] = {0};
					for( k=0;k<m_arrITC.GetSize();k++ )
					{
						if( memcmp(stgyfile.m_szCode,m_arrITC[k].itemcode,8)==0&&stgyfile.m_lExpTime==m_arrITC[k].ldate )
						{
							memcpy(code,m_arrITC[k].cashcode,8);
							break;
						}
					}
					if( memcmp(code,arrCash[j].szCode,8)==0 )
					{
						if( i>3 )
							f2 = (arrCash[j].fCash-stgyfile.m_fPriceEx[i-4])*stgyfile.m_iCustomCount[i];
						else
							f2 = (arrCash[j].fCash-stgyfile.m_fPrice[i])*stgyfile.m_iCustomCount[i];
						break;
					}
				}
				m_iYK += f2;
			}
			float fsktp,fprtp;
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( i>3 )
				{
					fsktp = stgyfile.m_fStrikeEx[i-4];
					fprtp = stgyfile.m_fPriceEx[i-4];
				}
				else
				{
					fsktp = stgyfile.m_fStrike[i];
					fprtp = stgyfile.m_fPrice[i];
				}
				if( fsktp==lastp.fStrike )
				{
					switch( stgyfile.m_iCustomIx[i] )
					{
					case 0:
					case 1:
						if( lastp.fCall==0.0 )
						{
							bPrice = FALSE;
							lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
						}
						break;
					case 2:
					case 3:
						if( lastp.fPut==0.0 )
						{
							bPrice = FALSE;
							lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
						}
						break;
					}
					switch( stgyfile.m_iCustomIx[i] )
					{
					case 0:
						f1 = fprtp - lastp.fCall;
						f1 = -1*f1*stgyfile.m_iCustomCount[i];
						break;
					case 1:
						f1 = lastp.fCall - fprtp;
						f1 = f1*stgyfile.m_iCustomCount[i];
						break;
					case 2:
						f1 = fprtp - lastp.fPut;
						f1 = -1*f1*stgyfile.m_iCustomCount[i];
						break;
					case 3:
						f1 = lastp.fPut - fprtp;
						f1 = f1*stgyfile.m_iCustomCount[i];
						break;
					}
					m_iYK += f1;
					break;
				}
			}
		}
		m_iYK *= stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 0:
		str = "Buy Call";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-2*stgyfile.m_nCount);
		arr.Add(str);
		str = "Buy Call";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<3;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					if( lastp.fCall==0.0 )
					{
						bPrice = FALSE;
						lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
					}
					if( i==0 )
						f1 = lastp.fCall-stgyfile.m_fPrice[0];
					else if( i==1 )
						f2 = stgyfile.m_fPrice[1]-lastp.fCall;
					else if( i==2 )
						f3 = lastp.fCall-stgyfile.m_fPrice[2];

					break;
				}
			}
		}
		m_iYK = (f1+f2*2+f3)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 1:
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		str = "Buy Call";
		arr.Add(str);
		str.Format("%d",2*stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<3;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					if( lastp.fCall==0.0 )
					{
						bPrice = FALSE;
						lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
					}
					if( i==0 )
						f1 = stgyfile.m_fPrice[0]-lastp.fCall;
					else if( i==1 )
						f2 = lastp.fCall-stgyfile.m_fPrice[1];
					else if( i==2 )
						f3 = stgyfile.m_fPrice[2]-lastp.fCall;

					break;
				}
			}
		}
		m_iYK = (f1+f2*2+f3)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 2:
	case 4:
		str = "Buy Call";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		str = "Buy Put";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<2;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					if( i==0 )
					{
						if( lastp.fCall==0.0 )
						{
							bPrice = FALSE;
							lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
						}
						f1 = lastp.fCall-stgyfile.m_fPrice[0];
					}
					else if( i==1 )
					{
						if( lastp.fPut==0.0 )
						{
							bPrice = FALSE;
							lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
						}
						f2 = lastp.fPut-stgyfile.m_fPrice[1];
					}
					break;
				}
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 3:
	case 5:
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Put";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<2;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					if( i==0 )
					{
						if( lastp.fCall==0.0 )
						{
							bPrice = FALSE;
							lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
						}
						f1 = stgyfile.m_fPrice[0]-lastp.fCall;
					}
					else if( i==1 )
					{
						if( lastp.fPut==0.0 )
						{
							bPrice = FALSE;
							lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
						}
						f2 = stgyfile.m_fPrice[1]-lastp.fPut;
					}
					break;
				}
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 6:
		str = "Buy Put";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Put";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		str = "Buy Call";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<4;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					switch( i )
					{
					case 0:
					case 1:
						if( lastp.fPut==0.0 )
						{
							bPrice = FALSE;
							lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
						}
						
						break;
					case 2:
					case 3:
						if( lastp.fCall==0.0 )
						{
							bPrice = FALSE;
							lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
						}
						break;
					}
					if( i==0 )
						f1 = lastp.fPut-stgyfile.m_fPrice[0];
					else if( i==1 )
						f2 = stgyfile.m_fPrice[1]-lastp.fPut;
					else if( i==2 )
						f3 = stgyfile.m_fPrice[2]-lastp.fCall;
					else if( i==3 )
						f4 = lastp.fCall-stgyfile.m_fPrice[3];
					break;
				}
			}
		}
		m_iYK = (f1+f2+f3+f4)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 7:
		str = "Buy Call";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( j=0;j<arrLP[nPos].GetSize();j++ )
		{
			LastPrice lastp = arrLP[nPos][j];
			if( stgyfile.m_fStrike[0]==lastp.fStrike )
			{
				if( lastp.fCall==0.0 )
				{
					bPrice = FALSE;
					lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
				}
				f1 = lastp.fCall-stgyfile.m_fPrice[0];
				break;
			}
		}
		m_iYK = f1*stgyfile.m_lShares*stgyfile.m_nCount;
		
		break;
	case 8:
		str = "Buy Put";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( j=0;j<arrLP[nPos].GetSize();j++ )
		{
			LastPrice lastp = arrLP[nPos][j];
			if( stgyfile.m_fStrike[0]==lastp.fStrike )
			{
				if( lastp.fPut==0.0 )
				{
					bPrice = FALSE;
					lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
				}
				f1 = lastp.fPut-stgyfile.m_fPrice[0];
				break;
			}
		}
		m_iYK = f1*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 9:
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( j=0;j<arrLP[nPos].GetSize();j++ )
		{
			LastPrice lastp = arrLP[nPos][j];
			if( stgyfile.m_fStrike[0]==lastp.fStrike )
			{
				if( lastp.fCall==0.0 )
				{
					bPrice = FALSE;
					lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
				}
				f1 = stgyfile.m_fPrice[0]-lastp.fCall;
				break;
			}
		}
		m_iYK = f1*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 10:
		str = "Sell Put";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( j=0;j<arrLP[nPos].GetSize();j++ )
		{
			LastPrice lastp = arrLP[nPos][j];
			if( stgyfile.m_fStrike[0]==lastp.fStrike )
			{
				if( lastp.fPut==0.0 )
				{
					bPrice = FALSE;
					lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
				}
				f1 = stgyfile.m_fPrice[0]-lastp.fPut;
				break;
			}
		}
		m_iYK = f1*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 11:
		str = "Buy Call";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<2;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					if( lastp.fCall==0.0 )
					{
						bPrice = FALSE;
						lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
					}
					if( i==0 )
						f1 = lastp.fCall-stgyfile.m_fPrice[0];
					else if( i==1 )
						f2 = stgyfile.m_fPrice[1]-lastp.fCall;
					break;
				}
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 12:
		str = "Sell Call";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		str = "Buy Call";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<2;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					if( lastp.fCall==0.0 )
					{
						bPrice = FALSE;
						lastp.fCall = ModelPrice_Stgy(TRUE,stgyfile,lastp);
					}
					if( i==0 )
						f1 = stgyfile.m_fPrice[0]-lastp.fCall;
					else if( i==1 )
						f2 = lastp.fCall-stgyfile.m_fPrice[1];
					break;
				}
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 13:
		str = "Buy Put";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		str = "Sell Put";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<2;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					if( lastp.fPut==0.0 )
					{
						bPrice = FALSE;
						lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
					}
					if( i==0 )
						f1 = lastp.fPut-stgyfile.m_fPrice[0];
					else if( i==1 )
						f2 = stgyfile.m_fPrice[1]-lastp.fPut;
					break;
				}
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	case 14:
		str = "Sell Put";
		arr.Add(str);
		str.Format("%d",-1*stgyfile.m_nCount);
		arr.Add(str);
		str = "Buy Put";
		arr.Add(str);
		str.Format("%d",stgyfile.m_nCount);
		arr.Add(str);
		if( nPos==-1 )
			break;
		for( i=0;i<2;i++ )
		{
			for( j=0;j<arrLP[nPos].GetSize();j++ )
			{
				LastPrice lastp = arrLP[nPos][j];
				if( stgyfile.m_fStrike[i]==lastp.fStrike )
				{
					if( lastp.fPut==0.0 )
					{
						bPrice = FALSE;
						lastp.fPut = ModelPrice_Stgy(FALSE,stgyfile,lastp);
					}
					if( i==0 )
						f1 = stgyfile.m_fPrice[0]-lastp.fPut;
					else if( i==1 )
						f2 = lastp.fPut-stgyfile.m_fPrice[1];
					break;
				}
			}
		}
		m_iYK = (f1+f2)*stgyfile.m_lShares*stgyfile.m_nCount;
		break;
	}

	return bPrice;
}

void CStrategy::GetMargin(float fStrike,long lDate,int &iCallMar,int &iPutMar)
{
	int i,j,k,month=-1,pos=-1;
	for( i=0;i<MAX_OPTIONS_COUNT;i++ )
	{
		if(m_TTOptions->m_arrMargin[i].GetSize()>0 && memcmp(m_TTOptions->m_arrMargin[i][0].m_szfcode,m_TTOptions->m_szOptCode,5)==0 )
		{
			for( j=0;j<3;j++ )
			{
				if( m_TTOptions->m_arrMargin[i][0].m_lTransdate[j]==lDate )
				{
					month = j;
					break;
				}
			}
			
			pos = i;
			break;
		}
	}
	if( pos==-1||month==-1 )
		return;
	
	
	for( j=0;j<m_TTOptions->m_arrMargin[pos].GetSize();j++ )
	{
		if( m_TTOptions->m_arrMargin[pos][j].m_fStrike==fStrike )
		{
			iCallMar = m_TTOptions->m_arrMargin[pos][j].m_iCall_Margin[month];
			iPutMar = m_TTOptions->m_arrMargin[pos][j].m_iPut_Margin[month];
			break;
		}
	}
		
}

BYTE CStrategy::CheckData()
{	
	CalendarRequest();
	Sleep(50);

/*	GetCaldInx();
	float fCorr = m_TTOptions->GetCorrStockPrice(FALSE);
	float fFarPrice = 0.0;//Զ�µ��ڻ���
	if( IsIndex()&&m_nIndex==17 )
	{
		fCorr = GetMonthPrice(m_lCaldExpDate1);
		fFarPrice = GetMonthPrice(m_lCaldExpDate2);
	}
	if( m_iCaldInx1==-1 )
	{
		return 1;
	}
	if( m_iCaldInx2==-1  )
		return 2;*/

	char cc[100];
	sprintf(cc,"1=%d,2=%d",m_lCaldExpDate1,m_lCaldExpDate2);
//	m_TTOptions->WriteLogFile(cc);

	if( !m_TTOptions->HaveFutures(m_TTOptions->m_szItemCode,m_lCaldExpDate1) )
		return 3;

	if( !m_TTOptions->HaveFutures(m_TTOptions->m_szItemCode,m_lCaldExpDate2) )
		return 4;
/*	if( fCorr==0.0 )
		return 3;
	if( IsIndex()&& fFarPrice==0.0 )
	{
		return 4;
	}

	CLPArray arrLP1;
	CLPArray arrLP2;
	float fPrice1=0.0, fPrice2=0.0;
	int i;
	EnterCriticalSection(&m_cs);
	arrLP1.Copy(m_TTOptions->m_arrLP[m_iCaldInx1]);
	arrLP2.Copy(m_TTOptions->m_arrLP[m_iCaldInx2]);
	LeaveCriticalSection( &m_cs );
	
	
	for( i=0;i<arrLP1.GetSize();i++ )
	{
		if( arrLP1[i].fStrike==m_cald.fStrike )
		{
			if( m_cald.bCall==0 )
				fPrice1 = arrLP1[i].fCall;
			else
				fPrice1 = arrLP1[i].fPut;
			break;
		}
	}
	
	
	for( i=0;i<arrLP2.GetSize();i++ )
	{
		if( arrLP2[i].fStrike==m_cald.fStrike )
		{
			if( m_cald.bCall==0 )
				fPrice2 = arrLP2[i].fCall;
			else
				fPrice2 = arrLP2[i].fPut;
			break;
		}
	} 
	if( fPrice1==0.0 )
		return 5;
	if( fPrice2==0.0 )
		return 6;
*/	

	return 0;
}

CString CStrategy::GetMonthString(long ldate)
{
	CString strDay = "";
	if( ldate>10000000 )
	{
		int nDay = ldate%100;
		ldate = ldate/100;
		strDay.Format("%02d",nDay);
	}
	CString str;
	CString szMonth[12] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"};
	int iYY = ldate/100%100;
	int iMM = ldate%100;
	str.Format("(%s%s %d)",strDay,szMonth[iMM-1],iYY);
	

	return str;
}

void CStrategy::CalendarRequest()
{
	m_iCaldInx1 = -1;
	m_iCaldInx2 = -1;
	int i;
	CCDArray tempCD;
	tempCD.RemoveAll();
	EnterCriticalSection(&m_cs);
	tempCD.Copy(m_TTOptions->m_arrCD);
	LeaveCriticalSection( &m_cs );
	long lM1 = m_cald.lMonth1;
	long lM2 = m_cald.lMonth2;
//	if( lM1>10000000 )
//		lM1 = lM1/100;
//	if( lM2>10000000 )
//		lM2 = lM2/100;
	for( i=0;i<tempCD.GetSize();i++ )
	{
		if( memcmp(tempCD[i].szCode,m_TTOptions->m_szItemCode,8)==0 && tempCD[i].lDate==lM2 )
			break;
	}
	if( i==tempCD.GetSize() )
		m_TTOptions->SendUpdateRP(TRUE,m_TTOptions->m_szItemCode,lM2);
	
	
	for( i=0;i<tempCD.GetSize();i++ )
	{
		if( memcmp(tempCD[i].szCode,m_TTOptions->m_szItemCode,8)==0 && tempCD[i].lDate==lM1 )
			break;
	}
	if( i==tempCD.GetSize() )
		m_TTOptions->SendUpdateRP(TRUE,m_TTOptions->m_szItemCode,lM1);
	
	char code[9] = {0};
	long exptime = m_cald.lMonth1;
	if( exptime<10000000 )
	{
		CString strItem;
		strItem.Format("%c%s",m_TTOptions->m_cbGroupCode,m_TTOptions->m_szItemCode);
		
		OptionsExpiryDateInfo expInfo;
		if(m_TTOptions->m_ExpiryDateMap.Lookup((LPCTSTR)strItem,expInfo)== TRUE)
		{
			for(int i=0;i<expInfo.expList.GetSize();i++)
			{
				if (expInfo.expList.ElementAt(i).lMonth == m_cald.lMonth1)
				{
					exptime = expInfo.expList.ElementAt(i).lExpiryDate;
					break;
				}	
			}
		}
	}
	
	m_lCaldExpDate1 = exptime;
	m_TTOptions->GetCashOrFuturesCode(m_TTOptions->m_szItemCode,exptime, code);
	ItemToCash itc;
	memcpy(itc.itemcode,m_TTOptions->m_szItemCode,8);
	itc.ldate = exptime;
	memcpy(itc.cashcode,code,8);
	m_arrITC.Add(itc);
	m_TTOptions->SendTeleHisCash(code);
	
	
	
	memset(code,0,9);
	exptime = m_cald.lMonth2;
	if( exptime<10000000 )
	{
		CString strItem;
		strItem.Format("%c%s",m_TTOptions->m_cbGroupCode,m_TTOptions->m_szItemCode);
		
		OptionsExpiryDateInfo expInfo;
		if(m_TTOptions->m_ExpiryDateMap.Lookup((LPCTSTR)strItem,expInfo)== TRUE)
		{
			for(int i=0;i<expInfo.expList.GetSize();i++)
			{
				if (expInfo.expList.ElementAt(i).lMonth == m_cald.lMonth2)
				{
					exptime = expInfo.expList.ElementAt(i).lExpiryDate;
					break;
				}	
			}
		}
	}
	
	m_lCaldExpDate2 = exptime;
	m_TTOptions->GetCashOrFuturesCode(m_TTOptions->m_szItemCode,exptime, code);
	memset(&itc,0,sizeof(itc));
	memcpy(itc.itemcode,m_TTOptions->m_szItemCode,8);
	itc.ldate = exptime;
	memcpy(itc.cashcode,code,8);
	m_arrITC.Add(itc);
	m_TTOptions->SendTeleHisCash(code);
}

void CStrategy::LoadData()
{
	int i,j,k,nCount,ct;
	k = 0;
	float fTotal = 0.0;
	if( m_bOrder )
	{
		m_list2.ModifyStyle(LVS_NOCOLUMNHEADER,0);
		m_edit2.SetWindowText(szTT4[m_TTOptions->m_iLangType]);
		m_edit3.SetWindowText(szPLTotal[m_TTOptions->m_iLangType]);
		nCount = m_list2.GetHeaderCtrl()->GetItemCount();
		for( i=0;i<nCount;i++ )
			m_list2.DeleteColumn(0);
		m_list2.InsertColumn(0,szbookDate[m_TTOptions->m_iLangType],LVCFMT_CENTER,80+5);
		m_list2.InsertColumn(1,szbookTime[m_TTOptions->m_iLangType],LVCFMT_CENTER,50+5);
		m_list2.InsertColumn(2,szStgy[m_TTOptions->m_iLangType],LVCFMT_CENTER,124);
		m_list2.InsertColumn(3,szDirection[m_TTOptions->m_iLangType],LVCFMT_CENTER,80);
		m_list2.InsertColumn(4,szCount[m_TTOptions->m_iLangType],LVCFMT_RIGHT,48);
		m_list2.InsertColumn(5,szItem[m_TTOptions->m_iLangType],LVCFMT_CENTER,58+5);
		m_list2.InsertColumn(6,szExpTime[m_TTOptions->m_iLangType],LVCFMT_CENTER,70+5);
		m_list2.InsertColumn(7,szstaEXP[m_TTOptions->m_iLangType],LVCFMT_CENTER,80);
		m_list2.InsertColumn(8,szStrike[m_TTOptions->m_iLangType],LVCFMT_CENTER,65);
		m_list2.InsertColumn(9,szLastP[m_TTOptions->m_iLangType],LVCFMT_RIGHT,60);
		m_list2.InsertColumn(10,szYK[m_TTOptions->m_iLangType],LVCFMT_CENTER,65);
		m_list2.InsertColumn(11,szDelete[m_TTOptions->m_iLangType],LVCFMT_CENTER,50+5);

		m_list2.DeleteAllItems();
	}

	if( m_StgyList.GetSize()==0 )
		return;

	CCDArray tempCD;
	tempCD.RemoveAll();
	EnterCriticalSection(&m_cs);
	tempCD.Copy(m_TTOptions->m_arrCD);
	LeaveCriticalSection( &m_cs );

	m_arrNum.RemoveAll();
	CStringArray strArry;
	CString strForm;
	
	int nYear,nMonth,nDay;
	StgyHistoryFile stgyfile;
	StgyFileExt     extfile;
	
	for( i=0;i<m_StgyList.GetSize();i++ )
	{
		memset(&stgyfile,0,sizeof(stgyfile));
		stgyfile = m_StgyList[i];
		memset(&extfile,0,sizeof(extfile));
		memcpy(&extfile,&m_ExtList[i],sizeof(extfile));

		nYear = stgyfile.m_lDate/10000;
		nMonth = stgyfile.m_lDate%10000/100;
		nDay = stgyfile.m_lDate%100;
		strForm.Format("%d.%d.%d",nYear,nMonth,nDay);
		m_list2.InsertItem(k,strForm);
		strForm.Format("%d",stgyfile.m_iTime);
		for( int a=strForm.GetLength();a<4;a++ )
			strForm.Insert(0,"0");
		strForm.Insert(2,":");
		m_list2.SetItemText(k,1,strForm);
		int stgyix;
		if( stgyfile.m_iCustomIx[6]==1 )
			stgyix = stgyfile.m_iCustomIx[7];
		else
			stgyix = stgyfile.m_fCapital;
		m_ComBoxType.GetLBText(stgyix,strForm);
		m_list2.SetItemText(k,2,strForm);
		strForm = stgyfile.m_szCode;
		strForm.Remove(' ');
		if( extfile.b_weekly==1 || extfile.b_Mth2_Weekly==1 )
			strForm += "(W)";
		m_list2.SetItemText(k,5,strForm);
		int lExpTime = stgyfile.m_lExpTime;
	//	if( stgyix==17 && stgyfile.m_lExpTime==extfile.cald.lMonth2 )
	//		lExpTime = extfile.cald.lMonth1;
		nYear = lExpTime/10000%100;
		nMonth = lExpTime%10000/100;
		nDay = lExpTime%100;
		strForm.Format("%d.%d.%d",nYear,nMonth,nDay);
		m_list2.SetItemText(k,6,strForm);
		int iExpDays;
		long lCurTime;
		CTime tm = CTime::GetCurrentTime();
		strForm = tm.Format("%Y%m%d");
		lCurTime = atoi(strForm);
		m_TTOptions->DateDiff(lExpTime,lCurTime,iExpDays);
		strForm.Format("%d",iExpDays);
		m_list2.SetItemText(k,7,strForm);
		if( iExpDays<0 )
			m_list2.SetItemText(k,7,"--");

		int nPos = -1;
		m_iYK = 0.0;
		for( int m=0;m<tempCD.GetSize();m++ )
		{
			CodeDate codedate;
			codedate = tempCD[m];
			if( memcmp(codedate.szCode,stgyfile.m_szCode,8)==0 &&
				( (extfile.b_weekly==0&&codedate.lDate==stgyfile.m_lExpTime/100)||(extfile.b_weekly==1&&codedate.lDate==stgyfile.m_lExpTime) ) )
			{
				nPos = m;
				break;
			}
		}
	
		ItemNum itemnum;
		memset(&itemnum,0,sizeof(ItemNum));
		BOOL bPrice = TRUE;
	//	if( nPos!=-1 )
		{
			bPrice = PairString(stgyfile,extfile.cald,strArry,nPos,extfile.b_Mth2_Weekly);
		}
		strForm.Format("%.0f",m_iYK);
		if( nPos==-1 )
		{
			strForm = "";
			SetTimer(3333,2000,NULL);
		}
		if( !m_TTOptions->HaveFutures(stgyfile.m_szCode,stgyfile.m_lExpTime) )
		{
			strForm = "";
			m_iYK = 0;
		}
		m_list2.SetItemText(k,10,strForm);
		
		fTotal += m_iYK;
	
		m_list2.SetItemText(k,11,"X");
		itemnum.bPrice = bPrice;
		itemnum.nItem = k;
		m_arrNum.Add(itemnum);
		ct = -1;
		for( j=0;j<6;j++ )
		{
			if( stgyfile.m_iCustomIx[j]==6 && stgyix==STGY_CUSTOM )
				continue;
			ct++;
			float fsktp;
			if( j>3 )
				fsktp = stgyfile.m_fStrikeEx[j-4];
			else
				fsktp = stgyfile.m_fStrike[j];

			if( fsktp!=0.0 || stgyix==15 || stgyix==16 || ( stgyix==STGY_CUSTOM&&stgyfile.m_iCustomIx[j]>=4 ) )
			{
				if( (stgyix==15 || stgyix==16) && j>1)
					break;
				if( ct>0 )
				{
					k++;
					m_list2.InsertItem(k,"");
					if( stgyix==17 || stgyix==18 )
					{
						nYear = extfile.cald.lMonth2/10000%100;
						nMonth = extfile.cald.lMonth2%10000/100;
						nDay = extfile.cald.lMonth2%100;
						strForm.Format("%d.%d.%d",nYear,nMonth,nDay);
						m_list2.SetItemText(k,6,strForm);
						m_TTOptions->DateDiff(extfile.cald.lMonth2,lCurTime,iExpDays);
						strForm.Format("%d",iExpDays);
						m_list2.SetItemText(k,7,strForm);
					}
				}
				if( strArry.GetSize()>ct*2 )
				{
				m_list2.SetItemText(k,3,strArry[ct*2]);
				m_list2.SetItemText(k,4,strArry[ct*2+1]);
				}

				GetPriceTxt(fsktp,strForm);
				if( fsktp==0.0 )
					strForm = "";
				m_list2.SetItemText(k,8,strForm);

				int pps=0;
				if( j>3 )
					pps=GetPriceTxt(stgyfile.m_fPriceEx[j-4],strForm);
				else
					pps=GetPriceTxt(stgyfile.m_fPrice[j],strForm);
				m_list2.SetItemText(k,9,strForm);
			}
		}
		k++;
	}
	strForm.Format("%.0f", fTotal);
	strForm = szPLTotal[m_TTOptions->m_iLangType] + strForm;
	m_edit3.SetWindowText(strForm);

	int iLen = 0;
	for( i=0;i<m_list2.GetItemCount();i++ )
	{
		CString str = m_list2.GetItemText(i,10);
		int iLenOld = m_list2.GetStringWidth(str);
		if( iLenOld>iLen )
			iLen = iLenOld;
	}
	if( iLen>50 )  //65-15
		m_list2.SetColumnWidth(10,iLen+15);

	m_bReLoadList2Data = FALSE;
}

void CStrategy::OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int i;
	int nTabInx = m_tab1.GetCurSel();
	switch(nTabInx)
	{
	case 0:
		m_bOrder = FALSE;
		if( m_bMode==2 )
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top+16);
		else if( m_nIndex==STGY_CUSTOM&&m_bMode==0 )
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top+33);
		else
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_TabRect.bottom-m_WinRect.top);
		if( m_bUseRecord )
		{
			m_ComBoxStrike.EnableWindow(TRUE);
			m_ComBoxStrike2.EnableWindow(TRUE);
			m_ComBoxStrike3.EnableWindow(TRUE);
			m_ComBoxStrike4.EnableWindow(TRUE);
			m_btnJianc.EnableWindow(TRUE);
			m_ComBoxType.EnableWindow(TRUE);
			m_bUseRecord = FALSE;
			BYTE CusIx[6];
			short CusCount[6];
			for( i=0;i<6;i++ )
			{
				CusIx[i] = m_nCustomIx[i];
				CusCount[i] = m_nCustomCount[i];
			}
			ClearFlag();
			for( i=0;i<6;i++ )
			{
				m_nCustomIx[i] = CusIx[i];
				m_nCustomCount[i] = CusCount[i];
			}
			SwitchCtrl();
			if( m_nIndex!=STGY_CUSTOM )
			{
				m_nIxStrike = -1;
				m_nIxStrike2 = -1;
				m_nIxStrike3 = -1;
				m_nIxStrike4 = -1;
				m_nIxStrike5 = -1;
				m_nIxStrike6 = -1;
			}
			for( i=0;i<3;i++ )
			{
				m_bResetBF[i] = TRUE;	
			}
			for( i=0;i<6;i++ )
			{
				m_bAlterPrice[i] = FALSE;
				m_bAlterPrice2[i] = FALSE;
			}
			if( m_bMode==0 )
			{
				CreateBtn();
				CreateSpin(&m_list,m_pSpin,2,2,m_bHaveCrt_Spin);
				if( m_nIndex==STGY_CUSTOM )
				{
					for( int j=0;j<5;j++ )
						CreateSpin(&m_list,m_pSpinEx[j],j+3,2,m_bHaveCrt_Spin);
					//if( m_bHaveCrt_Spin_C )
					//	DestroySpin(m_pSpin_C,m_bHaveCrt_Spin_C);
				}
			}
			m_TTOptions->m_bStgyMode = m_bMode;
			//m_nRetn = 0;
			m_TTOptions->OnSelectStrategy();
		}
		break;
	case 1:
		m_bOrder = TRUE;
		if( m_nIndex==STGY_CUSTOM && m_bMode==0 )
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.Height()+33);
		else if( m_bMode==2 )
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.Height()+16);
		else
			MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.Height());

		AdjustWindowH_Order();

		//m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top+33,m_RectEd2.Width(),m_RectEd2.Height());
		//m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top+33,m_RectEd3.Width(),m_RectEd3.Height());
		//m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top+33,m_RectLst2.Width(),m_RectLst2.Height());
		LoadData();
		break;
	}

	*pResult = 0;
}

void CStrategy::OnSetfocusEditIv1() 
{
	// TODO: Add your control notification handler code here
	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
	g_pDlg = this;
	g_hHook = ::SetWindowsHookEx(WH_KEYBOARD, HookProc, 0, ::GetCurrentThreadId());
}

void CStrategy::OnSetfocusEditIv2() 
{
	// TODO: Add your control notification handler code here
	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
	g_pDlg = this;
	g_hHook = ::SetWindowsHookEx(WH_KEYBOARD, HookProc, 0, ::GetCurrentThreadId());

}

void CStrategy::OnSetfocusEditIv3() 
{
	// TODO: Add your control notification handler code here
	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
	g_pDlg = this;
	g_hHook = ::SetWindowsHookEx(WH_KEYBOARD, HookProc, 0, ::GetCurrentThreadId());

}

void CStrategy::OnBtnCk() 
{
	if( m_nIndex==17 )
	{
		CCalendar dlg;
		dlg.m_pStgy = this;
		if( dlg.DoModal()==IDOK )
		{
			InitDays();
		}
		else
			return;
	}
	else if( m_nIndex==18 )
	{
		CDiagonal dlg;
		dlg.m_pStgy = this;
		if( dlg.DoModal()==IDOK )
		{
			InitDays();
		}
		else
			return;
	}

	if( m_nIndex!=17 && m_nIndex!=18 && m_nIxStrike==m_nIx1 && m_nIxStrike2==m_nIx2 && m_nIxStrike3==m_nIx3 && m_nIxStrike4==m_nIx4 )
	{
		return;
	}

	if( m_nIndex<=1 )
	{
		if( m_nIx1<m_nIx2 && m_nIx2<m_nIx3 )
		{
			m_nIxStrike = m_nIx1;
			m_nIxStrike2 = m_nIx2;
			m_nIxStrike3 = m_nIx3;
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
			m_ComBoxStrike3.SetCurSel(m_nIxStrike3);
		}
		else
		{
			MessageBox(szStkTip1[m_TTOptions->m_iLangType], "Tips",MB_OK);
			m_nIx1 = m_nIxStrike;
			m_nIx2 = m_nIxStrike2;
			m_nIx3 = m_nIxStrike3;
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
			m_ComBoxStrike3.SetCurSel(m_nIxStrike3);
			return;
		}
	}
	else if( m_nIndex==6 )
	{
		if( m_nIx1<m_nIx2 && m_nIx2<m_nIx3+m_nPos && m_nIx3<m_nIx4 )
		{
			m_nIxStrike = m_nIx1;
			m_nIxStrike2 = m_nIx2;
			m_nIxStrike3 = m_nIx3;
			m_nIxStrike4 = m_nIx4;
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
			m_ComBoxStrike3.SetCurSel(m_nIxStrike3);
			m_ComBoxStrike4.SetCurSel(m_nIxStrike4);
		}
		else
		{
			MessageBox(szStkTip1[m_TTOptions->m_iLangType], "Tips",MB_OK);
			m_nIx1 = m_nIxStrike;
			m_nIx2 = m_nIxStrike2;
			m_nIx3 = m_nIxStrike3;
			m_nIx4 = m_nIxStrike4;
			m_ComBoxStrike.SetCurSel(m_nIxStrike);
			m_ComBoxStrike2.SetCurSel(m_nIxStrike2);
			m_ComBoxStrike3.SetCurSel(m_nIxStrike3);
			m_ComBoxStrike4.SetCurSel(m_nIxStrike4);
			return;
		}
	}

	for( int ii=0;ii<3;ii++ )
	{
		m_bResetBF[ii] = TRUE;	
		m_bAlterPrice[ii] = FALSE;
		m_bAlterPrice2[ii] = FALSE;
	}
	
	SetListMode();
	int ordercount = m_nOrderCount;
	ClearFlag();
	m_nOrderCount = ordercount;
	
	m_nRetn = PrePaint();
	SelectType();
	if( m_nRetn==0 )
		return;
	
	DrawIncomeLine();
}

void CStrategy::OnClickList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW  *pEditCtrl = (NM_LISTVIEW *)pNMHDR;
	
	for( int i=0;i<m_arrNum.GetSize();i++ )
	{
		if( pEditCtrl->iSubItem==11 && pEditCtrl->iItem==m_arrNum[i].nItem )
		{
			if( IDNO==MessageBox(szDelTips[m_TTOptions->m_iLangType],"Tips",MB_YESNO) )
				break;
			
			int inum = 0;
			for( int j=0;j<m_StgyList.GetSize();j++ )
			{
				if( m_StgyList[i].m_lExpTime==m_StgyList[j].m_lExpTime && strcmp(m_StgyList[i].m_szCode,m_StgyList[j].m_szCode)==0
					&& m_ExtList[i].b_weekly==m_ExtList[j].b_weekly )
					inum++;
			}
			if( inum==1 )
			{
				long lTransdate = m_StgyList[i].m_lExpTime/100;
				if( m_ExtList[i].b_weekly==1 )
					lTransdate = m_StgyList[i].m_lExpTime;
				m_TTOptions->SendUpdateRP(FALSE,m_StgyList[i].m_szCode,lTransdate);
				if( m_ExtList[i].cald.lMonth2!=0 )
				{
					long lm = m_ExtList[i].cald.lMonth2;
					if( m_ExtList[i].b_Mth2_Weekly==0 )
						lm = lm/100;
					m_TTOptions->SendUpdateRP(FALSE,m_StgyList[i].m_szCode,lm);
				}
			}
			
			if( m_ExtList.GetSize()==m_StgyList.GetSize() )
				m_ExtList.RemoveAt(i);
			m_StgyList.RemoveAt(i);
			SaveStgyHistoryFile();

			int count = 0;
			if( i==m_arrNum.GetSize()-1 )
				count = m_list2.GetItemCount()-m_arrNum[i].nItem;
			else
				count = m_arrNum[i+1].nItem - m_arrNum[i].nItem;
			for( int k=0;k<count;k++ )
				m_list2.DeleteItem(m_arrNum[i].nItem);

			m_arrNum.RemoveAt(i);
			for( k=i;k<m_arrNum.GetSize();k++ )
			{
				m_arrNum[k].nItem -= count;
			}
			m_list2.Invalidate();
			break;
		}
	}
	
	
	*pResult = 0;
}

void CStrategy::OnDblclkList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW  *pList = (NM_LISTVIEW *)pNMHDR;

	int i,j,ix;
	if( m_bDrawing )
	{
		return;
	}

	BOOL bTemp = FALSE;
	m_bTransColor = FALSE;
	for( i=0;i<6;i++ )
		m_bPrice[i] = TRUE;

	for( i=0;i<m_arrNum.GetSize();i++ )
	{
		if( pList->iItem==m_arrNum[i].nItem )
		{
			m_list2.EnableWindow(FALSE);
			memset(&m_TTOptions->m_StgyFile,0,sizeof(StgyHistoryFile));
			memset(&m_ExtRecord,0,sizeof(StgyFileExt));
			m_ExtRecord = m_ExtList[i];
			m_bTarget = m_ExtRecord.b_RNG;
			m_fTargetLo = m_ExtRecord.f_Lo;
			m_fTargetUp = m_ExtRecord.f_Up;
			m_bWeekly = m_ExtRecord.b_weekly;

			m_cald.bDebit = m_ExtRecord.cald.bDebit;
			m_cald.bCall = m_ExtRecord.cald.bCall;
			m_cald.lMonth1 = m_ExtRecord.cald.lMonth1;
			
			long lm = m_ExtRecord.cald.lMonth2;
			if( m_ExtRecord.b_Mth2_Weekly==0 )
				lm = lm/100;
			m_cald.lMonth2 = lm;
			m_cald.fStrike = m_ExtRecord.cald.fStrike;
			m_fStrike2_Spread = m_ExtRecord.m_fStrike2_Spread;
			//memcpy(&m_TTOptions->m_StgyFile, &m_StgyList[i], sizeof(m_StgyList[i]));
			ix = m_nIndex;
			if( !m_arrNum[i].bPrice )
				m_bTransColor = TRUE;
			if( m_StgyList[i].m_iCustomIx[6]==1 )
				m_nIndex = m_StgyList[i].m_iCustomIx[7];
			else
				m_nIndex = m_StgyList[i].m_fCapital;

		//	m_cald.bDebit = m_ExtRecord.cald.bDebit;
		//	m_cald.bCall = m_ExtRecord.cald.bCall;
		//	m_cald.lMonth1 = m_ExtRecord.cald.lMonth1;
		//	m_cald.lMonth2 = m_ExtRecord.cald.lMonth2/100;  //�����ʱ���ǵ����գ���ȡ��ʱ�����
		//	m_cald.fStrike = m_ExtRecord.cald.fStrike;
			//m_nIndex = m_StgyList[i].m_iStgyIx;
			SwitchCtrl();
			m_ComBoxType.SetCurSel(m_nIndex);
			m_ComBoxStrike.EnableWindow(FALSE);
			m_ComBoxStrike2.EnableWindow(FALSE);
			m_ComBoxStrike3.EnableWindow(FALSE);
			m_ComBoxStrike4.EnableWindow(FALSE);
			m_btnJianc.EnableWindow(FALSE);
			m_ComBoxType.EnableWindow(FALSE);
			m_nOrderCount = m_StgyList[i].m_nCount;
			m_bUseRecord = TRUE;
			m_bDbClick = TRUE;
			m_fScale = 0.0;
			m_iDbClickInx = m_arrNum[i].nItem;

			m_TTOptions->DateDiff(m_StgyList[i].m_lExpTime,m_StgyList[i].m_lDate,m_InvestDays);
			m_ExpValue = m_StgyList[i].m_ExpValue;
			m_fHStgyPB = m_StgyList[i].m_fPB;
			m_bYte = m_StgyList[i].m_iCustomIx[6];
			m_fCapital = m_StgyList[i].m_fCapital;

			for( j=0;j<6;j++ )
			{
				if( j>3 )
				{
					m_TTOptions->m_StgyFile.m_fStrikeEx[j-4] = m_StgyList[i].m_fStrikeEx[j-4];
					m_fLPrice[j] = m_StgyList[i].m_fPriceEx[j-4];
				}
				else
				{
					m_TTOptions->m_StgyFile.m_fStrike[j] = m_StgyList[i].m_fStrike[j];
					m_fLPrice[j] = m_StgyList[i].m_fPrice[j];
				}

				if( m_nIndex==STGY_CUSTOM )
				{
					m_nCustomCount[j] = m_StgyList[i].m_iCustomCount[j];
					m_nCustomIx[j] = m_StgyList[i].m_iCustomIx[j];
					if( m_nCustomIx[j]==4 )
						bTemp = TRUE;
				}
			}
			
			if( ix!=STGY_CUSTOM && m_nIndex==STGY_CUSTOM && m_bMode==0 )
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top+33);
				m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top+33,m_RectLst2.Width(),m_RectLst2.Height());
				m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top+33,m_RectEd2.Width(),m_RectEd2.Height());
				m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top+33,m_RectEd3.Width(),m_RectEd3.Height());
				m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height()+33);
				m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height()+33);

				AdjustWindowH_Order();
			}
			else if( ix==STGY_CUSTOM && m_nIndex!=STGY_CUSTOM && m_bMode==0 )
			{
				MoveWindow(m_WinRect.left,m_WinRect.top,m_WinRect.Width(),m_WinRect.bottom-m_WinRect.top);
				m_edit2.MoveWindow(m_RectEd2.left,m_RectEd2.top,m_RectEd2.Width(),m_RectEd2.Height());
				m_edit3.MoveWindow(m_RectEd3.left,m_RectEd3.top,m_RectEd3.Width(),m_RectEd3.Height());
				m_list2.MoveWindow(m_RectLst2.left,m_RectLst2.top,m_RectLst2.Width(),m_RectLst2.Height());
				m_tab1.MoveWindow(m_TabClientRect.left,m_TabClientRect.top,m_TabClientRect.Width(),m_TabClientRect.Height());
				m_list.MoveWindow(m_RectLst1.left,m_RectLst1.top,m_RectLst1.Width(),m_RectLst1.Height());

				AdjustWindowH_Order();
			}
			
			m_nIxStrike = -2;
			m_nIxStrike2 = -2;
			m_nIxStrike3 = -2;
			m_nIxStrike4 = -2;
			m_nIxStrike5 = -2;
			m_nIxStrike6 = -2;//Ϊ�˺�-1���ֿ�

			for( j=0;j<3;j++ )
			{
				m_bResetBF[j] = TRUE;	
			}
			for( j=0;j<6;j++ )
			{
				m_fiSignPrice[j] = 0.0;
				m_bAlterPrice[j] = FALSE;
				m_bAlterPrice2[j] = TRUE;
			}
			if( m_bHaveCrt )
			{
				DestroyEdit(&m_list, m_editCrt, m_nItem, m_nSubItem, m_bHaveCrt);
			}
			if( m_bHaveCrt_Spin_C )
			{
				if( m_nIndex!=16 && !bTemp )
					DestroySpin(m_pSpin_C,m_bHaveCrt_Spin_C);
			}
			else
			{
				if( (m_nIndex==16 || bTemp)&&m_bMode==0 )
					CreateSpin(&m_list,m_pSpin_C,2,1,m_bHaveCrt_Spin_C);
			}
			if( m_bHaveCrt_Spin )
			{
				DestroySpin(m_pSpin,m_bHaveCrt_Spin);
				m_pBtn->DestroyWindow();
				if( ix==STGY_CUSTOM )
				{
					for( int j=0;j<5;j++ )
						DestroySpin(m_pSpinEx[j],m_bHaveCrt_Spin);
				}
			}

			m_bDrawing = TRUE;
			
			long ldate = m_StgyList[i].m_lExpTime/100;
			if( m_bWeekly==1 )
				ldate = m_StgyList[i].m_lExpTime;
			m_TTOptions->OnStgyDbClick(m_StgyList[i].m_szCode,ldate);
			
			if( m_nIndex!=17 && m_nIndex!=18 )
			{
				char code[9] = {0};
				m_TTOptions->GetCashOrFuturesCode(m_StgyList[i].m_szCode,m_StgyList[i].m_lExpTime, code);
				m_TTOptions->SendTeleHisCash(code);
			}
			else
				CalendarRequest();
			m_bDrawing = FALSE;
			m_TTOptions->OnSelectStrategy();

			break;
		}
	}
	
	*pResult = 0;
}

void CStrategy::OnMove(int x, int y) 
{
	CDialog::OnMove(x, y);
	
	int Height = m_WinRect.Height();
	int Height1 = m_TabRect.Height();
	GetWindowRect(m_WinRect);
	m_tab1.GetWindowRect(&m_TabRect);
	m_WinRect.bottom = m_WinRect.top+Height;
	m_TabRect.bottom = m_TabRect.top+Height1;
}



void CStrategy::OnKillfocusEditIv1() 
{
	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
}

void CStrategy::OnKillfocusEditIv2() 
{
	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
}

void CStrategy::OnKillfocusEditIv3() 
{
	if( g_hHook )
	{
		::UnhookWindowsHookEx(g_hHook);
		g_hHook = NULL;
	}
}

BOOL CStrategy::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
/*	if( m_bMode==1 )
		return CDialog::OnMouseWheel(nFlags, zDelta, pt);
	CRect frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);	
	int nCount = m_arrPL[0].GetSize();
	if( frmrect.PtInRect(pt) && nCount!=0 && m_bDrawing==FALSE )
	{
		m_nRetn = PrePaint();
		if( m_nRetn==1 )
		{
			if( zDelta>0 )
			{
				if( m_fScale==m_fLimitScale )
					return CDialog::OnMouseWheel(nFlags, zDelta, pt);
				m_fScale -= 0.2;
			}
			else if( zDelta<0 )
			{
				m_fScale += 0.2;
			}
			m_bFillList = FALSE;
			DrawIncomeLine();
		}
	}*/
	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}

void CStrategy::OnLButtonDown(UINT nFlags, CPoint point) 
{	
	if( m_bMode==1 )
		return ;

	CRect frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);	
	CRect rct(frmrect.left,frmrect.top+35,frmrect.right,frmrect.bottom-40);
	if( !m_bUseRecord && rct.PtInRect(point)  )
	{
		m_btMouseGet = 1;
		m_btMouseRelease = 0;
		BOOL bDraw = FALSE;
		if( point.x>=m_cx_TgtLo-3 && point.x<=m_cx_TgtLo+3 )
		{
			m_bSelectLo = TRUE;
			m_bSelectUp = FALSE;
		}
		else if( point.x>=m_cx_TgtUp-3 && point.x<=m_cx_TgtUp+3 )
		{
			m_bSelectLo = FALSE;
			m_bSelectUp = TRUE;
		}
		else
		{
			if( m_bSelectLo || m_bSelectUp )
			{
				m_bSelectLo = FALSE;
				m_bSelectUp = FALSE;
				bDraw = TRUE;
			}
		}
		int nCount = m_arrPL[0].GetSize();
		if( (m_bSelectLo || m_bSelectUp) && m_nRetn==1 && nCount!=0 && m_bDrawing==FALSE )
			bDraw = TRUE;
		if( bDraw )
		{
			m_point = point;
			m_bPainted = FALSE;
			DrawIncomeLine();
		}
	}

	int x1 = frmrect.right-80+2+12;
	int y1 = frmrect.bottom-16-12+10;
	int x2 = frmrect.right-56+2+12+10;
	int y2 = frmrect.bottom-16-12+10;;
	int r = 12;
	m_bBtnDown[0] = FALSE;
	m_bBtnDown[1] = FALSE;
	if( (pow(point.x-x1,2)+pow(point.y-y1,2))<=r*r )
	{
		m_bBtnDown[0] = TRUE;
		m_bPainted = FALSE;
		DrawIncomeLine();
	}
	else if( (pow(point.x-x2,2)+pow(point.y-y2,2))<=r*r )
	{
		m_bBtnDown[1] = TRUE;
		m_bPainted = FALSE;
		DrawIncomeLine();
	}


	CDialog::OnLButtonDown(nFlags, point);
}

void CStrategy::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if( m_bMode==1 )
		return ;

	CRect frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);
	
	if( (m_bSelectLo || m_bSelectUp) && m_btMouseGet==1 && m_btMouseRelease==0 )
	{
		int nCount = m_arrPL[0].GetSize();
		if( m_nRetn==1 && nCount!=0 && m_bDrawing==FALSE )
		{
			m_point = point;
			m_bPainted = FALSE;
			m_btMouseGet = 0;
			m_btMouseRelease = 1;
			DrawIncomeLine();
		}
	}

	if( (m_bSelectLo || m_bSelectUp) && m_btMouseGet==0 && m_btMouseRelease==1 )
	{
		int nCount = m_arrPL[0].GetSize();
		if( m_nRetn==1 && nCount!=0 && m_bDrawing==FALSE )
		{
			m_point = point;
			m_bPainted = FALSE;
			m_bSelectLo = FALSE;
			m_bSelectUp = FALSE;
			DrawIncomeLine();
		}
	}

	int x1 = frmrect.right-80+2+12;
	int y1 = frmrect.bottom-16-12+10;
	int x2 = frmrect.right-56+2+12+10;
	int y2 = frmrect.bottom-16-12+10;;
	int r = 12;
	m_bBtnDown[0] = FALSE;
	m_bBtnDown[1] = FALSE;
	if( (pow(point.x-x1,2)+pow(point.y-y1,2))<=r*r )
	{
		m_nRetn = PrePaint();
		if( m_fScale==m_fLimitScale )
			;
		else
			m_fScale -= 0.2;
		m_bFillList = FALSE;
		DrawIncomeLine();
	}
	else if( (pow(point.x-x2,2)+pow(point.y-y2,2))<=r*r )
	{
		m_nRetn = PrePaint();
		m_fScale += 0.2;
		m_bFillList = FALSE;
		DrawIncomeLine();
	}

	CDialog::OnLButtonUp(nFlags, point);
}

void CStrategy::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	DestroyWindow();
	//CDialog::OnClose();
}

void CStrategy::OnTarget() 
{
	// TODO: Add your command handler code here
	if( m_bTarget==0 )
	{
		m_bTarget = 1;
		InitTargetRange();
	}
	else
	{
		m_bTarget = 0;
		m_fLimitScale = 0.0;
	}
	
	m_nRetn = PrePaint();
	if( m_nRetn==0 )
		return;
	m_bPainted = TRUE;
	DrawIncomeLine();
}

void CStrategy::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	int nCount = m_arrPL[0].GetSize();
	if( nCount==0 )
		return;
	CRect frmrect;
	m_frame.GetWindowRect(&frmrect);
	ScreenToClient(&frmrect);
	frmrect.top += 25;
	frmrect.bottom -= 50;
	if( !m_bUseRecord && m_bTarget==1 && frmrect.PtInRect(point) )
	{
		CString strLo,strUp;
		GetPriceTxt(m_fTargetLo,strLo,1);
		GetPriceTxt(m_fTargetUp,strUp,1);
		m_TargetDlg.m_fLo = atof(strLo);
		m_TargetDlg.m_fUp = atof(strUp);
		if( m_TargetDlg.DoModal()==IDOK )
		{
			float fLo = m_TargetDlg.m_fLo;
			float fUp = m_TargetDlg.m_fUp;
			float fLimt1 = m_arrItem[iSign].m_fStrike-4*5*(m_arrItem[iSign].m_fStrike-m_arrItem[iSign-1].m_fStrike);
			float fLimt2 = m_arrItem[iSign].m_fStrike+5*5*(m_arrItem[iSign].m_fStrike-m_arrItem[iSign-1].m_fStrike);
			if( fLo>fUp )
			{
				AfxMessageBox("Upper Price should greater than Lower Price");
				return;
			}
			else if( fLo<fLimt1 || fLo>fLimt2 || fUp<fLimt1 || fUp>fLimt2 )
			{
				char msg[100];
				sprintf(msg,"please input: %.0f ~ %.0f",fLimt1,fLimt2);
				AfxMessageBox(msg);
				return;
			}
			m_fTargetLo = m_TargetDlg.m_fLo;
			m_fTargetUp = m_TargetDlg.m_fUp;
			m_fScale = 0.0;
			m_nRetn = PrePaint();
			if( m_nRetn==0 )
				return;
			m_bPainted = TRUE;
			DrawIncomeLine();
		}
	}

	CDialog::OnLButtonDblClk(nFlags, point);
}

BOOL CStrategy::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	SetCursor(m_hCursor);
	return TRUE;
//	return CDialog::OnSetCursor(pWnd, nHitTest, message);
}

void CStrategy::OnRclickList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
/*	CMenu menu; 
	CRect rect;
	m_pbtnStra->GetWindowRect(&rect);
	menu.LoadMenu(IDR_MENU2); 
	CMenu   *pContextMenu=menu.GetSubMenu(0); 
	pContextMenu->ModifyMenu(IDC_MENU_STGY,MF_BYCOMMAND|MF_STRING,IDC_MENU_STGY,szModeStgy[m_iLangType]);
	pContextMenu->ModifyMenu(IDC_MENU_PAIN,MF_BYCOMMAND|MF_STRING,IDC_MENU_PAIN,szModePain[m_iLangType]);
	RECT rect1;
	rect1.left = rect.left;
	rect1.right = rect.right;
	rect1.top = rect.top;
	pContextMenu->TrackPopupMenu(TPM_LEFTALIGN,rect.left,rect.bottom,m_pbtnStra,&rect1);*/	
	
	*pResult = 0;
}
