// btnWithTip.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "btnWithTip.h"
#include "TTOptions.h"
#include "Strategy.h"
#include <afxcmn.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CbtnWithTip

CbtnWithTip::CbtnWithTip()
{
	m_pToolTipCtrl1 = new CToolTipCtrl() ;
	ASSERT( m_pToolTipCtrl1!=NULL ) ;
	m_TTOptions = NULL;
}

CbtnWithTip::~CbtnWithTip()
{
	if( m_pToolTipCtrl1!=NULL )
	{
		delete m_pToolTipCtrl1 ;
		m_pToolTipCtrl1 = NULL ;
	}

}


BEGIN_MESSAGE_MAP(CbtnWithTip, CButton)
	//{{AFX_MSG_MAP(CbtnWithTip)
	ON_WM_MOUSEMOVE()
	ON_WM_DESTROY()
	ON_COMMAND(IDC_MENU_STGY, OnMenuStgy)
	ON_COMMAND(IDC_MENU_PAIN, OnMenuPain)
	ON_COMMAND(IDC_MENU_NORMAL, OnMenuNormal)
	ON_COMMAND(IDC_MENU_IV, OnMenuIV)
	ON_COMMAND(IDC_MENU_PB, OnMenuPB)
	ON_COMMAND(IDC_MENU_GK, OnMenuGK)
	ON_COMMAND(IDC_MENU_OI, OnMenuOI)
	ON_COMMAND(IDC_MENU_MG, OnMenuMG)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CbtnWithTip message handlers

void CbtnWithTip::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CButton::OnMouseMove(nFlags, point);
	if( m_pToolTipCtrl1->m_hWnd!=NULL )
	{
		MSG msg;
		msg.hwnd = m_hWnd;
		msg.message = WM_MOUSEMOVE;
		msg.wParam = 0 ;
		msg.lParam = 0 ;
		msg.time = 0;
		msg.pt.x = point.x ;
		msg.pt.y = point.y ;
		m_pToolTipCtrl1->RelayEvent(&msg);

	}

}

void CbtnWithTip::OnDestroy() 
{
	// ToolTipCtrl������ʱ, DestroyWindow(), ����˼��!
	if( m_pToolTipCtrl1!=NULL )
	{
		delete m_pToolTipCtrl1 ;
		m_pToolTipCtrl1 = NULL ;
	}
	CButton::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

void CbtnWithTip::OnMenuNormal() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
		if( m_TTOptions!=NULL )
		{
			if( m_TTOptions->m_bIVMode==0 )
				return;
			m_TTOptions->m_bIVMode = 0;
			m_TTOptions->OnSelectModeMenu();
			
		}
}

void CbtnWithTip::OnMenuIV() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
		if( m_TTOptions!=NULL )
		{
			if( m_TTOptions->m_bIVMode==1 )
				return;
			m_TTOptions->m_bIVMode = 1;
			m_TTOptions->OnSelectModeMenu();
			
		}
}

void CbtnWithTip::OnMenuPB() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
		if( m_TTOptions!=NULL )
		{
			if( m_TTOptions->m_bIVMode==2 )
				return;
			m_TTOptions->m_bIVMode = 2;
			m_TTOptions->OnSelectModeMenu();
			
		}
}

void CbtnWithTip::OnMenuGK() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
		if( m_TTOptions!=NULL )
		{
			if( m_TTOptions->m_bIVMode==3 )
				return;
			m_TTOptions->m_bIVMode = 3;
			m_TTOptions->OnSelectModeMenu();
			
		}
}

void CbtnWithTip::OnMenuOI() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
		if( m_TTOptions!=NULL )
		{
			if( m_TTOptions->m_bIVMode==4 )
				return;
			m_TTOptions->m_bIVMode = 4;
			m_TTOptions->OnSelectModeMenu();
			
		}
}

void CbtnWithTip::OnMenuMG() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
		if( m_TTOptions!=NULL )
		{
			if( m_TTOptions->m_bIVMode==5 )
				return;
			m_TTOptions->m_bIVMode = 5;
			m_TTOptions->OnSelectModeMenu();
			
		}
}

void CbtnWithTip::OnMenuStgy() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
	if( m_TTOptions!=NULL )
	{
		int mode = m_TTOptions->m_bStgyMode;
		if( mode!=0 )
		{
			m_TTOptions->m_bChanged = TRUE;
			m_TTOptions->m_bStgyMode = 0;
		}
		m_TTOptions->OnSelectStrategy();
		
	}
}

void CbtnWithTip::OnMenuPain() 
{	
	AFX_MANAGE_STATE(AfxGetStaticModuleState( )) 
	if( m_TTOptions!=NULL )
	{
		int mode = m_TTOptions->m_bStgyMode;
		if( mode!=1 )
		{
			m_TTOptions->m_bChanged = TRUE;
			m_TTOptions->m_bStgyMode = 1;
		}
		m_TTOptions->OnSelectStrategy();
		
	}
}
