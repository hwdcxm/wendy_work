// updateflag.h: interface for the UPDATEFLAG class.
//
//////////////////////////////////////////////////////////////////////
#pragma pack(1)
typedef struct
{
	long lTransdate;				//for yyyy mm 
	int	 nItemIndex;				//Item code index 
	float fStrikePrice;				//strike price
	char  bSort;						// Sort flag
	char  cbDelStrike;
	char  cbDelMM;
	//int  nColIndex;					// price field  index to update
}	UPDATEFLAG;
#pragma pack(8)



