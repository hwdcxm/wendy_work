#if !defined(AFX_DLGMONTH_H__81AA5E37_B8D7_11D3_AF26_00A0CC23E698__INCLUDED_)
#define AFX_DLGMONTH_H__81AA5E37_B8D7_11D3_AF26_00A0CC23E698__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlgMonth.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CdlgMonth dialog

class CdlgMonth : public CDialog
{
// Construction
public:
	CdlgMonth(CWnd* pParent = NULL,int iLangType = 0);   // standard constructor
	int m_iLangType;
	static void ClearMonth();
	static void AddItemCode(LPCTSTR pszItemCode);
	static void AddMonth(long lMonth) ;

public:
	static long  m_lMonth[24];
	static long  m_lSelMonth;
	static BYTE  m_cbMonthNum;
	static char  m_szItemCode[9];
	static int   m_nSel;

	BOOL m_bInit ;

public:
// Dialog Data
	//{{AFX_DATA(CdlgMonth)
	enum { IDD = IDD_OPMONTHDLG };
	CListBox	m_listboxMonth;
	CEdit	m_edtItem;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CdlgMonth)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual BOOL OnInitDialog();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CdlgMonth)
	virtual void OnOK();
	afx_msg void OnDblclkLbMonth();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGMONTH_H__81AA5E37_B8D7_11D3_AF26_00A0CC23E698__INCLUDED_)
