#if !defined(AFX_BTNINLIST_H__AB01E031_3B44_4162_95BE_7A513405C6D3__INCLUDED_)
#define AFX_BTNINLIST_H__AB01E031_3B44_4162_95BE_7A513405C6D3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// btnInList.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CbtnInList window
#define MACRO_Btn_Save_ID           612

class CStrategy;
class CbtnInList : public CButton
{
// Construction
public:
	CbtnInList();
	CStrategy *m_pStgy;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CbtnInList)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CbtnInList();

	// Generated message map functions
protected:
	//{{AFX_MSG(CbtnInList)
	afx_msg void OnClicked();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BTNINLIST_H__AB01E031_3B44_4162_95BE_7A513405C6D3__INCLUDED_)
