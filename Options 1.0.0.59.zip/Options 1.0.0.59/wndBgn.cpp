// wndBgn.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "wndBgn.h"
#include "TTOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CwndBgn

CString CwndBgn::m_strMyClass = "" ;
CwndBgn::CwndBgn()
{
	m_pOwner = NULL ;

	// load stock cursor, brush, and icon for
	// my own window class

	if( m_strMyClass.GetLength()<=0 )
	{
		AFX_MANAGE_STATE(AfxGetStaticModuleState())

		try
		{
		   m_strMyClass = AfxRegisterWndClass(
			  CS_VREDRAW | CS_HREDRAW,
			  ::LoadCursor(NULL, IDC_ARROW),
			  (HBRUSH) ::GetStockObject(LTGRAY_BRUSH),
			  NULL );
		}
		catch (CResourceException* pEx)
		{
//			  AfxMessageBox(
//				 _T("Couldn't register class! (Already registered?)"));
			  pEx->Delete();
		}

	}

}

CwndBgn::~CwndBgn()
{
}


BEGIN_MESSAGE_MAP(CwndBgn, CWnd)
	//{{AFX_MSG_MAP(CwndBgn)
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(MACRO_BtnItemCodeID, OnSelectItemCode)
	ON_BN_CLICKED(MACRO_BtnOptMonthID, OnSelectMonth)
	ON_BN_CLICKED(MACRO_BtnHighPriceID, OnSelectHighPrice)
	ON_BN_CLICKED(MACRO_BtnColumnWidthID, OnSelectColumnWidth)
	ON_BN_CLICKED(MACRO_Btn_IV_ID, OnSelectIVMode)
	ON_BN_CLICKED(MACRO_Btn_Simple_ID, OnSelectSimple)
	ON_BN_CLICKED(MACRO_Btn_ExportCSV_ID, OnSelectExportCSV)
	ON_BN_CLICKED(MACRO_Btn_Stra_ID, OnSelectStrategy)
	ON_MESSAGE( MACRO_MsgUpdateCtrls, OnUpdateCtrls ) 
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CwndBgn message handlers

LRESULT CwndBgn::OnUpdateCtrls(WPARAM arg1, LPARAM)
{
	if( m_pOwner!=NULL )
	{
		//m_pOwner->UpdateCtrls( arg1 );
			// arg1<0,  Update all ctrls.
	}
	return 0;

}

void CwndBgn::OnSelectItemCode() 
{
	if( m_pOwner!=NULL )
	{
		m_pOwner->m_bSelectWin = 0;
		m_pOwner->OnSelectItemCode() ;
	}

}

void CwndBgn::OnSelectMonth() 
{
	if( m_pOwner!=NULL )
	{
		m_pOwner->OnSelectMonth() ;
	}

}

void CwndBgn::OnSelectHighPrice() 
{//btn show/hide high/low price
	if( m_pOwner!=NULL )
	{
		m_pOwner->OnSelectHighPrice() ;
	}

}

void CwndBgn::OnSelectColumnWidth() 
{//btn reformat column width
	if( m_pOwner!=NULL )
	{
		m_pOwner->OnSelectColumnWidth() ;
	}

}

void CwndBgn::OnSelectIVMode() 
{//btn show/hide high/low price
	if( m_pOwner!=NULL )
	{
		m_pOwner->OnSelectIVMode() ;
	}

}

void CwndBgn::OnSelectSimple() 
{//btn simple mode
	if( m_pOwner!=NULL )
	{
		m_pOwner->OnSelectSimple() ;
	}

}

void CwndBgn::OnSelectExportCSV() 
{//export csv
	if( m_pOwner!=NULL )
	{
		m_pOwner->OnSelectExportCSV() ;
	}

}

void CwndBgn::OnSelectStrategy() 
{
	if( m_pOwner!=NULL )
	{
		m_pOwner->PopMenu() ;
	}
}


void CwndBgn::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CRect rec;
	GetClientRect(&rec);
//	dc.FillSolidRect(rec,GetSysColor(COLOR_MENU));

	dc.FillSolidRect(rec,GetSysColor(COLOR_3DFACE));
	// Do not call CWnd::OnPaint() for painting messages
}











HBRUSH CwndBgn::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CWnd::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if(nCtlColor == CTLCOLOR_STATIC)
    {
        
        if(pWnd == m_pOwner->m_pstaExpiryDate && m_pOwner->m_lTransdate>10000000 )
			pDC->SetTextColor(RGB(255,0,0));
	}
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}
