
/*
	Black Model 1976:
		
		  ����Black�� 1976�귢���� �ڻ���Option�� model.

*/


#include "stdafx.h"
#include "BM1976.h"
#include "PolyNormalTable.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int WriteLogFile(LPTSTR strLog)
{
	char strTime[100];
	SYSTEMTIME sysTime;
	GetLocalTime(&sysTime);

	HANDLE m_hLogFile;
	char strFileDir[200];
	char strTemp[50];
	sprintf(strTemp,"\\W2TOptionsIV-%04d%02d%02d.LOG",sysTime.wYear,sysTime.wMonth,sysTime.wDay);
	
	memset(strFileDir, 0, sizeof(strFileDir));
	GetCurrentDirectory(200, strFileDir);
	strcat(strFileDir, strTemp);
	
	m_hLogFile = CreateFile(strFileDir, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE,
		NULL, OPEN_ALWAYS, 0, NULL);
	
	if(m_hLogFile == INVALID_HANDLE_VALUE)
		return 1;
	
	SetFilePointer(m_hLogFile, 0, NULL, FILE_END);
	
	unsigned long nByteWrite = 0;
	char strMsg[1000];
	memset(strMsg, 0, sizeof(strMsg));
	
	
	sprintf(strTime, "%d-%02d-%02d %02d:%02d:%02d", sysTime.wYear, sysTime.wMonth, 
		sysTime.wDay, sysTime.wHour, sysTime.wMinute, sysTime.wSecond);
	
	lstrcpy(strMsg, strTime);
	lstrcat(strMsg, "     ");
	lstrcat(strMsg, strLog);
	lstrcat(strMsg, "\r\n");
	
	WriteFile(m_hLogFile, strMsg, lstrlen(strMsg), &nByteWrite, NULL);
	
	CloseHandle(m_hLogFile);
	return 1;
}

BOOL CBM1976Wrapper::CalMOP_ByBM1976( WARRANTOPT& warOpt,				
						  BSMCALINFO& echoInfo ) 
{
	return CalMOP_ByBM1976( warOpt.bCallOption, 
						 warOpt.bIndex,
						 warOpt.PaiXi_1,
						 warOpt.PaiXi_2,
						 warOpt.warrantPrice,
						 warOpt.conversionRatio,
						 warOpt.currentAssetPrice, 
						 warOpt.R,
						 warOpt.exercisePrice,
						 warOpt.T_t,
						 warOpt.riskFreeInterestRate,
						 warOpt.sd,
						 echoInfo ) ;
						
}

BOOL CBM1976Wrapper::CalMOP_ByBM1976( BOOL   bCallOption,		// ��call option��? 
								BOOL   bIndex,
								double PaiXi_1,
								double PaiXi_2,
							    double warrantPrice,			// ��֤�۸�
							    double conversionRatio,			// ���ɱ���
								double currentAssetPrice,		// ���ɼ۸�( ʵ�����ڻ��۸� )
								double R,						// ��Ϣ%	 
								double exercisePrice,			// ��ʹ��
								double T_t,						// �����ձ���
								double riskFreeInterestRate,	// �޷���Ͷ�ʻ�����
								double sd,						// ���Ƶ�Imply Volitility.
								BSMCALINFO& echoInfo ) 			// ������Ϣ.
{
	// c�������:		 http://finance-old.bi.no/~bernt/gcc_prog/recipes/recipes/node7.html#SECTION00720000000000000000
	// ����ָ��������: http://www.anthony-vba.kefra.com/vba/vba13.htm

	if( conversionRatio<=0.0 )
		return FALSE ;

	double F = currentAssetPrice ;
	//double F = (R==0.0) ? currentAssetPrice : currentAssetPrice*pow( MathE, -1.0*R*T_t ) ;	// ���ɼ۸�( ������Ϣ���� )


	double X = exercisePrice ;
	double r = riskFreeInterestRate/100 ;
	double time_sqrt = sqrt(T_t) ;

	double d1 = ( log( F/X ) + (r+0.5*sd*sd)*T_t ) /  ( sd*time_sqrt ) ;
	double d2 = d1 - sd*time_sqrt ;

	double N_d1  =  ( d1>0.0) ? N(d1) : 1.0-N(fabs(d1)) ;			// 
	double N_d2  =  ( d2>0.0) ? N(d2) : 1.0-N(fabs(d2)) ;			// 
	double Np_d1 =	pow( MathE, -0.5*d1*d1 ) / ( sqrt( 2.0*MathPI ) ) ;	// N'(d1)

	double delta,gamma,theta,vega;
	//////////////////////////////////////////////////  BSM  ģ��
	// ���� ��֤�۸�.
	double MOP ; 
	double MOP1 = ( F*N_d1 )- (pow( MathE, -1.0*r*T_t )*X*N_d2 );
	double MOP2 = MOP1 + X*pow( MathE, -1.0*r*T_t )-F;
	//����Excel�еĹ�ʽ�����ۼ۸����һЩ�Ķ�
	if( bIndex )
	{
		if( bCallOption==TRUE )
		{
			//double c  = pow( MathE, -1.0*r*T_t )*( F*N_d1 - X*N_d2 ) ;  //  call, �μ� <<An Introduction to Derivatives&Risk Management>> 336ҳ 		
			MOP = MOP1;
			MOP = MOP/conversionRatio ;
		}
		else
		{
			//double p  = X*pow( MathE, -1.0*r*T_t )*(1.0-N_d2) - F*pow( MathE, -1.0*r*T_t )*(1.0-N_d1) ;	//  put,  �μ� <<An Introduction to Derivatives&Risk Management>> 339ҳ 	
			MOP = MOP2;
			MOP = MOP/conversionRatio ;
		}
	}
	//////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////������ģ��
	else
	{
		double D_t = T_t/CONST_STEP;
		double sd_u = exp(sd*sqrt(D_t));
		double sd_d = exp(-1.0*sd*sqrt(D_t));
		double p = (exp(r*D_t)-sd_d)/(sd_u-sd_d);
		int i,j,k;
		double Binominal[CONST_STEP][CONST_STEP];
		double MOP_Step[CONST_STEP];
		double Price_Step[CONST_STEP+1];
		memset(MOP_Step,0,CONST_STEP*sizeof(double));
		memset(Price_Step,0,(CONST_STEP+1)*sizeof(double));
		memset(Binominal,0,CONST_STEP*CONST_STEP*sizeof(double));
		double MOPStep2;
		double Delta_Step1_1,Delta_Step1_2;
		double opt_u,opt_d;
		double S_u = F*sd_u;
		double S_d = F*sd_d;
		int nStep1,nStep2;
		if( PaiXi_1==0.0 )
		{
			Price_Step[0] = F;
			nStep1 = 0;
		}
		else
		{
			nStep1 = int(PaiXi_1/100);
			nStep2 = int(PaiXi_2/100);
			PaiXi_1 -= nStep1*100;
			PaiXi_2 -= nStep2*100;   
			if( nStep1<2 )
			{
				nStep1 = 2;  //�������greeks
			}
			else if( nStep1==CONST_STEP )
			{
				nStep1 = 0;
				Price_Step[0] = F;
				PaiXi_2 += PaiXi_1;
			}
		}
		for( i=nStep1;i>0;i-- )
		{
			Price_Step[nStep1-i] = F*pow(sd_u,i)*pow(sd_d,nStep1-i)-PaiXi_1;
			i--;
			Price_Step[nStep1-i] = F*pow(sd_u,i)*pow(sd_d,nStep1-i)-PaiXi_1;
			i++;
		}

		double tempPrice = 0.0;
		if( bCallOption==TRUE )
		{
			for( j=0;j<=nStep1;j++ )
			{
				for( i=CONST_STEP;i>nStep1;i-- )
				{
					opt_u = Price_Step[j]*pow(sd_u,i-nStep1)*pow(sd_d,CONST_STEP-i)-X-PaiXi_2;
					if( opt_u<0.0 )
						opt_u = 0.0;
	
					i--;
					opt_d = Price_Step[j]*pow(sd_u,i-nStep1)*pow(sd_d,CONST_STEP-i)-X-PaiXi_2;
					if( opt_d<0.0 )
						opt_d = 0.0;
					i++;

					tempPrice = Price_Step[j]*pow(sd_u,i-nStep1-1)*pow(sd_d,CONST_STEP-i);
					Binominal[j][CONST_STEP-i] = (opt_u*p+opt_d*(1.0-p))/(1.0+r*D_t);
					if( Binominal[j][CONST_STEP-i]<(tempPrice-X) )
						Binominal[j][CONST_STEP-i] = tempPrice-X;
				}
			}
		}
		else
		{
			for( j=0;j<=nStep1;j++ )
			{
				for( i=CONST_STEP;i>nStep1;i-- )
				{
					opt_u = X-Price_Step[j]*pow(sd_u,i-nStep1)*pow(sd_d,CONST_STEP-i)-PaiXi_2;
					if( opt_u<0.0 )
						opt_u = 0.0;
					
					i--;
					opt_d = X-Price_Step[j]*pow(sd_u,i-nStep1)*pow(sd_d,CONST_STEP-i)-PaiXi_2;
					if( opt_d<0.0 )
						opt_d = 0.0;
					i++;

					tempPrice = Price_Step[j]*pow(sd_u,i-nStep1-1)*pow(sd_d,CONST_STEP-i);
					Binominal[j][CONST_STEP-i] = (opt_u*p+opt_d*(1.0-p))/(1.0+r*D_t);
					if( Binominal[j][CONST_STEP-i]<(X-tempPrice) )
						Binominal[j][CONST_STEP-i] = X-tempPrice;
				}
			}
		}

		int nCount = 0;
		if( nStep1==0 )
		{
			nCount = CONST_STEP-1;
			for( i=0;i<CONST_STEP;i++ )
				MOP_Step[i] = Binominal[0][i];
		}
		else
		{
			nCount = nStep1;
			for( i=0;i<=nStep1;i++ )
			{
				for( j=CONST_STEP-nStep1-1;j>0;j-- )
				{
					for( k=j;k>0;k-- )
					{
						tempPrice = Price_Step[i]*pow(sd_u,k-1)*pow(sd_d,j-k);
						if( j==1 )
							tempPrice = Price_Step[i]+PaiXi_1;
						Binominal[i][j-k] = (Binominal[i][j-k]*p+Binominal[i][j-k+1]*(1.0-p))/(1.0+r*D_t);
						if( bCallOption==TRUE )
						{
							if( Binominal[i][j-k]<tempPrice-X )
								Binominal[i][j-k] = tempPrice-X;
						}
						else
						{
							if( Binominal[i][j-k]<X-tempPrice )
								Binominal[i][j-k] = X-tempPrice;
						}
					}
				}
				MOP_Step[i] = Binominal[i][0];
			}
		}
		

		for( i=nCount;i>0;i-- )
		{
			if( i==2 )
			{
				Delta_Step1_1 = (MOP_Step[0]-MOP_Step[1])/(S_u*sd_u-S_u*sd_d);
				Delta_Step1_2 = (MOP_Step[1]-MOP_Step[2])/(S_u*sd_d-S_d*sd_d);
				MOPStep2 = MOP_Step[1];
			}
			if( i==1 )
				delta = (MOP_Step[0]-MOP_Step[1])/(S_u-S_d);
			for( j=i;j>0;j-- )
			{
				tempPrice = F*pow(sd_u,j-1)*pow(sd_d,i-j);
				MOP_Step[i-j] = (MOP_Step[i-j]*p+MOP_Step[i-j+1]*(1.0-p))/(1.0+r*D_t);
				if( i!=1 )
				{
					if( bCallOption==TRUE )
					{
						if( MOP_Step[i-j]<tempPrice-X )
							MOP_Step[i-j] = tempPrice-X;
					}
					else
					{
						if( MOP_Step[i-j]<X-tempPrice )
							MOP_Step[i-j] = X-tempPrice;
					}
				}
			}
		}
		MOP = MOP_Step[0];
		theta = (MOPStep2-MOP)/(D_t*2*365);
		gamma = (Delta_Step1_1-Delta_Step1_2)/(S_u-S_d);
	}
	///////////////////////////////////////////////////////////
	vega  = F*time_sqrt*Np_d1*0.01/conversionRatio  ;	// paul, 2008-4-30, *0.01/conversionRatio
	if( bIndex )
	{
	delta = ( bCallOption==TRUE ) ? N_d1 : N_d1-1.0 ;	// ÿ�� �Գ�ֵ
	gamma = Np_d1 / ( F*sd*time_sqrt ) ;
	theta = ( bCallOption==TRUE ) ? 
						-1.0*( F*Np_d1*sd / (2.0*time_sqrt) ) - r*X*pow( MathE, -1.0*r*T_t )*N_d2 : 
						-1.0*( F*Np_d1*sd / (2.0*time_sqrt) ) + r*X*pow( MathE, -1.0*r*T_t )*( 1-N_d2 ) ; 	
	theta = theta/(365.0*conversionRatio) ;	// paul, 2008-4-30
											// ben 2017.6.29   252��Ϊ365
	}


	double rho  =  ( bCallOption==TRUE ) ? 
						X*T_t*pow( MathE, -1.0*r*T_t )*N_d2 :
						-1.0*X*T_t*pow( MathE, -1.0*r*T_t )*( 1.0 - N_d2 ) ;

	// �����ʽ��վ��û��, jacky��excel����.
	double temp1 = F*time_sqrt ;
	double temp2 = 1.0/(sqrt(2.0*MathPI)) ;
	double temp3 = pow( MathE, -(d1*d1/2.0) ) ;
	double temp4 = temp1*temp2*temp3 ;
	double IV  = sd-(MOP-warrantPrice)/temp4 ;
	double IV_Sensitivity = (warrantPrice!=0.0) ? ( warrantPrice+vega )/warrantPrice*100.0-100.0 : 0.0 ;
	double TimeDecaysPerDay = (warrantPrice!=0.0) ? ( warrantPrice-theta )/warrantPrice*100.0-100.0 : 0.0 ;
	double omega = (warrantPrice!=0.0) ? currentAssetPrice*N_d1/(warrantPrice*conversionRatio) : 0.0 ;

	echoInfo.gamma = gamma ;
	echoInfo.impliedVolitility = IV ;
	echoInfo.modelledOptionPrice = MOP ;
	echoInfo.rho	= rho ;
	echoInfo.theta  = theta ;
	echoInfo.vega   = vega ;
	echoInfo.delta  = delta ;
	echoInfo.IV_Sensitivity = IV_Sensitivity ;
	echoInfo.TimeDecaysPerDay = TimeDecaysPerDay ;
	echoInfo.omega = omega ;
	echoInfo.ITM = N_d2;

	///////////////////////////////////////////////////
	
	///////////////////////////

	return TRUE ;

}

double CBM1976Wrapper::N( double sd ) 
{
	// ����ľ���ֻ��ȡ��С��λ4λ.
	//return CPolyNormalWrapper::CalPr_Below( sd ) ;
	
	// ��̬���ٶ���������? 
	if( sd>=0.0 )
	{
		return CPolyNormalWrapper::CalPolyNormal( sd )+0.5 ;
	}
	else
	{
		return 0.5 - CPolyNormalWrapper::CalPolyNormal( fabs(sd) ) ;
	}

}

BOOL CBM1976Wrapper::CalIV_ByCalculous( WARRANTOPT& warOpt, BSMCALINFO& echoInfo )
{
	// ��Ȼһֱ������ȥҲ���ܴﵽ��С���, ��֪��ʲôԭ��.
	memset( &echoInfo, 0, sizeof(echoInfo) ) ;
	int i = 0 ;
	do
	{
		if( CalMOP_ByBM1976( warOpt, echoInfo )==FALSE )
		{
			memset( &echoInfo, 0, sizeof(echoInfo) ) ;
			return FALSE ;
		}

		if( fabs( warOpt.warrantPrice-echoInfo.modelledOptionPrice )<=0.0001 )
			break ;
		warOpt.sd = echoInfo.impliedVolitility ;

		i++ ;
	}while( i<7 ) ;

	/*
		���һ��, Ҫ���� ������ֵ.
	*/
	WARRANTOPT TempOpt ;
	memcpy( &TempOpt, &warOpt, sizeof(WARRANTOPT) ) ;
	TempOpt.T_t = TempOpt.T_t-1.0/365.0 ;   //ben 2017.6.29   5.0��Ϊ1.0  ����������
	echoInfo.TimeDecay = 0.0 ;
	if( TempOpt.T_t>0.0 )
	{
		BSMCALINFO TempInfo ;
		if( CalMOP_ByBM1976( TempOpt, TempInfo )==TRUE && echoInfo.theta!=0.0 )//doubleֵ�� != �Ƚϲ��ð�
		{
			echoInfo.TimeDecay = (TempInfo.theta/echoInfo.theta)*100.0 - 100.0 ;
		}
	}

	return TRUE ;

}

BOOL CBM1976Wrapper::CalIV_BySection( WARRANTOPT& warOpt, BSMCALINFO& echoInfo ) 
{
	int count = 1 ;
//	double dtMin = 0.0 ;
//	double dtMax = 2.0 ; 
//	double dtAvg = 0.0 ;
	int i = 0 ;
	int outside = 0;
	echoInfo.impliedVolitility = 1.0 ;
	do
	{
//		dtAvg = (dtMin+dtMax)/2 ;
//		warOpt.sd = dtAvg ;
		warOpt.sd = echoInfo.impliedVolitility;
		if( CalMOP_ByBM1976( warOpt, echoInfo )==FALSE )
		{
			memset( &echoInfo, 0, sizeof(echoInfo) ) ;
			return FALSE ;
		}

		// ��� iv<=0.0 || iv>=2.0, ������, û������.  20170807 ben ��Ϊ>=3.0
		if( echoInfo.impliedVolitility<=0.0f || echoInfo.impliedVolitility>=3.0f )
		{
			outside++;
			if( outside>1 )
			{
				memset( &echoInfo, 0, sizeof(echoInfo) ) ;
				return FALSE ;
			}
		}

	//	TRACE( "count:%d, min:%.8f, max:%.8f, MOP:%.8f\r\n", count, dtMin, dtMax, echoInfo.modelledOptionPrice ) ;
		count++ ;
	/*	if( echoInfo.modelledOptionPrice<warOpt.warrantPrice )
		{
			dtMin = dtAvg ;
		}
		else
		{
			dtMax = dtAvg ;
		}*/

		if( fabs(echoInfo.modelledOptionPrice-warOpt.warrantPrice)<=0.00005 )
			break ;
	//	if( (dtMax-dtMin)<=0.00001 )
	//		break ;

		i++ ;
	}while( i<50 ) ;

	/*
		���һ��, Ҫ���� ������ֵ.
	*/
	WARRANTOPT TempOpt ;
	memcpy( &TempOpt, &warOpt, sizeof(WARRANTOPT) ) ;
	TempOpt.T_t = TempOpt.T_t-1.0/365.0 ;  //ben 2017.6.29   5.0��Ϊ1.0  ����������
	echoInfo.TimeDecay = 0.0 ;
	if( TempOpt.T_t>0.0 )
	{
	//	TempOpt.sd = dtAvg ;
		TempOpt.sd = warOpt.sd ;
		BSMCALINFO TempInfo ;
		if( CalMOP_ByBM1976( TempOpt, TempInfo )==TRUE && echoInfo.theta!=0.0 )
		{
			echoInfo.TimeDecay = (TempInfo.theta/echoInfo.theta)*100.0 - 100.0 ;
		}

	}

	echoInfo.impliedVolitility = warOpt.sd;
	
//	echoInfo.impliedVolitility = dtAvg ;
	return TRUE ;

}