#if !defined(AFX_STRATEGY_H__99FA58AB_9A75_4EBE_B3EE_713721F4B13A__INCLUDED_)
#define AFX_STRATEGY_H__99FA58AB_9A75_4EBE_B3EE_713721F4B13A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Strategy.h : header file
//
#include "TTOptions.h"
#include "resource.h"
#include "Target.h"
//#include "MyList.h"
/////////////////////////////////////////////////////////////////////////////
// CStrategy dialog

typedef CArray< float, float& > CArrayFloat;

#define MACRO_MsgRedrawER    2088
#define MACRO_MsgRedrawDiagonal   2089

class CTTOptions ;
class CbtnInList;
class CMyEdit;
class CMySpinCtrl;
class CMyComBo;
class CStrategy : public CDialog
{
// Construction
public:
	CStrategy(CWnd* pParent = NULL);   // standard constructor
	~CStrategy() ;
	CTTOptions* m_TTOptions;
	CbtnInList* m_pBtn;
	CMyEdit*    m_editCrt;
	CMySpinCtrl*	m_pSpin;     //��һ��������spin
	CMySpinCtrl*	m_pSpinEx[5];//�Զ�����Ժ�������������spin
	CMyComBo*		m_pCombo;    
	CMySpinCtrl*	m_pSpin_C;   //��������spin

	CTarget			m_TargetDlg;

	StgyHistoryList m_StgyList;
	StgyFileExtList m_ExtList;
	CITCArray       m_arrITC;
	Calend          m_cald;
	float			m_fStrike2_Spread;

	CRITICAL_SECTION  m_cs;

	CPoint	m_point;
	CRect   m_Rect;
	
	CFont   m_font1;
	CFont   m_font2;
	CFont   m_font3;
	CFont   m_font4;
	CFont   m_font5;
	CFont   m_font6;
	CBrush m_bsh1,m_bsh2,m_bsh3,m_bsh4,m_bsh5;

	CRect   m_rect1;
	CRect   m_rect2;
	CRect   m_rect3;  //��¼����Ҫ�ƶ��Ŀؼ�λ��
	CRect   m_rect4;
	CRect   m_rect5;
	CRect   m_WinRect;
	CRect   m_TabRect;
	CRect   m_TabClientRect;
	CRect   m_frmrect;
	CRect   m_RectLst1;
	CRect   m_RectLst2;
	CRect   m_RectEd2;
	CRect   m_RectEd3;
// Dialog Data
	//{{AFX_DATA(CStrategy)
	enum { IDD = IDD_STRATEGY };
	CButton	m_btnMode;
	CButton	m_light;
	CEdit	m_edit3;
	CEdit	m_edit2;
	CListCtrl	m_list2;
	CButton	m_btnJianc;
	CTabCtrl	m_tab1;
	CEdit	m_edit;
	CEdit	m_editIV3;
	CEdit	m_editIV2;
	CEdit	m_editIV1;
	CButton	m_BtnSave;
	CListCtrl	m_list;
	CButton	m_ck3;
	CButton	m_ck2;
	CButton	m_ck1;
	CButton	m_SelBox;
	CButton	m_BtnR;
	CButton	m_BtnL;
	CStatic	m_staDay3;
	CStatic	m_staDay2;
	CStatic	m_staDay1;
	CStatic	m_staPrice4;
	CStatic	m_staCost4;
	CStatic	m_CrlStatic4;
	CComboBox	m_ComBoxStrike4;
	CStatic	m_staPL4;
	CStatic	m_staPL3;
	CStatic	m_staPL2;
	CStatic	m_staPL1;
	CButton	m_btnRefresh;
	CComboBox	m_CMBTime;
	CStatic	m_staPrice3;
	CStatic	m_staPrice2;
	CStatic	m_staPrice1;
	CStatic	m_staCost3;
	CStatic	m_staCost2;
	CStatic	m_staCost1;
	CStatic	m_staSize;
	CComboBox	m_CMBIVData;
	CComboBox	m_ComBoxStrike3;
	CComboBox	m_ComBoxStrike2;
	CStatic	m_CrlStatic3;
	CStatic	m_CrlStatic2;
	CStatic	m_CrlStatic1;
	CComboBox	m_ComBoxStrike;
	CButton	m_frame;
	CComboBox	m_ComBoxType;
	//}}AFX_DATA

	int     m_nRetn;
	BYTE    m_bMode;
	BYTE    m_bTempMode;
	int     m_iCheck[3];
	BOOL    m_bShowTip;
	int     m_nPos;
	int     m_nPrePos;
	int     m_nCkCount;
	BOOL    m_bResetBF[3];
	int     m_iOdr;
	int     m_nOrderCount;
	short   m_nCustomCount[6];
	BYTE    m_nCustomIx[6];
	
	BOOL    m_bOrder;
	BOOL    m_bAlterPrice[6];
	BOOL    m_bAlterPrice2[6];
	BOOL    m_bPrice[6];   //order���Ƿ��гɼ�
	BOOL    m_bTransColor; //�Ƿ���Ҫתӯ����ɫ
	BOOL    m_bBtnDown[2];

	int     m_iSort[6];
	float   m_fLPrice[6];
	float   m_fTheoIV;
	float   m_fStock_C;  //Sell Stock�ɱ�ϵ��

	int     m_nIx1,m_nIx2,m_nIx3,m_nIx4;//m_nIxStrike�ĸ���

	CArrayInt  m_arrInt;
	CNumArray  m_arrNum;
	float m_fiSignPrice[6];
	int iSign, iSign1, iSign2, iSign3, iSign4,iSign5,iSign6;
	float principal;
//	float m_fEliminate;  //��Ҫ�޳��ĳɱ�
	double Gain,Loss;  //1.0��ʾ����
	//ӯ���ļ�Ȩƽ��ֵ
	float m_fWeig_Gain;
	float m_fWeig_Loss;

	float   m_fScale;
	float   m_fLimitScale;
	float   m_iYK;
	BOOL    m_bUseRecord;

	BOOL    m_bFillList;
	BOOL    m_bPainted;
	BOOL    m_bReLoadList2Data;
	BOOL    m_bDbClick;

	CDC MemDC;
	CBitmap MemBitmap;
	CDC *pdc;

	

	int     m_nIxStrike;
	int     m_nIxStrike2;
	int     m_nIxStrike3;
	int     m_nIxStrike4;
	int     m_nIxStrike5;
	int     m_nIxStrike6;

	int		m_nIndex;
	int		m_nIndexIV;
	int	    m_lShares;
	CBrush  m_brush;
	CBrush  m_brush1;
	int     m_iSeconds;
	int     m_iDbClickInx;

	int     m_nDay1;
	int     m_nDay2;
	int     m_nDay3;

	int     m_nRow;
	int     m_RecordInx;

	CArrayItem  m_arrItem;
	CArrayFloat m_arrPL[5];
	CArrayFloat m_arrBrkValue;
	CArrayFloat m_arrBrkPB;  
	float       m_fIVedit;
	float       m_fStgyPB;
	int			m_InvestDays;  //Ͷ�ʵ�����
	float		m_ExpValue;    //����ʱ��Ԥ�ڻر�
	float		m_ExpValueS;
	float       m_fHStgyPB;    //����ʱ����ϻ���
	BYTE		m_bYte;        //�Ƿ񱣴���m_fHStgyPB
	BYTE		m_bTarget;
	float       m_fCapital;    //����ʱ�ĳɱ�
	float       m_fCapitalS;
	float		m_fTargetLo;
	float		m_fTargetUp;
	float       m_ER;
	float       m_PP;
	BYTE        m_bWeekly;
	BOOL        m_bItemCodeChange;

	int			m_cx_TgtLo;
	int			m_cx_TgtUp;
	BYTE		m_btMouseGet;
	BYTE		m_btMouseRelease;
	BOOL        m_bSelectLo;
	BOOL		m_bSelectUp;
	HCURSOR     m_hCursor;
	StgyFileExt m_ExtRecord;

	BSMCALINFO  m_cald_calinfo1;
	BSMCALINFO  m_cald_calinfo2;
	
	float linear_equation(BOOL bBuy,BOOL bCall,float fStrike,float fXData);
	BYTE CheckData();
	void GetMargin(float fStrike,long lDate,int &iCallMar,int &iPutMar);
	CString GetMonthString(long ldate);
	void CalendarRequest();
	void AdjustWindowH_Order();
	void AdjustColumnWidth();
	void Trans_Y_axis(CArrayFloat &floarr,CStringArray &strarr);
	void ReadStgyHistoryFile();
	void SaveStgyHistoryFile();
	void LoadData();
	BOOL PairString(StgyHistoryFile stgyfile, Calend cald,CStringArray &arr, int nPos=-1,BYTE bWeekly=0);
	//��������ʹ�۵����ۼ۸�
	float ModelPrice_Stgy(BOOL bCall,StgyHistoryFile stgyfile,LastPrice lastp);
	float ModelPrice_Clad(BOOL bCall,double dStrike, double dMaket, int iExpDay, BYTE bPos=0);
	void ClearFlag();
	void FindStrikeIx(StgyHistoryFile stgyfile);
	float GetCustomStgy(float fValue);
	float Get_Fx_y(CArrayFloat &arrPL,float xValue);
	float GetExpectReturn();
	void  GetCustomBreak( CArrayFloat &arrflo );
	void SortStrikeIx();
	int GetCustomPriceAndType(int iIx, int iSign,float &fPrice);
	void GetBrkProb();
	void UpdateYK();
	float GetMonthPrice(long lDate);
	
	void InitTargetRange();

	void OnModeStgy();
	void OnModePain();
	void CreateBtn();
	void CreateEdt( NM_LISTVIEW  *pEditCtrl, CMyEdit *createdit, int &Item, int &SubItem, BOOL &havecreat ); 
	void DestroyEdit(CListCtrl *list,CMyEdit* distroyedit, int &Item, int &SubItem, BOOL &havecreat);
	void CreateSpin( CListCtrl *list, CMySpinCtrl *creatspin, int Item, int SubItem, BOOL &havecreat ); 
	void DestroySpin(CMySpinCtrl* distroyspin,  BOOL &havecreat);
	void CreateCombo(NM_LISTVIEW *list,CMyComBo *combo,int &Item,int &SubItem,BOOL &havecreat);
	void DestroyCombo( CListCtrl *list, CMyComBo *combo,BOOL &havecreat );
	int  m_nItem;
	int  m_nSubItem;
	BOOL m_bHaveCrt;
	BOOL m_bDrawing;

	int  m_ComboItem;
	int  m_ComboSubItem;
	BOOL m_bCrtCombo;
	BOOL m_bHaveCrt_Spin;
	BOOL m_bHaveCrt_Spin_C;

	unsigned int m_iCaldInx1;
	unsigned int m_iCaldInx2;
	unsigned long m_lCaldExpDate1;
	unsigned long m_lCaldExpDate2;
	int  m_iExpDays;
	short	m_iLangType	;

	void GetCaldInx();
	double CalcExpectReturn(CArrayFloat &arrPL);
	double Calc_ER_Target(CArrayFloat &arrPL,float fLow,float fUp);
	void InitGDI();
	void InitDays();
	void SelectType();
	int  PrePaint();
	void SufPaint();
	int  DrawIncomeLine();
	float CalcStock(float fValue);
	int  GetPriceTxt(float fo, CString &strprice,int flag=0);
	void SwitchCtrl();
	void SetLang();
	int  CalcPainValue();
	int  CalcPrecis(float &iYmax, float &iYmin, float &dea);
	BOOL  IsIndex();
	BOOL  IsIndex_Ext(char *code);
	double GetStockBF();//��Ʊ�Ĳ���ָ��  ��ָ����ָ����VHSI
	BOOL GetTextGK(LPTSTR pszText, float fValue, BYTE cbDecimal);
	float UnitPrice(float fPrice,int iSign, BOOL bCall);

	void  OnBtnLR();
	void  SetListMode();
//	void  Fy_x(float &arrfo, CArrayFloat &arrPL, float x);          //������f(x)
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStrategy)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual BOOL OnEraseBkgnd(CDC* pDC);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	

	// Generated message map functions
	//{{AFX_MSG(CStrategy)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnSelchangeComboType();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSelchangeComboStrike();
	afx_msg void OnSelchangeComboStrike2();
	afx_msg void OnSelchangeComboStrike3();
	afx_msg void OnSelchangeIvdata();
	afx_msg void OnRefresh();
	afx_msg void OnSelchangeCmbtime();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBtnMode();
	afx_msg void OnSelchangeComboStrike4();
	afx_msg void OnDestroy();
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomDraw1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin3(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnBtnR();
	afx_msg void OnBtnL();
	afx_msg void OnCheck1();
	afx_msg void OnCheck2();
	afx_msg void OnCheck3();
	afx_msg void OnBtnSave();
	afx_msg void OnPl();
	afx_msg void OnDe();
	afx_msg void OnVe();
	afx_msg void OnGa();
	afx_msg void OnTh();
	afx_msg void OnCb();
	afx_msg void OnCa();
	afx_msg void OnPb();
	afx_msg void OnPa();
	afx_msg void OnCl();
	afx_msg void OnPla();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnDeltaposSpin4(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin5(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin6(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSetfocusEditIv1();
	afx_msg void OnSetfocusEditIv2();
	afx_msg void OnSetfocusEditIv3();
	afx_msg void OnBtnCk();
	afx_msg void OnClickList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMove(int x, int y);
	afx_msg void OnKillfocusEditIv1();
	afx_msg void OnKillfocusEditIv2();
	afx_msg void OnKillfocusEditIv3();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnClose();
	afx_msg void OnTarget();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnRclickList2(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg LRESULT OnMyRedrawER(WPARAM, LPARAM);
	afx_msg LRESULT OnMyRedrawDiagonal(WPARAM, LPARAM);
	DECLARE_MESSAGE_MAP()
	
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STRATEGY_H__99FA58AB_9A75_4EBE_B3EE_713721F4B13A__INCLUDED_)
