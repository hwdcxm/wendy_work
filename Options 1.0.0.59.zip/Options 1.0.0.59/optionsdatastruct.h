#define G_TXTOCCFILEID         0xFF70         
#define G_GENCODELEN           8             /* File name length */
#define TT_OP_ITEMNUM			6

#define G_FRMSPECTRANSCODE     5

#define	G_GENCODELEN           8

/*****************�ػ�����ǰ���б��±�ֵ***************************************
#define POS_CALL_OI				0
#define POS_PUT_OI				20
#define POS_CALL_HIGH			2
#define POS_PUT_HIGH			17
#define POS_CALL_LOW			3
#define POS_PUT_LOW				18
#define POS_CALL_VOL			1
#define POS_PUT_VOL				19
#define POS_CALL_ASK			8	
#define POS_PUT_ASK				13
#define POS_CALL_BID			7
#define POS_PUT_BID				12
#define POS_CALL_LAST			4
#define POS_PUT_LAST			15
#define POS_STRIKE				10
#define POS_CALL_LASTQ			5
#define POS_PUT_LASTQ			16
#define POS_CALL_BIDQ			6
#define POS_PUT_BIDQ			11
#define POS_CALL_ASKQ			9
#define POS_PUT_ASKQ			14

//********************************************************/



/////////////////////�ػ���������б��±�ֵ//////////////////////////////////
#define POS_CALL_OI				0
#define POS_PUT_OI				20

#define POS_CALL_HIGH			1
#define POS_PUT_HIGH			18

#define POS_CALL_LOW			2
#define POS_PUT_LOW				19

#define POS_CALL_BIDQ			6
#define POS_PUT_BIDQ			11

#define POS_CALL_BID			7
#define POS_PUT_BID				12

#define POS_CALL_ASK			8	
#define POS_PUT_ASK				13

#define POS_CALL_ASKQ			9
#define POS_PUT_ASKQ			14

#define POS_CALL_VOL			3
#define POS_PUT_VOL				17

#define POS_CALL_LASTQ			4
#define POS_PUT_LASTQ			16

#define POS_CALL_LAST			5
#define POS_PUT_LAST			15

#define POS_STRIKE				10
//////////////////////////////////////////////////////////////////////////////


#define G_TXTFCODELEN          6             /* Length of cash item code in futures item code */
#define G_TXTOPTASK            0             /* Index to any 'askbid[2]' structure - this holds ask */
#define G_TXTOPTBID            1             /* Index to any 'askbid[2]' structure - this holds bid */
#define G_TXTOPTHLLO           0             /* Lowest price (index to g_txtoptcpS.hilo[]) */
#define G_TXTOPTHLHI           1             /* Highest price (index to g_txtoptcpS.hilo[]) */
#define G_TXTMAXOPTITEM        9             /* Maximum no. of options items less 1 */
#define G_TXTNUMOPTITEM        (G_TXTMAXOPTITEM + 1)
#define G_TXTMAXOPTMONTH       9             /* Maximum no. of options months less 1 */
#define G_TXTNUMOPTMONTH       (G_TXTMAXOPTMONTH + 1)
#define G_TXTMAXOPTSTRIKE      39            /* Maximum no. of options strike prices less 1 */
#define G_TXTNUMOPTSTRIKE      (G_TXTMAXOPTSTRIKE + 1)

#define OPTTXTYASK              0        /* Options trans. and special types - see 'frame3.des' */
#define OPTTXTYBID              1
#define OPTTXTYLAST             2
#define OPTTXTYHIGH             3
#define OPTTXTYLOW              4
#define OPTTXTYSUMMARY          50
#define OPTTXTYCORLAST          60
#define OPTTXTYCORVOL           61
#define OPTTXTYDELSTRIKE        62
#define OPTTXTYDELMONTH         63
#define OPTSPTYMASKCALLPUT      0x01
#define OPTSPTYMASKTHEORET      0x02
#define OPTSPTYMASKCABINET      0x04
#define OPTSPTYMASKDECIMAL      0x18

// Options
#define DE_FILEID			"OptionsExpiryDateFile"		//file id
// Strategy
#define STGY_FILEID         "StrategyHistoryFile"
#define STGY_FILEID2	    "StrategyHistoryFile2"

#define STGY_CUSTOM         19

#define TT_OPT_CODELEN			(6)
#define TT_OPT_NUMSTRIKEPRICE		(40)
#define G_TXTFCODELEN          6		/* Length of cash item code in futures item code */
#define	MAXPATH				(64)
#pragma pack(1)

typedef struct                               /* Options call/put details */
{
 unsigned theoretask:1;                      /* TRUE-Theoretical ask, FALSE-Actual ask */
 unsigned theoretbid:1;                      /* TRUE-Theoretical bid, FALSE-Actual bid */
 unsigned cabinetbid:1;                      /* TRUE-Cabinet bid */
 unsigned cabinetlast:1;                     /* TRUE-Cabinet last */
 unsigned reserved:4;                        /* Reserved - to make no. of bits a multiple of 8 */
 char reserve1;
 float ab[2],                                /* Ask/bid */
       last,                                 /* Last */
       vol,                                  /* Volume */
       oab[2],                               /* Opening ask/bid */
       olast,                                /* Opening last */
       hilo[2],                              /* Low/high */
       cuvol,                                /* Cumulative volume (total no. of contracts traded) */
       oi,                                   /* Open interest */
       ptover;                               /* Previous turnover */
 char reserve2[10];
} g_txtoptcpS;

typedef struct                               /* Options strike price details */
{
 float strikeprice;                          /* Strike price */
 char reserve1[4];
 g_txtoptcpS cp[2];                          /* Call/put details */
} g_txtoptstS;

typedef struct                               /* Options month details */
{
 long mth;                                   /* Trading month - yyyymm */
 char futcode[G_GENCODELEN];                 /* Corr. futures item code */
 int futhashval;                             /* Futures hash value (index to g_grptempS[]); -1=None */
 char reserve1[22];
 unsigned stsorted:1;                        /* TRUE-The strike price details are sorted in ascending order of strike price */
 unsigned decimal:2;                         /* No. of decimal points for this strike price, bid and ask values */
 unsigned reserved:5;                        /* Reserved - to make no. of bits a multiple of 8 */
 char reserve2[90];
 g_txtoptstS st[G_TXTNUMOPTSTRIKE];          /* Strike price details */
} g_txtoptmmS;

typedef struct                               /* Options pages - data from HKFE */
{
 char groupcode;                             /* Group code; as defined in g_grpgpS */
 char itemcode[G_GENCODELEN];                /* Corr. cash item code */
 int itemhashval;                            /* Cash hash value (index to g_grptempS[]); -1=None */
 char fcode[G_TXTFCODELEN];                  /* Cash item code used in futures item code; NULL-terminated without trailing spaces */
 char reserve1[16];
 unsigned mmsorted:1;                        /* TRUE-The month details are sorted in ascending order of yyyymm */
 unsigned reserved:7;                        /* Reserved - to make no. of bits a multiple of 8 */
 char reserve2[93];
 g_txtoptmmS mm[G_TXTNUMOPTMONTH];           /* Month details */
} g_txtoptS;
//OCC FILE STRUCT
typedef struct                  /* Option cash itrem codes file header */
{
	WORD id;			        /* G_TXTOCCFILEID */
	BYTE reserved;              /* Reserved - 0x1A */
	WORD numitem;               /* No. of cash item codes */
	BYTE unused[27];
} g_txtoccheadS;


typedef struct                  /*Option cash item codes file detail */
{
	BYTE groupcode;                             /* Group code; as defined in g_grpgpS */
	BYTE itemcode[G_GENCODELEN+1];              /* Item code - for display only */
	BYTE fcode[G_TXTFCODELEN];                  /* Cash item code used in futures item code; NULL-terminated without trailing spaces */
	//BYTE unused[16];   
	BYTE cashitemcode[G_GENCODELEN+1];            /* Cash item code */   //andy modify 2009.06.04 �����������Ͻǵ��ֻ�����,����MHI�����������HSI
	BYTE optcode[5];
	BYTE unused[2];		
} g_txtoccS;

typedef CArray<g_txtoccS,g_txtoccS&> OccList;

typedef struct
{
	unsigned char cbGroupCode;
	char          szItemCode[G_GENCODELEN];
	long		  lTransdate;
	float         fStrikePrice;
	unsigned char cbOrder;
} FrameID;
typedef struct
{
	unsigned char cbGroupCode;
	char          szItemCode[G_GENCODELEN];
} DSFrameID;
typedef struct
{	
	unsigned short wFrameType;
} FrameHead;

typedef unsigned short FrameLen;

typedef unsigned short ElementType;

//andy add 2012.02.23 add for ExpryDate
typedef struct
{	
	long lMonth;		//YYYYMM
	long lExpiryDate;   //YYYYMMDD

} OptionsExpiryDate;

typedef struct
{	
	char			szItemCode[8];		//��Ʊ��         
	int				nMonthCount;		//month������    
	char			cGroup;				//�� A/B/C ����  
	long			m_lShares;          //����
	char			m_szReserve[47];	//               
} OptionsExpiryDateItem;

typedef struct
{	
	char			m_szFileID[32] ;	//�ļ�ID    "OptionsExpiryDateFile"	
	char			m_szVersion[32];	//�汾��   
	unsigned short	m_LenOfHeader ;		//ͷ������  
	int				m_nItemCount;		//item�ĸ���   
	float			m_fInterestRate;    //��ȫ����     
	long			m_LastModifiedDate;	//            
	unsigned short	m_LastModifiedTime; //				
	char			m_szReserve[78] ;

} OptionsExpiryDateFileHead;


typedef CArray<OptionsExpiryDate,OptionsExpiryDate &> ExpiryDateList;

struct	OptionsExpiryDateInfo
{

	CString	ItemCode;	//Group+Item "A00700   "		
	ExpiryDateList expList;

	const void operator=(const OptionsExpiryDateInfo & Data)
	{
		ItemCode = Data.ItemCode;
		expList.Copy(Data.expList);
	}	
};

struct OptPreOI
{
	float m_fStrike;
	float m_fPre_CallOI;
	float m_fPre_PutOI;
};
typedef CArray<OptPreOI,OptPreOI &> CPreOIArray;

struct OptionsItemShares
{
	CString ItemCode;
	long    Shares;
};

typedef	CMap<CString,LPCSTR,OptionsExpiryDateInfo,OptionsExpiryDateInfo&> OptionsExpiryDateMap;

typedef	CMap<CString,LPCSTR,OptionsItemShares,OptionsItemShares&> OptionsItemSharesMap;

typedef struct
{
	char	m_szfcode[5];
	long	m_lTransdate[5];
	float   m_fStrike;
	int     m_iCall_Margin[5];
	int     m_iPut_Margin[5];
	char    m_szRes[20];
}Margin;
typedef CArray<Margin,Margin &> MarginArray;

typedef struct
{
	float fStrike;
	BYTE  bDebit; //Debit or Credit
	BYTE  bCall; //Call or Put
	long  lMonth1;
	long  lMonth2;
}Calend;

typedef struct 
{
	char  m_szCode[9];
	long  m_lDate;
	int   m_iTime;
	//int   m_iStgyIx; //�������   ��Ϊ�浽m_iCustomIx[7]
	int   m_fCapital;
//	long  m_lExpDays;
	float m_fPB;

	long  m_lExpTime;
	float m_fStrike[4];  //Ԥ��4����ʹ��
	float m_fPrice[4];
	int   m_lShares;  //ÿ����Ŀ
	int   m_nCount;   //����

	BYTE  m_iCustomIx[8];
	short m_iCustomCount[6];
	float m_fStrikeEx[2]; //��չ2����ʹ��
	float m_fPriceEx[2];
	float m_ExpValue;
	//char  m_szReserve[4];
}StgyHistoryFile;

typedef struct
{
	double d_ER;
	float  f_PP;
	float  f_Lo;
	float  f_Up;
	BYTE   b_RNG;    //save�Ƿ��������ER-PP
	BYTE   b_weekly;  //weekly option?  ��ͬ�·ݵ�ʱ���ʾ��һ���·���weekly
	Calend cald;
	float  m_fStrike2_Spread;
	BYTE   b_Mth2_Weekly;  //��ͬ�·ݵĵڶ������Ƿ�weekly
	char   m_szReserve[51];
}StgyFileExt;

typedef CArray<StgyHistoryFile,StgyHistoryFile &> StgyHistoryList;
typedef CArray<StgyFileExt,StgyFileExt &> StgyFileExtList;

typedef struct
{
	int  nItem;
	BOOL bPrice;
}ItemNum;

typedef CArray<ItemNum, ItemNum&> CNumArray;

typedef struct
{
	float fStrike;
	float fCall;
	float fPut;
}LastPrice;

typedef struct
{
	char szCode[8];
	long lDate;
}CodeDate;

typedef struct
{
	char szCode[8];
	float fCash;
}CodeCash;

typedef struct
{
	char itemcode[8];
	long ldate;
	char cashcode[8];
}ItemToCash;

typedef CArray<LastPrice, LastPrice&> CLPArray;
typedef CArray<CodeDate, CodeDate&> CCDArray;
typedef CArray<CodeCash, CodeCash&> CCashArray;
typedef CArray<ItemToCash, ItemToCash&> CITCArray;

typedef CArray<int, int&> CArrayInt;


/*
extern char *szType[3];
extern char *szSize[3];
extern char *szRefresh[3];
extern char *szManual[3];
extern char *szStrike[3];
extern char *szDescrip[3];
extern char *szBidAsk[3];
extern char *szPreMium[3];
extern char *szMaxGain[3];
extern char *szMaxLoss[3];
extern char *szBreak[3];
extern char *szMode0[3]; 
extern char *szMode1[3]; 

*/

#pragma pack(8)

