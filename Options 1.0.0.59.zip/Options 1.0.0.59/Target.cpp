// Target.cpp : implementation file
//

#include "stdafx.h"
#include "options.h"
#include "Target.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTarget dialog


CTarget::CTarget(CWnd* pParent /*=NULL*/)
	: CDialog(CTarget::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTarget)
	m_fLo = 0.0f;
	m_fUp = 0.0f;
	//}}AFX_DATA_INIT
}


void CTarget::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTarget)
	DDX_Text(pDX, IDC_EDIT_LOW, m_fLo);
	DDX_Text(pDX, IDC_EDIT_UP, m_fUp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTarget, CDialog)
	//{{AFX_MSG_MAP(CTarget)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTarget message handlers

BOOL CTarget::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTarget::OnOK() 
{
	// TODO: Add extra validation here
	float fLo,fUp;
	fLo = m_fLo;
	fUp = m_fUp;
	UpdateData(TRUE);
	CDialog::OnOK();
}
